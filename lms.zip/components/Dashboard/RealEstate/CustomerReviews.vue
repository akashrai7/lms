<template>
  <div class="card bg-white border-0 rounded-3 mb-4">
    <div class="card-body p-4">
      <div
        class="d-flex justify-content-between align-items-center flex-wrap gap-3 mb-3 mb-lg-4"
      >
        <h3 class="mb-0">Customer Reviews</h3>

        <div class="dropdown action-opt">
          <button
            class="btn bg-transparent p-0"
            type="button"
            data-bs-toggle="dropdown"
            aria-expanded="false"
          >
            <i data-feather="more-horizontal"></i>
          </button>
          <ul
            class="dropdown-menu dropdown-menu-end bg-white border box-shadow"
          >
            <li>
              <a class="dropdown-item" href="javascript:;">
                <i data-feather="clock"></i>
                Today
              </a>
            </li>
            <li>
              <a class="dropdown-item" href="javascript:;">
                <i data-feather="pie-chart"></i>
                Last 7 Days
              </a>
            </li>
            <li>
              <a class="dropdown-item" href="javascript:;">
                <i data-feather="rotate-cw"></i>
                Last Month
              </a>
            </li>
            <li>
              <a class="dropdown-item" href="javascript:;">
                <i data-feather="calendar"></i>
                Last 1 Year
              </a>
            </li>
            <li>
              <a class="dropdown-item" href="javascript:;">
                <i data-feather="bar-chart"></i>
                All Time
              </a>
            </li>
            <li>
              <a class="dropdown-item" href="javascript:;">
                <i data-feather="eye"></i>
                View
              </a>
            </li>
            <li>
              <a class="dropdown-item" href="javascript:;">
                <i data-feather="trash"></i>
                Delete
              </a>
            </li>
          </ul>
        </div>
      </div>

      <div class="mb-4">
        <div class="d-flex align-items-center mb-2">
          <div class="flex-shrink-0">
            <img
              src="~/assets/images/user-48.jpg"
              class="rounded-circle"
              style="width: 40px; height: 40px"
              alt="user"
            />
          </div>
          <div class="flex-grow-1 ms-2">
            <div class="d-flex flex-wrap gap-2 justify-content-between">
              <div>
                <h4 class="fs-15 mb-0 fw-semibold">Irene George</h4>
                <span class="fs-12">15m ago</span>
              </div>
              <div class="d-flex gap-1">
                <i class="ri-star-line text-warning fs-16"></i>
                <i class="ri-star-line text-warning fs-16"></i>
                <i class="ri-star-line text-warning fs-16"></i>
                <i class="ri-star-line text-warning fs-16"></i>
                <i class="ri-star-line text-warning fs-16"></i>
              </div>
            </div>
          </div>
        </div>
        <p class="fs-12" style="line-height: 1.4">
          "Great service! Found exactly what I needed for my property, and the
          process was smooth and hassle-free."
        </p>
      </div>
      <div class="mb-4">
        <div class="d-flex align-items-center mb-2">
          <div class="flex-shrink-0">
            <img
              src="~/assets/images/user-49.jpg"
              class="rounded-circle"
              style="width: 40px; height: 40px"
              alt="user"
            />
          </div>
          <div class="flex-grow-1 ms-2">
            <div class="d-flex flex-wrap gap-2 justify-content-between">
              <div>
                <h4 class="fs-15 mb-0 fw-semibold">Irene George</h4>
                <span class="fs-12">15m ago</span>
              </div>
              <div class="d-flex gap-1">
                <i class="ri-star-line text-warning fs-16"></i>
                <i class="ri-star-line text-warning fs-16"></i>
                <i class="ri-star-line text-warning fs-16"></i>
                <i class="ri-star-line text-warning fs-16"></i>
                <i class="ri-star-line text-warning fs-16"></i>
              </div>
            </div>
          </div>
        </div>
        <p class="fs-12" style="line-height: 1.4">
          "Great service! Found exactly what I needed for my property, and the
          process was smooth and hassle-free."
        </p>
      </div>
      <div class="mb-4">
        <div class="d-flex align-items-center mb-2">
          <div class="flex-shrink-0">
            <img
              src="~/assets/images/user-50.jpg"
              class="rounded-circle"
              style="width: 40px; height: 40px"
              alt="user"
            />
          </div>
          <div class="flex-grow-1 ms-2">
            <div class="d-flex flex-wrap gap-2 justify-content-between">
              <div>
                <h4 class="fs-15 mb-0 fw-semibold">Irene George</h4>
                <span class="fs-12">15m ago</span>
              </div>
              <div class="d-flex gap-1">
                <i class="ri-star-line text-warning fs-16"></i>
                <i class="ri-star-line text-warning fs-16"></i>
                <i class="ri-star-line text-warning fs-16"></i>
                <i class="ri-star-line text-warning fs-16"></i>
                <i class="ri-star-line text-warning fs-16"></i>
              </div>
            </div>
          </div>
        </div>
        <p class="fs-12" style="line-height: 1.4">
          "Great service! Found exactly what I needed for my property, and the
          process was smooth and hassle-free."
        </p>
      </div>
      <div class="mb-4">
        <div class="d-flex align-items-center mb-2">
          <div class="flex-shrink-0">
            <img
              src="~/assets/images/user-51.jpg"
              class="rounded-circle"
              style="width: 40px; height: 40px"
              alt="user"
            />
          </div>
          <div class="flex-grow-1 ms-2">
            <div class="d-flex flex-wrap gap-2 justify-content-between">
              <div>
                <h4 class="fs-15 mb-0 fw-semibold">Irene George</h4>
                <span class="fs-12">15m ago</span>
              </div>
              <div class="d-flex gap-1">
                <i class="ri-star-line text-warning fs-16"></i>
                <i class="ri-star-line text-warning fs-16"></i>
                <i class="ri-star-line text-warning fs-16"></i>
                <i class="ri-star-line text-warning fs-16"></i>
                <i class="ri-star-line text-warning fs-16"></i>
              </div>
            </div>
          </div>
        </div>
        <p class="fs-12" style="line-height: 1.4">
          "Great service! Found exactly what I needed for my property, and the
          process was smooth and hassle-free."
        </p>
      </div>
      <div class="mb-4">
        <div class="d-flex align-items-center mb-2">
          <div class="flex-shrink-0">
            <img
              src="~/assets/images/user-52.jpg"
              class="rounded-circle"
              style="width: 40px; height: 40px"
              alt="user"
            />
          </div>
          <div class="flex-grow-1 ms-2">
            <div class="d-flex flex-wrap gap-2 justify-content-between">
              <div>
                <h4 class="fs-15 mb-0 fw-semibold">Irene George</h4>
                <span class="fs-12">15m ago</span>
              </div>
              <div class="d-flex gap-1">
                <i class="ri-star-line text-warning fs-16"></i>
                <i class="ri-star-line text-warning fs-16"></i>
                <i class="ri-star-line text-warning fs-16"></i>
                <i class="ri-star-line text-warning fs-16"></i>
                <i class="ri-star-line text-warning fs-16"></i>
              </div>
            </div>
          </div>
        </div>
        <p class="fs-12" style="line-height: 1.4">
          "Great service! Found exactly what I needed for my property, and the
          process was smooth and hassle-free."
        </p>
      </div>

      <nav aria-label="Page navigation example">
        <ul class="pagination mb-0 justify-content-center">
          <li class="page-item">
            <a class="page-link icon" href="#" aria-label="Previous">
              <i class="material-symbols-outlined">keyboard_arrow_left</i>
            </a>
          </li>
          <li class="page-item">
            <a class="page-link active" href="#">1</a>
          </li>
          <li class="page-item">
            <a class="page-link" href="#">2</a>
          </li>
          <li class="page-item">
            <a class="page-link" href="#">3</a>
          </li>
          <li class="page-item">
            <a class="page-link" href="#">4</a>
          </li>
          <li class="page-item">
            <a class="page-link icon" href="#" aria-label="Next">
              <i class="material-symbols-outlined">keyboard_arrow_right</i>
            </a>
          </li>
        </ul>
      </nav>
    </div>
  </div>
</template>

<script lang="ts">
import { defineComponent } from "vue";

export default defineComponent({
  name: "CustomerReviews",
});
</script>
