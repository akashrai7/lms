<template>
  <form class="src-form position-relative">
    <input type="text" class="form-control" placeholder="Search here....." />
    <button
      type="submit"
      class="src-btn position-absolute top-50 end-0 translate-middle-y bg-transparent p-0 border-0"
    >
      <span class="material-symbols-outlined">search</span>
    </button>
  </form>
</template>

<script>
export default {
  name: "SearchFrom",
};
</script>
