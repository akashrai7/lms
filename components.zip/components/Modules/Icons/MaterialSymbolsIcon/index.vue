<template>
  <div>
    <div class="card bg-white border-0 rounded-3 mb-4">
      <div class="card-body p-4 text-center">
        <pre class="line-numbers pt-0 pb-0 ps-25 pe-25 mb-0">
<code class="language-markup" id="basicAlertsCode">
&lt;span class="material-symbols-outlined"&gt;search&lt;/span&gt;
</code>
</pre>
      </div>
    </div>

    <div class="row">
      <div class="col-lg-2 col-sm-6 col-md-3">
        <div class="card bg-white border-0 rounded-3 mb-4">
          <div class="card-body p-4 text-center">
            <i class="material-symbols-outlined">search</i>
            <span class="d-block mt-4">search</span>
          </div>
        </div>
      </div>
      <div class="col-lg-2 col-sm-6 col-md-3">
        <div class="card bg-white border-0 rounded-3 mb-4">
          <div class="card-body p-4 text-center">
            <i class="material-symbols-outlined">home</i>
            <span class="d-block mt-4">home</span>
          </div>
        </div>
      </div>
      <div class="col-lg-2 col-sm-6 col-md-3">
        <div class="card bg-white border-0 rounded-3 mb-4">
          <div class="card-body p-4 text-center">
            <i class="material-symbols-outlined">menu</i>
            <span class="d-block mt-4">menu</span>
          </div>
        </div>
      </div>
      <div class="col-lg-2 col-sm-6 col-md-3">
        <div class="card bg-white border-0 rounded-3 mb-4">
          <div class="card-body p-4 text-center">
            <i class="material-symbols-outlined">close</i>
            <span class="d-block mt-4">close</span>
          </div>
        </div>
      </div>
      <div class="col-lg-2 col-sm-6 col-md-3">
        <div class="card bg-white border-0 rounded-3 mb-4">
          <div class="card-body p-4 text-center">
            <i class="material-symbols-outlined">settings</i>
            <span class="d-block mt-4">settings</span>
          </div>
        </div>
      </div>
      <div class="col-lg-2 col-sm-6 col-md-3">
        <div class="card bg-white border-0 rounded-3 mb-4">
          <div class="card-body p-4 text-center">
            <i class="material-symbols-outlined">done</i>
            <span class="d-block mt-4">done</span>
          </div>
        </div>
      </div>
      <div class="col-lg-2 col-sm-6 col-md-3">
        <div class="card bg-white border-0 rounded-3 mb-4">
          <div class="card-body p-4 text-center">
            <i class="material-symbols-outlined">expand_more</i>
            <span class="d-block mt-4">expand_more</span>
          </div>
        </div>
      </div>
      <div class="col-lg-2 col-sm-6 col-md-3">
        <div class="card bg-white border-0 rounded-3 mb-4">
          <div class="card-body p-4 text-center">
            <i class="material-symbols-outlined">search</i>
            <span class="d-block mt-4">search</span>
          </div>
        </div>
      </div>
      <div class="col-lg-2 col-sm-6 col-md-3">
        <div class="card bg-white border-0 rounded-3 mb-4">
          <div class="card-body p-4 text-center">
            <i class="material-symbols-outlined">check_circle</i>
            <span class="d-block mt-4">check_circle</span>
          </div>
        </div>
      </div>
      <div class="col-lg-2 col-sm-6 col-md-3">
        <div class="card bg-white border-0 rounded-3 mb-4">
          <div class="card-body p-4 text-center">
            <i class="material-symbols-outlined">favorite</i>
            <span class="d-block mt-4">favorite</span>
          </div>
        </div>
      </div>
      <div class="col-lg-2 col-sm-6 col-md-3">
        <div class="card bg-white border-0 rounded-3 mb-4">
          <div class="card-body p-4 text-center">
            <i class="material-symbols-outlined">add</i>
            <span class="d-block mt-4">add</span>
          </div>
        </div>
      </div>
      <div class="col-lg-2 col-sm-6 col-md-3">
        <div class="card bg-white border-0 rounded-3 mb-4">
          <div class="card-body p-4 text-center">
            <i class="material-symbols-outlined">arrow_back</i>
            <span class="d-block mt-4">arrow_back</span>
          </div>
        </div>
      </div>
      <div class="col-lg-2 col-sm-6 col-md-3">
        <div class="card bg-white border-0 rounded-3 mb-4">
          <div class="card-body p-4 text-center">
            <i class="material-symbols-outlined">star</i>
            <span class="d-block mt-4">star</span>
          </div>
        </div>
      </div>
      <div class="col-lg-2 col-sm-6 col-md-3">
        <div class="card bg-white border-0 rounded-3 mb-4">
          <div class="card-body p-4 text-center">
            <i class="material-symbols-outlined">chevron_right</i>
            <span class="d-block mt-4">chevron_right</span>
          </div>
        </div>
      </div>
      <div class="col-lg-2 col-sm-6 col-md-3">
        <div class="card bg-white border-0 rounded-3 mb-4">
          <div class="card-body p-4 text-center">
            <i class="material-symbols-outlined">logout</i>
            <span class="d-block mt-4">logout</span>
          </div>
        </div>
      </div>
      <div class="col-lg-2 col-sm-6 col-md-3">
        <div class="card bg-white border-0 rounded-3 mb-4">
          <div class="card-body p-4 text-center">
            <i class="material-symbols-outlined">arrow_forward_ios</i>
            <span class="d-block mt-4">arrow_forward_ios</span>
          </div>
        </div>
      </div>
      <div class="col-lg-2 col-sm-6 col-md-3">
        <div class="card bg-white border-0 rounded-3 mb-4">
          <div class="card-body p-4 text-center">
            <i class="material-symbols-outlined">add_circle</i>
            <span class="d-block mt-4">add_circle</span>
          </div>
        </div>
      </div>
      <div class="col-lg-2 col-sm-6 col-md-3">
        <div class="card bg-white border-0 rounded-3 mb-4">
          <div class="card-body p-4 text-center">
            <i class="material-symbols-outlined">cancel</i>
            <span class="d-block mt-4">cancel</span>
          </div>
        </div>
      </div>
      <div class="col-lg-2 col-sm-6 col-md-3">
        <div class="card bg-white border-0 rounded-3 mb-4">
          <div class="card-body p-4 text-center">
            <i class="material-symbols-outlined">arrow_back_ios</i>
            <span class="d-block mt-4">arrow_back_ios</span>
          </div>
        </div>
      </div>
      <div class="col-lg-2 col-sm-6 col-md-3">
        <div class="card bg-white border-0 rounded-3 mb-4">
          <div class="card-body p-4 text-center">
            <i class="material-symbols-outlined">arrow_forward</i>
            <span class="d-block mt-4">arrow_forward</span>
          </div>
        </div>
      </div>
      <div class="col-lg-2 col-sm-6 col-md-3">
        <div class="card bg-white border-0 rounded-3 mb-4">
          <div class="card-body p-4 text-center">
            <i class="material-symbols-outlined">arrow_drop_down</i>
            <span class="d-block mt-4">arrow_drop_down</span>
          </div>
        </div>
      </div>
      <div class="col-lg-2 col-sm-6 col-md-3">
        <div class="card bg-white border-0 rounded-3 mb-4">
          <div class="card-body p-4 text-center">
            <i class="material-symbols-outlined">check</i>
            <span class="d-block mt-4">check</span>
          </div>
        </div>
      </div>
      <div class="col-lg-2 col-sm-6 col-md-3">
        <div class="card bg-white border-0 rounded-3 mb-4">
          <div class="card-body p-4 text-center">
            <i class="material-symbols-outlined">check_box</i>
            <span class="d-block mt-4">check_box</span>
          </div>
        </div>
      </div>
      <div class="col-lg-2 col-sm-6 col-md-3">
        <div class="card bg-white border-0 rounded-3 mb-4">
          <div class="card-body p-4 text-center">
            <i class="material-symbols-outlined">toggle_on</i>
            <span class="d-block mt-4">toggle_on</span>
          </div>
        </div>
      </div>
      <div class="col-lg-2 col-sm-6 col-md-3">
        <div class="card bg-white border-0 rounded-3 mb-4">
          <div class="card-body p-4 text-center">
            <i class="material-symbols-outlined">open_in_new</i>
            <span class="d-block mt-4">open_in_new</span>
          </div>
        </div>
      </div>
      <div class="col-lg-2 col-sm-6 col-md-3">
        <div class="card bg-white border-0 rounded-3 mb-4">
          <div class="card-body p-4 text-center">
            <i class="material-symbols-outlined">grade</i>
            <span class="d-block mt-4">grade</span>
          </div>
        </div>
      </div>
      <div class="col-lg-2 col-sm-6 col-md-3">
        <div class="card bg-white border-0 rounded-3 mb-4">
          <div class="card-body p-4 text-center">
            <i class="material-symbols-outlined">refresh</i>
            <span class="d-block mt-4">refresh</span>
          </div>
        </div>
      </div>
      <div class="col-lg-2 col-sm-6 col-md-3">
        <div class="card bg-white border-0 rounded-3 mb-4">
          <div class="card-body p-4 text-center">
            <i class="material-symbols-outlined">check_box_outline_blank</i>
            <span class="d-block mt-4">check_box_outline_blank</span>
          </div>
        </div>
      </div>
      <div class="col-lg-2 col-sm-6 col-md-3">
        <div class="card bg-white border-0 rounded-3 mb-4">
          <div class="card-body p-4 text-center">
            <i class="material-symbols-outlined">login</i>
            <span class="d-block mt-4">login</span>
          </div>
        </div>
      </div>
      <div class="col-lg-2 col-sm-6 col-md-3">
        <div class="card bg-white border-0 rounded-3 mb-4">
          <div class="card-body p-4 text-center">
            <i class="material-symbols-outlined">chevron_left</i>
            <span class="d-block mt-4">chevron_left</span>
          </div>
        </div>
      </div>
      <div class="col-lg-12 text-center mb-4">
        <a
          href="https://fonts.google.com/icons"
          target="_blank"
          class="btn btn-primary py-2 px-4 text-decoration-none rounded-pill"
        >
          <span class="d-inline-block py-1">View All Icons</span>
        </a>
      </div>
    </div>
  </div>
</template>

<script lang="ts">
import { defineComponent, onMounted } from "vue";
import Prism from "prismjs";
import "prismjs/themes/prism.min.css";

export default defineComponent({
  name: "MaterialSymbolsIcon",
  setup() {
    onMounted(() => {
      Prism.highlightAll();
    });
  },
});
</script>
