<template>
  <div>
    <ModulesExtraPagesTimelineBasicTimeline />

    <ModulesExtraPagesTimelineAdvancedTimeline />
  </div>
</template>

<script lang="ts">
import { defineComponent } from "vue";

export default defineComponent({
  name: "Timeline",
});
</script>
