<template>
  <div class="card bg-white border-0 rounded-3 mb-4">
    <div class="card-body p-4">
      <div class="mb-4">
        <h3 class="mb-0">Advanced Timeline</h3>
      </div>
      <div class="timeline-wrap">
        <div class="timeline-item-2 mb-5">
          <div class="text p-4 rounded-3">
            <h3 class="fs-14 fw-medium text-primary">
              Weekly Stand-Up Meetings:
            </h3>
            <p>
              We continued our weekly stand-up meetings where team members
              provided updates on their current tasks, discussed any roadblocks,
              and coordinated efforts for the week ahead.
            </p>
            <ul class="ps-0 mb-3 list-unstyled d-flex align-items-center">
              <li>
                <NuxtLink to="/my-profile">
                  <img
                    src="~/assets/images/user-16.jpg"
                    class="wh-34 lh-34 rounded-circle border border-1 border-color-white"
                    alt="user"
                  />
                </NuxtLink>
              </li>
              <li class="ms-m-15">
                <NuxtLink to="/my-profile">
                  <img
                    src="~/assets/images/user-17.jpg"
                    class="wh-34 lh-34 rounded-circle border border-1 border-color-white"
                    alt="user"
                  />
                </NuxtLink>
              </li>
              <li class="ms-m-15">
                <NuxtLink to="/my-profile">
                  <img
                    src="~/assets/images/user-18.jpg"
                    class="wh-34 lh-34 rounded-circle border border-1 border-color-white"
                    alt="user"
                  />
                </NuxtLink>
              </li>
              <li class="ms-m-15">
                <NuxtLink to="/my-profile">
                  <img
                    src="~/assets/images/user-19.jpg"
                    class="wh-34 lh-34 rounded-circle border border-1 border-color-white"
                    alt="user"
                  />
                </NuxtLink>
              </li>
              <li class="ms-m-15">
                <NuxtLink
                  to="/users/users-list"
                  class="wh-34 lh-34 rounded-circle bg-primary d-block text-center text-decoration-none text-white fs-12 fw-medium border border-1 border-color-white"
                >
                  +10
                </NuxtLink>
              </li>
            </ul>
            <span class="d-block text-primary"
              ><span class="text-body fw-medium">By:</span> Olivia
              Rodriguez</span
            >
          </div>

          <div class="icon">
            <div></div>
          </div>

          <div class="time">
            <time>12:00 AM, 25 Mar, 2024</time>
          </div>
        </div>

        <div class="timeline-item-2 mb-5">
          <div class="text p-4 rounded-3">
            <h3 class="fs-14 fw-medium text-primary">
              Project Kickoff Session:
            </h3>
            <p>
              Briefly explain the purpose of the kickoff session and its
              importance in setting the project on the right track. Discuss any
              assumptions made about the scope and clarify
            </p>
            <span class="d-block text-primary"
              ><span class="text-body fw-medium">By:</span> Olivia
              Rodriguez</span
            >
          </div>

          <div class="icon two">
            <div></div>
          </div>

          <div class="time">
            <time>04:00 PM, 24 Mar, 2024</time>
          </div>
        </div>

        <div class="timeline-item-2 mb-5">
          <div class="text p-4 rounded-3">
            <h3 class="fs-14 fw-medium text-primary">
              Team Building Workshop:
            </h3>
            <p>
              Arrange for a suitable venue and ensure that any necessary
              materials or resources are readily available. Start the workshop
              with a fun icebreaker activity to help team members
            </p>
            <ul class="ps-0 mb-3 list-unstyled d-flex align-items-center">
              <li>
                <NuxtLink to="/my-profile">
                  <img
                    src="~/assets/images/user-16.jpg"
                    class="wh-34 lh-34 rounded-circle border border-1 border-color-white"
                    alt="user"
                  />
                </NuxtLink>
              </li>
              <li class="ms-m-15">
                <NuxtLink to="/my-profile">
                  <img
                    src="~/assets/images/user-17.jpg"
                    class="wh-34 lh-34 rounded-circle border border-1 border-color-white"
                    alt="user"
                  />
                </NuxtLink>
              </li>
              <li class="ms-m-15">
                <NuxtLink to="/my-profile">
                  <img
                    src="~/assets/images/user-18.jpg"
                    class="wh-34 lh-34 rounded-circle border border-1 border-color-white"
                    alt="user"
                  />
                </NuxtLink>
              </li>
              <li class="ms-m-15">
                <NuxtLink to="/my-profile">
                  <img
                    src="~/assets/images/user-19.jpg"
                    class="wh-34 lh-34 rounded-circle border border-1 border-color-white"
                    alt="user"
                  />
                </NuxtLink>
              </li>
              <li class="ms-m-15">
                <NuxtLink
                  to="/users/users-list"
                  class="wh-34 lh-34 rounded-circle bg-primary d-block text-center text-decoration-none text-white fs-12 fw-medium border border-1 border-color-white"
                  >+10</NuxtLink
                >
              </li>
            </ul>
            <span class="d-block text-primary"
              ><span class="text-body fw-medium">By:</span> Olivia
              Rodriguez</span
            >
          </div>
          <div class="icon three">
            <div></div>
          </div>
          <div class="time">
            <time>02 PM, 23 Mar, 2024</time>
          </div>
        </div>

        <div class="timeline-item-2">
          <div class="text p-4 rounded-3">
            <h3 class="fs-14 fw-medium text-primary">
              Lunch & Learning Session:
            </h3>
            <p>
              Determine a convenient time and date for the session, ideally
              during a lunch break or over a lunch hour. Start the session on
              time and welcome all participants.
            </p>
            <ul class="ps-0 mb-3 list-unstyled d-flex align-items-center">
              <li>
                <NuxtLink to="/my-profile">
                  <img
                    src="~/assets/images/user-16.jpg"
                    class="wh-34 lh-34 rounded-circle border border-1 border-color-white"
                    alt="user"
                  />
                </NuxtLink>
              </li>
              <li class="ms-m-15">
                <NuxtLink to="/my-profile">
                  <img
                    src="~/assets/images/user-17.jpg"
                    class="wh-34 lh-34 rounded-circle border border-1 border-color-white"
                    alt="user"
                  />
                </NuxtLink>
              </li>
              <li class="ms-m-15">
                <NuxtLink to="/my-profile">
                  <img
                    src="~/assets/images/user-18.jpg"
                    class="wh-34 lh-34 rounded-circle border border-1 border-color-white"
                    alt="user"
                  />
                </NuxtLink>
              </li>
              <li class="ms-m-15">
                <NuxtLink to="/my-profile">
                  <img
                    src="~/assets/images/user-19.jpg"
                    class="wh-34 lh-34 rounded-circle border border-1 border-color-white"
                    alt="user"
                  />
                </NuxtLink>
              </li>
              <li class="ms-m-15">
                <NuxtLink
                  to="/users/users-list"
                  class="wh-34 lh-34 rounded-circle bg-primary d-block text-center text-decoration-none text-white fs-12 fw-medium border border-1 border-color-white"
                >
                  +10
                </NuxtLink>
              </li>
            </ul>
            <span class="d-block text-primary"
              ><span class="text-body fw-medium">By:</span> Olivia
              Rodriguez</span
            >
          </div>
          <div class="icon four">
            <div></div>
          </div>
          <div class="time">
            <time>12:00 PM, 22 Mar, 2024</time>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script lang="ts">
import { defineComponent } from "vue";

export default defineComponent({
  name: "AdvancedTimeline",
});
</script>
