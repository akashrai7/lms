<template>
  <div class="card bg-white border-0 rounded-3 mb-4">
    <div class="card-body p-4 pb-0">
      <div class="row">
        <div class="col-lg-4 col-sm-6">
          <div class="mb-4">
            <img
              src="~/assets/images/product-6.jpg"
              class="rounded-3"
              alt="product"
            />
          </div>
        </div>
        <div class="col-lg-4 col-sm-6">
          <div class="mb-4">
            <img
              src="~/assets/images/product-7.jpg"
              class="rounded-3"
              alt="product"
            />
          </div>
        </div>
        <div class="col-lg-4 col-sm-6">
          <div class="mb-4">
            <img
              src="~/assets/images/product-8.jpg"
              class="rounded-3"
              alt="product"
            />
          </div>
        </div>
        <div class="col-lg-3 col-sm-6">
          <div class="mb-4">
            <img
              src="~/assets/images/product-9.jpg"
              class="rounded-3"
              alt="product"
            />
          </div>
        </div>
        <div class="col-lg-3 col-sm-6">
          <div class="mb-4">
            <img
              src="~/assets/images/product-10.jpg"
              class="rounded-3"
              alt="product"
            />
          </div>
        </div>
        <div class="col-lg-3 col-sm-6">
          <div class="mb-4">
            <img
              src="~/assets/images/product-11.jpg"
              class="rounded-3"
              alt="product"
            />
          </div>
        </div>
        <div class="col-lg-3 col-sm-6">
          <div class="mb-4">
            <img
              src="~/assets/images/product-12.jpg"
              class="rounded-3"
              alt="product"
            />
          </div>
        </div>
        <div class="col-lg-6 col-sm-6">
          <div class="mb-4">
            <img
              src="~/assets/images/product-13.jpg"
              class="rounded-3"
              alt="product"
            />
          </div>
        </div>
        <div class="col-lg-6 col-sm-6">
          <div class="mb-4">
            <img
              src="~/assets/images/product-14.jpg"
              class="rounded-3"
              alt="product"
            />
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script lang="ts">
import { defineComponent } from "vue";

export default defineComponent({
  name: "Gallery",
});
</script>
