<template>
  <div class="row justify-content-center">
    <div class="col-lg-6">
      <div class="card bg-white border-0 rounded-3 mb-4">
        <div class="card-body p-4">
          <h4 class="fs-18 mb-4">Basic Chips</h4>
          <ul class="nav nav-tabs mb-4" id="myTab" role="tablist">
            <li class="nav-item" role="presentation">
              <button
                class="nav-link active"
                id="preview-tab"
                data-bs-toggle="tab"
                data-bs-target="#preview-tab-pane"
                type="button"
                role="tab"
                aria-controls="preview-tab-pane"
                aria-selected="true"
              >
                Preview
              </button>
            </li>
            <li class="nav-item" role="presentation">
              <button
                class="nav-link"
                id="code-tab"
                data-bs-toggle="tab"
                data-bs-target="#code-tab-pane"
                type="button"
                role="tab"
                aria-controls="code-tab-pane"
                aria-selected="false"
              >
                Code
              </button>
            </li>
          </ul>
          <div class="tab-content" id="myTabContent">
            <div
              class="tab-pane fade show active"
              id="preview-tab-pane"
              role="tabpanel"
              aria-labelledby="preview-tab"
              tabindex="0"
            >
              <div class="d-flex flex-wrap gap-2">
                <button class="btn btn-primary text-white rounded-pill">
                  <div class="d-flex align-items-center">
                    <i class="ri-home-4-line text-white"></i>
                    <span class="ms-1">Primary</span>
                  </div>
                </button>
                <button class="btn btn-secondary text-white rounded-pill">
                  <div class="d-flex align-items-center">
                    <i class="ri-home-4-line text-white"></i>
                    <span class="ms-1">Secondary</span>
                  </div>
                </button>
                <button class="btn btn-success text-white rounded-pill">
                  <div class="d-flex align-items-center">
                    <i class="ri-home-4-line text-white"></i>
                    <span class="ms-1">Success</span>
                  </div>
                </button>
                <button class="btn btn-danger text-white rounded-pill">
                  <div class="d-flex align-items-center">
                    <i class="ri-home-4-line text-white"></i>
                    <span class="ms-1">Danger</span>
                  </div>
                </button>
                <button class="btn btn-warning text-white rounded-pill">
                  <div class="d-flex align-items-center">
                    <i class="ri-home-4-line text-white"></i>
                    <span class="ms-1">Warning</span>
                  </div>
                </button>
                <button class="btn btn-info text-white rounded-pill">
                  <div class="d-flex align-items-center">
                    <i class="ri-home-4-line text-white"></i>
                    <span class="ms-1">Info</span>
                  </div>
                </button>
                <button class="btn btn-light text-white rounded-pill">
                  <div class="d-flex align-items-center">
                    <i class="ri-home-4-line text-white"></i>
                    <span class="ms-1">Light</span>
                  </div>
                </button>
                <button class="btn btn-dark text-white rounded-pill">
                  <div class="d-flex align-items-center">
                    <i class="ri-home-4-line text-white"></i>
                    <span class="ms-1">Dark</span>
                  </div>
                </button>
              </div>
            </div>
            <div
              class="tab-pane fade"
              id="code-tab-pane"
              role="tabpanel"
              aria-labelledby="code-tab"
              tabindex="0"
            >
              <button
                class="btn btn-outline-primary bg-white btn-sm copy-btn position-absolute top-0 end-0"
                data-clipboard-target="#basicAlertsCode"
              >
                Copy
              </button>
              <pre class="line-numbers pt-0 pb-0 ps-25 pe-25 mb-0">
<code class="language-markup" id="basicAlertsCode">
&lt;button class="btn btn-primary text-white rounded-pill"&gt;
&lt;div class="d-flex align-items-center"&gt;
&lt;i class="ri-home-4-line text-white"&gt;&lt;/i&gt;
&lt;span class="ms-1"&gt;Primary&lt;/span&gt;
&lt;/div&gt;
&lt;/button&gt;
&lt;button class="btn btn-secondary text-white rounded-pill"&gt;
&lt;div class="d-flex align-items-center"&gt;
&lt;i class="ri-home-4-line text-white"&gt;&lt;/i&gt;
&lt;span class="ms-1"&gt;Secondary&lt;/span&gt;
&lt;/div&gt;
&lt;/button&gt;
&lt;button class="btn btn-success text-white rounded-pill"&gt;
&lt;div class="d-flex align-items-center"&gt;
&lt;i class="ri-home-4-line text-white"&gt;&lt;/i&gt;
&lt;span class="ms-1"&gt;Success&lt;/span&gt;
&lt;/div&gt;
&lt;/button&gt;
&lt;button class="btn btn-danger text-white rounded-pill"&gt;
&lt;div class="d-flex align-items-center"&gt;
&lt;i class="ri-home-4-line text-white"&gt;&lt;/i&gt;
&lt;span class="ms-1"&gt;Danger&lt;/span&gt;
&lt;/div&gt;
&lt;/button&gt;
&lt;button class="btn btn-warning text-white rounded-pill"&gt;
&lt;div class="d-flex align-items-center"&gt;
&lt;i class="ri-home-4-line text-white"&gt;&lt;/i&gt;
&lt;span class="ms-1"&gt;Warning&lt;/span&gt;
&lt;/div&gt;
&lt;/button&gt;
&lt;button class="btn btn-info text-white rounded-pill"&gt;
&lt;div class="d-flex align-items-center"&gt;
&lt;i class="ri-home-4-line text-white"&gt;&lt;/i&gt;
&lt;span class="ms-1"&gt;Info&lt;/span&gt;
&lt;/div&gt;
&lt;/button&gt;
&lt;button class="btn btn-light text-white rounded-pill"&gt;
&lt;div class="d-flex align-items-center"&gt;
&lt;i class="ri-home-4-line text-white"&gt;&lt;/i&gt;
&lt;span class="ms-1"&gt;Light&lt;/span&gt;
&lt;/div&gt;
&lt;/button&gt;
&lt;button class="btn btn-dark text-white rounded-pill"&gt;
&lt;div class="d-flex align-items-center"&gt;
&lt;i class="ri-home-4-line text-white"&gt;&lt;/i&gt;
&lt;span class="ms-1"&gt;Dark&lt;/span&gt;
&lt;/div&gt;
&lt;/button&gt;
</code>
</pre>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="col-lg-6">
      <div class="card bg-white border-0 rounded-3 mb-4">
        <div class="card-body p-4">
          <h4 class="fs-18 mb-4">Basic Chips With Icon Style</h4>
          <ul class="nav nav-tabs mb-4" id="myTab2" role="tablist">
            <li class="nav-item" role="presentation">
              <button
                class="nav-link active"
                id="preview2-tab"
                data-bs-toggle="tab"
                data-bs-target="#preview2-tab-pane"
                type="button"
                role="tab"
                aria-controls="preview2-tab-pane"
                aria-selected="true"
              >
                Preview
              </button>
            </li>
            <li class="nav-item" role="presentation">
              <button
                class="nav-link"
                id="code2-tab"
                data-bs-toggle="tab"
                data-bs-target="#code2-tab-pane"
                type="button"
                role="tab"
                aria-controls="code2-tab-pane"
                aria-selected="false"
              >
                Code
              </button>
            </li>
          </ul>
          <div class="tab-content" id="myTabContent2">
            <div
              class="tab-pane fade show active"
              id="preview2-tab-pane"
              role="tabpanel"
              aria-labelledby="preview2-tab"
              tabindex="0"
            >
              <div class="d-flex flex-wrap gap-2">
                <button class="btn btn-primary text-white rounded-pill px-2">
                  <div class="d-flex align-items-center">
                    <i
                      class="ri-home-4-line wh-25 bg-white text-primary fs-16 rounded-circle"
                    ></i>
                    <span class="ms-1">Primary</span>
                  </div>
                </button>
                <button class="btn btn-secondary text-white rounded-pill px-2">
                  <div class="d-flex align-items-center">
                    <i
                      class="ri-home-4-line wh-25 bg-white text-primary fs-16 rounded-circle"
                    ></i>
                    <span class="ms-1">Secondary</span>
                  </div>
                </button>
                <button class="btn btn-success text-white rounded-pill px-2">
                  <div class="d-flex align-items-center">
                    <i
                      class="ri-home-4-line wh-25 bg-white text-primary fs-16 rounded-circle"
                    ></i>
                    <span class="ms-1">Success</span>
                  </div>
                </button>
                <button class="btn btn-danger text-white rounded-pill px-2">
                  <div class="d-flex align-items-center">
                    <i
                      class="ri-home-4-line wh-25 bg-white text-primary fs-16 rounded-circle"
                    ></i>
                    <span class="ms-1">Danger</span>
                  </div>
                </button>
                <button class="btn btn-warning text-white rounded-pill px-2">
                  <div class="d-flex align-items-center">
                    <i
                      class="ri-home-4-line wh-25 bg-white text-primary fs-16 rounded-circle"
                    ></i>
                    <span class="ms-1">Warning</span>
                  </div>
                </button>
                <button class="btn btn-info text-white rounded-pill px-2">
                  <div class="d-flex align-items-center">
                    <i
                      class="ri-home-4-line wh-25 bg-white text-primary fs-16 rounded-circle"
                    ></i>
                    <span class="ms-1">Info</span>
                  </div>
                </button>
                <button class="btn btn-light text-white rounded-pill px-2">
                  <div class="d-flex align-items-center">
                    <i
                      class="ri-home-4-line wh-25 bg-white text-primary fs-16 rounded-circle"
                    ></i>
                    <span class="ms-1">Light</span>
                  </div>
                </button>
                <button class="btn btn-dark text-white rounded-pill px-2">
                  <div class="d-flex align-items-center">
                    <i
                      class="ri-home-4-line wh-25 bg-white text-primary fs-16 rounded-circle"
                    ></i>
                    <span class="ms-1">Dark</span>
                  </div>
                </button>
              </div>
            </div>
            <div
              class="tab-pane fade"
              id="code2-tab-pane"
              role="tabpanel"
              aria-labelledby="code2-tab"
              tabindex="0"
            >
              <button
                class="btn btn-outline-primary bg-white btn-sm copy-btn position-absolute top-0 end-0"
                data-clipboard-target="#basicAlertsCode2"
              >
                Copy
              </button>
              <pre class="line-numbers pt-0 pb-0 ps-25 pe-25 mb-0">
<code class="language-markup" id="basicAlertsCode2">
&lt;button class="btn btn-primary text-white rounded-pill px-2"&gt;
&lt;div class="d-flex align-items-center"&gt;
&lt;i class="ri-home-4-line wh-25 bg-white text-primary fs-16 rounded-circle"&gt;&lt;/i&gt;
&lt;span class="ms-1"&gt;Primary&lt;/span&gt;
&lt;/div&gt;
&lt;/button&gt;
&lt;button class="btn btn-secondary text-white rounded-pill px-2"&gt;
&lt;div class="d-flex align-items-center"&gt;
&lt;i class="ri-home-4-line wh-25 bg-white text-primary fs-16 rounded-circle"&gt;&lt;/i&gt;
&lt;span class="ms-1"&gt;Secondary&lt;/span&gt;
&lt;/div&gt;
&lt;/button&gt;
&lt;button class="btn btn-success text-white rounded-pill px-2"&gt;
&lt;div class="d-flex align-items-center"&gt;
&lt;i class="ri-home-4-line wh-25 bg-white text-primary fs-16 rounded-circle"&gt;&lt;/i&gt;
&lt;span class="ms-1"&gt;Success&lt;/span&gt;
&lt;/div&gt;
&lt;/button&gt;
&lt;button class="btn btn-danger text-white rounded-pill px-2"&gt;
&lt;div class="d-flex align-items-center"&gt;
&lt;i class="ri-home-4-line wh-25 bg-white text-primary fs-16 rounded-circle"&gt;&lt;/i&gt;
&lt;span class="ms-1"&gt;Danger&lt;/span&gt;
&lt;/div&gt;
&lt;/button&gt;
&lt;button class="btn btn-warning text-white rounded-pill px-2"&gt;
&lt;div class="d-flex align-items-center"&gt;
&lt;i class="ri-home-4-line wh-25 bg-white text-primary fs-16 rounded-circle"&gt;&lt;/i&gt;
&lt;span class="ms-1"&gt;Warning&lt;/span&gt;
&lt;/div&gt;
&lt;/button&gt;
&lt;button class="btn btn-info text-white rounded-pill px-2"&gt;
&lt;div class="d-flex align-items-center"&gt;
&lt;i class="ri-home-4-line wh-25 bg-white text-primary fs-16 rounded-circle"&gt;&lt;/i&gt;
&lt;span class="ms-1"&gt;Info&lt;/span&gt;
&lt;/div&gt;
&lt;/button&gt;
&lt;button class="btn btn-light text-white rounded-pill px-2"&gt;
&lt;div class="ri-home-4-line wh-25 bg-white text-primary fs-16 rounded-circle"&gt;
&lt;i class="ri-home-4-line wh-25 bg-white text-primary fs-16 rounded-circle"&gt;&lt;/i&gt;
&lt;span class="ms-1"&gt;Light&lt;/span&gt;
&lt;/div&gt;
&lt;/button&gt;
&lt;button class="btn btn-dark text-white rounded-pill px-2"&gt;
&lt;div class="d-flex align-items-center"&gt;
&lt;i class="ri-home-4-line wh-25 bg-white text-primary fs-16 rounded-circle"&gt;&lt;/i&gt;
&lt;span class="ms-1"&gt;Dark&lt;/span&gt;
&lt;/div&gt;
&lt;/button&gt;
</code>
</pre>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="col-lg-6">
      <div class="card bg-white border-0 rounded-3 mb-4">
        <div class="card-body p-4">
          <h4 class="fs-18 mb-4">Chips With Image</h4>
          <ul class="nav nav-tabs mb-4" id="myTab3" role="tablist">
            <li class="nav-item" role="presentation">
              <button
                class="nav-link active"
                id="preview3-tab"
                data-bs-toggle="tab"
                data-bs-target="#preview3-tab-pane"
                type="button"
                role="tab"
                aria-controls="preview3-tab-pane"
                aria-selected="true"
              >
                Preview
              </button>
            </li>
            <li class="nav-item" role="presentation">
              <button
                class="nav-link"
                id="code3-tab"
                data-bs-toggle="tab"
                data-bs-target="#code3-tab-pane"
                type="button"
                role="tab"
                aria-controls="code3-tab-pane"
                aria-selected="false"
              >
                Code
              </button>
            </li>
          </ul>
          <div class="tab-content" id="myTabContent3">
            <div
              class="tab-pane fade show active"
              id="preview3-tab-pane"
              role="tabpanel"
              aria-labelledby="preview3-tab"
              tabindex="0"
            >
              <div class="d-flex flex-wrap gap-2">
                <button class="btn btn-primary text-white rounded-pill px-2">
                  <div class="d-flex align-items-center">
                    <img
                      src="~/assets/images/user-1.jpg"
                      class="rounded-circle wh-25"
                      alt="user"
                    />
                    <span class="ms-1">Primary</span>
                  </div>
                </button>
                <button class="btn btn-secondary text-white rounded-pill px-2">
                  <div class="d-flex align-items-center">
                    <img
                      src="~/assets/images/user-2.jpg"
                      class="rounded-circle wh-25"
                      alt="user"
                    />
                    <span class="ms-1">Secondary</span>
                  </div>
                </button>
                <button class="btn btn-success text-white rounded-pill px-2">
                  <div class="d-flex align-items-center">
                    <img
                      src="~/assets/images/user-3.jpg"
                      class="rounded-circle wh-25"
                      alt="user"
                    />
                    <span class="ms-1">Success</span>
                  </div>
                </button>
                <button class="btn btn-danger text-white rounded-pill px-2">
                  <div class="d-flex align-items-center">
                    <img
                      src="~/assets/images/user-4.jpg"
                      class="rounded-circle wh-25"
                      alt="user"
                    />
                    <span class="ms-1">Danger</span>
                  </div>
                </button>
                <button class="btn btn-warning text-white rounded-pill px-2">
                  <div class="d-flex align-items-center">
                    <img
                      src="~/assets/images/user-5.jpg"
                      class="rounded-circle wh-25"
                      alt="user"
                    />
                    <span class="ms-1">Warning</span>
                  </div>
                </button>
                <button class="btn btn-info text-white rounded-pill px-2">
                  <div class="d-flex align-items-center">
                    <img
                      src="~/assets/images/user-6.jpg"
                      class="rounded-circle wh-25"
                      alt="user"
                    />
                    <span class="ms-1">Info</span>
                  </div>
                </button>
                <button class="btn btn-light text-white rounded-pill px-2">
                  <div class="d-flex align-items-center">
                    <img
                      src="~/assets/images/user-7.jpg"
                      class="rounded-circle wh-25"
                      alt="user"
                    />
                    <span class="ms-1">Light</span>
                  </div>
                </button>
                <button class="btn btn-dark text-white rounded-pill px-2">
                  <div class="d-flex align-items-center">
                    <img
                      src="~/assets/images/user-8.jpg"
                      class="rounded-circle wh-25"
                      alt="user"
                    />
                    <span class="ms-1">Dark</span>
                  </div>
                </button>
              </div>
            </div>
            <div
              class="tab-pane fade"
              id="code3-tab-pane"
              role="tabpanel"
              aria-labelledby="code3-tab"
              tabindex="0"
            >
              <button
                class="btn btn-outline-primary bg-white btn-sm copy-btn position-absolute top-0 end-0"
                data-clipboard-target="#basicAlertsCode3"
              >
                Copy
              </button>
              <pre class="line-numbers pt-0 pb-0 ps-25 pe-25 mb-0">
<code class="language-markup" id="basicAlertsCode3">
&lt;button class="btn btn-primary text-white rounded-pill px-2"&gt;
&lt;div class="d-flex align-items-center"&gt;
&lt;img src="~/assets/images/user-1.jpg" class="rounded-circle wh-25" alt="user"&gt;
&lt;span class="ms-1"&gt;Primary&lt;/span&gt;
&lt;/div&gt;
&lt;/button&gt;
&lt;button class="btn btn-secondary text-white rounded-pill px-2"&gt;
&lt;div class="d-flex align-items-center"&gt;
&lt;img src="~/assets/images/user-2.jpg" class="rounded-circle wh-25" alt="user"&gt;
&lt;span class="ms-1"&gt;Secondary&lt;/span&gt;
&lt;/div&gt;
&lt;/button&gt;
&lt;button class="btn btn-success text-white rounded-pill px-2"&gt;
&lt;div class="d-flex align-items-center"&gt;
&lt;img src="~/assets/images/user-3.jpg" class="rounded-circle wh-25" alt="user"&gt;
&lt;span class="ms-1"&gt;Success&lt;/span&gt;
&lt;/div&gt;
&lt;/button&gt;
&lt;button class="btn btn-danger text-white rounded-pill px-2"&gt;
&lt;div class="d-flex align-items-center"&gt;
&lt;img src="~/assets/images/user-4.jpg" class="rounded-circle wh-25" alt="user"&gt;
&lt;span class="ms-1"&gt;Danger&lt;/span&gt;
&lt;/div&gt;
&lt;/button&gt;
&lt;button class="btn btn-warning text-white rounded-pill px-2"&gt;
&lt;div class="d-flex align-items-center"&gt;
&lt;img src="~/assets/images/user-5.jpg" class="rounded-circle wh-25" alt="user"&gt;
&lt;span class="ms-1"&gt;Warning&lt;/span&gt;
&lt;/div&gt;
&lt;/button&gt;
&lt;button class="btn btn-info text-white rounded-pill px-2"&gt;
&lt;div class="d-flex align-items-center"&gt;
&lt;img src="~/assets/images/user-6.jpg" class="rounded-circle wh-25" alt="user"&gt;
&lt;span class="ms-1"&gt;Info&lt;/span&gt;
&lt;/div&gt;
&lt;/button&gt;
&lt;button class="btn btn-light text-white rounded-pill px-2"&gt;
&lt;div class="d-flex align-items-center"&gt;
&lt;img src="~/assets/images/user-7.jpg" class="rounded-circle wh-25" alt="user"&gt;
&lt;span class="ms-1"&gt;Light&lt;/span&gt;
&lt;/div&gt;
&lt;/button&gt;
&lt;button class="btn btn-dark text-white rounded-pill px-2"&gt;
&lt;div class="d-flex align-items-center"&gt;
&lt;img src="~/assets/images/user-8.jpg" class="rounded-circle wh-25" alt="user"&gt;
&lt;span class="ms-1"&gt;Dark&lt;/span&gt;
&lt;/div&gt;
&lt;/button&gt;
</code>
</pre>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="col-lg-6">
      <div class="card bg-white border-0 rounded-3 mb-4">
        <div class="card-body p-4">
          <h4 class="fs-18 mb-4">Chips With Image & Border</h4>
          <ul class="nav nav-tabs mb-4" id="myTab4" role="tablist">
            <li class="nav-item" role="presentation">
              <button
                class="nav-link active"
                id="preview4-tab"
                data-bs-toggle="tab"
                data-bs-target="#preview4-tab-pane"
                type="button"
                role="tab"
                aria-controls="preview4-tab-pane"
                aria-selected="true"
              >
                Preview
              </button>
            </li>
            <li class="nav-item" role="presentation">
              <button
                class="nav-link"
                id="code4-tab"
                data-bs-toggle="tab"
                data-bs-target="#code4-tab-pane"
                type="button"
                role="tab"
                aria-controls="code4-tab-pane"
                aria-selected="false"
              >
                Code
              </button>
            </li>
          </ul>
          <div class="tab-content" id="myTabContent4">
            <div
              class="tab-pane fade show active"
              id="preview4-tab-pane"
              role="tabpanel"
              aria-labelledby="preview4-tab"
              tabindex="0"
            >
              <div class="d-flex flex-wrap gap-2">
                <button class="btn btn-primary text-white rounded-pill px-2">
                  <div class="d-flex align-items-center">
                    <img
                      src="~/assets/images/user-1.jpg"
                      class="rounded-circle wh-25 border border-2 border-white"
                      alt="user"
                    />
                    <span class="ms-1">Primary</span>
                  </div>
                </button>
                <button class="btn btn-secondary text-white rounded-pill px-2">
                  <div class="d-flex align-items-center">
                    <img
                      src="~/assets/images/user-2.jpg"
                      class="rounded-circle wh-25 border border-2 border-white"
                      alt="user"
                    />
                    <span class="ms-1">Secondary</span>
                  </div>
                </button>
                <button class="btn btn-success text-white rounded-pill px-2">
                  <div class="d-flex align-items-center">
                    <img
                      src="~/assets/images/user-3.jpg"
                      class="rounded-circle wh-25 border border-2 border-white"
                      alt="user"
                    />
                    <span class="ms-1">Success</span>
                  </div>
                </button>
                <button class="btn btn-danger text-white rounded-pill px-2">
                  <div class="d-flex align-items-center">
                    <img
                      src="~/assets/images/user-4.jpg"
                      class="rounded-circle wh-25 border border-2 border-white"
                      alt="user"
                    />
                    <span class="ms-1">Danger</span>
                  </div>
                </button>
                <button class="btn btn-warning text-white rounded-pill px-2">
                  <div class="d-flex align-items-center">
                    <img
                      src="~/assets/images/user-5.jpg"
                      class="rounded-circle wh-25 border border-2 border-white"
                      alt="user"
                    />
                    <span class="ms-1">Warning</span>
                  </div>
                </button>
                <button class="btn btn-info text-white rounded-pill px-2">
                  <div class="d-flex align-items-center">
                    <img
                      src="~/assets/images/user-6.jpg"
                      class="rounded-circle wh-25 border border-2 border-white"
                      alt="user"
                    />
                    <span class="ms-1">Info</span>
                  </div>
                </button>
                <button class="btn btn-light text-white rounded-pill px-2">
                  <div class="d-flex align-items-center">
                    <img
                      src="~/assets/images/user-7.jpg"
                      class="rounded-circle wh-25 border border-2 border-white"
                      alt="user"
                    />
                    <span class="ms-1">Light</span>
                  </div>
                </button>
                <button class="btn btn-dark text-white rounded-pill px-2">
                  <div class="d-flex align-items-center">
                    <img
                      src="~/assets/images/user-8.jpg"
                      class="rounded-circle wh-25 border border-2 border-white"
                      alt="user"
                    />
                    <span class="ms-1">Dark</span>
                  </div>
                </button>
              </div>
            </div>
            <div
              class="tab-pane fade"
              id="code4-tab-pane"
              role="tabpanel"
              aria-labelledby="code4-tab"
              tabindex="0"
            >
              <button
                class="btn btn-outline-primary bg-white btn-sm copy-btn position-absolute top-0 end-0"
                data-clipboard-target="#basicAlertsCode4"
              >
                Copy
              </button>
              <pre class="line-numbers pt-0 pb-0 ps-25 pe-25 mb-0">
<code class="language-markup" id="basicAlertsCode4">
&lt;button class="btn btn-primary text-white rounded-pill px-2"&gt;
&lt;div class="d-flex align-items-center"&gt;
&lt;img src="~/assets/images/user-1.jpg" class="rounded-circle wh-25 border border-2 border-white" alt="user"&gt;
&lt;span class="ms-1"&gt;Primary&lt;/span&gt;
&lt;/div&gt;
&lt;/button&gt;
&lt;button class="btn btn-secondary text-white rounded-pill px-2"&gt;
&lt;div class="d-flex align-items-center"&gt;
&lt;img src="~/assets/images/user-2.jpg" class="rounded-circle wh-25 border border-2 border-white" alt="user"&gt;
&lt;span class="ms-1"&gt;Secondary&lt;/span&gt;
&lt;/div&gt;
&lt;/button&gt;
&lt;button class="btn btn-success text-white rounded-pill px-2"&gt;
&lt;div class="d-flex align-items-center"&gt;
&lt;img src="~/assets/images/user-3.jpg" class="rounded-circle wh-25 border border-2 border-white" alt="user"&gt;
&lt;span class="ms-1"&gt;Success&lt;/span&gt;
&lt;/div&gt;
&lt;/button&gt;
&lt;button class="btn btn-danger text-white rounded-pill px-2"&gt;
&lt;div class="d-flex align-items-center"&gt;
&lt;img src="~/assets/images/user-4.jpg" class="rounded-circle wh-25 border border-2 border-white" alt="user"&gt;
&lt;span class="ms-1"&gt;Danger&lt;/span&gt;
&lt;/div&gt;
&lt;/button&gt;
&lt;button class="btn btn-warning text-white rounded-pill px-2"&gt;
&lt;div class="d-flex align-items-center"&gt;
&lt;img src="~/assets/images/user-5.jpg" class="rounded-circle wh-25 border border-2 border-white" alt="user"&gt;
&lt;span class="ms-1"&gt;Warning&lt;/span&gt;
&lt;/div&gt;
&lt;/button&gt;
&lt;button class="btn btn-info text-white rounded-pill px-2"&gt;
&lt;div class="d-flex align-items-center"&gt;
&lt;img src="~/assets/images/user-6.jpg" class="rounded-circle wh-25 border border-2 border-white" alt="user"&gt;
&lt;span class="ms-1"&gt;Info&lt;/span&gt;
&lt;/div&gt;
&lt;/button&gt;
&lt;button class="btn btn-light text-white rounded-pill px-2"&gt;
&lt;div class="d-flex align-items-center"&gt;
&lt;img src="~/assets/images/user-7.jpg" class="rounded-circle wh-25 border border-2 border-white" alt="user"&gt;
&lt;span class="ms-1"&gt;Light&lt;/span&gt;
&lt;/div&gt;
&lt;/button&gt;
&lt;button class="btn btn-dark text-white rounded-pill px-2"&gt;
&lt;div class="d-flex align-items-center"&gt;
&lt;img src="~/assets/images/user-8.jpg" class="rounded-circle wh-25 border border-2 border-white" alt="user"&gt;
&lt;span class="ms-1"&gt;Dark&lt;/span&gt;
&lt;/div&gt;
&lt;/button&gt;
</code>
</pre>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="col-lg-6">
      <div class="card bg-white border-0 rounded-3 mb-4">
        <div class="card-body p-4">
          <h4 class="fs-18 mb-4">Chips All Style</h4>
          <ul class="nav nav-tabs mb-4" id="myTab5" role="tablist">
            <li class="nav-item" role="presentation">
              <button
                class="nav-link active"
                id="preview5-tab"
                data-bs-toggle="tab"
                data-bs-target="#preview5-tab-pane"
                type="button"
                role="tab"
                aria-controls="preview5-tab-pane"
                aria-selected="true"
              >
                Preview
              </button>
            </li>
            <li class="nav-item" role="presentation">
              <button
                class="nav-link"
                id="code5-tab"
                data-bs-toggle="tab"
                data-bs-target="#code5-tab-pane"
                type="button"
                role="tab"
                aria-controls="code5-tab-pane"
                aria-selected="false"
              >
                Code
              </button>
            </li>
          </ul>
          <div class="tab-content" id="myTabContent5">
            <div
              class="tab-pane fade show active"
              id="preview5-tab-pane"
              role="tabpanel"
              aria-labelledby="preview5-tab"
              tabindex="0"
            >
              <div class="d-flex flex-wrap gap-2">
                <button class="btn btn-primary text-white rounded-pill px-2">
                  <div class="d-flex align-items-center">
                    <i class="ri-home-4-line text-white"></i>
                    <span class="ms-1">Primary</span>
                  </div>
                </button>
                <button class="btn btn-secondary text-white rounded-pill px-2">
                  <div class="d-flex align-items-center">
                    <img
                      src="~/assets/images/user-2.jpg"
                      class="rounded-circle wh-25 border border-2 border-white"
                      alt="user"
                    />
                    <span class="ms-1">Secondary</span>
                  </div>
                </button>
                <button class="btn btn-success text-white rounded-pill px-2">
                  <div class="d-flex align-items-center">
                    <i
                      class="ri-check-line wh-25 bg-white text-primary fs-16 rounded-circle"
                    ></i>
                    <span class="ms-1">Success</span>
                  </div>
                </button>
                <button class="btn btn-danger text-white rounded-pill px-2">
                  <div class="d-flex align-items-center">
                    <i
                      class="ri-close-line wh-25 bg-white text-primary fs-16 rounded-circle"
                    ></i>
                    <span class="ms-1">Danger</span>
                  </div>
                </button>
                <button class="btn btn-warning text-white rounded-pill px-2">
                  <div class="d-flex align-items-center">
                    <span class="me-2">Warning</span>
                    <img
                      src="~/assets/images/user-5.jpg"
                      class="rounded-circle wh-25 border border-2 border-white"
                      alt="user"
                    />
                  </div>
                </button>
              </div>
            </div>
            <div
              class="tab-pane fade"
              id="code5-tab-pane"
              role="tabpanel"
              aria-labelledby="code5-tab"
              tabindex="0"
            >
              <button
                class="btn btn-outline-primary bg-white btn-sm copy-btn position-absolute top-0 end-0"
                data-clipboard-target="#basicAlertsCode5"
              >
                Copy
              </button>
              <pre class="line-numbers pt-0 pb-0 ps-25 pe-25 mb-0">
<code class="language-markup" id="basicAlertsCode5">
&lt;button class="btn btn-primary text-white rounded-pill px-2"&gt;
&lt;div class="d-flex align-items-center"&gt;
&lt;i class="ri-home-4-line text-white"&gt;&lt;/i&gt;
&lt;span class="ms-1"&gt;Primary&lt;/span&gt;
&lt;/div&gt;
&lt;/button&gt;
&lt;button class="btn btn-secondary text-white rounded-pill px-2"&gt;
&lt;div class="d-flex align-items-center"&gt;
&lt;img src="~/assets/images/user-2.jpg" class="rounded-circle wh-25 border border-2 border-white" alt="user"&gt;
&lt;span class="ms-1"&gt;Secondary&lt;/span&gt;
&lt;/div&gt;
&lt;/button&gt;
&lt;button class="btn btn-success text-white rounded-pill px-2"&gt;
&lt;div class="d-flex align-items-center"&gt;
&lt;i class="ri-check-line wh-25 bg-white text-primary fs-16 rounded-circle"&gt;&lt;/i&gt;
&lt;span class="ms-1"&gt;Success&lt;/span&gt;
&lt;/div&gt;
&lt;/button&gt;
&lt;button class="btn btn-danger text-white rounded-pill px-2"&gt;
&lt;div class="d-flex align-items-center"&gt;
&lt;i class="ri-close-line wh-25 bg-white text-primary fs-16 rounded-circle"&gt;&lt;/i&gt;
&lt;span class="ms-1"&gt;Danger&lt;/span&gt;
&lt;/div&gt;
&lt;/button&gt;
&lt;button class="btn btn-warning text-white rounded-pill px-2"&gt;
&lt;div class="d-flex align-items-center"&gt;
&lt;span class="me-2"&gt;Warning&lt;/span&gt;
&lt;img src="~/assets/images/user-5.jpg" class="rounded-circle wh-25 border border-2 border-white" alt="user"&gt;
&lt;/div&gt;
&lt;/button&gt;
</code>
</pre>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script lang="ts">
import { defineComponent, onMounted } from "vue";
import Prism from "prismjs";
import "prismjs/themes/prism.min.css";

export default defineComponent({
  name: "ClipBoard",
  setup() {
    onMounted(() => {
      Prism.highlightAll();
    });
  },
});
</script>
