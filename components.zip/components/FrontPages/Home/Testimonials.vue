<template>
  <div class="testimonials-area pt-150" id="testimonials">
    <div class="container">
      <div class="section-title mw-630">
        <span class="top-title">
          <span>Testimonials</span>
        </span>
        <h2>Inspiring Feedback: What Users Love About Trezo Dashboard</h2>
      </div>
      <div class="masonrow">
        <div class="item">
          <div class="single-testimonials">
            <ul class="reating ps-0 list-unstyled">
              <li>
                <i class="ri-star-fill"></i>
              </li>
              <li>
                <i class="ri-star-fill"></i>
              </li>
              <li>
                <i class="ri-star-fill"></i>
              </li>
              <li>
                <i class="ri-star-fill"></i>
              </li>
              <li>
                <i class="ri-star-fill"></i>
              </li>
            </ul>
            <p>
              Trezo Dashboard Template has transformed how we manage our data.
              Its intuitive design and customizable features have streamlined
              our analytics process, enabling us to make informed decisions
              faster than ever before.
            </p>

            <div class="d-flex align-items-center review-info">
              <div class="review">
                <img
                  src="~/assets/images/landing/testimonial-1.jpg"
                  class="rounded-circle wh-50"
                  alt="testimonial"
                />
              </div>
              <div class="ms-3">
                <h4>Sarah Thompson</h4>
                <span>Data Analyst</span>
              </div>
            </div>
          </div>
        </div>
        <div class="item">
          <div class="single-testimonials">
            <ul class="reating ps-0 list-unstyled">
              <li>
                <i class="ri-star-fill"></i>
              </li>
              <li>
                <i class="ri-star-fill"></i>
              </li>
              <li>
                <i class="ri-star-fill"></i>
              </li>
              <li>
                <i class="ri-star-fill"></i>
              </li>
              <li>
                <i class="ri-star-half-fill"></i>
              </li>
            </ul>
            <p>
              As a developer, I appreciate the flexibility and robustness of
              Trezo Dashboard Template. It offers a wide range of features that
              cater to our diverse needs, and its clean codebase has made
              customization a breeze. Highly recommended!
            </p>

            <div class="d-flex align-items-center review-info">
              <div class="review">
                <img
                  src="~/assets/images/landing/testimonial-2.jpg"
                  class="rounded-circle wh-50"
                  alt="testimonial"
                />
              </div>
              <div class="ms-3">
                <h4>John Smith</h4>
                <span>Software Engineer</span>
              </div>
            </div>
          </div>
        </div>
        <div class="item">
          <div class="single-testimonials">
            <ul class="reating ps-0 list-unstyled">
              <li>
                <i class="ri-star-fill"></i>
              </li>
              <li>
                <i class="ri-star-fill"></i>
              </li>
              <li>
                <i class="ri-star-fill"></i>
              </li>
              <li>
                <i class="ri-star-fill"></i>
              </li>
              <li>
                <i class="ri-star-line"></i>
              </li>
            </ul>
            <p>
              Trezo Dashboard Template has been a lifesaver for our
              organization. It's helped us streamline our reporting processes
              and communicate insights effectively across departments. The time
              saved has allowed us to focus more on strategic initiatives.
            </p>

            <div class="d-flex align-items-center review-info">
              <div class="review">
                <img
                  src="~/assets/images/landing/testimonial-3.jpg"
                  class="rounded-circle wh-50"
                  alt="testimonial"
                />
              </div>
              <div class="ms-3">
                <h4>Alex Rodriguez</h4>
                <span>Marketing Director</span>
              </div>
            </div>
          </div>
        </div>
        <div class="item">
          <div class="single-testimonials">
            <ul class="reating ps-0 list-unstyled">
              <li>
                <i class="ri-star-fill"></i>
              </li>
              <li>
                <i class="ri-star-fill"></i>
              </li>
              <li>
                <i class="ri-star-fill"></i>
              </li>
              <li>
                <i class="ri-star-half-fill"></i>
              </li>
              <li>
                <i class="ri-star-line"></i>
              </li>
            </ul>
            <p>
              I can't recommend Trezo Dashboard Template enough. It's helped us
              gain a deeper understanding of our business metrics and identify
              areas for improvement. The responsive support team is an added
              bonus, always ready to assist whenever we need it.
            </p>

            <div class="d-flex align-items-center review-info">
              <div class="review">
                <img
                  src="~/assets/images/landing/testimonial-4.jpg"
                  class="rounded-circle wh-50"
                  alt="testimonial"
                />
              </div>
              <div class="ms-3">
                <h4>Kevin Brown</h4>
                <span>Jessica Martinez</span>
              </div>
            </div>
          </div>
        </div>
        <div class="item">
          <div class="single-testimonials">
            <ul class="reating ps-0 list-unstyled">
              <li>
                <i class="ri-star-fill"></i>
              </li>
              <li>
                <i class="ri-star-fill"></i>
              </li>
              <li>
                <i class="ri-star-fill"></i>
              </li>
              <li>
                <i class="ri-star-fill"></i>
              </li>
              <li>
                <i class="ri-star-fill"></i>
              </li>
            </ul>
            <p>
              Using Trezo Dashboard Template has been a game-changer for our
              team. The ability to customize widgets to suit our specific needs
              has allowed us to gain deeper insights into our performance
              metrics and drive business growth.
            </p>

            <div class="d-flex align-items-center review-info">
              <div class="review">
                <img
                  src="~/assets/images/landing/testimonial-5.jpg"
                  class="rounded-circle wh-50"
                  alt="testimonial"
                />
              </div>
              <div class="ms-3">
                <h4>Olivia Adams</h4>
                <span>Marketing Coordinator</span>
              </div>
            </div>
          </div>
        </div>
        <div class="item">
          <div class="single-testimonials">
            <ul class="reating ps-0 list-unstyled">
              <li>
                <i class="ri-star-fill"></i>
              </li>
              <li>
                <i class="ri-star-fill"></i>
              </li>
              <li>
                <i class="ri-star-fill"></i>
              </li>
              <li>
                <i class="ri-star-line"></i>
              </li>
              <li>
                <i class="ri-star-line"></i>
              </li>
            </ul>
            <p>
              As a startup, we needed a dashboard solution that was both
              powerful and cost-effective. Trezo Dashboard Template checked all
              the boxes for us. It's helped us stay agile and competitive in a
              fast-paced market.
            </p>

            <div class="d-flex align-items-center review-info">
              <div class="review">
                <img
                  src="~/assets/images/landing/testimonial-6.jpg"
                  class="rounded-circle wh-50"
                  alt="testimonial"
                />
              </div>
              <div class="ms-3">
                <h4>Daniel Lee</h4>
                <span>Co-founder, StartupX</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script lang="ts">
import { defineComponent } from "vue";

export default defineComponent({
  name: "Testimonials",
});
</script>
