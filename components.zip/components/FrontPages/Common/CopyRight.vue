<template>
  <div class="copyright-area bg-white text-center py-4">
    <div class="container">
      <p class="fs-14">
        © <span class="text-primary-div">Trezo</span> is Proudly Owned by
        <a
          href="https://envytheme.com/"
          target="_blank"
          class="text-decoration-none text-primary"
        >
          EnvyTheme
        </a>
      </p>
    </div>
  </div>
</template>

<script lang="ts">
import { defineComponent } from "vue";

export default defineComponent({
  name: "CopyRight",
});
</script>
