<template>
  <div class="navbar-area position-relative">
    <div class="accordion d-flex justify-content-start align-items-center">
      <div class="accordion-item border-radius border-0 megamenu">
        <button
          type="button"
          class="accordion-button text-start shadow-none fw-medium border-0 transition border-radius"
        >
          <i class="material-symbols-outlined"> dashboard </i>
          <span class="title lh-1"> Dashboard </span>
          <span
            class="trezo-badge rounded-circle fw-medium d-inline-block text-center"
          >
            30
          </span>
        </button>
        <div class="accordion-body border-radius">
          <ul class="sidebar-sub-menu p-0 list-unstyled mb-0">
            <li class="sidemenu-item">
              <NuxtLink
                to="/dashboard"
                class="sidemenu-link border-radius d-block position-relative transition fw-medium"
              >
                eCommerce
              </NuxtLink>
            </li>
            <li class="sidemenu-item">
              <NuxtLink
                to="/dashboard/crm"
                class="sidemenu-link border-radius d-block position-relative transition fw-medium"
              >
                CRM
                <span class="trezo-badge d-inline-block position-relative">
                  Hot
                </span>
              </NuxtLink>
            </li>
            <li class="sidemenu-item">
              <NuxtLink
                to="/dashboard/project-management"
                class="sidemenu-link border-radius d-block position-relative transition fw-medium"
              >
                Project Management
              </NuxtLink>
            </li>
            <li class="sidemenu-item">
              <NuxtLink
                to="/dashboard/lms"
                class="sidemenu-link border-radius d-block position-relative transition fw-medium"
              >
                LMS
                <span class="trezo-badge d-inline-block position-relative">
                  Hot
                </span>
              </NuxtLink>
            </li>
            <li class="sidemenu-item">
              <NuxtLink
                to="/dashboard/help-desk"
                class="sidemenu-link border-radius d-block position-relative transition fw-medium"
              >
                HelpDesk
              </NuxtLink>
            </li>
            <li class="sidemenu-item">
              <NuxtLink
                to="/dashboard/analytics"
                class="sidemenu-link border-radius d-block position-relative transition fw-medium"
              >
                Analytics
              </NuxtLink>
            </li>
            <li class="sidemenu-item">
              <NuxtLink
                to="/dashboard/crypto"
                class="sidemenu-link border-radius d-block position-relative transition fw-medium"
              >
                Crypto
              </NuxtLink>
            </li>
            <li class="sidemenu-item">
              <NuxtLink
                to="/dashboard/sales"
                class="sidemenu-link border-radius d-block position-relative transition fw-medium"
              >
                Sales
              </NuxtLink>
            </li>
            <li class="sidemenu-item">
              <NuxtLink
                to="/dashboard/hospital"
                class="sidemenu-link border-radius d-block position-relative transition fw-medium"
              >
                Hospital
              </NuxtLink>
            </li>
            <li class="sidemenu-item">
              <NuxtLink
                to="/dashboard/hrm"
                class="sidemenu-link border-radius d-block position-relative transition fw-medium"
              >
                HRM
              </NuxtLink>
            </li>
            <li class="sidemenu-item">
              <NuxtLink
                to="/dashboard/school"
                class="sidemenu-link border-radius d-block position-relative transition fw-medium"
              >
                School
              </NuxtLink>
            </li>
            <li class="sidemenu-item">
              <NuxtLink
                to="/dashboard/call-center"
                class="sidemenu-link border-radius d-block position-relative transition fw-medium"
              >
                Call Center
                <span
                  class="trezo-badge d-inline-block position-relative style-two"
                >
                  Popular
                </span>
              </NuxtLink>
            </li>
            <li class="sidemenu-item">
              <NuxtLink
                to="/dashboard/marketing"
                class="sidemenu-link border-radius d-block position-relative transition fw-medium"
              >
                Marketing
              </NuxtLink>
            </li>
            <li class="sidemenu-item">
              <NuxtLink
                to="/dashboard/nft"
                class="sidemenu-link border-radius d-block position-relative transition fw-medium"
              >
                NFT
              </NuxtLink>
            </li>
            <li class="sidemenu-item">
              <NuxtLink
                to="/dashboard/saas"
                class="sidemenu-link border-radius d-block position-relative transition fw-medium"
              >
                SaaS
              </NuxtLink>
            </li>
            <li class="sidemenu-item">
              <NuxtLink
                to="/dashboard/real-estate"
                class="sidemenu-link border-radius d-block position-relative transition fw-medium"
              >
                Real Estate
              </NuxtLink>
            </li>
            <li class="sidemenu-item">
              <NuxtLink
                to="/dashboard/shipment"
                class="sidemenu-link border-radius d-block position-relative transition fw-medium"
              >
                Shipment
              </NuxtLink>
            </li>
            <li class="sidemenu-item">
              <NuxtLink
                to="/dashboard/finance"
                class="sidemenu-link border-radius d-block position-relative transition fw-medium"
              >
                Finance
              </NuxtLink>
            </li>
            <li class="sidemenu-item">
              <NuxtLink
                to="/dashboard/pos-system"
                class="sidemenu-link border-radius d-block position-relative transition fw-medium"
              >
                POS System
              </NuxtLink>
            </li>
            <li class="sidemenu-item">
              <NuxtLink
                to="/dashboard/podcast"
                class="sidemenu-link border-radius d-block position-relative transition fw-medium"
              >
                Podcast
              </NuxtLink>
            </li>
            <li class="sidemenu-item">
              <NuxtLink
                to="/dashboard/social-media"
                class="sidemenu-link border-radius d-block position-relative transition fw-medium"
              >
                Social Media
              </NuxtLink>
            </li>
            <li class="sidemenu-item">
              <NuxtLink
                to="/dashboard/doctor"
                class="sidemenu-link border-radius d-block position-relative transition fw-medium"
              >
                Doctor
              </NuxtLink>
            </li>
            <li class="sidemenu-item">
              <NuxtLink
                to="/dashboard/beauty-salon"
                class="sidemenu-link border-radius d-block position-relative transition fw-medium"
              >
                Beauty Salon
              </NuxtLink>
            </li>
            <li class="sidemenu-item">
              <NuxtLink
                to="/dashboard/store-analysis"
                class="sidemenu-link border-radius d-block position-relative transition fw-medium"
              >
                Store Analysis
              </NuxtLink>
            </li>
            <li class="sidemenu-item">
              <NuxtLink
                to="/dashboard/restaurant"
                class="sidemenu-link border-radius d-block position-relative transition fw-medium"
              >
                Restaurant
              </NuxtLink>
            </li>
            <li class="sidemenu-item">
              <NuxtLink
                to="/dashboard/hotel"
                class="sidemenu-link border-radius d-block position-relative transition fw-medium"
              >
                Hotel
                <span class="trezo-badge d-inline-block position-relative">
                  New
                </span>
              </NuxtLink>
            </li>
            <li class="sidemenu-item">
              <NuxtLink
                to="/dashboard/real-estate-agent"
                class="sidemenu-link border-radius d-block position-relative transition fw-medium"
              >
                Real Estate Agent
                <span class="trezo-badge d-inline-block position-relative">
                  New
                </span>
              </NuxtLink>
            </li>
            <li class="sidemenu-item">
              <NuxtLink
                to="/dashboard/credit-card"
                class="sidemenu-link border-radius d-block position-relative transition fw-medium"
              >
                Credit Card
                <span class="trezo-badge d-inline-block position-relative">
                  New
                </span>
              </NuxtLink>
            </li>
            <li class="sidemenu-item">
              <NuxtLink
                to="/dashboard/crypto-trader"
                class="sidemenu-link border-radius d-block position-relative transition fw-medium"
              >
                Crypto Trader
                <span class="trezo-badge d-inline-block position-relative">
                  New
                </span>
              </NuxtLink>
            </li>
            <li class="sidemenu-item">
              <NuxtLink
                to="/dashboard/crypto-performance"
                class="sidemenu-link border-radius d-block position-relative transition fw-medium"
              >
                Crypto Performance
                <span class="trezo-badge d-inline-block position-relative">
                  New
                </span>
              </NuxtLink>
            </li>
          </ul>
        </div>
      </div>
      <div class="accordion-item border-radius border-0">
        <button
          type="button"
          class="accordion-button text-start shadow-none fw-medium border-0 transition border-radius"
        >
          <i class="material-symbols-outlined"> deployed_code </i>
          <span class="title lh-1"> Apps </span>
        </button>
        <div class="accordion-body border-radius">
          <ul class="sidebar-sub-menu p-0 list-unstyled mb-0">
            <li class="sidemenu-item">
              <NuxtLink
                to="/apps/to-do-list"
                class="sidemenu-link with-icon border-radius d-block position-relative transition fw-medium"
              >
                <i class="material-symbols-outlined"> format_list_bulleted </i>
                <span class="title lh-1"> To Do List </span>
              </NuxtLink>
            </li>
            <li class="sidemenu-item">
              <NuxtLink
                to="/apps/calendar"
                class="sidemenu-link with-icon border-radius d-block position-relative transition fw-medium"
              >
                <i class="material-symbols-outlined"> date_range </i>
                <span class="title lh-1"> Calendar </span>
              </NuxtLink>
            </li>
            <li class="sidemenu-item">
              <NuxtLink
                to="/apps/contacts"
                class="sidemenu-link with-icon border-radius d-block position-relative transition fw-medium"
              >
                <i class="material-symbols-outlined"> contact_page </i>
                <span class="title lh-1"> Contacts </span>
              </NuxtLink>
            </li>
            <li class="sidemenu-item">
              <NuxtLink
                to="/apps/chat"
                class="sidemenu-link with-icon border-radius d-block position-relative transition fw-medium"
              >
                <i class="material-symbols-outlined"> chat </i>
                <span class="title lh-1"> Chat </span>
              </NuxtLink>
            </li>
            <li class="sidemenu-item">
              <button
                type="button"
                class="accordion-button with-icon text-start shadow-none fw-medium border-0 transition border-radius"
              >
                <i class="material-symbols-outlined"> mail </i>
                <span class="title lh-1"> Email </span>
                <span
                  class="trezo-badge rounded-circle fw-medium d-inline-block text-center style-two"
                >
                  3
                </span>
              </button>
              <div class="accordion-body border-radius">
                <ul class="sidebar-sub-menu p-0 list-unstyled mb-0">
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/apps/email/inbox"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Inbox
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/apps/email/compose"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Compose
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/apps/email/read-email"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Read
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/apps/email/snoozed"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Snooozed
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/apps/email/draft"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Draft
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/apps/email/sent-mail"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Sent Mail
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/apps/email/trash-email"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Trash
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/apps/email/spam"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Spam
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/apps/email/starred"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Starred
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/apps/email/important"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Important
                    </NuxtLink>
                  </li>
                </ul>
              </div>
            </li>
            <li class="sidemenu-item">
              <NuxtLink
                to="/apps/kanban-board"
                class="sidemenu-link with-icon border-radius d-block position-relative transition fw-medium"
              >
                <i class="material-symbols-outlined"> team_dashboard </i>
                <span class="title lh-1"> Kanban Board </span>
              </NuxtLink>
            </li>
            <li class="sidemenu-item">
              <button
                type="button"
                class="accordion-button with-icon text-start shadow-none fw-medium border-0 transition border-radius"
              >
                <i class="material-symbols-outlined"> folder_open </i>
                <span class="title lh-1"> File Manager </span>
                <span
                  class="trezo-badge rounded-circle fw-medium d-inline-block text-center style-three"
                >
                  7
                </span>
              </button>
              <div class="accordion-body border-radius">
                <ul class="sidebar-sub-menu p-0 list-unstyled mb-0">
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/apps/file-manager/my-drive"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      My Drive
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/apps/file-manager/assets"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Assets
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/apps/file-manager/projects"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Projects
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/apps/file-manager/personal"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Personal
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/apps/file-manager/applications"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Applications
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/apps/file-manager/documents"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Documents
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/apps/file-manager/media"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Media
                    </NuxtLink>
                  </li>
                </ul>
              </div>
            </li>
          </ul>
        </div>
      </div>
      <div class="accordion-item border-radius border-0">
        <button
          type="button"
          class="accordion-button text-start shadow-none fw-medium border-0 transition border-radius"
        >
          <i class="material-symbols-outlined"> layers </i>
          <span class="title lh-1"> Pages </span>
        </button>
        <div class="accordion-body border-radius">
          <ul class="sidebar-sub-menu p-0 list-unstyled mb-0">
            <li class="sidemenu-item">
              <button
                type="button"
                class="accordion-button with-icon text-start shadow-none fw-medium border-0 transition border-radius"
              >
                <i class="material-symbols-outlined"> note_stack </i>
                <span class="title lh-1"> Front Pages </span>
              </button>
              <div class="accordion-body border-radius">
                <ul class="sidebar-sub-menu p-0 list-unstyled mb-0">
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Home
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/features"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Features
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/our-team"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Our Team
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/faq"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      FAQ’s
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/contact"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Contact
                    </NuxtLink>
                  </li>
                </ul>
              </div>
            </li>
            <li class="sidemenu-item">
              <button
                type="button"
                class="accordion-button with-icon text-start shadow-none fw-medium border-0 transition border-radius"
              >
                <i class="material-symbols-outlined"> shopping_cart </i>
                <span class="title lh-1"> eCommerce </span>
              </button>
              <div class="accordion-body border-radius">
                <ul class="sidebar-sub-menu p-0 list-unstyled mb-0">
                  <li class="sidemenu-item">
                    <button
                      type="button"
                      class="accordion-button text-start shadow-none fw-medium border-0 transition border-radius"
                    >
                      Products
                    </button>
                    <div class="accordion-body border-radius">
                      <ul class="sidebar-sub-menu p-0 list-unstyled mb-0">
                        <li class="sidemenu-item">
                          <NuxtLink
                            to="/ecommerce/products-grid"
                            class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                          >
                            Products Grid
                          </NuxtLink>
                        </li>
                        <li class="sidemenu-item">
                          <NuxtLink
                            to="/ecommerce/products-list"
                            class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                          >
                            Products List
                          </NuxtLink>
                        </li>
                        <li class="sidemenu-item">
                          <NuxtLink
                            to="/ecommerce/product-details"
                            class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                          >
                            Product Details
                          </NuxtLink>
                        </li>
                        <li class="sidemenu-item">
                          <NuxtLink
                            to="/ecommerce/create-product"
                            class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                          >
                            Create Product
                          </NuxtLink>
                        </li>
                        <li class="sidemenu-item">
                          <NuxtLink
                            to="/ecommerce/edit-product"
                            class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                          >
                            Edit Product
                          </NuxtLink>
                        </li>
                      </ul>
                    </div>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/ecommerce/cart"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Cart
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/ecommerce/checkout"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Checkout
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/ecommerce/orders"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Orders
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/ecommerce/order-details"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Order Details
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/ecommerce/create-order"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Create Order
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/ecommerce/order-tracking"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Order Tracking
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/ecommerce/customers"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Customers
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/ecommerce/customer-details"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Customer Details
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/ecommerce/categories"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Categories
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/ecommerce/sellers"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Sellers
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/ecommerce/seller-details"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Seller Details
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/ecommerce/create-seller"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Create Seller
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/ecommerce/reviews"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Reviews
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/ecommerce/refunds"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Refunds
                    </NuxtLink>
                  </li>
                </ul>
              </div>
            </li>
            <li class="sidemenu-item">
              <button
                type="button"
                class="accordion-button with-icon text-start shadow-none fw-medium border-0 transition border-radius"
              >
                <i class="material-symbols-outlined"> handshake </i>
                <span class="title lh-1"> CRM </span>
              </button>
              <div class="accordion-body border-radius">
                <ul class="sidebar-sub-menu p-0 list-unstyled mb-0">
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/crm/contacts"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Contacts
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/crm/customers"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Customers
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/crm/leads"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Leads
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/crm/deals"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Deals
                    </NuxtLink>
                  </li>
                </ul>
              </div>
            </li>
            <li class="sidemenu-item">
              <button
                type="button"
                class="accordion-button with-icon text-start shadow-none fw-medium border-0 transition border-radius"
              >
                <i class="material-symbols-outlined"> description </i>
                <span class="title lh-1"> Project Management </span>
              </button>
              <div class="accordion-body border-radius">
                <ul class="sidebar-sub-menu p-0 list-unstyled mb-0">
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/project-management/project-overview"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Project Overview
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/project-management/project-list"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Projects List
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/project-management/create-project"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Create Project
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/project-management/clients"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Clients
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/project-management/teams"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Teams
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/project-management/kanban-board"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Kanban Board
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/project-management/user"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Users
                    </NuxtLink>
                  </li>
                </ul>
              </div>
            </li>
            <li class="sidemenu-item">
              <button
                type="button"
                class="accordion-button with-icon text-start shadow-none fw-medium border-0 transition border-radius"
              >
                <i class="material-symbols-outlined"> auto_stories </i>
                <span class="title lh-1"> LMS </span>
              </button>
              <div class="accordion-body border-radius">
                <ul class="sidebar-sub-menu p-0 list-unstyled mb-0">
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/lms/courses-list"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Courses List
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/lms/course-details"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Course Details
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/lms/lesson-preview"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Lesson Preview
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/lms/create-course"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Create Course
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/lms/edit-course"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Edit Course
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/lms/instructors"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Instructors
                    </NuxtLink>
                  </li>
                </ul>
              </div>
            </li>
            <li class="sidemenu-item">
              <button
                type="button"
                class="accordion-button with-icon text-start shadow-none fw-medium border-0 transition border-radius"
              >
                <i class="material-symbols-outlined"> support </i>
                <span class="title lh-1"> HelpDesk </span>
              </button>
              <div class="accordion-body border-radius">
                <ul class="sidebar-sub-menu p-0 list-unstyled mb-0">
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/help-desk/tickets"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Tickets
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/help-desk/ticket-details"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Ticket Details
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/help-desk/agents"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Agents
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/help-desk/reports"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Reports
                    </NuxtLink>
                  </li>
                </ul>
              </div>
            </li>
            <li class="sidemenu-item">
              <button
                type="button"
                class="accordion-button with-icon text-start shadow-none fw-medium border-0 transition border-radius"
              >
                <i class="material-symbols-outlined"> store </i>
                <span class="title lh-1"> NFT Marketplace </span>
              </button>
              <div class="accordion-body border-radius">
                <ul class="sidebar-sub-menu p-0 list-unstyled mb-0">
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/nft-marketplace/marketplace"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Marketplace
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/nft-marketplace/explore-all"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Explore All
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/nft-marketplace/live-auction"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Live Auction
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/nft-marketplace/nft-details"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      NFT Details
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/nft-marketplace/creators"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Creators
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/nft-marketplace/creator-details"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Creator Details
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/nft-marketplace/wallet-connect"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Wallet Connect
                    </NuxtLink>
                  </li>
                </ul>
              </div>
            </li>
            <li class="sidemenu-item">
              <button
                type="button"
                class="accordion-button with-icon text-start shadow-none fw-medium border-0 transition border-radius"
              >
                <i class="material-symbols-outlined"> real_estate_agent </i>
                <span class="title lh-1"> Real Estate </span>
              </button>
              <div class="accordion-body border-radius">
                <ul class="sidebar-sub-menu p-0 list-unstyled mb-0">
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/real-estate/real-estate-customers"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Real Estate Customers
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/real-estate/property-list"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Property List
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/real-estate/property-overview"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Property Overview
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/real-estate/add-property"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Add Property
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/real-estate/agent-list"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Agent list
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/real-estate/agent-overview"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Agent Overview
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/real-estate/add-agent"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Add Agent
                    </NuxtLink>
                  </li>
                </ul>
              </div>
            </li>
            <li class="sidemenu-item">
              <button
                type="button"
                class="accordion-button with-icon text-start shadow-none fw-medium border-0 transition border-radius"
              >
                <i class="material-symbols-outlined"> calculate </i>
                <span class="title lh-1"> Finance </span>
              </button>
              <div class="accordion-body border-radius">
                <ul class="sidebar-sub-menu p-0 list-unstyled mb-0">
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/finance/wallet"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Wallet
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/finance/transaction"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Transactions
                    </NuxtLink>
                  </li>
                </ul>
              </div>
            </li>
            <li class="sidemenu-item">
              <button
                type="button"
                class="accordion-button with-icon text-start shadow-none fw-medium border-0 transition border-radius"
              >
                <i class="material-symbols-outlined"> badge </i>
                <span class="title lh-1"> Doctor </span>
              </button>
              <div class="accordion-body border-radius">
                <ul class="sidebar-sub-menu p-0 list-unstyled mb-0">
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/doctor/patients-list"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Patients List
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/doctor/add-patient"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Add Patient
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/doctor/patient-details"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Patient Details
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/doctor/appointments"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Appointments
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/doctor/prescriptions"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Prescriptions
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/doctor/write-prescription"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Write a Prescription
                    </NuxtLink>
                  </li>
                </ul>
              </div>
            </li>
            <li class="sidemenu-item">
              <button
                type="button"
                class="accordion-button with-icon text-start shadow-none fw-medium border-0 transition border-radius"
              >
                <i class="material-symbols-outlined"> lunch_dining </i>
                <span class="title lh-1"> Restaurant </span>
              </button>
              <div class="accordion-body border-radius">
                <ul class="sidebar-sub-menu p-0 list-unstyled mb-0">
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/restaurant/menus"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Menus
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/restaurant/dish-details"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Dish Details
                    </NuxtLink>
                  </li>
                </ul>
              </div>
            </li>
            <li class="sidemenu-item">
              <button
                type="button"
                class="accordion-button with-icon text-start shadow-none fw-medium border-0 transition border-radius"
              >
                <i class="material-symbols-outlined"> hotel </i>
                <span class="title lh-1"> Hotel </span>
              </button>
              <div class="accordion-body border-radius">
                <ul class="sidebar-sub-menu p-0 list-unstyled mb-0">
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/hotel/rooms-list"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Rooms List
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/hotel/room-details"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Room Details
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/hotel/guests-list"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Guests List
                    </NuxtLink>
                  </li>
                </ul>
              </div>
            </li>
            <li class="sidemenu-item">
              <button
                type="button"
                class="accordion-button with-icon text-start shadow-none fw-medium border-0 transition border-radius"
              >
                <i class="material-symbols-outlined"> location_away </i>
                <span class="title lh-1"> Real Estate Agent </span>
              </button>
              <div class="accordion-body border-radius">
                <ul class="sidebar-sub-menu p-0 list-unstyled mb-0">
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/real-estate-agent/properties"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Properties
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/real-estate-agent/property-details"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Property Details
                    </NuxtLink>
                  </li>
                </ul>
              </div>
            </li>
            <li class="sidemenu-item">
              <button
                type="button"
                class="accordion-button with-icon text-start shadow-none fw-medium border-0 transition border-radius"
              >
                <i class="material-symbols-outlined"> paid </i>
                <span class="title lh-1"> Crypto Trader </span>
              </button>
              <div class="accordion-body border-radius">
                <ul class="sidebar-sub-menu p-0 list-unstyled mb-0">
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/crypto-trader/transactions"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Transactions
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/crypto-trader/gainers-losers"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Gainers & Losers
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/crypto-trader/wallet-crypto"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Menus
                    </NuxtLink>
                  </li>
                </ul>
              </div>
            </li>
            <li class="sidemenu-item">
              <button
                type="button"
                class="accordion-button with-icon text-start shadow-none fw-medium border-0 transition border-radius"
              >
                <i class="material-symbols-outlined"> local_activity </i>
                <span class="title lh-1"> Events </span>
              </button>
              <div class="accordion-body border-radius">
                <ul class="sidebar-sub-menu p-0 list-unstyled mb-0">
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/events"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Events Grid
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/events/events-list"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Events List
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/events/event-details"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Event Details
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/events/create-an-event"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Create An Event
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/events/edit-an-event"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Edit An Event
                    </NuxtLink>
                  </li>
                </ul>
              </div>
            </li>
            <li class="sidemenu-item">
              <button
                type="button"
                class="accordion-button with-icon text-start shadow-none fw-medium border-0 transition border-radius"
              >
                <i class="material-symbols-outlined"> share </i>
                <span class="title lh-1"> Social </span>
              </button>
              <div class="accordion-body border-radius">
                <ul class="sidebar-sub-menu p-0 list-unstyled mb-0">
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/social/profile"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Profile
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/social/settings"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Settings
                    </NuxtLink>
                  </li>
                </ul>
              </div>
            </li>
            <li class="sidemenu-item">
              <button
                type="button"
                class="accordion-button with-icon text-start shadow-none fw-medium border-0 transition border-radius"
              >
                <i class="material-symbols-outlined"> content_paste </i>
                <span class="title lh-1"> Invoices </span>
              </button>
              <div class="accordion-body border-radius">
                <ul class="sidebar-sub-menu p-0 list-unstyled mb-0">
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/invoices/invoice-list"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Invoices
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/invoices/invoice-details"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Invoice Details
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/invoices/create-invoice"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Create Invoice
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/invoices/edit-invoice"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Edit Invoice
                    </NuxtLink>
                  </li>
                </ul>
              </div>
            </li>
            <li class="sidemenu-item">
              <button
                type="button"
                class="accordion-button with-icon text-start shadow-none fw-medium border-0 transition border-radius"
              >
                <i class="material-symbols-outlined"> person </i>
                <span class="title lh-1"> Users </span>
              </button>
              <div class="accordion-body border-radius">
                <ul class="sidebar-sub-menu p-0 list-unstyled mb-0">
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/users/team-members"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Team Members
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/users/users-list"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Users List
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/users/add-user"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Add User
                    </NuxtLink>
                  </li>
                </ul>
              </div>
            </li>
            <li class="sidemenu-item">
              <button
                type="button"
                class="accordion-button with-icon text-start shadow-none fw-medium border-0 transition border-radius"
              >
                <i class="material-symbols-outlined"> account_box </i>
                <span class="title lh-1"> Profile </span>
              </button>
              <div class="accordion-body border-radius">
                <ul class="sidebar-sub-menu p-0 list-unstyled mb-0">
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/profile/user-profile"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      User Profile
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/profile/teams"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Teams
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/profile/my-projects"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Projects
                    </NuxtLink>
                  </li>
                </ul>
              </div>
            </li>
            <li class="sidemenu-item">
              <NuxtLink
                to="/starter"
                class="sidemenu-link with-icon border-radius d-block position-relative transition fw-medium"
              >
                <i class="material-symbols-outlined"> star_border </i>
                <span class="title lh-1"> Starter </span>
              </NuxtLink>
            </li>
          </ul>
        </div>
      </div>
      <div class="accordion-item border-radius border-0">
        <button
          type="button"
          class="accordion-button text-start shadow-none fw-medium border-0 transition border-radius"
        >
          <i class="material-symbols-outlined"> token </i>
          <span class="title lh-1"> Modules </span>
        </button>
        <div class="accordion-body border-radius">
          <ul class="sidebar-sub-menu p-0 list-unstyled mb-0">
            <li class="sidemenu-item">
              <button
                type="button"
                class="accordion-button with-icon text-start shadow-none fw-medium border-0 transition border-radius"
              >
                <i class="material-symbols-outlined"> qr_code_scanner </i>
                <span class="title lh-1"> UI Elements </span>
              </button>
              <div class="accordion-body border-radius">
                <ul class="sidebar-sub-menu p-0 list-unstyled mb-0">
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/ui-elements/alerts"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Alerts
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/ui-elements/avatar"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Avatars
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/ui-elements/buttons"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Buttons
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/ui-elements/badges"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Badges
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/ui-elements/cards"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Cards
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/ui-elements/carousels"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Carousels
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/ui-elements/dropdowns"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Dropdowns
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/ui-elements/grids"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Grids
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/ui-elements/images"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Images
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/ui-elements/list"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      List
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/ui-elements/modals"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Modals
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/ui-elements/navs"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Navs
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/ui-elements/paginations"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Paginations
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/ui-elements/popover-tooltips"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Popover Tooltips
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/ui-elements/progress"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Progress
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/ui-elements/spinners"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Spinners
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/ui-elements/tabs"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Tabs
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/ui-elements/accordions"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Accordions
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/ui-elements/date-time-picker"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Date Time Picker
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/ui-elements/videos"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Videos
                    </NuxtLink>
                  </li>
                </ul>
              </div>
            </li>
            <li class="sidemenu-item">
              <button
                type="button"
                class="accordion-button with-icon text-start shadow-none fw-medium border-0 transition border-radius"
              >
                <i class="material-symbols-outlined"> emoji_emotions </i>
                <span class="title lh-1"> Icons </span>
              </button>
              <div class="accordion-body border-radius">
                <ul class="sidebar-sub-menu p-0 list-unstyled mb-0">
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/icons/material-icons"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Material Symbols
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/icons/remixicon"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      RemixIcon
                    </NuxtLink>
                  </li>
                </ul>
              </div>
            </li>
            <li class="sidemenu-item">
              <button
                type="button"
                class="accordion-button with-icon text-start shadow-none fw-medium border-0 transition border-radius"
              >
                <i class="material-symbols-outlined"> table_chart </i>
                <span class="title lh-1"> Tables </span>
              </button>
              <div class="accordion-body border-radius">
                <ul class="sidebar-sub-menu p-0 list-unstyled mb-0">
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/tables/basic-table"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Basic Table
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/tables/data-tables"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Data Table
                    </NuxtLink>
                  </li>
                </ul>
              </div>
            </li>
            <li class="sidemenu-item">
              <button
                type="button"
                class="accordion-button with-icon text-start shadow-none fw-medium border-0 transition border-radius"
              >
                <i class="material-symbols-outlined"> lock_open </i>
                <span class="title lh-1"> Authentication </span>
              </button>
              <div class="accordion-body border-radius">
                <ul class="sidebar-sub-menu p-0 list-unstyled mb-0">
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/authentication/login"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Login
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/authentication/register"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Register
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/authentication/reset-password"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Reset Password
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/authentication/forget-password"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Forgot Password
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/authentication/confirm-email"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Confirm Email
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/authentication/lock-screen"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Lock Screen
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/authentication/logout"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Logout
                    </NuxtLink>
                  </li>
                </ul>
              </div>
            </li>
            <li class="sidemenu-item">
              <button
                type="button"
                class="accordion-button with-icon text-start shadow-none fw-medium border-0 transition border-radius"
              >
                <i class="material-symbols-outlined"> content_copy </i>
                <span class="title lh-1"> Extra Pages </span>
              </button>
              <div class="accordion-body border-radius">
                <ul class="sidebar-sub-menu p-0 list-unstyled mb-0">
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/extra-pages/pricing-plan"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Pricing
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/extra-pages/faq"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      FAQ’s
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/extra-pages/faq"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      FAQ
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/extra-pages/timeline"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Timeline
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/extra-pages/animation"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Animation
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/extra-pages/clip-board"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Clip Board
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/extra-pages/drag-drop"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Drag & Drop
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/extra-pages/range-slider"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Range Slider
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/extra-pages/ratings"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Ratings
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/extra-pages/toasts"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Toasts
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/extra-pages/check-radio"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Check & Radio
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/extra-pages/select"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Select
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/extra-pages/scrollbar"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Scrollbar
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/extra-pages/gallery"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Gallery
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/extra-pages/search"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Search
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/extra-pages/blank-page"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Blank Page
                    </NuxtLink>
                  </li>
                </ul>
              </div>
            </li>
            <li class="sidemenu-item">
              <button
                type="button"
                class="accordion-button with-icon text-start shadow-none fw-medium border-0 transition border-radius"
              >
                <i class="material-symbols-outlined"> error </i>
                <span class="title lh-1"> Errors </span>
              </button>
              <div class="accordion-body border-radius">
                <ul class="sidebar-sub-menu p-0 list-unstyled mb-0">
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/error/not-found"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      404 Error Page
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/error/internal-error"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Internal Error
                    </NuxtLink>
                  </li>
                </ul>
              </div>
            </li>
            <li class="sidemenu-item">
              <NuxtLink
                to="/widgets"
                class="sidemenu-link with-icon border-radius d-block position-relative transition fw-medium"
              >
                <i class="material-symbols-outlined"> widgets </i>
                <span class="title lh-1"> Widgets </span>
              </NuxtLink>
            </li>
            <li class="sidemenu-item">
              <NuxtLink
                to="/google-map"
                class="sidemenu-link with-icon border-radius d-block position-relative transition fw-medium"
              >
                <i class="material-symbols-outlined"> map </i>
                <span class="title lh-1"> Google Map </span>
              </NuxtLink>
            </li>
            <li class="sidemenu-item">
              <NuxtLink
                to="/notification"
                class="sidemenu-link with-icon border-radius d-block position-relative transition fw-medium"
              >
                <i class="material-symbols-outlined"> notifications </i>
                <span class="title lh-1"> Notifications </span>
              </NuxtLink>
            </li>
            <li class="sidemenu-item">
              <NuxtLink
                to="/members"
                class="sidemenu-link with-icon border-radius d-block position-relative transition fw-medium"
              >
                <i class="material-symbols-outlined"> people </i>
                <span class="title lh-1"> Members </span>
              </NuxtLink>
            </li>
            <li class="sidemenu-item">
              <NuxtLink
                to="/apex-charts"
                class="sidemenu-link with-icon border-radius d-block position-relative transition fw-medium"
              >
                <i class="material-symbols-outlined"> pie_chart </i>
                <span class="title lh-1">Apex Charts</span>
              </NuxtLink>
            </li>
          </ul>
        </div>
      </div>
      <div class="accordion-item border-radius border-0">
        <button
          type="button"
          class="accordion-button text-start shadow-none fw-medium border-0 transition border-radius"
        >
          <i class="material-symbols-outlined"> forum </i>
          <span class="title lh-1"> Forms </span>
        </button>
        <div class="accordion-body border-radius">
          <ul class="sidebar-sub-menu p-0 list-unstyled mb-0">
            <li class="sidemenu-item">
              <NuxtLink
                to="/forms/basic-elements"
                class="sidemenu-link border-radius d-block position-relative transition fw-medium"
              >
                Basic Elements
              </NuxtLink>
            </li>
            <li class="sidemenu-item">
              <NuxtLink
                to="/forms/advanced-elements"
                class="sidemenu-link border-radius d-block position-relative transition fw-medium"
              >
                Advanced Elements
              </NuxtLink>
            </li>
            <li class="sidemenu-item">
              <NuxtLink
                to="/forms/validation"
                class="sidemenu-link border-radius d-block position-relative transition fw-medium"
              >
                Validation
              </NuxtLink>
            </li>
            <li class="sidemenu-item">
              <NuxtLink
                to="/forms/wizard"
                class="sidemenu-link border-radius d-block position-relative transition fw-medium"
              >
                Wizard
              </NuxtLink>
            </li>
            <li class="sidemenu-item">
              <NuxtLink
                to="/forms/editors"
                class="sidemenu-link border-radius d-block position-relative transition fw-medium"
              >
                Editors
              </NuxtLink>
            </li>
            <li class="sidemenu-item">
              <NuxtLink
                to="/forms/file-upload"
                class="sidemenu-link border-radius d-block position-relative transition fw-medium"
              >
                File Upload
              </NuxtLink>
            </li>
          </ul>
        </div>
      </div>
      <div class="accordion-item border-radius border-0">
        <button
          type="button"
          class="accordion-button text-start shadow-none fw-medium border-0 transition border-radius"
        >
          <i class="material-symbols-outlined"> open_run </i>
          <span class="title lh-1"> Others </span>
        </button>
        <div class="accordion-body border-radius">
          <ul class="sidebar-sub-menu p-0 list-unstyled mb-0">
            <li class="sidemenu-item">
              <NuxtLink
                to="/my-profile"
                class="sidemenu-link with-icon border-radius d-block position-relative transition fw-medium"
              >
                <i class="material-symbols-outlined"> account_circle </i>
                <span class="title lh-1"> My Profile </span>
              </NuxtLink>
            </li>
            <li class="sidemenu-item">
              <button
                type="button"
                class="accordion-button with-icon text-start shadow-none fw-medium border-0 transition border-radius"
              >
                <i class="material-symbols-outlined"> settings </i>
                <span class="title lh-1"> Settings </span>
              </button>
              <div class="accordion-body border-radius">
                <ul class="sidebar-sub-menu p-0 list-unstyled mb-0">
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/settings/account-settings"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Account Settings
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/settings/change-password"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Change Password
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/settings/connections"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Connections
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/settings/privacy-policy"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Privacy Policy
                    </NuxtLink>
                  </li>
                  <li class="sidemenu-item">
                    <NuxtLink
                      to="/settings/terms-conditions"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Terms & Conditions
                    </NuxtLink>
                  </li>
                </ul>
              </div>
            </li>
            <li class="sidemenu-item">
              <button
                type="button"
                class="accordion-button with-icon text-start shadow-none fw-medium border-0 transition border-radius"
              >
                <i class="material-symbols-outlined"> unfold_more </i>
                <span class="title lh-1"> Multi Level Menu </span>
              </button>
              <div class="accordion-body border-radius">
                <ul class="sidebar-sub-menu p-0 list-unstyled mb-0">
                  <li class="sidemenu-item">
                    <a
                      href="javascript:void(0)"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      First
                    </a>
                  </li>
                  <li class="sidemenu-item">
                    <a
                      href="javascript:void(0)"
                      class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                    >
                      Third
                    </a>
                  </li>
                  <li class="sidemenu-item">
                    <button
                      type="button"
                      class="accordion-button text-start shadow-none fw-medium border-0 transition border-radius"
                    >
                      Third
                      <span
                        class="trezo-badge rounded-circle fw-medium d-inline-block text-center"
                      >
                        3
                      </span>
                    </button>
                    <div class="accordion-body border-radius">
                      <ul class="sidebar-sub-menu p-0 list-unstyled mb-0">
                        <li class="sidemenu-item">
                          <a
                            href="javascript:void(0)"
                            class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                          >
                            Third 1
                          </a>
                        </li>
                        <li class="sidemenu-item">
                          <button
                            type="button"
                            class="accordion-button text-start shadow-none fw-medium border-0 transition border-radius"
                          >
                            Third 2
                          </button>
                          <div class="accordion-body border-radius">
                            <ul class="sidebar-sub-menu p-0 list-unstyled mb-0">
                              <li class="sidemenu-item">
                                <a
                                  href="javascript:void(0)"
                                  class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                                >
                                  Four 1
                                </a>
                              </li>
                            </ul>
                          </div>
                        </li>
                        <li class="sidemenu-item">
                          <a
                            href="javascript:void(0)"
                            class="sidemenu-link border-radius d-block position-relative transition fw-medium"
                          >
                            Third 3
                          </a>
                        </li>
                      </ul>
                    </div>
                  </li>
                </ul>
              </div>
            </li>
            <li class="sidemenu-item">
              <NuxtLink
                to="/authentication/logout"
                class="sidemenu-link with-icon border-radius d-block position-relative transition fw-medium"
              >
                <i class="material-symbols-outlined"> logout </i>
                <span class="title lh-1"> Logout </span>
              </NuxtLink>
            </li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  // eslint-disable-next-line vue/multi-word-component-names
  name: "Navbar",
};
</script>

<style lang="scss" scoped>
.navbar-area {
  border-top: 1px solid var(--borderColor);
  max-width: 1295px;
  z-index: 999;
  margin: {
    top: 13px;
    left: auto;
    right: auto;
  }
  padding: {
    bottom: 0;
    top: 13px;
  }
  .accordion {
    gap: 6px;

    .accordion-item {
      background-color: transparent;
      color: var(--blackColor);
      white-space: nowrap;
      position: relative;

      .accordion-button {
        display: flex;
        align-items: center;
        color: var(--blackColor);
        font-size: var(--fontSize);
        background-color: transparent;
        padding: {
          bottom: 9px;
          right: 33px;
          left: 14px;
          top: 9px;
        }
        i {
          transition: var(--transition);
          color: var(--bodyColor);
          margin-right: 7px;
          font-size: 22px;
          line-height: 1;
        }
        .trezo-badge {
          padding: 0;
          width: 20px;
          height: 20px;
          font-size: 11px;
          line-height: 20px;
          color: var(--orangeColor);
          background-color: #fff5ed;
          margin: {
            left: 11px;
            right: 0;
          }
          &.style-two {
            color: #00b69b;
            background: rgba(0, 182, 155, 0.07);
          }
          &.style-three {
            color: #ee368c;
            background: rgba(238, 54, 140, 0.1);
          }
        }
        &::after {
          display: none;
        }
        &::before {
          top: 50%;
          right: 8px;
          margin-top: 1px;
          content: "\ea4e";
          position: absolute;
          color: var(--bodyColor);
          transform: translateY(-50%);
          transition: var(--transition);
          font: {
            size: 19px;
            family: remixicon;
          }
        }
        &:hover {
          color: var(--blackColor);
          background-color: #f6f7f9;

          i {
            color: var(--blackColor);
          }
          &::before {
            color: var(--blackColor);
          }
        }
      }
      &:has(.router-link-active) .accordion-button {
        color: var(--blackColor);
        background-color: #f6f7f9;

        i {
          color: var(--blackColor);
        }
        &::before {
          color: var(--blackColor);
        }
      }
      .accordion-body {
        left: 0;
        top: 100%;
        opacity: 0;
        z-index: 1;
        width: 270px;
        padding: 12px 0;
        margin-top: 13px;
        position: absolute;
        visibility: hidden;
        transition: var(--transition);
        background-color: var(--whiteColor);
        box-shadow: 0 0.25rem 1.125rem 0 rgba(47, 43, 61, 0.1);

        .accordion-button {
          color: var(--bodyColor);
          font-size: var(--fontSize);
          background-color: transparent;
          padding: {
            bottom: 10px;
            right: 10px;
            left: 31px;
            top: 10px;
          }
          &::after {
            top: 50%;
            left: 13px;
            width: 10px;
            content: "";
            height: 10px;
            transition: 0.3s;
            border-radius: 50%;
            position: absolute;
            display: inline-block;
            transform: translateY(-50%);
            background: unset !important;
            border: 1px solid var(--bodyColor);
          }
          i {
            margin-right: 0;
          }
          &:hover,
          &.router-link-active {
            background-color: #ecf0ff;
            color: var(--primaryColor);

            i {
              color: var(--primaryColor);
            }
            &::after {
              border-color: var(--primaryColor);
            }
            &::before {
              color: var(--primaryColor);
            }
          }
          .trezo-badge {
            top: 50%;
            padding: 0;
            right: 34px;
            width: 20px;
            height: 20px;
            font-size: 11px;
            line-height: 20px;
            position: absolute;
            color: var(--orangeColor);
            transform: translateY(-50%);
            background-color: #fff5ed;

            &.style-two {
              color: #00b69b;
              background: rgba(0, 182, 155, 0.07);
            }
            &.style-three {
              color: #ee368c;
              background: rgba(238, 54, 140, 0.1);
            }
          }
          &.with-icon {
            display: flex !important;
            align-items: center;
            padding-left: 12px;
            gap: 7px;

            i {
              font-size: 21px;
            }
            &::after {
              display: none;
            }
          }
        }
        .sidebar-sub-menu {
          .sidemenu-item {
            position: relative;
            padding: {
              left: 12px;
              right: 12px;
            }
            .sidemenu-link {
              color: var(--bodyColor);
              font-size: var(--fontSize);
              padding: {
                bottom: 10px;
                right: 12px;
                left: 31px;
                top: 10px;
              }
              &::after {
                top: 50%;
                left: 13px;
                width: 10px;
                content: "";
                height: 10px;
                transition: 0.3s;
                border-radius: 50%;
                position: absolute;
                transform: translateY(-50%);
                border: 1px solid var(--bodyColor);
              }
              &:hover,
              &.router-link-active {
                background-color: #ecf0ff;
                color: var(--primaryColor);

                &::after {
                  border-color: var(--primaryColor);
                }
              }
              .trezo-badge {
                top: -1px;
                padding: 2px 6px;
                margin-left: 5px;
                border-radius: 3px;
                line-height: initial;
                color: var(--orangeColor);
                background-color: #ffe8d4;
                font: {
                  size: 10px;
                  weight: normal;
                }
                &::before {
                  top: 50%;
                  left: -3px;
                  width: 6px;
                  height: 6px;
                  content: "";
                  position: absolute;
                  background: #ffe8d4;
                  transform: translateY(-50%) rotate(45deg);
                }
                &.style-two {
                  color: var(--successColor);
                  background-color: #d8ffc8;

                  &::before {
                    background: #d8ffc8;
                  }
                }
                &.style-three {
                  color: var(--purpleColor);
                  background-color: #eae0f3;

                  &::before {
                    background: #eae0f3;
                  }
                }
              }
              &.with-icon {
                display: flex !important;
                align-items: center;
                padding-left: 12px;
                gap: 7px;

                i {
                  font-size: 21px;
                }
                &::after {
                  display: none;
                }
              }
            }
            .accordion-body {
              top: 0;
              left: 100%;
              opacity: 0;
              margin-top: 0;
              visibility: hidden;

              .sidebar-sub-menu {
                .sidemenu-item {
                  .accordion-body {
                    opacity: 0;
                    // left: -100%;
                    visibility: hidden;

                    .sidebar-sub-menu {
                      .sidemenu-item {
                        .accordion-body {
                          opacity: 0;
                          // left: 100%;
                          visibility: hidden;
                        }
                        &:hover {
                          .accordion-body {
                            opacity: 1;
                            visibility: visible;
                          }
                        }
                      }
                    }
                  }
                  &:hover {
                    .accordion-body {
                      opacity: 1;
                      visibility: visible;
                    }
                  }
                }
              }
            }
            &:hover {
              .accordion-body {
                opacity: 1;
                visibility: visible;
              }
            }
          }
        }
      }
      &.megamenu {
        position: inherit;

        .accordion-body {
          width: auto;
          right: 0;
          padding: {
            left: 12px;
            right: 12px;
          }
          .sidebar-sub-menu {
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            margin: {
              left: -5px;
              right: -5px;
            }
            .sidemenu-item {
              flex: 0 0 auto;
              width: 25%;
              padding: {
                left: 5px;
                right: 5px;
              }
            }
          }
        }
      }
      &:hover {
        .accordion-body {
          opacity: 1;
          visibility: visible;
        }
      }
      &:last-child {
        .accordion-body {
          left: auto;
          right: 0;

          .sidebar-sub-menu {
            .sidemenu-item {
              .accordion-body {
                left: -100%;

                .sidebar-sub-menu {
                  .sidemenu-item {
                    .accordion-body {
                      left: 100%;

                      .sidebar-sub-menu {
                        .sidemenu-item {
                          .accordion-body {
                            left: 100%;
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}

/* Max width 767px */
@media only screen and (max-width: 767px) {
  .navbar-area {
    display: none;
  }
}

/* Min width 576px to Max width 767px */
@media only screen and (min-width: 576px) and (max-width: 767px) {
}

/* Min width 768px to Max width 991px */
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .navbar-area {
    display: none;
  }
}

/* Min width 992px to Max width 1199px */
@media only screen and (min-width: 992px) and (max-width: 1199px) {
  .navbar-area {
    max-width: 100%;

    .accordion {
      .accordion-item {
        .accordion-body {
          width: 250px;
        }
        &:last-child,
        &:nth-last-child(2) {
          .accordion-body {
            left: auto;
            right: 0;

            .sidebar-sub-menu {
              .sidemenu-item {
                .accordion-body {
                  left: -100%;

                  .sidebar-sub-menu {
                    .sidemenu-item {
                      .accordion-body {
                        left: -100%;

                        .sidebar-sub-menu {
                          .sidemenu-item {
                            .accordion-body {
                              left: 100%;
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}

/* Min width 1200px to Max width 1399px */
@media only screen and (min-width: 1200px) and (max-width: 1399px) {
  .navbar-area {
    max-width: 100%;

    .accordion {
      .accordion-item {
        .accordion-body {
          width: 250px;
        }
        &:last-child,
        &:nth-last-child(2) {
          .accordion-body {
            left: auto;
            right: 0;

            .sidebar-sub-menu {
              .sidemenu-item {
                .accordion-body {
                  left: -100%;

                  .sidebar-sub-menu {
                    .sidemenu-item {
                      .accordion-body {
                        left: -100%;

                        .sidebar-sub-menu {
                          .sidemenu-item {
                            .accordion-body {
                              left: 100%;
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}

/* Min width 1600px */
@media only screen and (min-width: 1600px) {
  .navbar-area {
    max-width: 1545px;
  }
}
</style>
