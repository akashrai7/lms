<template>
  <div class="row justify-content-center">
    <div class="col-xxl-3 col-xl-6 col-sm-6">
      <div class="card bg-white border-0 rounded-3 mb-4">
        <div class="card-body p-4">
          <div class="mb-3 text-center">
            <img src="~/assets/images/png.png" alt="png" />
            <span class="fs-15 fw-bold text-secondary d-block mt-3">
              Projects
            </span>
          </div>
          <div class="d-flex justify-content-center align-items-center gap-3">
            <button
              class="ps-0 border-0 bg-transparent lh-1 position-relative top-2"
            >
              <i class="material-symbols-outlined fs-16 text-primary">
                visibility
              </i>
            </button>
            <button
              class="ps-0 border-0 bg-transparent lh-1 position-relative top-2"
            >
              <i class="material-symbols-outlined fs-16 text-body">edit</i>
            </button>
            <button
              class="ps-0 border-0 bg-transparent lh-1 position-relative top-2"
            >
              <i class="material-symbols-outlined fs-16 text-danger">delete</i>
            </button>
          </div>
        </div>
      </div>
    </div>
    <div class="col-xxl-3 col-xl-6 col-sm-6">
      <div class="card bg-white border-0 rounded-3 mb-4">
        <div class="card-body p-4">
          <div class="mb-3 text-center">
            <img src="~/assets/images/jpg.png" alt="jpg" />
            <span class="fs-15 fw-bold text-secondary d-block mt-3">
              Documents
            </span>
          </div>
          <div class="d-flex justify-content-center align-items-center gap-3">
            <button
              class="ps-0 border-0 bg-transparent lh-1 position-relative top-2"
            >
              <i class="material-symbols-outlined fs-16 text-primary">
                visibility
              </i>
            </button>
            <button
              class="ps-0 border-0 bg-transparent lh-1 position-relative top-2"
            >
              <i class="material-symbols-outlined fs-16 text-body">edit</i>
            </button>
            <button
              class="ps-0 border-0 bg-transparent lh-1 position-relative top-2"
            >
              <i class="material-symbols-outlined fs-16 text-danger">delete</i>
            </button>
          </div>
        </div>
      </div>
    </div>
    <div class="col-xxl-3 col-xl-6 col-sm-6">
      <div class="card bg-white border-0 rounded-3 mb-4">
        <div class="card-body p-4">
          <div class="mb-3 text-center">
            <img src="~/assets/images/txt.png" alt="txt" />
            <span class="fs-15 fw-bold text-secondary d-block mt-3">Media</span>
          </div>
          <div class="d-flex justify-content-center align-items-center gap-3">
            <button
              class="ps-0 border-0 bg-transparent lh-1 position-relative top-2"
            >
              <i class="material-symbols-outlined fs-16 text-primary"
                >visibility</i
              >
            </button>
            <button
              class="ps-0 border-0 bg-transparent lh-1 position-relative top-2"
            >
              <i class="material-symbols-outlined fs-16 text-body">edit</i>
            </button>
            <button
              class="ps-0 border-0 bg-transparent lh-1 position-relative top-2"
            >
              <i class="material-symbols-outlined fs-16 text-danger">delete</i>
            </button>
          </div>
        </div>
      </div>
    </div>
    <div class="col-xxl-3 col-xl-6 col-sm-6">
      <div class="card bg-white border-0 rounded-3 mb-4">
        <div class="card-body p-4">
          <div class="mb-3 text-center">
            <img src="~/assets/images/pdf.png" alt="txt" />
            <span class="fs-15 fw-bold text-secondary d-block mt-3"
              >Applications</span
            >
          </div>
          <div class="d-flex justify-content-center align-items-center gap-3">
            <button
              class="ps-0 border-0 bg-transparent lh-1 position-relative top-2"
            >
              <i class="material-symbols-outlined fs-16 text-primary"
                >visibility</i
              >
            </button>
            <button
              class="ps-0 border-0 bg-transparent lh-1 position-relative top-2"
            >
              <i class="material-symbols-outlined fs-16 text-body">edit</i>
            </button>
            <button
              class="ps-0 border-0 bg-transparent lh-1 position-relative top-2"
            >
              <i class="material-symbols-outlined fs-16 text-danger">delete</i>
            </button>
          </div>
        </div>
      </div>
    </div>
    <div class="col-xxl-3 col-xl-6 col-sm-6">
      <div class="card bg-white border-0 rounded-3 mb-4">
        <div class="card-body p-4">
          <div class="mb-3 text-center">
            <img src="~/assets/images/xl4.png" alt="xl4" />
            <span class="fs-15 fw-bold text-secondary d-block mt-3"
              >ET Template</span
            >
          </div>
          <div class="d-flex justify-content-center align-items-center gap-3">
            <button
              class="ps-0 border-0 bg-transparent lh-1 position-relative top-2"
            >
              <i class="material-symbols-outlined fs-16 text-primary"
                >visibility</i
              >
            </button>
            <button
              class="ps-0 border-0 bg-transparent lh-1 position-relative top-2"
            >
              <i class="material-symbols-outlined fs-16 text-body">edit</i>
            </button>
            <button
              class="ps-0 border-0 bg-transparent lh-1 position-relative top-2"
            >
              <i class="material-symbols-outlined fs-16 text-danger">delete</i>
            </button>
          </div>
        </div>
      </div>
    </div>
    <div class="col-xxl-3 col-xl-6 col-sm-6">
      <div class="card bg-white border-0 rounded-3 mb-4">
        <div class="card-body p-4">
          <div class="mb-3 text-center">
            <img src="~/assets/images/doc.png" alt="doc" />
            <span class="fs-15 fw-bold text-secondary d-block mt-3"
              >React Template</span
            >
          </div>
          <div class="d-flex justify-content-center align-items-center gap-3">
            <button
              class="ps-0 border-0 bg-transparent lh-1 position-relative top-2"
            >
              <i class="material-symbols-outlined fs-16 text-primary"
                >visibility</i
              >
            </button>
            <button
              class="ps-0 border-0 bg-transparent lh-1 position-relative top-2"
            >
              <i class="material-symbols-outlined fs-16 text-body">edit</i>
            </button>
            <button
              class="ps-0 border-0 bg-transparent lh-1 position-relative top-2"
            >
              <i class="material-symbols-outlined fs-16 text-danger">delete</i>
            </button>
          </div>
        </div>
      </div>
    </div>
    <div class="col-xxl-3 col-xl-6 col-sm-6">
      <div class="card bg-white border-0 rounded-3 mb-4">
        <div class="card-body p-4">
          <div class="mb-3 text-center">
            <img src="~/assets/images/png.png" alt="png" />
            <span class="fs-15 fw-bold text-secondary d-block mt-3"
              >Material UI</span
            >
          </div>
          <div class="d-flex justify-content-center align-items-center gap-3">
            <button
              class="ps-0 border-0 bg-transparent lh-1 position-relative top-2"
            >
              <i class="material-symbols-outlined fs-16 text-primary"
                >visibility</i
              >
            </button>
            <button
              class="ps-0 border-0 bg-transparent lh-1 position-relative top-2"
            >
              <i class="material-symbols-outlined fs-16 text-body">edit</i>
            </button>
            <button
              class="ps-0 border-0 bg-transparent lh-1 position-relative top-2"
            >
              <i class="material-symbols-outlined fs-16 text-danger">delete</i>
            </button>
          </div>
        </div>
      </div>
    </div>
    <div class="col-xxl-3 col-xl-6 col-sm-6">
      <div class="card bg-white border-0 rounded-3 mb-4">
        <div class="card-body p-4">
          <div class="mb-3 text-center">
            <img src="~/assets/images/jpg.png" alt="jpg" />
            <span class="fs-15 fw-bold text-secondary d-block mt-3"
              >WP Theme</span
            >
          </div>
          <div class="d-flex justify-content-center align-items-center gap-3">
            <button
              class="ps-0 border-0 bg-transparent lh-1 position-relative top-2"
            >
              <i class="material-symbols-outlined fs-16 text-primary"
                >visibility</i
              >
            </button>
            <button
              class="ps-0 border-0 bg-transparent lh-1 position-relative top-2"
            >
              <i class="material-symbols-outlined fs-16 text-body">edit</i>
            </button>
            <button
              class="ps-0 border-0 bg-transparent lh-1 position-relative top-2"
            >
              <i class="material-symbols-outlined fs-16 text-danger">delete</i>
            </button>
          </div>
        </div>
      </div>
    </div>
    <div class="col-xxl-3 col-xl-6 col-sm-6">
      <div class="card bg-white border-0 rounded-3 mb-4">
        <div class="card-body p-4">
          <div class="mb-3 text-center">
            <img src="~/assets/images/txt.png" alt="txt" />
            <span class="fs-15 fw-bold text-secondary d-block mt-3"
              >Personal Photos</span
            >
          </div>
          <div class="d-flex justify-content-center align-items-center gap-3">
            <button
              class="ps-0 border-0 bg-transparent lh-1 position-relative top-2"
            >
              <i class="material-symbols-outlined fs-16 text-primary"
                >visibility</i
              >
            </button>
            <button
              class="ps-0 border-0 bg-transparent lh-1 position-relative top-2"
            >
              <i class="material-symbols-outlined fs-16 text-body">edit</i>
            </button>
            <button
              class="ps-0 border-0 bg-transparent lh-1 position-relative top-2"
            >
              <i class="material-symbols-outlined fs-16 text-danger">delete</i>
            </button>
          </div>
        </div>
      </div>
    </div>
    <div class="col-xxl-3 col-xl-6 col-sm-6">
      <div class="card bg-white border-0 rounded-3 mb-4">
        <div class="card-body p-4">
          <div class="mb-3 text-center">
            <img src="~/assets/images/pdf.png" alt="txt" />
            <span class="fs-15 fw-bold text-secondary d-block mt-3"
              >Mobile Apps</span
            >
          </div>
          <div class="d-flex justify-content-center align-items-center gap-3">
            <button
              class="ps-0 border-0 bg-transparent lh-1 position-relative top-2"
            >
              <i class="material-symbols-outlined fs-16 text-primary"
                >visibility</i
              >
            </button>
            <button
              class="ps-0 border-0 bg-transparent lh-1 position-relative top-2"
            >
              <i class="material-symbols-outlined fs-16 text-body">edit</i>
            </button>
            <button
              class="ps-0 border-0 bg-transparent lh-1 position-relative top-2"
            >
              <i class="material-symbols-outlined fs-16 text-danger">delete</i>
            </button>
          </div>
        </div>
      </div>
    </div>
    <div class="col-xxl-3 col-xl-6 col-sm-6">
      <div class="card bg-white border-0 rounded-3 mb-4">
        <div class="card-body p-4">
          <div class="mb-3 text-center">
            <img src="~/assets/images/xl4.png" alt="xl4" />
            <span class="fs-15 fw-bold text-secondary d-block mt-3"
              >Important Files</span
            >
          </div>
          <div class="d-flex justify-content-center align-items-center gap-3">
            <button
              class="ps-0 border-0 bg-transparent lh-1 position-relative top-2"
            >
              <i class="material-symbols-outlined fs-16 text-primary"
                >visibility</i
              >
            </button>
            <button
              class="ps-0 border-0 bg-transparent lh-1 position-relative top-2"
            >
              <i class="material-symbols-outlined fs-16 text-body">edit</i>
            </button>
            <button
              class="ps-0 border-0 bg-transparent lh-1 position-relative top-2"
            >
              <i class="material-symbols-outlined fs-16 text-danger">delete</i>
            </button>
          </div>
        </div>
      </div>
    </div>
    <div class="col-xxl-3 col-xl-6 col-sm-6">
      <div class="card bg-white border-0 rounded-3 mb-4">
        <div class="card-body p-4">
          <div class="mb-3 text-center">
            <img src="~/assets/images/jpg.png" alt="jpg" />
            <span class="fs-15 fw-bold text-secondary d-block mt-3"
              >Angular Template</span
            >
          </div>
          <div class="d-flex justify-content-center align-items-center gap-3">
            <button
              class="ps-0 border-0 bg-transparent lh-1 position-relative top-2"
            >
              <i class="material-symbols-outlined fs-16 text-primary"
                >visibility</i
              >
            </button>
            <button
              class="ps-0 border-0 bg-transparent lh-1 position-relative top-2"
            >
              <i class="material-symbols-outlined fs-16 text-body">edit</i>
            </button>
            <button
              class="ps-0 border-0 bg-transparent lh-1 position-relative top-2"
            >
              <i class="material-symbols-outlined fs-16 text-danger">delete</i>
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script lang="ts">
import { defineComponent } from "vue";

export default defineComponent({
  name: "Documents",
});
</script>
