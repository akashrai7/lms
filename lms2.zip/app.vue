<template>
  <NuxtLayout></NuxtLayout>
</template>

<script setup lang="ts">
useHead({
  title: "Trezo - Nuxt.js Bootstrap 5 Admin Dashboard Template",
  meta: [{ name: "description", content: "My amazing dashboard." }],
});
</script>
