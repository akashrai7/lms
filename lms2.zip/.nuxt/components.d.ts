
import type { DefineComponent, SlotsType } from 'vue'
type IslandComponent<T extends DefineComponent> = T & DefineComponent<{}, {refresh: () => Promise<void>}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, SlotsType<{ fallback: { error: unknown } }>>
type HydrationStrategies = {
  hydrateOnVisible?: IntersectionObserverInit | true
  hydrateOnIdle?: number | true
  hydrateOnInteraction?: keyof HTMLElementEventMap | Array<keyof HTMLElementEventMap> | true
  hydrateOnMediaQuery?: string
  hydrateAfter?: number
  hydrateWhen?: boolean
  hydrateNever?: true
}
type LazyComponent<T> = (T & DefineComponent<HydrationStrategies, {}, {}, {}, {}, {}, {}, { hydrated: () => void }>)
interface _GlobalComponents {
      'ApexChartsBasicBarAreaChart': typeof import("../components/ApexCharts/BasicBarAreaChart.vue")['default']
    'ApexChartsBasicColumnAreaChart': typeof import("../components/ApexCharts/BasicColumnAreaChart.vue")['default']
    'ApexChartsBasicLineChart': typeof import("../components/ApexCharts/BasicLineChart.vue")['default']
    'ApexChartsColumnWithDataLabelsChart': typeof import("../components/ApexCharts/ColumnWithDataLabelsChart.vue")['default']
    'ApexChartsDashedChart': typeof import("../components/ApexCharts/DashedChart.vue")['default']
    'ApexChartsGroupedChart': typeof import("../components/ApexCharts/GroupedChart.vue")['default']
    'ApexChartsLineWithDataLabelsChart': typeof import("../components/ApexCharts/LineWithDataLabelsChart.vue")['default']
    'ApexChartsNegativeAreaChart': typeof import("../components/ApexCharts/NegativeAreaChart.vue")['default']
    'ApexChartsSplineAreaChart': typeof import("../components/ApexCharts/SplineAreaChart.vue")['default']
    'ApexChartsSteplineChart': typeof import("../components/ApexCharts/SteplineChart.vue")['default']
    'ApexCharts': typeof import("../components/ApexCharts/index.vue")['default']
    'AppsCalendarContent': typeof import("../components/Apps/Calendar/CalendarContent.vue")['default']
    'AppsCalendarWorkingSchedule': typeof import("../components/Apps/Calendar/WorkingSchedule.vue")['default']
    'AppsChat': typeof import("../components/Apps/Chat/index.vue")['default']
    'AppsContactsList': typeof import("../components/Apps/Contacts/ContactsList.vue")['default']
    'AppsEmailCompose': typeof import("../components/Apps/Email/Compose/index.vue")['default']
    'AppsEmailDraft': typeof import("../components/Apps/Email/Draft/index.vue")['default']
    'AppsEmailSidebar': typeof import("../components/Apps/Email/EmailSidebar.vue")['default']
    'AppsEmailImportant': typeof import("../components/Apps/Email/Important/index.vue")['default']
    'AppsEmailInbox': typeof import("../components/Apps/Email/Inbox/index.vue")['default']
    'AppsEmailReadEmail': typeof import("../components/Apps/Email/ReadEmail/index.vue")['default']
    'AppsEmailSentMail': typeof import("../components/Apps/Email/SentMail/index.vue")['default']
    'AppsEmailSnoozed': typeof import("../components/Apps/Email/Snoozed/index.vue")['default']
    'AppsEmailSpam': typeof import("../components/Apps/Email/Spam/index.vue")['default']
    'AppsEmailStarred': typeof import("../components/Apps/Email/Starred/index.vue")['default']
    'AppsEmailTrash': typeof import("../components/Apps/Email/Trash/index.vue")['default']
    'AppsFileManagerApplications': typeof import("../components/Apps/FileManager/Applications/index.vue")['default']
    'AppsFileManagerAssets': typeof import("../components/Apps/FileManager/Assets/index.vue")['default']
    'AppsFileManagerDocuments': typeof import("../components/Apps/FileManager/Documents/index.vue")['default']
    'AppsFileManagerImportant': typeof import("../components/Apps/FileManager/Important/index.vue")['default']
    'AppsFileManagerMedia': typeof import("../components/Apps/FileManager/Media/index.vue")['default']
    'AppsFileManagerMyDriveFiles': typeof import("../components/Apps/FileManager/MyDrive/MyDriveFiles.vue")['default']
    'AppsFileManagerMyDriveRecentFiles': typeof import("../components/Apps/FileManager/MyDrive/RecentFiles.vue")['default']
    'AppsFileManagerPersonal': typeof import("../components/Apps/FileManager/Personal/index.vue")['default']
    'AppsFileManagerProjects': typeof import("../components/Apps/FileManager/Projects/index.vue")['default']
    'AppsFileManagerRecants': typeof import("../components/Apps/FileManager/Recants/index.vue")['default']
    'AppsFileManagerSidebar': typeof import("../components/Apps/FileManager/Sidebar.vue")['default']
    'AppsFileManagerSpam': typeof import("../components/Apps/FileManager/Spam/index.vue")['default']
    'AppsFileManagerTrash': typeof import("../components/Apps/FileManager/Trash/index.vue")['default']
    'AppsKanbanBoard': typeof import("../components/Apps/KanbanBoard/index.vue")['default']
    'AppsToDoList': typeof import("../components/Apps/ToDoList/index.vue")['default']
    'CommonCalendarContent': typeof import("../components/Common/CalendarContent.vue")['default']
    'CommonDatePicker': typeof import("../components/Common/DatePicker.vue")['default']
    'CommonPageTitle': typeof import("../components/Common/PageTitle.vue")['default']
    'CommonPagination': typeof import("../components/Common/Pagination.vue")['default']
    'CommonPaginationTwo': typeof import("../components/Common/PaginationTwo.vue")['default']
    'CommonTextEditor': typeof import("../components/Common/TextEditor.vue")['default']
    'DashboardAnalyticsOverviewChart': typeof import("../components/Dashboard/Analytics/AnalyticsOverviewChart.vue")['default']
    'DashboardAnalyticsBrowserUsedByUsers': typeof import("../components/Dashboard/Analytics/BrowserUsedByUsers.vue")['default']
    'DashboardAnalyticsBrowserUsedByUsersChart': typeof import("../components/Dashboard/Analytics/BrowserUsedByUsersChart.vue")['default']
    'DashboardAnalyticsClicksChart': typeof import("../components/Dashboard/Analytics/ClicksChart.vue")['default']
    'DashboardAnalyticsClicksImpressionsByKeywords': typeof import("../components/Dashboard/Analytics/ClicksImpressionsByKeywords.vue")['default']
    'DashboardAnalyticsImpressionsChart': typeof import("../components/Dashboard/Analytics/ImpressionsChart.vue")['default']
    'DashboardAnalyticsNewRegistersChart': typeof import("../components/Dashboard/Analytics/NewRegistersChart.vue")['default']
    'DashboardAnalyticsRealtimeActiveUsersChart': typeof import("../components/Dashboard/Analytics/RealtimeActiveUsersChart.vue")['default']
    'DashboardAnalyticsSessionsByChannelChart': typeof import("../components/Dashboard/Analytics/SessionsByChannelChart.vue")['default']
    'DashboardAnalyticsSessionsChart': typeof import("../components/Dashboard/Analytics/SessionsChart.vue")['default']
    'DashboardAnalyticsTopBrowsingPagesToday': typeof import("../components/Dashboard/Analytics/TopBrowsingPagesToday.vue")['default']
    'DashboardAnalyticsUsersByCountry': typeof import("../components/Dashboard/Analytics/UsersByCountry.vue")['default']
    'DashboardAnalyticsWebsiteVisitsChart': typeof import("../components/Dashboard/Analytics/WebsiteVisitsChart.vue")['default']
    'DashboardBeautySalonCustomerSatisfactionRateChart': typeof import("../components/Dashboard/BeautySalon/CustomerSatisfactionRateChart.vue")['default']
    'DashboardBeautySalonCustomersFromChannels': typeof import("../components/Dashboard/BeautySalon/CustomersFromChannels.vue")['default']
    'DashboardBeautySalonFeaturedServices': typeof import("../components/Dashboard/BeautySalon/FeaturedServices.vue")['default']
    'DashboardBeautySalonNewCustomers': typeof import("../components/Dashboard/BeautySalon/NewCustomers.vue")['default']
    'DashboardBeautySalonRecentAppointments': typeof import("../components/Dashboard/BeautySalon/RecentAppointments.vue")['default']
    'DashboardBeautySalonRevenueByServicesChart': typeof import("../components/Dashboard/BeautySalon/RevenueByServicesChart.vue")['default']
    'DashboardBeautySalonTopCustomers': typeof import("../components/Dashboard/BeautySalon/TopCustomers.vue")['default']
    'DashboardBeautySalonTopSellingProducts': typeof import("../components/Dashboard/BeautySalon/TopSellingProducts.vue")['default']
    'DashboardBeautySalonTopStylistPerformance': typeof import("../components/Dashboard/BeautySalon/TopStylistPerformance.vue")['default']
    'DashboardBeautySalonWelcomeBeautySalon': typeof import("../components/Dashboard/BeautySalon/WelcomeBeautySalon.vue")['default']
    'DashboardCRMAnnualProfitChart': typeof import("../components/Dashboard/CRM/AnnualProfitChart.vue")['default']
    'DashboardCRMBalanceOverviewChart': typeof import("../components/Dashboard/CRM/BalanceOverviewChart.vue")['default']
    'DashboardCRMLeadConversionChart': typeof import("../components/Dashboard/CRM/LeadConversionChart.vue")['default']
    'DashboardCRMLeadsBySourceChart': typeof import("../components/Dashboard/CRM/LeadsBySourceChart.vue")['default']
    'DashboardCRMRecentLeads': typeof import("../components/Dashboard/CRM/RecentLeads.vue")['default']
    'DashboardCRMRevenueGrowthChart': typeof import("../components/Dashboard/CRM/RevenueGrowthChart.vue")['default']
    'DashboardCRMSalesReportChart': typeof import("../components/Dashboard/CRM/SalesReportChart.vue")['default']
    'DashboardCRMTopPerformers': typeof import("../components/Dashboard/CRM/TopPerformers.vue")['default']
    'DashboardCRMTopProductsBySales': typeof import("../components/Dashboard/CRM/TopProductsBySales.vue")['default']
    'DashboardCRMTotalOrdersChart': typeof import("../components/Dashboard/CRM/TotalOrdersChart.vue")['default']
    'DashboardCallCenterAgentAvgEarningsChart': typeof import("../components/Dashboard/CallCenter/AgentAvgEarnings/AgentAvgEarningsChart.vue")['default']
    'DashboardCallCenterAgentAvgEarningsFiveChart': typeof import("../components/Dashboard/CallCenter/AgentAvgEarnings/AgentAvgEarningsFiveChart.vue")['default']
    'DashboardCallCenterAgentAvgEarningsFourChart': typeof import("../components/Dashboard/CallCenter/AgentAvgEarnings/AgentAvgEarningsFourChart.vue")['default']
    'DashboardCallCenterAgentAvgEarningsThreeChart': typeof import("../components/Dashboard/CallCenter/AgentAvgEarnings/AgentAvgEarningsThreeChart.vue")['default']
    'DashboardCallCenterAgentAvgEarningsTwoChart': typeof import("../components/Dashboard/CallCenter/AgentAvgEarnings/AgentAvgEarningsTwoChart.vue")['default']
    'DashboardCallCenterAgentAvgEarnings': typeof import("../components/Dashboard/CallCenter/AgentAvgEarnings/index.vue")['default']
    'DashboardCallCenterAgentsPerformanceOverview': typeof import("../components/Dashboard/CallCenter/AgentsPerformanceOverview.vue")['default']
    'DashboardCallCenterGeography': typeof import("../components/Dashboard/CallCenter/CallCenterGeography.vue")['default']
    'DashboardCallCenterInboundCallsChart': typeof import("../components/Dashboard/CallCenter/InboundCallsChart.vue")['default']
    'DashboardCallCenterOutboundCallsChart': typeof import("../components/Dashboard/CallCenter/OutboundCallsChart.vue")['default']
    'DashboardCallCenterOverviewAnsweredCallsChart': typeof import("../components/Dashboard/CallCenter/Overview/AnsweredCallsChart.vue")['default']
    'DashboardCallCenterOverviewMissedCallsChart': typeof import("../components/Dashboard/CallCenter/Overview/MissedCallsChart.vue")['default']
    'DashboardCallCenterOverviewTotalCallsChart': typeof import("../components/Dashboard/CallCenter/Overview/TotalCallsChart.vue")['default']
    'DashboardCallCenterOverview': typeof import("../components/Dashboard/CallCenter/Overview/index.vue")['default']
    'DashboardCallCenterRecentCalls': typeof import("../components/Dashboard/CallCenter/RecentCalls.vue")['default']
    'DashboardCreditCardCardsWithAmountChart': typeof import("../components/Dashboard/CreditCard/CardsWithAmountChart.vue")['default']
    'DashboardCreditCardCreditUtilizationRatioChart': typeof import("../components/Dashboard/CreditCard/CreditUtilizationRatioChart.vue")['default']
    'DashboardCreditCardDailyLimit': typeof import("../components/Dashboard/CreditCard/DailyLimit.vue")['default']
    'DashboardCreditCardInterestChargeFeesChart': typeof import("../components/Dashboard/CreditCard/InterestChargeFeesChart.vue")['default']
    'DashboardCreditCardMonthlySpendingChart': typeof import("../components/Dashboard/CreditCard/MonthlySpendingChart.vue")['default']
    'DashboardCreditCardMyCards': typeof import("../components/Dashboard/CreditCard/MyCards.vue")['default']
    'DashboardCreditCardQuickTransfer': typeof import("../components/Dashboard/CreditCard/QuickTransfer.vue")['default']
    'DashboardCreditCardRecentTransactions': typeof import("../components/Dashboard/CreditCard/RecentTransactions.vue")['default']
    'DashboardCreditCardSpendingBreakdownChart': typeof import("../components/Dashboard/CreditCard/SpendingBreakdownChart.vue")['default']
    'DashboardCreditCardStatisticsChart': typeof import("../components/Dashboard/CreditCard/StatisticsChart.vue")['default']
    'DashboardCreditCardTotalBalance': typeof import("../components/Dashboard/CreditCard/TotalBalance.vue")['default']
    'DashboardCreditCardTotalExpense': typeof import("../components/Dashboard/CreditCard/TotalExpense.vue")['default']
    'DashboardCryptoBinanceChart': typeof import("../components/Dashboard/Crypto/BinanceChart.vue")['default']
    'DashboardCryptoBitcoinChart': typeof import("../components/Dashboard/Crypto/BitcoinChart.vue")['default']
    'DashboardCryptoCardanoChart': typeof import("../components/Dashboard/Crypto/CardanoChart.vue")['default']
    'DashboardCryptoRankings': typeof import("../components/Dashboard/Crypto/CryptoRankings.vue")['default']
    'DashboardCryptoCryptocurrencyWatchList': typeof import("../components/Dashboard/Crypto/CryptocurrencyWatchList.vue")['default']
    'DashboardCryptoEthereumChart': typeof import("../components/Dashboard/Crypto/EthereumChart.vue")['default']
    'DashboardCryptoExchangeCoin': typeof import("../components/Dashboard/Crypto/ExchangeCoin.vue")['default']
    'DashboardCryptoMarketPriceStatisticsChart': typeof import("../components/Dashboard/Crypto/MarketPriceStatisticsChart.vue")['default']
    'DashboardCryptoPortfolio': typeof import("../components/Dashboard/Crypto/Portfolio.vue")['default']
    'DashboardCryptoSolanaChart': typeof import("../components/Dashboard/Crypto/SolanaChart.vue")['default']
    'DashboardCryptoTransactionHistory': typeof import("../components/Dashboard/Crypto/TransactionHistory.vue")['default']
    'DashboardCryptoPerformanceBreadcrumb': typeof import("../components/Dashboard/CryptoPerformance/Breadcrumb.vue")['default']
    'DashboardCryptoPerformanceComparativeAnalysisChart': typeof import("../components/Dashboard/CryptoPerformance/ComparativeAnalysisChart.vue")['default']
    'DashboardCryptoPerformanceCryptoMarketCap': typeof import("../components/Dashboard/CryptoPerformance/CryptoMarketCap.vue")['default']
    'DashboardCryptoPerformanceIndividualAssetPerformance': typeof import("../components/Dashboard/CryptoPerformance/IndividualAssetPerformance.vue")['default']
    'DashboardCryptoPerformanceMarketPerformanceChart': typeof import("../components/Dashboard/CryptoPerformance/MarketPerformanceChart.vue")['default']
    'DashboardCryptoPerformanceMetricsChart': typeof import("../components/Dashboard/CryptoPerformance/PerformanceMetricsChart.vue")['default']
    'DashboardCryptoPerformancePerInvestmentChart': typeof import("../components/Dashboard/CryptoPerformance/PerformancePerInvestmentChart.vue")['default']
    'DashboardCryptoPerformancePortfolioValue': typeof import("../components/Dashboard/CryptoPerformance/PortfolioValue.vue")['default']
    'DashboardCryptoPerformanceRiskStabilityIndicatorsChart': typeof import("../components/Dashboard/CryptoPerformance/RiskStabilityIndicatorsChart.vue")['default']
    'DashboardCryptoPerformanceTransactionsHistory': typeof import("../components/Dashboard/CryptoPerformance/TransactionsHistory.vue")['default']
    'DashboardCryptoTraderAssetAllocationChart': typeof import("../components/Dashboard/CryptoTrader/AssetAllocationChart.vue")['default']
    'DashboardCryptoTraderCryptoStatsPanel': typeof import("../components/Dashboard/CryptoTrader/CryptoStatsPanel.vue")['default']
    'DashboardCryptoTraderGainersLosers': typeof import("../components/Dashboard/CryptoTrader/GainersLosers.vue")['default']
    'DashboardCryptoTraderLivePriceTracker': typeof import("../components/Dashboard/CryptoTrader/LivePriceTracker.vue")['default']
    'DashboardCryptoTraderMarketSentimentIndicatorChart': typeof import("../components/Dashboard/CryptoTrader/MarketSentimentIndicatorChart.vue")['default']
    'DashboardCryptoTraderPortfolioDistributionChart': typeof import("../components/Dashboard/CryptoTrader/PortfolioDistributionChart.vue")['default']
    'DashboardCryptoTraderPriceMovementChart': typeof import("../components/Dashboard/CryptoTrader/PriceMovementChart.vue")['default']
    'DashboardCryptoTraderProfitLossChart': typeof import("../components/Dashboard/CryptoTrader/ProfitLossChart.vue")['default']
    'DashboardCryptoTraderRecentTransactions': typeof import("../components/Dashboard/CryptoTrader/RecentTransactions.vue")['default']
    'DashboardCryptoTraderRiskExposureChart': typeof import("../components/Dashboard/CryptoTrader/RiskExposureChart.vue")['default']
    'DashboardCryptoTraderTradesPerMonthChart': typeof import("../components/Dashboard/CryptoTrader/TradesPerMonthChart.vue")['default']
    'DashboardCryptoTraderTradingVolumeChart': typeof import("../components/Dashboard/CryptoTrader/TradingVolumeChart.vue")['default']
    'DashboardDoctorWelcome': typeof import("../components/Dashboard/Doctor/DoctorWelcome.vue")['default']
    'DashboardDoctorIncomeExpenseChart': typeof import("../components/Dashboard/Doctor/IncomeExpenseChart.vue")['default']
    'DashboardDoctorMyRecentPatients': typeof import("../components/Dashboard/Doctor/MyRecentPatients.vue")['default']
    'DashboardDoctorPatientDistributionChart': typeof import("../components/Dashboard/Doctor/PatientDistributionChart.vue")['default']
    'DashboardDoctorPatientRetentionChart': typeof import("../components/Dashboard/Doctor/PatientRetentionChart.vue")['default']
    'DashboardDoctorRecentLabReports': typeof import("../components/Dashboard/Doctor/RecentLabReports.vue")['default']
    'DashboardDoctorStatsAppointments': typeof import("../components/Dashboard/Doctor/Stats/Appointments.vue")['default']
    'DashboardDoctorStatsEarnings': typeof import("../components/Dashboard/Doctor/Stats/Earnings.vue")['default']
    'DashboardDoctorStatsOperations': typeof import("../components/Dashboard/Doctor/Stats/Operations.vue")['default']
    'DashboardDoctorStatsPatients': typeof import("../components/Dashboard/Doctor/Stats/Patients.vue")['default']
    'DashboardDoctorStats': typeof import("../components/Dashboard/Doctor/Stats/index.vue")['default']
    'DashboardDoctorTodaySchedule': typeof import("../components/Dashboard/Doctor/TodaySchedule.vue")['default']
    'DashboardDoctorUpgradePlan': typeof import("../components/Dashboard/Doctor/UpgradePlan.vue")['default']
    'DashboardFinanceAccountPayable': typeof import("../components/Dashboard/Finance/AccountPayable.vue")['default']
    'DashboardFinanceAccountsReceivable': typeof import("../components/Dashboard/Finance/AccountsReceivable.vue")['default']
    'DashboardFinanceAddCardDetailModal': typeof import("../components/Dashboard/Finance/AddCardDetailModal.vue")['default']
    'DashboardFinanceCashEndOfTheMonthChart': typeof import("../components/Dashboard/Finance/CashEndOfTheMonthChart.vue")['default']
    'DashboardFinanceDebitCard': typeof import("../components/Dashboard/Finance/DebitCard.vue")['default']
    'DashboardFinanceExpenseBreakdownChart': typeof import("../components/Dashboard/Finance/ExpenseBreakdownChart.vue")['default']
    'DashboardFinanceIncomeSourceChart': typeof import("../components/Dashboard/Finance/IncomeSourceChart.vue")['default']
    'DashboardFinanceNetProfitChart': typeof import("../components/Dashboard/Finance/NetProfitChart.vue")['default']
    'DashboardFinanceStaticChart': typeof import("../components/Dashboard/Finance/StaticChart.vue")['default']
    'DashboardFinanceTotalExpenses': typeof import("../components/Dashboard/Finance/TotalExpenses.vue")['default']
    'DashboardFinanceTotalIncome': typeof import("../components/Dashboard/Finance/TotalIncome.vue")['default']
    'DashboardFinanceTransactionHistory': typeof import("../components/Dashboard/Finance/TransactionHistory.vue")['default']
    'DashboardFinanceWeeklyExpensesChart': typeof import("../components/Dashboard/Finance/WeeklyExpensesChart.vue")['default']
    'DashboardHRMDateRangePicker': typeof import("../components/Dashboard/HRM/DateRangePicker.vue")['default']
    'DashboardHRMEmployeeAttendanceTrendsChart': typeof import("../components/Dashboard/HRM/EmployeeAttendanceTrendsChart.vue")['default']
    'DashboardHRMEmployeeLeaveRequest': typeof import("../components/Dashboard/HRM/EmployeeLeaveRequest.vue")['default']
    'DashboardHRMEmployeeList': typeof import("../components/Dashboard/HRM/EmployeeList.vue")['default']
    'DashboardHRMEmployeeSalaryChart': typeof import("../components/Dashboard/HRM/EmployeeSalaryChart.vue")['default']
    'DashboardHRMEmployeeWorkFormatChart': typeof import("../components/Dashboard/HRM/EmployeeWorkFormatChart.vue")['default']
    'DashboardHRMNewEmployees': typeof import("../components/Dashboard/HRM/NewEmployees.vue")['default']
    'DashboardHRMResignedEmployees': typeof import("../components/Dashboard/HRM/ResignedEmployees.vue")['default']
    'DashboardHRMTotalEmployees': typeof import("../components/Dashboard/HRM/TotalEmployees.vue")['default']
    'DashboardHRMWelcomeBack': typeof import("../components/Dashboard/HRM/WelcomeBack.vue")['default']
    'DashboardHelpDeskCongratulations': typeof import("../components/Dashboard/HelpDesk/Congratulations.vue")['default']
    'DashboardHelpDeskCustomerSatisfactionChart': typeof import("../components/Dashboard/HelpDesk/CustomerSatisfactionChart.vue")['default']
    'DashboardHelpDeskNewAndSolvedTicketsChart': typeof import("../components/Dashboard/HelpDesk/NewAndSolvedTicketsChart.vue")['default']
    'DashboardHelpDeskPerformanceOfAgents': typeof import("../components/Dashboard/HelpDesk/PerformanceOfAgents.vue")['default']
    'DashboardHelpDeskRecentCustomerRatings': typeof import("../components/Dashboard/HelpDesk/RecentCustomerRatings.vue")['default']
    'DashboardHelpDeskResponseTimeChart': typeof import("../components/Dashboard/HelpDesk/ResponseTimeChart.vue")['default']
    'DashboardHelpDeskSupportOverviewChart': typeof import("../components/Dashboard/HelpDesk/SupportOverviewChart.vue")['default']
    'DashboardHelpDeskTicketsDueChart': typeof import("../components/Dashboard/HelpDesk/TicketsDueChart.vue")['default']
    'DashboardHelpDeskTicketsInProgressChart': typeof import("../components/Dashboard/HelpDesk/TicketsInProgressChart.vue")['default']
    'DashboardHelpDeskTicketsNewOpenChart': typeof import("../components/Dashboard/HelpDesk/TicketsNewOpenChart.vue")['default']
    'DashboardHelpDeskTicketsResolvedChart': typeof import("../components/Dashboard/HelpDesk/TicketsResolvedChart.vue")['default']
    'DashboardHelpDeskTicketsStatusChart': typeof import("../components/Dashboard/HelpDesk/TicketsStatusChart.vue")['default']
    'DashboardHelpDeskToDoList': typeof import("../components/Dashboard/HelpDesk/ToDoList.vue")['default']
    'DashboardHospitalBedOccupancyRateChart': typeof import("../components/Dashboard/Hospital/BedOccupancyRateChart.vue")['default']
    'DashboardHospitalCriticalPatientsChart': typeof import("../components/Dashboard/Hospital/CriticalPatientsChart.vue")['default']
    'DashboardHospitalDateRangePicker': typeof import("../components/Dashboard/Hospital/DateRangePicker.vue")['default']
    'DashboardHospitalEmergencyRoomVisitsChart': typeof import("../components/Dashboard/Hospital/EmergencyRoomVisitsChart.vue")['default']
    'DashboardHospitalEarnings': typeof import("../components/Dashboard/Hospital/HospitalEarnings.vue")['default']
    'DashboardHospitalOverallVisitorsChart': typeof import("../components/Dashboard/Hospital/OverallVisitorsChart.vue")['default']
    'DashboardHospitalPatientAdmissionsDischargesChart': typeof import("../components/Dashboard/Hospital/PatientAdmissionsDischargesChart.vue")['default']
    'DashboardHospitalPatientAppointments': typeof import("../components/Dashboard/Hospital/PatientAppointments.vue")['default']
    'DashboardHospitalPatientByAgeChart': typeof import("../components/Dashboard/Hospital/PatientByAgeChart.vue")['default']
    'DashboardHospitalPatientsChart': typeof import("../components/Dashboard/Hospital/PatientsChart.vue")['default']
    'DashboardHospitalScheduleAppointment': typeof import("../components/Dashboard/Hospital/ScheduleAppointment.vue")['default']
    'DashboardHospitalYourScheduleToday': typeof import("../components/Dashboard/Hospital/YourScheduleToday.vue")['default']
    'DashboardHotelCustomerReviews': typeof import("../components/Dashboard/Hotel/CustomerReviews.vue")['default']
    'DashboardHotelGuestActivityChart': typeof import("../components/Dashboard/Hotel/GuestActivityChart.vue")['default']
    'DashboardHotelPopularRooms': typeof import("../components/Dashboard/Hotel/PopularRooms.vue")['default']
    'DashboardHotelRecentBookings': typeof import("../components/Dashboard/Hotel/RecentBookings.vue")['default']
    'DashboardHotelRoomsAvailabilityChart': typeof import("../components/Dashboard/Hotel/RoomsAvailabilityChart.vue")['default']
    'DashboardHotelStatsCheckIn': typeof import("../components/Dashboard/Hotel/Stats/CheckIn.vue")['default']
    'DashboardHotelStatsCheckOut': typeof import("../components/Dashboard/Hotel/Stats/CheckOut.vue")['default']
    'DashboardHotelStatsNewBookings': typeof import("../components/Dashboard/Hotel/Stats/NewBookings.vue")['default']
    'DashboardHotelStats': typeof import("../components/Dashboard/Hotel/Stats/index.vue")['default']
    'DashboardHotelUpcomingVIPReservations': typeof import("../components/Dashboard/Hotel/UpcomingVIPReservations.vue")['default']
    'DashboardLMSCourses': typeof import("../components/Dashboard/LMS/Courses.vue")['default']
    'DashboardLMSCoursesSalesChart': typeof import("../components/Dashboard/LMS/CoursesSalesChart.vue")['default']
    'DashboardLMSEnrolledByCountries': typeof import("../components/Dashboard/LMS/EnrolledByCountries.vue")['default']
    'DashboardLMSGroupLessons': typeof import("../components/Dashboard/LMS/GroupLessons.vue")['default']
    'DashboardLMSOurTopCourses': typeof import("../components/Dashboard/LMS/OurTopCourses.vue")['default']
    'DashboardLMSStudentsInterestedTopicsChart': typeof import("../components/Dashboard/LMS/StudentsInterestedTopicsChart.vue")['default']
    'DashboardLMSStudentsProgress': typeof import("../components/Dashboard/LMS/StudentsProgress.vue")['default']
    'DashboardLMSTimeSpentChart': typeof import("../components/Dashboard/LMS/TimeSpentChart.vue")['default']
    'DashboardLMSTopInstructors': typeof import("../components/Dashboard/LMS/TopInstructors.vue")['default']
    'DashboardLMSTotalCourses': typeof import("../components/Dashboard/LMS/TotalCourses.vue")['default']
    'DashboardLMSTotalEnrolled': typeof import("../components/Dashboard/LMS/TotalEnrolled.vue")['default']
    'DashboardLMSTotalMentors': typeof import("../components/Dashboard/LMS/TotalMentors.vue")['default']
    'DashboardLMSWelcomeDashboard': typeof import("../components/Dashboard/LMS/WelcomeDashboard.vue")['default']
    'DashboardMarketingAvatarPreview': typeof import("../components/Dashboard/Marketing/AvatarPreview.vue")['default']
    'DashboardMarketingCampaignsContent': typeof import("../components/Dashboard/Marketing/CampaignsContent.vue")['default']
    'DashboardMarketingChannelsContent': typeof import("../components/Dashboard/Marketing/ChannelsContent.vue")['default']
    'DashboardMarketingCreateCampaignsModal': typeof import("../components/Dashboard/Marketing/CreateCampaignsModal.vue")['default']
    'DashboardMarketingExternalLinks': typeof import("../components/Dashboard/Marketing/ExternalLinks.vue")['default']
    'DashboardMarketingHighlightsContent': typeof import("../components/Dashboard/Marketing/HighlightsContent.vue")['default']
    'DashboardMarketingInstagramCampaignsChart': typeof import("../components/Dashboard/Marketing/InstagramCampaignsChart.vue")['default']
    'DashboardMarketingInstagramSubscriberChart': typeof import("../components/Dashboard/Marketing/InstagramSubscriberChart.vue")['default']
    'DashboardMarketingNewMarketingTool': typeof import("../components/Dashboard/Marketing/NewMarketingTool.vue")['default']
    'DashboardMarketingNewMobileApp': typeof import("../components/Dashboard/Marketing/NewMobileApp.vue")['default']
    'DashboardMarketingPerformanceOverviewChart': typeof import("../components/Dashboard/Marketing/PerformanceOverviewChart.vue")['default']
    'DashboardMarketingStatusContent': typeof import("../components/Dashboard/Marketing/StatusContent.vue")['default']
    'DashboardNFTActiveAuctions': typeof import("../components/Dashboard/NFT/ActiveAuctions.vue")['default']
    'DashboardNFTCreateNFT': typeof import("../components/Dashboard/NFT/CreateNFT.vue")['default']
    'DashboardNFTEthereumRateChart': typeof import("../components/Dashboard/NFT/EthereumRateChart.vue")['default']
    'DashboardNFTEthereumRateFiveChart': typeof import("../components/Dashboard/NFT/EthereumRateFiveChart.vue")['default']
    'DashboardNFTEthereumRateFourChart': typeof import("../components/Dashboard/NFT/EthereumRateFourChart.vue")['default']
    'DashboardNFTEthereumRateTab': typeof import("../components/Dashboard/NFT/EthereumRateTab.vue")['default']
    'DashboardNFTEthereumRateThreeChart': typeof import("../components/Dashboard/NFT/EthereumRateThreeChart.vue")['default']
    'DashboardNFTEthereumRateTwoChart': typeof import("../components/Dashboard/NFT/EthereumRateTwoChart.vue")['default']
    'DashboardNFTFeaturedNFTArtworks': typeof import("../components/Dashboard/NFT/FeaturedNFTArtworks.vue")['default']
    'DashboardNFTHistoryOfBids': typeof import("../components/Dashboard/NFT/HistoryOfBids.vue")['default']
    'DashboardNFTManageYourNFT': typeof import("../components/Dashboard/NFT/ManageYourNFT.vue")['default']
    'DashboardNFTMostPopularSellers': typeof import("../components/Dashboard/NFT/MostPopularSellers.vue")['default']
    'DashboardNFTSlideItem': typeof import("../components/Dashboard/NFT/NFTSlideItem.vue")['default']
    'DashboardNFTNewMobileApp': typeof import("../components/Dashboard/NFT/NewMobileApp.vue")['default']
    'DashboardNFTTopCollections': typeof import("../components/Dashboard/NFT/TopCollections.vue")['default']
    'DashboardNFTTopNFTs': typeof import("../components/Dashboard/NFT/TopNFTs.vue")['default']
    'DashboardNFTWorldwideTopCreators': typeof import("../components/Dashboard/NFT/WorldwideTopCreators.vue")['default']
    'DashboardPOSSystemCategoriesTab': typeof import("../components/Dashboard/POSSystem/CategoriesTab.vue")['default']
    'DashboardPOSSystemCustomerSegmentation': typeof import("../components/Dashboard/POSSystem/CustomerSegmentation.vue")['default']
    'DashboardPOSSystemOrderDetails': typeof import("../components/Dashboard/POSSystem/OrderDetails.vue")['default']
    'DashboardPOSSystemQuantityCounter': typeof import("../components/Dashboard/POSSystem/QuantityCounter.vue")['default']
    'DashboardPOSSystemSalesAnalyticsSalesByCategory': typeof import("../components/Dashboard/POSSystem/SalesAnalytics/SalesByCategory.vue")['default']
    'DashboardPOSSystemSalesAnalyticsSalesOverTime': typeof import("../components/Dashboard/POSSystem/SalesAnalytics/SalesOverTime.vue")['default']
    'DashboardPOSSystemSalesAnalytics': typeof import("../components/Dashboard/POSSystem/SalesAnalytics/index.vue")['default']
    'DashboardPOSSystemStats': typeof import("../components/Dashboard/POSSystem/Stats.vue")['default']
    'DashboardPodcastFeatured': typeof import("../components/Dashboard/Podcast/Featured.vue")['default']
    'DashboardPodcastListenerAnalyticsChart': typeof import("../components/Dashboard/Podcast/ListenerAnalyticsChart.vue")['default']
    'DashboardPodcastMostPopular': typeof import("../components/Dashboard/Podcast/MostPopular.vue")['default']
    'DashboardPodcastPlayer': typeof import("../components/Dashboard/Podcast/Player.vue")['default']
    'DashboardPodcastPopularHosts': typeof import("../components/Dashboard/Podcast/PopularHosts.vue")['default']
    'DashboardPodcastRecentlyPlayed': typeof import("../components/Dashboard/Podcast/RecentlyPlayed.vue")['default']
    'DashboardPodcastSalesByGenderChart': typeof import("../components/Dashboard/Podcast/SalesByGenderChart.vue")['default']
    'DashboardPodcastTodayEarningsChart': typeof import("../components/Dashboard/Podcast/TodayEarningsChart.vue")['default']
    'DashboardPodcastTopPodcasts': typeof import("../components/Dashboard/Podcast/TopPodcasts.vue")['default']
    'DashboardPodcastUpcomingEpisodes': typeof import("../components/Dashboard/Podcast/UpcomingEpisodes.vue")['default']
    'DashboardProjectManagementAllProjects': typeof import("../components/Dashboard/ProjectManagement/AllProjects.vue")['default']
    'DashboardProjectManagementMyTasks': typeof import("../components/Dashboard/ProjectManagement/MyTasks.vue")['default']
    'DashboardProjectManagementProjectsAnalysisChart': typeof import("../components/Dashboard/ProjectManagement/ProjectsAnalysisChart.vue")['default']
    'DashboardProjectManagementProjectsOverview': typeof import("../components/Dashboard/ProjectManagement/ProjectsOverview.vue")['default']
    'DashboardProjectManagementProjectsProgressChart': typeof import("../components/Dashboard/ProjectManagement/ProjectsProgressChart.vue")['default']
    'DashboardProjectManagementProjectsRoadmapChart': typeof import("../components/Dashboard/ProjectManagement/ProjectsRoadmapChart.vue")['default']
    'DashboardProjectManagementTasksOverviewChart': typeof import("../components/Dashboard/ProjectManagement/TasksOverviewChart.vue")['default']
    'DashboardProjectManagementTeamMembers': typeof import("../components/Dashboard/ProjectManagement/TeamMembers.vue")['default']
    'DashboardProjectManagementToDoList': typeof import("../components/Dashboard/ProjectManagement/ToDoList.vue")['default']
    'DashboardProjectManagementWorkingSchedule': typeof import("../components/Dashboard/ProjectManagement/WorkingSchedule.vue")['default']
    'DashboardRealEstateActiveTotalProperty': typeof import("../components/Dashboard/RealEstate/ActiveTotalProperty.vue")['default']
    'DashboardRealEstateCustomerReviews': typeof import("../components/Dashboard/RealEstate/CustomerReviews.vue")['default']
    'DashboardRealEstateLatestTransaction': typeof import("../components/Dashboard/RealEstate/LatestTransaction.vue")['default']
    'DashboardRealEstateMostSalesLocation': typeof import("../components/Dashboard/RealEstate/MostSalesLocation.vue")['default']
    'DashboardRealEstateNewCustomers': typeof import("../components/Dashboard/RealEstate/NewCustomers.vue")['default']
    'DashboardRealEstateNewListingsSoldPropertiesChart': typeof import("../components/Dashboard/RealEstate/NewListingsSoldPropertiesChart.vue")['default']
    'DashboardRealEstatePropertiesForRentChart': typeof import("../components/Dashboard/RealEstate/PropertiesForRentChart.vue")['default']
    'DashboardRealEstatePropertiesForSaleChart': typeof import("../components/Dashboard/RealEstate/PropertiesForSaleChart.vue")['default']
    'DashboardRealEstateRecentProperty': typeof import("../components/Dashboard/RealEstate/RecentProperty.vue")['default']
    'DashboardRealEstateRentalIncomeChart': typeof import("../components/Dashboard/RealEstate/RentalIncomeChart.vue")['default']
    'DashboardRealEstateRevenueChart': typeof import("../components/Dashboard/RealEstate/RevenueChart.vue")['default']
    'DashboardRealEstateSocialSearchChart': typeof import("../components/Dashboard/RealEstate/SocialSearchChart.vue")['default']
    'DashboardRealEstateTopProperty': typeof import("../components/Dashboard/RealEstate/TopProperty.vue")['default']
    'DashboardRealEstateAgentClientRatings': typeof import("../components/Dashboard/RealEstateAgent/ClientRatings.vue")['default']
    'DashboardRealEstateAgentDownloadApp': typeof import("../components/Dashboard/RealEstateAgent/DownloadApp.vue")['default']
    'DashboardRealEstateAgentLatestTransactions': typeof import("../components/Dashboard/RealEstateAgent/LatestTransactions.vue")['default']
    'DashboardRealEstateAgentMyFeaturedListings': typeof import("../components/Dashboard/RealEstateAgent/MyFeaturedListings.vue")['default']
    'DashboardRealEstateAgentRecentClients': typeof import("../components/Dashboard/RealEstateAgent/RecentClients.vue")['default']
    'DashboardRealEstateAgentRevenueGoalProgress': typeof import("../components/Dashboard/RealEstateAgent/RevenueGoalProgress.vue")['default']
    'DashboardRealEstateAgentSalesByCountry': typeof import("../components/Dashboard/RealEstateAgent/SalesByCountry.vue")['default']
    'DashboardRealEstateAgentStats': typeof import("../components/Dashboard/RealEstateAgent/Stats.vue")['default']
    'DashboardRealEstateAgentTopChannels': typeof import("../components/Dashboard/RealEstateAgent/TopChannels.vue")['default']
    'DashboardRealEstateAgentTotalRevenueChart': typeof import("../components/Dashboard/RealEstateAgent/TotalRevenueChart.vue")['default']
    'DashboardRealEstateAgentWelcomeRealEstateAgent': typeof import("../components/Dashboard/RealEstateAgent/WelcomeRealEstateAgent.vue")['default']
    'DashboardRestaurantCustomerRatings': typeof import("../components/Dashboard/Restaurant/CustomerRatings.vue")['default']
    'DashboardRestaurantExpense': typeof import("../components/Dashboard/Restaurant/Expense.vue")['default']
    'DashboardRestaurantLowStockAlerts': typeof import("../components/Dashboard/Restaurant/LowStockAlerts.vue")['default']
    'DashboardRestaurantOrderSummaryChart': typeof import("../components/Dashboard/Restaurant/OrderSummaryChart.vue")['default']
    'DashboardRestaurantPendingOrdersChart': typeof import("../components/Dashboard/Restaurant/PendingOrdersChart.vue")['default']
    'DashboardRestaurantRecentOrdersList': typeof import("../components/Dashboard/Restaurant/RecentOrdersList.vue")['default']
    'DashboardRestaurantStatsToday': typeof import("../components/Dashboard/Restaurant/RestaurantStatsToday.vue")['default']
    'DashboardRestaurantRevenue': typeof import("../components/Dashboard/Restaurant/Revenue.vue")['default']
    'DashboardRestaurantRevenueByBranches': typeof import("../components/Dashboard/Restaurant/RevenueByBranches.vue")['default']
    'DashboardRestaurantRevenueExpenseChart': typeof import("../components/Dashboard/Restaurant/RevenueExpenseChart.vue")['default']
    'DashboardRestaurantStaffPerformanceScores': typeof import("../components/Dashboard/Restaurant/StaffPerformanceScores.vue")['default']
    'DashboardRestaurantTickets': typeof import("../components/Dashboard/Restaurant/Tickets.vue")['default']
    'DashboardRestaurantTopSellingItems': typeof import("../components/Dashboard/Restaurant/TopSellingItems.vue")['default']
    'DashboardRestaurantTotalOrdersChart': typeof import("../components/Dashboard/Restaurant/TotalOrdersChart.vue")['default']
    'DashboardSaaSActiveUserChart': typeof import("../components/Dashboard/SaaS/ActiveUserChart.vue")['default']
    'DashboardSaaSActiveUsers': typeof import("../components/Dashboard/SaaS/ActiveUsers.vue")['default']
    'DashboardSaaSActiveUsersChart': typeof import("../components/Dashboard/SaaS/ActiveUsersChart.vue")['default']
    'DashboardSaaSConversionChart': typeof import("../components/Dashboard/SaaS/ConversionChart.vue")['default']
    'DashboardSaaSGrossRevenueChart': typeof import("../components/Dashboard/SaaS/GrossRevenueChart.vue")['default']
    'DashboardSaaSLatestTransaction': typeof import("../components/Dashboard/SaaS/LatestTransaction.vue")['default']
    'DashboardSaaSPaymentChart': typeof import("../components/Dashboard/SaaS/PaymentChart.vue")['default']
    'DashboardSaaSProductTradeConditionChart': typeof import("../components/Dashboard/SaaS/ProductTradeConditionChart.vue")['default']
    'DashboardSaaSRevenueChart': typeof import("../components/Dashboard/SaaS/RevenueChart.vue")['default']
    'DashboardSaaSSalesByCountry': typeof import("../components/Dashboard/SaaS/SalesByCountry.vue")['default']
    'DashboardSaaSTopRefers': typeof import("../components/Dashboard/SaaS/TopRefers.vue")['default']
    'DashboardSaaSUpgradePlans': typeof import("../components/Dashboard/SaaS/UpgradePlans.vue")['default']
    'DashboardSalesGrossEarningsChart': typeof import("../components/Dashboard/Sales/GrossEarningsChart.vue")['default']
    'DashboardSalesRealTimeSalesChart': typeof import("../components/Dashboard/Sales/RealTimeSalesChart.vue")['default']
    'DashboardSalesRecentEarningsChart': typeof import("../components/Dashboard/Sales/RecentEarningsChart.vue")['default']
    'DashboardSalesRecentOrders': typeof import("../components/Dashboard/Sales/RecentOrders.vue")['default']
    'DashboardSalesByLocations': typeof import("../components/Dashboard/Sales/SalesByLocations.vue")['default']
    'DashboardSalesOverviewChart': typeof import("../components/Dashboard/Sales/SalesOverviewChart.vue")['default']
    'DashboardSalesTotalOrdersChart': typeof import("../components/Dashboard/Sales/TotalOrdersChart.vue")['default']
    'DashboardSalesTotalProfitChart': typeof import("../components/Dashboard/Sales/TotalProfitChart.vue")['default']
    'DashboardSalesTotalRevenueChart': typeof import("../components/Dashboard/Sales/TotalRevenueChart.vue")['default']
    'DashboardSalesTotalSalesChart': typeof import("../components/Dashboard/Sales/TotalSalesChart.vue")['default']
    'DashboardSalesTransactionHistory': typeof import("../components/Dashboard/Sales/TransactionHistory.vue")['default']
    'DashboardSalesWelcomeBack': typeof import("../components/Dashboard/Sales/WelcomeBack.vue")['default']
    'DashboardSchoolAttendanceAnalyticsChart': typeof import("../components/Dashboard/School/AttendanceAnalyticsChart.vue")['default']
    'DashboardSchoolNewAdmissionsChart': typeof import("../components/Dashboard/School/NewAdmissionsChart.vue")['default']
    'DashboardSchoolNoticeBoard': typeof import("../components/Dashboard/School/NoticeBoard.vue")['default']
    'DashboardSchoolOverview': typeof import("../components/Dashboard/School/SchoolOverview.vue")['default']
    'DashboardSchoolStatsAttendanceToday': typeof import("../components/Dashboard/School/Stats/AttendanceToday.vue")['default']
    'DashboardSchoolStatsTotalStudents': typeof import("../components/Dashboard/School/Stats/TotalStudents.vue")['default']
    'DashboardSchoolStatsTotalTeachers': typeof import("../components/Dashboard/School/Stats/TotalTeachers.vue")['default']
    'DashboardSchoolStats': typeof import("../components/Dashboard/School/Stats/index.vue")['default']
    'DashboardSchoolStudentsList': typeof import("../components/Dashboard/School/StudentsList.vue")['default']
    'DashboardSchoolStudentsOverviewChart': typeof import("../components/Dashboard/School/StudentsOverviewChart.vue")['default']
    'DashboardSchoolTeachers': typeof import("../components/Dashboard/School/Teachers.vue")['default']
    'DashboardSchoolUpcomingEvents': typeof import("../components/Dashboard/School/UpcomingEvents.vue")['default']
    'DashboardShipmentAverageDeliveryTimeChart': typeof import("../components/Dashboard/Shipment/AverageDeliveryTimeChart.vue")['default']
    'DashboardShipmentChatContent': typeof import("../components/Dashboard/Shipment/ChatContent.vue")['default']
    'DashboardShipmentLiveShipmentStatusChart': typeof import("../components/Dashboard/Shipment/LiveShipmentStatusChart.vue")['default']
    'DashboardShipmentOnTimeDeliveryChart': typeof import("../components/Dashboard/Shipment/OnTimeDeliveryChart.vue")['default']
    'DashboardShipmentDeliveredChart': typeof import("../components/Dashboard/Shipment/ShipmentDeliveredChart.vue")['default']
    'DashboardShipmentList': typeof import("../components/Dashboard/Shipment/ShipmentList.vue")['default']
    'DashboardShipmentToTopCountries': typeof import("../components/Dashboard/Shipment/ShipmentToTopCountries.vue")['default']
    'DashboardShipmentTodaysShipmentsChart': typeof import("../components/Dashboard/Shipment/TodaysShipmentsChart.vue")['default']
    'DashboardShipmentTopShippingMethodsChart': typeof import("../components/Dashboard/Shipment/TopShippingMethodsChart.vue")['default']
    'DashboardShipmentTotalCustomer': typeof import("../components/Dashboard/Shipment/TotalCustomer.vue")['default']
    'DashboardShipmentTotalIncome': typeof import("../components/Dashboard/Shipment/TotalIncome.vue")['default']
    'DashboardShipmentTotalOrder': typeof import("../components/Dashboard/Shipment/TotalOrder.vue")['default']
    'DashboardShipmentTotalShipment': typeof import("../components/Dashboard/Shipment/TotalShipment.vue")['default']
    'DashboardShipmentTrackingOrder': typeof import("../components/Dashboard/Shipment/TrackingOrder.vue")['default']
    'DashboardSocialMediaFacebookCampaignOverviewChart': typeof import("../components/Dashboard/SocialMedia/FacebookCampaignOverviewChart.vue")['default']
    'DashboardSocialMediaFacebookFollowers': typeof import("../components/Dashboard/SocialMedia/FacebookFollowers.vue")['default']
    'DashboardSocialMediaFollowersByGenderChart': typeof import("../components/Dashboard/SocialMedia/FollowersByGenderChart.vue")['default']
    'DashboardSocialMediaInstagramFollowers': typeof import("../components/Dashboard/SocialMedia/InstagramFollowers.vue")['default']
    'DashboardSocialMediaLinkedInFollowers': typeof import("../components/Dashboard/SocialMedia/LinkedInFollowers.vue")['default']
    'DashboardSocialMediaLinkedInNetFollowersChart': typeof import("../components/Dashboard/SocialMedia/LinkedInNetFollowersChart.vue")['default']
    'DashboardSocialMediaRecentInstagramFollowers': typeof import("../components/Dashboard/SocialMedia/RecentInstagramFollowers.vue")['default']
    'DashboardSocialMediaSuggestions': typeof import("../components/Dashboard/SocialMedia/Suggestions.vue")['default']
    'DashboardSocialMediaTikTokFollowers': typeof import("../components/Dashboard/SocialMedia/TikTokFollowers.vue")['default']
    'DashboardSocialMediaUpgradePlan': typeof import("../components/Dashboard/SocialMedia/UpgradePlan.vue")['default']
    'DashboardSocialMediaXFollowers': typeof import("../components/Dashboard/SocialMedia/XFollowers.vue")['default']
    'DashboardSocialMediaYouTubeSubscribers': typeof import("../components/Dashboard/SocialMedia/YouTubeSubscribers.vue")['default']
    'DashboardStoreAnalysisCustomerVisits': typeof import("../components/Dashboard/StoreAnalysis/CustomerVisits.vue")['default']
    'DashboardStoreAnalysisGrossRevenue': typeof import("../components/Dashboard/StoreAnalysis/GrossRevenue.vue")['default']
    'DashboardStoreAnalysisRecentSales': typeof import("../components/Dashboard/StoreAnalysis/RecentSales.vue")['default']
    'DashboardStoreAnalysisSAWelcome': typeof import("../components/Dashboard/StoreAnalysis/SAWelcome.vue")['default']
    'DashboardStoreAnalysisSalesByCategoryChart': typeof import("../components/Dashboard/StoreAnalysis/SalesByCategoryChart.vue")['default']
    'DashboardStoreAnalysisSalesByGenderChart': typeof import("../components/Dashboard/StoreAnalysis/SalesByGenderChart.vue")['default']
    'DashboardStoreAnalysisSalesThisMonthChart': typeof import("../components/Dashboard/StoreAnalysis/SalesThisMonthChart.vue")['default']
    'DashboardStoreAnalysisStats': typeof import("../components/Dashboard/StoreAnalysis/Stats.vue")['default']
    'DashboardStoreAnalysisStockAlerts': typeof import("../components/Dashboard/StoreAnalysis/StockAlerts.vue")['default']
    'DashboardStoreAnalysisTopSellingProducts': typeof import("../components/Dashboard/StoreAnalysis/TopSellingProducts.vue")['default']
    'DashboardECommerceOrderSummaryChart': typeof import("../components/Dashboard/eCommerce/OrderSummaryChart.vue")['default']
    'DashboardECommerceRecentOrders': typeof import("../components/Dashboard/eCommerce/RecentOrders.vue")['default']
    'DashboardECommerceRecentTransactions': typeof import("../components/Dashboard/eCommerce/RecentTransactions.vue")['default']
    'DashboardECommerceReturningCustomerRateChart': typeof import("../components/Dashboard/eCommerce/ReturningCustomerRateChart.vue")['default']
    'DashboardECommerceSalesByLocations': typeof import("../components/Dashboard/eCommerce/SalesByLocations.vue")['default']
    'DashboardECommerceTopSellingProducts': typeof import("../components/Dashboard/eCommerce/TopSellingProducts.vue")['default']
    'DashboardECommerceTotalCustomersChart': typeof import("../components/Dashboard/eCommerce/TotalCustomersChart.vue")['default']
    'DashboardECommerceTotalOrdersChart': typeof import("../components/Dashboard/eCommerce/TotalOrdersChart.vue")['default']
    'DashboardECommerceTotalRevenueChart': typeof import("../components/Dashboard/eCommerce/TotalRevenueChart.vue")['default']
    'DashboardECommerceTotalSalesChart': typeof import("../components/Dashboard/eCommerce/TotalSalesChart.vue")['default']
    'DashboardECommerceWelcomeDashboard': typeof import("../components/Dashboard/eCommerce/WelcomeDashboard.vue")['default']
    'FrontPagesCommonBackToUp': typeof import("../components/FrontPages/Common/BackToUp.vue")['default']
    'FrontPagesCommonCTA': typeof import("../components/FrontPages/Common/CTA.vue")['default']
    'FrontPagesCommonContactUs': typeof import("../components/FrontPages/Common/ContactUs.vue")['default']
    'FrontPagesCommonCopyRight': typeof import("../components/FrontPages/Common/CopyRight.vue")['default']
    'FrontPagesCommonFAQ': typeof import("../components/FrontPages/Common/FAQ.vue")['default']
    'FrontPagesCommonFooter': typeof import("../components/FrontPages/Common/Footer.vue")['default']
    'FrontPagesCommonKeyFeatures': typeof import("../components/FrontPages/Common/KeyFeatures.vue")['default']
    'FrontPagesCommonNavbar': typeof import("../components/FrontPages/Common/Navbar.vue")['default']
    'FrontPagesCommonOurTeam': typeof import("../components/FrontPages/Common/OurTeam.vue")['default']
    'FrontPagesCommonPageTitle': typeof import("../components/FrontPages/Common/PageTitle.vue")['default']
    'FrontPagesHomeBanner': typeof import("../components/FrontPages/Home/Banner.vue")['default']
    'FrontPagesHomeTailorYourDashboard': typeof import("../components/FrontPages/Home/TailorYourDashboard.vue")['default']
    'FrontPagesHomeTestimonials': typeof import("../components/FrontPages/Home/Testimonials.vue")['default']
    'LayoutAddNewCardModal': typeof import("../components/Layout/AddNewCardModal.vue")['default']
    'LayoutAddNewCategorieModal': typeof import("../components/Layout/AddNewCategorieModal.vue")['default']
    'LayoutAddNewContactModal': typeof import("../components/Layout/AddNewContactModal.vue")['default']
    'LayoutAddNewCustomerModal': typeof import("../components/Layout/AddNewCustomerModal.vue")['default']
    'LayoutAddNewDealsModal': typeof import("../components/Layout/AddNewDealsModal.vue")['default']
    'LayoutAddNewFileModal': typeof import("../components/Layout/AddNewFileModal.vue")['default']
    'LayoutAddNewInstructorsModal': typeof import("../components/Layout/AddNewInstructorsModal.vue")['default']
    'LayoutAddNewLabelModal': typeof import("../components/Layout/AddNewLabelModal.vue")['default']
    'LayoutAddNewLeadModal': typeof import("../components/Layout/AddNewLeadModal.vue")['default']
    'LayoutAddNewOrderModal': typeof import("../components/Layout/AddNewOrderModal.vue")['default']
    'LayoutAddNewUserModal': typeof import("../components/Layout/AddNewUserModal.vue")['default']
    'LayoutCreateTaskModal': typeof import("../components/Layout/CreateTaskModal.vue")['default']
    'LayoutLeftSidebar': typeof import("../components/Layout/LeftSidebar/index.vue")['default']
    'LayoutMainFooter': typeof import("../components/Layout/MainFooter.vue")['default']
    'LayoutPreloader': typeof import("../components/Layout/Preloader.vue")['default']
    'LayoutSettingsSidebarCardStyleBG': typeof import("../components/Layout/SettingsSidebar/CardStyleBG.vue")['default']
    'LayoutSettingsSidebarCardStyleRadius': typeof import("../components/Layout/SettingsSidebar/CardStyleRadius.vue")['default']
    'LayoutSettingsSidebarContainerStyleBtn': typeof import("../components/Layout/SettingsSidebar/ContainerStyleBtn.vue")['default']
    'LayoutSettingsSidebarHorizontalLayout': typeof import("../components/Layout/SettingsSidebar/HorizontalLayout.vue")['default']
    'LayoutSettingsSidebarOnlyFooterDark': typeof import("../components/Layout/SettingsSidebar/OnlyFooterDark.vue")['default']
    'LayoutSettingsSidebarOnlyHeaderDark': typeof import("../components/Layout/SettingsSidebar/OnlyHeaderDark.vue")['default']
    'LayoutSettingsSidebarOnlySidebarDark': typeof import("../components/Layout/SettingsSidebar/OnlySidebarDark.vue")['default']
    'LayoutSettingsSidebarRTLModeSwitch': typeof import("../components/Layout/SettingsSidebar/RTLModeSwitch.vue")['default']
    'LayoutSettingsSidebar': typeof import("../components/Layout/SettingsSidebar/index.vue")['default']
    'LayoutTopHeaderAdminProfile': typeof import("../components/Layout/TopHeader/AdminProfile.vue")['default']
    'LayoutTopHeaderDarkSwtichBtn': typeof import("../components/Layout/TopHeader/DarkSwtichBtn.vue")['default']
    'LayoutTopHeaderLanguageMenu': typeof import("../components/Layout/TopHeader/LanguageMenu.vue")['default']
    'LayoutTopHeaderNavbar': typeof import("../components/Layout/TopHeader/Navbar.vue")['default']
    'LayoutTopHeaderNotificationsLists': typeof import("../components/Layout/TopHeader/NotificationsLists.vue")['default']
    'LayoutTopHeaderSearchFrom': typeof import("../components/Layout/TopHeader/SearchFrom.vue")['default']
    'LayoutTopHeaderSettingsBtn': typeof import("../components/Layout/TopHeader/SettingsBtn.vue")['default']
    'LayoutTopHeaderToggleFullscreenBtn': typeof import("../components/Layout/TopHeader/ToggleFullscreenBtn.vue")['default']
    'LayoutTopHeaderWebApps': typeof import("../components/Layout/TopHeader/WebApps.vue")['default']
    'LayoutTopHeader': typeof import("../components/Layout/TopHeader/index.vue")['default']
    'ModulesAuthenticationConfirmMail': typeof import("../components/Modules/Authentication/ConfirmMail/index.vue")['default']
    'ModulesAuthenticationForgetPassword': typeof import("../components/Modules/Authentication/ForgetPassword/index.vue")['default']
    'ModulesAuthenticationLockScreen': typeof import("../components/Modules/Authentication/LockScreen/index.vue")['default']
    'ModulesAuthenticationLogOut': typeof import("../components/Modules/Authentication/LogOut/index.vue")['default']
    'ModulesAuthenticationLogin': typeof import("../components/Modules/Authentication/Login/index.vue")['default']
    'ModulesAuthenticationRegister': typeof import("../components/Modules/Authentication/Register/index.vue")['default']
    'ModulesAuthenticationResetPassword': typeof import("../components/Modules/Authentication/ResetPassword/index.vue")['default']
    'ModulesExtraPagesAnimation': typeof import("../components/Modules/ExtraPages/Animation/index.vue")['default']
    'ModulesExtraPagesCheckRadio': typeof import("../components/Modules/ExtraPages/CheckRadio/index.vue")['default']
    'ModulesExtraPagesClipBoard': typeof import("../components/Modules/ExtraPages/ClipBoard/index.vue")['default']
    'ModulesExtraPagesDragDrop': typeof import("../components/Modules/ExtraPages/DragDrop/index.vue")['default']
    'ModulesExtraPagesFAQ': typeof import("../components/Modules/ExtraPages/FAQ/index.vue")['default']
    'ModulesExtraPagesGallery': typeof import("../components/Modules/ExtraPages/Gallery/index.vue")['default']
    'ModulesExtraPagesPricingStyleOne': typeof import("../components/Modules/ExtraPages/Pricing/PricingStyleOne.vue")['default']
    'ModulesExtraPagesPricingStyleThree': typeof import("../components/Modules/ExtraPages/Pricing/PricingStyleThree.vue")['default']
    'ModulesExtraPagesPricingStyleTwo': typeof import("../components/Modules/ExtraPages/Pricing/PricingStyleTwo.vue")['default']
    'ModulesExtraPagesPricing': typeof import("../components/Modules/ExtraPages/Pricing/index.vue")['default']
    'ModulesExtraPagesRangeSlider': typeof import("../components/Modules/ExtraPages/RangeSlider/index.vue")['default']
    'ModulesExtraPagesRatingsInteractiveRating': typeof import("../components/Modules/ExtraPages/Ratings/InteractiveRating.vue")['default']
    'ModulesExtraPagesRatingsRTLSupport': typeof import("../components/Modules/ExtraPages/Ratings/RTLSupport.vue")['default']
    'ModulesExtraPagesRatingsReadOnlyPresetValue': typeof import("../components/Modules/ExtraPages/Ratings/ReadOnlyPresetValue.vue")['default']
    'ModulesExtraPagesRatingsSettingGettingValues': typeof import("../components/Modules/ExtraPages/Ratings/SettingGettingValues.vue")['default']
    'ModulesExtraPagesRatings': typeof import("../components/Modules/ExtraPages/Ratings/index.vue")['default']
    'ModulesExtraPagesScrollbar': typeof import("../components/Modules/ExtraPages/Scrollbar/index.vue")['default']
    'ModulesExtraPagesSearch': typeof import("../components/Modules/ExtraPages/Search/index.vue")['default']
    'ModulesExtraPagesSelect': typeof import("../components/Modules/ExtraPages/Select/index.vue")['default']
    'ModulesExtraPagesTimelineAdvancedTimeline': typeof import("../components/Modules/ExtraPages/Timeline/AdvancedTimeline.vue")['default']
    'ModulesExtraPagesTimelineBasicTimeline': typeof import("../components/Modules/ExtraPages/Timeline/BasicTimeline.vue")['default']
    'ModulesExtraPagesTimeline': typeof import("../components/Modules/ExtraPages/Timeline/index.vue")['default']
    'ModulesExtraPagesToasts': typeof import("../components/Modules/ExtraPages/Toasts/index.vue")['default']
    'ModulesExtraPagesTypography': typeof import("../components/Modules/ExtraPages/Typography/index.vue")['default']
    'ModulesFormsAdvancedElementsQuantityCounter': typeof import("../components/Modules/Forms/AdvancedElements/QuantityCounter.vue")['default']
    'ModulesFormsAdvancedElementsQuantityCounterTwo': typeof import("../components/Modules/Forms/AdvancedElements/QuantityCounterTwo.vue")['default']
    'ModulesFormsAdvancedElements': typeof import("../components/Modules/Forms/AdvancedElements/index.vue")['default']
    'ModulesFormsBasicElements': typeof import("../components/Modules/Forms/BasicElements/index.vue")['default']
    'ModulesFormsEditors': typeof import("../components/Modules/Forms/Editors/index.vue")['default']
    'ModulesFormsFileUpload': typeof import("../components/Modules/Forms/FileUpload/index.vue")['default']
    'ModulesFormsValidation': typeof import("../components/Modules/Forms/Validation/index.vue")['default']
    'ModulesFormsWizard': typeof import("../components/Modules/Forms/Wizard/index.vue")['default']
    'ModulesGoogleMap': typeof import("../components/Modules/GoogleMap/index.vue")['default']
    'ModulesIconsFeatherIcon': typeof import("../components/Modules/Icons/FeatherIcon/index.vue")['default']
    'ModulesIconsMaterialSymbolsIcon': typeof import("../components/Modules/Icons/MaterialSymbolsIcon/index.vue")['default']
    'ModulesIconsRemixIcon': typeof import("../components/Modules/Icons/RemixIcon/index.vue")['default']
    'ModulesInternalError': typeof import("../components/Modules/InternalError/index.vue")['default']
    'ModulesMembers': typeof import("../components/Modules/Members/index.vue")['default']
    'ModulesNotification': typeof import("../components/Modules/Notification/index.vue")['default']
    'ModulesTablesBasicTable': typeof import("../components/Modules/Tables/BasicTable/index.vue")['default']
    'ModulesTablesDataTable': typeof import("../components/Modules/Tables/DataTable/index.vue")['default']
    'ModulesUIElementsAccordions': typeof import("../components/Modules/UIElements/Accordions/index.vue")['default']
    'ModulesUIElementsAlertsAdditionalContentAlerts': typeof import("../components/Modules/UIElements/Alerts/AdditionalContentAlerts.vue")['default']
    'ModulesUIElementsAlertsWithIcon': typeof import("../components/Modules/UIElements/Alerts/AlertsWithIcon.vue")['default']
    'ModulesUIElementsAlertsBGAlertsWithIcon': typeof import("../components/Modules/UIElements/Alerts/BGAlertsWithIcon.vue")['default']
    'ModulesUIElementsAlertsBGBasicAlerts': typeof import("../components/Modules/UIElements/Alerts/BGBasicAlerts.vue")['default']
    'ModulesUIElementsAlertsBGOutlineAlerts': typeof import("../components/Modules/UIElements/Alerts/BGOutlineAlerts.vue")['default']
    'ModulesUIElementsAlertsBasicAlerts': typeof import("../components/Modules/UIElements/Alerts/BasicAlerts.vue")['default']
    'ModulesUIElementsAlertsDismissingAlerts': typeof import("../components/Modules/UIElements/Alerts/DismissingAlerts.vue")['default']
    'ModulesUIElementsAlertsOutlineAlerts': typeof import("../components/Modules/UIElements/Alerts/OutlineAlerts.vue")['default']
    'ModulesUIElementsAlerts': typeof import("../components/Modules/UIElements/Alerts/index.vue")['default']
    'ModulesUIElementsAvatarSizeRoundedCircleExample': typeof import("../components/Modules/UIElements/Avatar/AvatarSizeRoundedCircleExample.vue")['default']
    'ModulesUIElementsAvatarSizeSimpleRoundedExample': typeof import("../components/Modules/UIElements/Avatar/AvatarSizeSimpleRoundedExample.vue")['default']
    'ModulesUIElementsAvatarGroupUserExample': typeof import("../components/Modules/UIElements/Avatar/GroupUserExample.vue")['default']
    'ModulesUIElementsAvatarSingleUserExample': typeof import("../components/Modules/UIElements/Avatar/SingleUserExample.vue")['default']
    'ModulesUIElementsAvatarSingleUserWithBadgeExample': typeof import("../components/Modules/UIElements/Avatar/SingleUserWithBadgeExample.vue")['default']
    'ModulesUIElementsAvatarTextAvatarSizeRoundedCircleExample': typeof import("../components/Modules/UIElements/Avatar/TextAvatarSizeRoundedCircleExample.vue")['default']
    'ModulesUIElementsAvatarTextAvatarSizeSimpleRoundedExample': typeof import("../components/Modules/UIElements/Avatar/TextAvatarSizeSimpleRoundedExample.vue")['default']
    'ModulesUIElementsAvatar': typeof import("../components/Modules/UIElements/Avatar/index.vue")['default']
    'ModulesUIElementsBadgesWithIcons': typeof import("../components/Modules/UIElements/Badges/BadgesWithIcons.vue")['default']
    'ModulesUIElementsBadgesDefaultBadges': typeof import("../components/Modules/UIElements/Badges/DefaultBadges.vue")['default']
    'ModulesUIElementsBadgesHeadingsBadges': typeof import("../components/Modules/UIElements/Badges/HeadingsBadges.vue")['default']
    'ModulesUIElementsBadgesOtherBadges': typeof import("../components/Modules/UIElements/Badges/OtherBadges.vue")['default']
    'ModulesUIElementsBadgesRoundedPillBadges': typeof import("../components/Modules/UIElements/Badges/RoundedPillBadges.vue")['default']
    'ModulesUIElementsBadgesRoundedPillBadgesTwo': typeof import("../components/Modules/UIElements/Badges/RoundedPillBadgesTwo.vue")['default']
    'ModulesUIElementsBadgesSoftBadges': typeof import("../components/Modules/UIElements/Badges/SoftBadges.vue")['default']
    'ModulesUIElementsBadges': typeof import("../components/Modules/UIElements/Badges/index.vue")['default']
    'ModulesUIElementsButtonsBlockButtons': typeof import("../components/Modules/UIElements/Buttons/BlockButtons.vue")['default']
    'ModulesUIElementsButtonsWithIcon': typeof import("../components/Modules/UIElements/Buttons/ButtonsWithIcon.vue")['default']
    'ModulesUIElementsButtonsDefaultButtons': typeof import("../components/Modules/UIElements/Buttons/DefaultButtons.vue")['default']
    'ModulesUIElementsButtonsOutlineButtons': typeof import("../components/Modules/UIElements/Buttons/OutlineButtons.vue")['default']
    'ModulesUIElementsButtonsOutlineRoundedButtons': typeof import("../components/Modules/UIElements/Buttons/OutlineRoundedButtons.vue")['default']
    'ModulesUIElementsButtonsRoundedButtons': typeof import("../components/Modules/UIElements/Buttons/RoundedButtons.vue")['default']
    'ModulesUIElementsButtonsSoftButtons': typeof import("../components/Modules/UIElements/Buttons/SoftButtons.vue")['default']
    'ModulesUIElementsButtons': typeof import("../components/Modules/UIElements/Buttons/index.vue")['default']
    'ModulesUIElementsCardsCardWithBgImage': typeof import("../components/Modules/UIElements/Cards/CardWithBgImage.vue")['default']
    'ModulesUIElementsCardsCardWithImage': typeof import("../components/Modules/UIElements/Cards/CardWithImage.vue")['default']
    'ModulesUIElementsCardsCardWithList': typeof import("../components/Modules/UIElements/Cards/CardWithList.vue")['default']
    'ModulesUIElementsCardsDefaultCard': typeof import("../components/Modules/UIElements/Cards/DefaultCard.vue")['default']
    'ModulesUIElementsCards': typeof import("../components/Modules/UIElements/Cards/index.vue")['default']
    'ModulesUIElementsCarouselsSlidesOnly': typeof import("../components/Modules/UIElements/Carousels/SlidesOnly.vue")['default']
    'ModulesUIElementsCarouselsSlidesWithControls': typeof import("../components/Modules/UIElements/Carousels/SlidesWithControls.vue")['default']
    'ModulesUIElementsCarousels': typeof import("../components/Modules/UIElements/Carousels/index.vue")['default']
    'ModulesUIElementsDateTimePicker': typeof import("../components/Modules/UIElements/DateTimePicker/index.vue")['default']
    'ModulesUIElementsDropdownsDropdownDefaultButtons': typeof import("../components/Modules/UIElements/Dropdowns/DropdownDefaultButtons.vue")['default']
    'ModulesUIElementsDropdowns': typeof import("../components/Modules/UIElements/Dropdowns/index.vue")['default']
    'ModulesUIElementsGrids': typeof import("../components/Modules/UIElements/Grids/index.vue")['default']
    'ModulesUIElementsImages': typeof import("../components/Modules/UIElements/Images/index.vue")['default']
    'ModulesUIElementsList': typeof import("../components/Modules/UIElements/List/index.vue")['default']
    'ModulesUIElementsModals': typeof import("../components/Modules/UIElements/Modals/index.vue")['default']
    'ModulesUIElementsNavs': typeof import("../components/Modules/UIElements/Navs/index.vue")['default']
    'ModulesUIElementsPaginations': typeof import("../components/Modules/UIElements/Paginations/index.vue")['default']
    'ModulesUIElementsPopoverTooltips': typeof import("../components/Modules/UIElements/PopoverTooltips/index.vue")['default']
    'ModulesUIElementsProgress': typeof import("../components/Modules/UIElements/Progress/index.vue")['default']
    'ModulesUIElementsSpinners': typeof import("../components/Modules/UIElements/Spinners/index.vue")['default']
    'ModulesUIElementsTabs': typeof import("../components/Modules/UIElements/Tabs/index.vue")['default']
    'ModulesUIElementsVideos': typeof import("../components/Modules/UIElements/Videos/index.vue")['default']
    'ModulesWidgetsAnnualProfitChart': typeof import("../components/Modules/Widgets/AnnualProfitChart.vue")['default']
    'ModulesWidgetsCoursesSalesChart': typeof import("../components/Modules/Widgets/CoursesSalesChart.vue")['default']
    'ModulesWidgetsInProgressChart': typeof import("../components/Modules/Widgets/InProgressChart.vue")['default']
    'ModulesWidgetsLeadConversionChart': typeof import("../components/Modules/Widgets/LeadConversionChart.vue")['default']
    'ModulesWidgetsOurTopCourses': typeof import("../components/Modules/Widgets/OurTopCourses.vue")['default']
    'ModulesWidgetsProjectsAnalysisChart': typeof import("../components/Modules/Widgets/ProjectsAnalysisChart.vue")['default']
    'ModulesWidgetsProjectsOverview': typeof import("../components/Modules/Widgets/ProjectsOverview.vue")['default']
    'ModulesWidgetsProjectsRoadmapChart': typeof import("../components/Modules/Widgets/ProjectsRoadmapChart.vue")['default']
    'ModulesWidgetsRevenueGrowthChart': typeof import("../components/Modules/Widgets/RevenueGrowthChart.vue")['default']
    'ModulesWidgetsTeamMembers': typeof import("../components/Modules/Widgets/TeamMembers.vue")['default']
    'ModulesWidgetsTicketsDueChart': typeof import("../components/Modules/Widgets/TicketsDueChart.vue")['default']
    'ModulesWidgetsTicketsNewOpenChart': typeof import("../components/Modules/Widgets/TicketsNewOpenChart.vue")['default']
    'ModulesWidgetsTicketsResolvedChart': typeof import("../components/Modules/Widgets/TicketsResolvedChart.vue")['default']
    'ModulesWidgetsTimeSpentChart': typeof import("../components/Modules/Widgets/TimeSpentChart.vue")['default']
    'ModulesWidgetsTotalCourses': typeof import("../components/Modules/Widgets/TotalCourses.vue")['default']
    'ModulesWidgetsTotalCustomersChart': typeof import("../components/Modules/Widgets/TotalCustomersChart.vue")['default']
    'ModulesWidgetsTotalEnrolled': typeof import("../components/Modules/Widgets/TotalEnrolled.vue")['default']
    'ModulesWidgetsTotalMentors': typeof import("../components/Modules/Widgets/TotalMentors.vue")['default']
    'ModulesWidgetsTotalOrdersChart': typeof import("../components/Modules/Widgets/TotalOrdersChart.vue")['default']
    'ModulesWidgetsTotalOrdersChartTwo': typeof import("../components/Modules/Widgets/TotalOrdersChartTwo.vue")['default']
    'ModulesWidgetsTotalRevenueChart': typeof import("../components/Modules/Widgets/TotalRevenueChart.vue")['default']
    'ModulesWidgetsWelcomeBack': typeof import("../components/Modules/Widgets/WelcomeBack.vue")['default']
    'ModulesWidgetsWorkingSchedule': typeof import("../components/Modules/Widgets/WorkingSchedule.vue")['default']
    'ModulesWidgets': typeof import("../components/Modules/Widgets/index.vue")['default']
    'OthersMyProfileAdditionalInformation': typeof import("../components/Others/MyProfile/AdditionalInformation.vue")['default']
    'OthersMyProfileInformation': typeof import("../components/Others/MyProfile/ProfileInformation.vue")['default']
    'OthersMyProfileIntro': typeof import("../components/Others/MyProfile/ProfileIntro.vue")['default']
    'OthersMyProfileProjectsAnalysisChart': typeof import("../components/Others/MyProfile/ProjectsAnalysisChart.vue")['default']
    'OthersMyProfileRecentActivity': typeof import("../components/Others/MyProfile/RecentActivity.vue")['default']
    'OthersMyProfileToDoList': typeof import("../components/Others/MyProfile/ToDoList.vue")['default']
    'OthersMyProfileTotalOrders': typeof import("../components/Others/MyProfile/TotalOrders.vue")['default']
    'OthersMyProfileTotalProjects': typeof import("../components/Others/MyProfile/TotalProjects.vue")['default']
    'OthersMyProfileTotalRevenue': typeof import("../components/Others/MyProfile/TotalRevenue.vue")['default']
    'OthersMyProfileWelcomeBack': typeof import("../components/Others/MyProfile/WelcomeBack.vue")['default']
    'OthersMyProfile': typeof import("../components/Others/MyProfile/index.vue")['default']
    'OthersSettingsAccountSettings': typeof import("../components/Others/Settings/AccountSettings/index.vue")['default']
    'OthersSettingsChangePassword': typeof import("../components/Others/Settings/ChangePassword/index.vue")['default']
    'OthersSettingsConnections': typeof import("../components/Others/Settings/Connections/index.vue")['default']
    'OthersSettingsPrivacyPolicy': typeof import("../components/Others/Settings/PrivacyPolicy/index.vue")['default']
    'OthersSettingsMenu': typeof import("../components/Others/Settings/SettingsMenu.vue")['default']
    'OthersSettingsTermsConditions': typeof import("../components/Others/Settings/TermsConditions/index.vue")['default']
    'PagesCRMContacts': typeof import("../components/Pages/CRM/Contacts/index.vue")['default']
    'PagesCRMCustomers': typeof import("../components/Pages/CRM/Customers/index.vue")['default']
    'PagesCRMDeals': typeof import("../components/Pages/CRM/Deals/index.vue")['default']
    'PagesCRMLeadsAnnualProfitChart': typeof import("../components/Pages/CRM/Leads/AnnualProfitChart.vue")['default']
    'PagesCRMLeadsLeadConversionChart': typeof import("../components/Pages/CRM/Leads/LeadConversionChart.vue")['default']
    'PagesCRMLeadsRevenueGrowthChart': typeof import("../components/Pages/CRM/Leads/RevenueGrowthChart.vue")['default']
    'PagesCRMLeadsTotalOrdersChart': typeof import("../components/Pages/CRM/Leads/TotalOrdersChart.vue")['default']
    'PagesCRMLeads': typeof import("../components/Pages/CRM/Leads/index.vue")['default']
    'PagesCryptoTraderCTWallet': typeof import("../components/Pages/CryptoTrader/CTWallet/index.vue")['default']
    'PagesCryptoTraderGainersLosers': typeof import("../components/Pages/CryptoTrader/GainersLosers/index.vue")['default']
    'PagesCryptoTraderTransactions': typeof import("../components/Pages/CryptoTrader/Transactions/index.vue")['default']
    'PagesDoctorAddPatient': typeof import("../components/Pages/Doctor/AddPatient/index.vue")['default']
    'PagesDoctorAppointmentsTodayAppointments': typeof import("../components/Pages/Doctor/Appointments/TodayAppointments.vue")['default']
    'PagesDoctorAppointmentsTodaySchedule': typeof import("../components/Pages/Doctor/Appointments/TodaySchedule.vue")['default']
    'PagesDoctorAppointments': typeof import("../components/Pages/Doctor/Appointments/index.vue")['default']
    'PagesDoctorPatientDetails': typeof import("../components/Pages/Doctor/PatientDetails/index.vue")['default']
    'PagesDoctorPatientsList': typeof import("../components/Pages/Doctor/PatientsList/index.vue")['default']
    'PagesDoctorPrescriptions': typeof import("../components/Pages/Doctor/Prescriptions/index.vue")['default']
    'PagesDoctorWritePrescription': typeof import("../components/Pages/Doctor/WritePrescription/index.vue")['default']
    'PagesEcommerceCartQuantityCounter': typeof import("../components/Pages/Ecommerce/Cart/QuantityCounter.vue")['default']
    'PagesEcommerceCart': typeof import("../components/Pages/Ecommerce/Cart/index.vue")['default']
    'PagesEcommerceCategories': typeof import("../components/Pages/Ecommerce/Categories/index.vue")['default']
    'PagesEcommerceCheckout': typeof import("../components/Pages/Ecommerce/Checkout/index.vue")['default']
    'PagesEcommerceCreateOrderBillingInformation': typeof import("../components/Pages/Ecommerce/CreateOrder/BillingInformation.vue")['default']
    'PagesEcommerceCreateOrderPaymentMethod': typeof import("../components/Pages/Ecommerce/CreateOrder/PaymentMethod.vue")['default']
    'PagesEcommerceCreateOrderYourOrder': typeof import("../components/Pages/Ecommerce/CreateOrder/YourOrder.vue")['default']
    'PagesEcommerceCreateOrder': typeof import("../components/Pages/Ecommerce/CreateOrder/index.vue")['default']
    'PagesEcommerceCreateProduct': typeof import("../components/Pages/Ecommerce/CreateProduct/index.vue")['default']
    'PagesEcommerceCreateSeller': typeof import("../components/Pages/Ecommerce/CreateSeller/index.vue")['default']
    'PagesEcommerceCustomerDetailsTransactionsHistory': typeof import("../components/Pages/Ecommerce/CustomerDetails/TransactionsHistory.vue")['default']
    'PagesEcommerceCustomerDetailsUserCard': typeof import("../components/Pages/Ecommerce/CustomerDetails/UserCard.vue")['default']
    'PagesEcommerceCustomerDetails': typeof import("../components/Pages/Ecommerce/CustomerDetails/index.vue")['default']
    'PagesEcommerceCustomers': typeof import("../components/Pages/Ecommerce/Customers/index.vue")['default']
    'PagesEcommerceEditProduct': typeof import("../components/Pages/Ecommerce/EditProduct/index.vue")['default']
    'PagesEcommerceOrderDetailsBillingDetails': typeof import("../components/Pages/Ecommerce/OrderDetails/BillingDetails.vue")['default']
    'PagesEcommerceOrderDetailsDeliveryDetails': typeof import("../components/Pages/Ecommerce/OrderDetails/DeliveryDetails.vue")['default']
    'PagesEcommerceOrderDetailsOrderSummary': typeof import("../components/Pages/Ecommerce/OrderDetails/OrderSummary.vue")['default']
    'PagesEcommerceOrderDetailsQuantityCounter': typeof import("../components/Pages/Ecommerce/OrderDetails/QuantityCounter.vue")['default']
    'PagesEcommerceOrderDetailsRecentOrders': typeof import("../components/Pages/Ecommerce/OrderDetails/RecentOrders.vue")['default']
    'PagesEcommerceOrderDetailsShippingDetails': typeof import("../components/Pages/Ecommerce/OrderDetails/ShippingDetails.vue")['default']
    'PagesEcommerceOrderDetailsTrackingID': typeof import("../components/Pages/Ecommerce/OrderDetails/TrackingID.vue")['default']
    'PagesEcommerceOrderDetails': typeof import("../components/Pages/Ecommerce/OrderDetails/index.vue")['default']
    'PagesEcommerceOrderTracking': typeof import("../components/Pages/Ecommerce/OrderTracking/index.vue")['default']
    'PagesEcommerceOrders': typeof import("../components/Pages/Ecommerce/Orders/index.vue")['default']
    'PagesEcommerceProductsDetailsTabs': typeof import("../components/Pages/Ecommerce/ProductsDetails/ProductsDetailsTabs.vue")['default']
    'PagesEcommerceProductsDetailsProductsFilter': typeof import("../components/Pages/Ecommerce/ProductsDetails/ProductsFilter.vue")['default']
    'PagesEcommerceProductsDetails': typeof import("../components/Pages/Ecommerce/ProductsDetails/index.vue")['default']
    'PagesEcommerceProductsGridProductsFilter': typeof import("../components/Pages/Ecommerce/ProductsGrid/ProductsFilter.vue")['default']
    'PagesEcommerceProductsGrid': typeof import("../components/Pages/Ecommerce/ProductsGrid/index.vue")['default']
    'PagesEcommerceProductsList': typeof import("../components/Pages/Ecommerce/ProductsList/index.vue")['default']
    'PagesEcommerceRefunds': typeof import("../components/Pages/Ecommerce/Refunds/index.vue")['default']
    'PagesEcommerceReviews': typeof import("../components/Pages/Ecommerce/Reviews/index.vue")['default']
    'PagesEcommerceSellerDetailsProductsList': typeof import("../components/Pages/Ecommerce/SellerDetails/ProductsList.vue")['default']
    'PagesEcommerceSellerDetailsRevenueChart': typeof import("../components/Pages/Ecommerce/SellerDetails/RevenueChart.vue")['default']
    'PagesEcommerceSellerDetailsSellerID': typeof import("../components/Pages/Ecommerce/SellerDetails/SellerID.vue")['default']
    'PagesEcommerceSellerDetailsSellerOverview': typeof import("../components/Pages/Ecommerce/SellerDetails/SellerOverview.vue")['default']
    'PagesEcommerceSellerDetails': typeof import("../components/Pages/Ecommerce/SellerDetails/index.vue")['default']
    'PagesEcommerceSellers': typeof import("../components/Pages/Ecommerce/Sellers/index.vue")['default']
    'PagesEventsCreateAnEvent': typeof import("../components/Pages/Events/CreateAnEvent/index.vue")['default']
    'PagesEventsEditAnEvent': typeof import("../components/Pages/Events/EditAnEvent/index.vue")['default']
    'PagesEventsEventDetailsAboutThisEvent': typeof import("../components/Pages/Events/EventDetails/AboutThisEvent.vue")['default']
    'PagesEventsEventDetailsAnnualConference': typeof import("../components/Pages/Events/EventDetails/AnnualConference.vue")['default']
    'PagesEventsEventDetailsEventInfo': typeof import("../components/Pages/Events/EventDetails/EventInfo.vue")['default']
    'PagesEventsEventDetailsSpeakerTopic': typeof import("../components/Pages/Events/EventDetails/SpeakerTopic.vue")['default']
    'PagesEventsEventDetails': typeof import("../components/Pages/Events/EventDetails/index.vue")['default']
    'PagesEventsEventsGrid': typeof import("../components/Pages/Events/EventsGrid/index.vue")['default']
    'PagesEventsEventsList': typeof import("../components/Pages/Events/EventsList/index.vue")['default']
    'PagesFinanceTransactionAddNewTransactionModal': typeof import("../components/Pages/Finance/Transaction/AddNewTransactionModal.vue")['default']
    'PagesFinanceTransaction': typeof import("../components/Pages/Finance/Transaction/index.vue")['default']
    'PagesFinanceWalletAddCardDetailModal': typeof import("../components/Pages/Finance/Wallet/AddCardDetailModal.vue")['default']
    'PagesFinanceWalletDebitCard': typeof import("../components/Pages/Finance/Wallet/DebitCard.vue")['default']
    'PagesFinanceWalletStaticChart': typeof import("../components/Pages/Finance/Wallet/StaticChart.vue")['default']
    'PagesFinanceWalletTotalExpenses': typeof import("../components/Pages/Finance/Wallet/TotalExpenses.vue")['default']
    'PagesFinanceWalletTotalIncome': typeof import("../components/Pages/Finance/Wallet/TotalIncome.vue")['default']
    'PagesFinanceWalletTransactionHistory': typeof import("../components/Pages/Finance/Wallet/TransactionHistory.vue")['default']
    'PagesFinanceWallet': typeof import("../components/Pages/Finance/Wallet/index.vue")['default']
    'PagesHelpDeskAgents': typeof import("../components/Pages/HelpDesk/Agents/index.vue")['default']
    'PagesHelpDeskReportsCustomerSatisfactionChart': typeof import("../components/Pages/HelpDesk/Reports/CustomerSatisfactionChart.vue")['default']
    'PagesHelpDeskReportsNewAndSolvedTicketsChart': typeof import("../components/Pages/HelpDesk/Reports/NewAndSolvedTicketsChart.vue")['default']
    'PagesHelpDeskReportsPerformanceOfAgents': typeof import("../components/Pages/HelpDesk/Reports/PerformanceOfAgents.vue")['default']
    'PagesHelpDeskReportsResponseTimeChart': typeof import("../components/Pages/HelpDesk/Reports/ResponseTimeChart.vue")['default']
    'PagesHelpDeskReportsTasksOverviewChart': typeof import("../components/Pages/HelpDesk/Reports/TasksOverviewChart.vue")['default']
    'PagesHelpDeskReportsTicketsStatusChart': typeof import("../components/Pages/HelpDesk/Reports/TicketsStatusChart.vue")['default']
    'PagesHelpDeskReports': typeof import("../components/Pages/HelpDesk/Reports/index.vue")['default']
    'PagesHelpDeskTicketDetailsAttachments': typeof import("../components/Pages/HelpDesk/TicketDetails/Attachments.vue")['default']
    'PagesHelpDeskTicketDetailsComments': typeof import("../components/Pages/HelpDesk/TicketDetails/Comments.vue")['default']
    'PagesHelpDeskTicketDetailsTicket': typeof import("../components/Pages/HelpDesk/TicketDetails/Ticket.vue")['default']
    'PagesHelpDeskTicketDetailsTicketDescription': typeof import("../components/Pages/HelpDesk/TicketDetails/TicketDescription.vue")['default']
    'PagesHelpDeskTicketDetails': typeof import("../components/Pages/HelpDesk/TicketDetails/index.vue")['default']
    'PagesHelpDeskTicketsAllTickets': typeof import("../components/Pages/HelpDesk/Tickets/AllTickets.vue")['default']
    'PagesHelpDeskTicketsDueChart': typeof import("../components/Pages/HelpDesk/Tickets/TicketsDueChart.vue")['default']
    'PagesHelpDeskTicketsInProgressChart': typeof import("../components/Pages/HelpDesk/Tickets/TicketsInProgressChart.vue")['default']
    'PagesHelpDeskTicketsNewOpenChart': typeof import("../components/Pages/HelpDesk/Tickets/TicketsNewOpenChart.vue")['default']
    'PagesHelpDeskTicketsResolvedChart': typeof import("../components/Pages/HelpDesk/Tickets/TicketsResolvedChart.vue")['default']
    'PagesHelpDeskTickets': typeof import("../components/Pages/HelpDesk/Tickets/index.vue")['default']
    'PagesHotelGuestsList': typeof import("../components/Pages/Hotel/GuestsList/index.vue")['default']
    'PagesHotelRoomDetailsReviews': typeof import("../components/Pages/Hotel/RoomDetails/Reviews.vue")['default']
    'PagesHotelRoomDetails': typeof import("../components/Pages/Hotel/RoomDetails/index.vue")['default']
    'PagesHotelRoomsList': typeof import("../components/Pages/Hotel/RoomsList/index.vue")['default']
    'PagesInvoicesCreateInvoice': typeof import("../components/Pages/Invoices/CreateInvoice/index.vue")['default']
    'PagesInvoicesEditInvoice': typeof import("../components/Pages/Invoices/EditInvoice/index.vue")['default']
    'PagesInvoicesInvoiceDetails': typeof import("../components/Pages/Invoices/InvoiceDetails/index.vue")['default']
    'PagesInvoicesInvoicesList': typeof import("../components/Pages/Invoices/InvoicesList/index.vue")['default']
    'PagesLMSCourseDetailsCourse': typeof import("../components/Pages/LMS/CourseDetails/Course.vue")['default']
    'PagesLMSCourseDetailsCourseInstructor': typeof import("../components/Pages/LMS/CourseDetails/CourseInstructor.vue")['default']
    'PagesLMSCourseDetailsEnrolledStudents': typeof import("../components/Pages/LMS/CourseDetails/EnrolledStudents.vue")['default']
    'PagesLMSCourseDetailsManageReviews': typeof import("../components/Pages/LMS/CourseDetails/ManageReviews.vue")['default']
    'PagesLMSCourseDetailsRatings': typeof import("../components/Pages/LMS/CourseDetails/Ratings.vue")['default']
    'PagesLMSCourseDetailsTablesOfContent': typeof import("../components/Pages/LMS/CourseDetails/TablesOfContent.vue")['default']
    'PagesLMSCourseDetailsWriteFeedbackHere': typeof import("../components/Pages/LMS/CourseDetails/WriteFeedbackHere.vue")['default']
    'PagesLMSCourseDetails': typeof import("../components/Pages/LMS/CourseDetails/index.vue")['default']
    'PagesLMSCoursesList': typeof import("../components/Pages/LMS/CoursesList/index.vue")['default']
    'PagesLMSCreateCourse': typeof import("../components/Pages/LMS/CreateCourse/index.vue")['default']
    'PagesLMSEditCourse': typeof import("../components/Pages/LMS/EditCourse/index.vue")['default']
    'PagesLMSInstructors': typeof import("../components/Pages/LMS/Instructors/index.vue")['default']
    'PagesLMSLessonPreview': typeof import("../components/Pages/LMS/LessonPreview/index.vue")['default']
    'PagesLMSAdminInstituteType': typeof import("../components/Pages/LMS/admin/institute-type.vue")['default']
    'PagesNFTMarketplaceCreatorDetailsCarterID': typeof import("../components/Pages/NFTMarketplace/CreatorDetails/CarterID.vue")['default']
    'PagesNFTMarketplaceCreatorDetailsCarterNFTs': typeof import("../components/Pages/NFTMarketplace/CreatorDetails/CarterNFTs.vue")['default']
    'PagesNFTMarketplaceCreatorDetails': typeof import("../components/Pages/NFTMarketplace/CreatorDetails/index.vue")['default']
    'PagesNFTMarketplaceCreatorsFilterContent': typeof import("../components/Pages/NFTMarketplace/Creators/FilterContent.vue")['default']
    'PagesNFTMarketplaceCreators': typeof import("../components/Pages/NFTMarketplace/Creators/index.vue")['default']
    'PagesNFTMarketplaceExploreAllPriceFilter': typeof import("../components/Pages/NFTMarketplace/ExploreAll/PriceFilter.vue")['default']
    'PagesNFTMarketplaceExploreAll': typeof import("../components/Pages/NFTMarketplace/ExploreAll/index.vue")['default']
    'PagesNFTMarketplaceLiveAuctionCountdownTimer': typeof import("../components/Pages/NFTMarketplace/LiveAuction/CountdownTimer.vue")['default']
    'PagesNFTMarketplaceLiveAuctionHistoryOfBids': typeof import("../components/Pages/NFTMarketplace/LiveAuction/HistoryOfBids.vue")['default']
    'PagesNFTMarketplaceLiveAuctionNewMobileApp': typeof import("../components/Pages/NFTMarketplace/LiveAuction/NewMobileApp.vue")['default']
    'PagesNFTMarketplaceLiveAuction': typeof import("../components/Pages/NFTMarketplace/LiveAuction/index.vue")['default']
    'PagesNFTMarketplaceMarketplaceCreateNFT': typeof import("../components/Pages/NFTMarketplace/Marketplace/CreateNFT.vue")['default']
    'PagesNFTMarketplaceMarketplaceFeaturedNFTArtworks': typeof import("../components/Pages/NFTMarketplace/Marketplace/FeaturedNFTArtworks.vue")['default']
    'PagesNFTMarketplaceMarketplaceManageYourNFT': typeof import("../components/Pages/NFTMarketplace/Marketplace/ManageYourNFT.vue")['default']
    'PagesNFTMarketplaceMarketplaceTopCreators': typeof import("../components/Pages/NFTMarketplace/Marketplace/TopCreators.vue")['default']
    'PagesNFTMarketplaceNFTDetailsCountdownTimer': typeof import("../components/Pages/NFTMarketplace/NFTDetails/CountdownTimer.vue")['default']
    'PagesNFTMarketplaceNFTDetails': typeof import("../components/Pages/NFTMarketplace/NFTDetails/index.vue")['default']
    'PagesNFTMarketplaceWalletConnect': typeof import("../components/Pages/NFTMarketplace/WalletConnect/index.vue")['default']
    'PagesProfileCover': typeof import("../components/Pages/Profile/ProfileCover.vue")['default']
    'PagesProfileMenu': typeof import("../components/Pages/Profile/ProfileMenu.vue")['default']
    'PagesProfileProjects': typeof import("../components/Pages/Profile/Projects/index.vue")['default']
    'PagesProfileTeams': typeof import("../components/Pages/Profile/Teams/index.vue")['default']
    'PagesProfileUserProfileAboutMe': typeof import("../components/Pages/Profile/UserProfile/AboutMe.vue")['default']
    'PagesProfileUserProfileFollowers': typeof import("../components/Pages/Profile/UserProfile/Followers.vue")['default']
    'PagesProfileUserProfileMyProjects': typeof import("../components/Pages/Profile/UserProfile/MyProjects.vue")['default']
    'PagesProfileUserProfile': typeof import("../components/Pages/Profile/UserProfile/index.vue")['default']
    'PagesProjectManagementClients': typeof import("../components/Pages/ProjectManagement/Clients/index.vue")['default']
    'PagesProjectManagementCreateProject': typeof import("../components/Pages/ProjectManagement/CreateProject/index.vue")['default']
    'PagesProjectManagementKanbanBoard': typeof import("../components/Pages/ProjectManagement/KanbanBoard/index.vue")['default']
    'PagesProjectManagementProjectOverviewProjectRoadmapChart': typeof import("../components/Pages/ProjectManagement/ProjectOverview/ProjectRoadmapChart.vue")['default']
    'PagesProjectManagementProjectOverviewProjectsOverview': typeof import("../components/Pages/ProjectManagement/ProjectOverview/ProjectsOverview.vue")['default']
    'PagesProjectManagementProjectOverviewRecentActivity': typeof import("../components/Pages/ProjectManagement/ProjectOverview/RecentActivity.vue")['default']
    'PagesProjectManagementProjectOverviewTasksOverviewChart': typeof import("../components/Pages/ProjectManagement/ProjectOverview/TasksOverviewChart.vue")['default']
    'PagesProjectManagementProjectOverviewTeamMembers': typeof import("../components/Pages/ProjectManagement/ProjectOverview/TeamMembers.vue")['default']
    'PagesProjectManagementProjectOverviewThemeDevelopment': typeof import("../components/Pages/ProjectManagement/ProjectOverview/ThemeDevelopment.vue")['default']
    'PagesProjectManagementProjectOverviewToDoList': typeof import("../components/Pages/ProjectManagement/ProjectOverview/ToDoList.vue")['default']
    'PagesProjectManagementProjectOverview': typeof import("../components/Pages/ProjectManagement/ProjectOverview/index.vue")['default']
    'PagesProjectManagementProjectsList': typeof import("../components/Pages/ProjectManagement/ProjectsList/index.vue")['default']
    'PagesProjectManagementTeams': typeof import("../components/Pages/ProjectManagement/Teams/index.vue")['default']
    'PagesProjectManagementUsers': typeof import("../components/Pages/ProjectManagement/Users/index.vue")['default']
    'PagesRealEstateAddAgent': typeof import("../components/Pages/RealEstate/AddAgent/index.vue")['default']
    'PagesRealEstateAddProperty': typeof import("../components/Pages/RealEstate/AddProperty/index.vue")['default']
    'PagesRealEstateAgentList': typeof import("../components/Pages/RealEstate/AgentList/index.vue")['default']
    'PagesRealEstateAgentOverviewClientTestimonials': typeof import("../components/Pages/RealEstate/AgentOverview/ClientTestimonials.vue")['default']
    'PagesRealEstateAgentOverviewProfile': typeof import("../components/Pages/RealEstate/AgentOverview/Profile.vue")['default']
    'PagesRealEstateAgentOverviewPropertyStatusPropertiesForRentChart': typeof import("../components/Pages/RealEstate/AgentOverview/PropertyStatus/PropertiesForRentChart.vue")['default']
    'PagesRealEstateAgentOverviewPropertyStatusPropertiesForSaleChart': typeof import("../components/Pages/RealEstate/AgentOverview/PropertyStatus/PropertiesForSaleChart.vue")['default']
    'PagesRealEstateAgentOverviewPropertyStatus': typeof import("../components/Pages/RealEstate/AgentOverview/PropertyStatus/index.vue")['default']
    'PagesRealEstateAgentOverview': typeof import("../components/Pages/RealEstate/AgentOverview/index.vue")['default']
    'PagesRealEstatePropertyListAddProperty': typeof import("../components/Pages/RealEstate/PropertyList/AddProperty.vue")['default']
    'PagesRealEstatePropertyList': typeof import("../components/Pages/RealEstate/PropertyList/index.vue")['default']
    'PagesRealEstatePropertyOverviewProfile': typeof import("../components/Pages/RealEstate/PropertyOverview/Profile/index.vue")['default']
    'PagesRealEstatePropertyOverview': typeof import("../components/Pages/RealEstate/PropertyOverview/index.vue")['default']
    'PagesRealEstateRealEstateCustomersAddNewCustomer': typeof import("../components/Pages/RealEstate/RealEstateCustomers/AddNewCustomer.vue")['default']
    'PagesRealEstateRealEstateCustomersAddNewCustomerModal': typeof import("../components/Pages/RealEstate/RealEstateCustomers/AddNewCustomerModal.vue")['default']
    'PagesRealEstateRealEstateCustomers': typeof import("../components/Pages/RealEstate/RealEstateCustomers/index.vue")['default']
    'PagesRealEstateAgentProperties': typeof import("../components/Pages/RealEstateAgent/Properties/index.vue")['default']
    'PagesRealEstateAgentPropertyDetailsReviews': typeof import("../components/Pages/RealEstateAgent/PropertyDetails/Reviews.vue")['default']
    'PagesRealEstateAgentPropertyDetails': typeof import("../components/Pages/RealEstateAgent/PropertyDetails/index.vue")['default']
    'PagesRestaurantDishDetailsReviewsComponent': typeof import("../components/Pages/Restaurant/DishDetails/ReviewsComponent.vue")['default']
    'PagesRestaurantDishDetails': typeof import("../components/Pages/Restaurant/DishDetails/index.vue")['default']
    'PagesRestaurantMenus': typeof import("../components/Pages/Restaurant/Menus/index.vue")['default']
    'PagesSocialProfile': typeof import("../components/Pages/Social/Profile/index.vue")['default']
    'PagesSocialSettings': typeof import("../components/Pages/Social/Settings/index.vue")['default']
    'PagesStarter': typeof import("../components/Pages/Starter/index.vue")['default']
    'PagesUsersAddUser': typeof import("../components/Pages/Users/AddUser/index.vue")['default']
    'PagesUsersTeamMembers': typeof import("../components/Pages/Users/TeamMembers/index.vue")['default']
    'PagesUsersUsersList': typeof import("../components/Pages/Users/UsersList/index.vue")['default']
    'NuxtWelcome': typeof import("../node_modules/nuxt/dist/app/components/welcome.vue")['default']
    'NuxtLayout': typeof import("../node_modules/nuxt/dist/app/components/nuxt-layout")['default']
    'NuxtErrorBoundary': typeof import("../node_modules/nuxt/dist/app/components/nuxt-error-boundary.vue")['default']
    'ClientOnly': typeof import("../node_modules/nuxt/dist/app/components/client-only")['default']
    'DevOnly': typeof import("../node_modules/nuxt/dist/app/components/dev-only")['default']
    'ServerPlaceholder': typeof import("../node_modules/nuxt/dist/app/components/server-placeholder")['default']
    'NuxtLink': typeof import("../node_modules/nuxt/dist/app/components/nuxt-link")['default']
    'NuxtLoadingIndicator': typeof import("../node_modules/nuxt/dist/app/components/nuxt-loading-indicator")['default']
    'NuxtTime': typeof import("../node_modules/nuxt/dist/app/components/nuxt-time.vue")['default']
    'NuxtRouteAnnouncer': typeof import("../node_modules/nuxt/dist/app/components/nuxt-route-announcer")['default']
    'NuxtImg': typeof import("../node_modules/nuxt/dist/app/components/nuxt-stubs")['NuxtImg']
    'NuxtPicture': typeof import("../node_modules/nuxt/dist/app/components/nuxt-stubs")['NuxtPicture']
    'BAccordion': typeof import("bootstrap-vue-next/components/BAccordion")['BAccordion']
    'BAccordionItem': typeof import("bootstrap-vue-next/components/BAccordion")['BAccordionItem']
    'BAlert': typeof import("bootstrap-vue-next/components/BAlert")['BAlert']
    'BAvatar': typeof import("bootstrap-vue-next/components/BAvatar")['BAvatar']
    'BAvatarGroup': typeof import("bootstrap-vue-next/components/BAvatar")['BAvatarGroup']
    'BBadge': typeof import("bootstrap-vue-next/components/BBadge")['BBadge']
    'BBreadcrumb': typeof import("bootstrap-vue-next/components/BBreadcrumb")['BBreadcrumb']
    'BBreadcrumbItem': typeof import("bootstrap-vue-next/components/BBreadcrumb")['BBreadcrumbItem']
    'BButton': typeof import("bootstrap-vue-next/components/BButton")['BButton']
    'BButtonGroup': typeof import("bootstrap-vue-next/components/BButton")['BButtonGroup']
    'BButtonToolbar': typeof import("bootstrap-vue-next/components/BButton")['BButtonToolbar']
    'BCloseButton': typeof import("bootstrap-vue-next/components/BButton")['BCloseButton']
    'BCard': typeof import("bootstrap-vue-next/components/BCard")['BCard']
    'BCardBody': typeof import("bootstrap-vue-next/components/BCard")['BCardBody']
    'BCardFooter': typeof import("bootstrap-vue-next/components/BCard")['BCardFooter']
    'BCardGroup': typeof import("bootstrap-vue-next/components/BCard")['BCardGroup']
    'BCardHeader': typeof import("bootstrap-vue-next/components/BCard")['BCardHeader']
    'BCardImg': typeof import("bootstrap-vue-next/components/BCard")['BCardImg']
    'BCardSubtitle': typeof import("bootstrap-vue-next/components/BCard")['BCardSubtitle']
    'BCardText': typeof import("bootstrap-vue-next/components/BCard")['BCardText']
    'BCardTitle': typeof import("bootstrap-vue-next/components/BCard")['BCardTitle']
    'BCarousel': typeof import("bootstrap-vue-next/components/BCarousel")['BCarousel']
    'BCarouselSlide': typeof import("bootstrap-vue-next/components/BCarousel")['BCarouselSlide']
    'BCol': typeof import("bootstrap-vue-next/components/BContainer")['BCol']
    'BCollapse': typeof import("bootstrap-vue-next/components/BCollapse")['BCollapse']
    'BContainer': typeof import("bootstrap-vue-next/components/BContainer")['BContainer']
    'BDropdown': typeof import("bootstrap-vue-next/components/BDropdown")['BDropdown']
    'BDropdownDivider': typeof import("bootstrap-vue-next/components/BDropdown")['BDropdownDivider']
    'BDropdownForm': typeof import("bootstrap-vue-next/components/BDropdown")['BDropdownForm']
    'BDropdownGroup': typeof import("bootstrap-vue-next/components/BDropdown")['BDropdownGroup']
    'BDropdownHeader': typeof import("bootstrap-vue-next/components/BDropdown")['BDropdownHeader']
    'BDropdownItem': typeof import("bootstrap-vue-next/components/BDropdown")['BDropdownItem']
    'BDropdownItemButton': typeof import("bootstrap-vue-next/components/BDropdown")['BDropdownItemButton']
    'BDropdownText': typeof import("bootstrap-vue-next/components/BDropdown")['BDropdownText']
    'BForm': typeof import("bootstrap-vue-next/components/BForm")['BForm']
    'BFormCheckbox': typeof import("bootstrap-vue-next/components/BFormCheckbox")['BFormCheckbox']
    'BFormCheckboxGroup': typeof import("bootstrap-vue-next/components/BFormCheckbox")['BFormCheckboxGroup']
    'BFormDatalist': typeof import("bootstrap-vue-next/components/BForm")['BFormDatalist']
    'BFormFile': typeof import("bootstrap-vue-next/components/BFormFile")['BFormFile']
    'BFormFloatingLabel': typeof import("bootstrap-vue-next/components/BForm")['BFormFloatingLabel']
    'BFormGroup': typeof import("bootstrap-vue-next/components/BFormGroup")['BFormGroup']
    'BFormInput': typeof import("bootstrap-vue-next/components/BFormInput")['BFormInput']
    'BFormInvalidFeedback': typeof import("bootstrap-vue-next/components/BForm")['BFormInvalidFeedback']
    'BFormRadio': typeof import("bootstrap-vue-next/components/BFormRadio")['BFormRadio']
    'BFormRadioGroup': typeof import("bootstrap-vue-next/components/BFormRadio")['BFormRadioGroup']
    'BFormRow': typeof import("bootstrap-vue-next/components/BForm")['BFormRow']
    'BFormSelect': typeof import("bootstrap-vue-next/components/BFormSelect")['BFormSelect']
    'BFormSelectOption': typeof import("bootstrap-vue-next/components/BFormSelect")['BFormSelectOption']
    'BFormSelectOptionGroup': typeof import("bootstrap-vue-next/components/BFormSelect")['BFormSelectOptionGroup']
    'BFormSpinbutton': typeof import("bootstrap-vue-next/components/BFormSpinbutton")['BFormSpinbutton']
    'BFormTag': typeof import("bootstrap-vue-next/components/BFormTags")['BFormTag']
    'BFormTags': typeof import("bootstrap-vue-next/components/BFormTags")['BFormTags']
    'BFormText': typeof import("bootstrap-vue-next/components/BForm")['BFormText']
    'BFormTextarea': typeof import("bootstrap-vue-next/components/BFormTextarea")['BFormTextarea']
    'BFormValidFeedback': typeof import("bootstrap-vue-next/components/BForm")['BFormValidFeedback']
    'BImg': typeof import("bootstrap-vue-next/components/BImg")['BImg']
    'BInput': typeof import("bootstrap-vue-next/components/BFormInput")['BInput']
    'BInputGroup': typeof import("bootstrap-vue-next/components/BInputGroup")['BInputGroup']
    'BInputGroupText': typeof import("bootstrap-vue-next/components/BInputGroup")['BInputGroupText']
    'BListGroup': typeof import("bootstrap-vue-next/components/BListGroup")['BListGroup']
    'BListGroupItem': typeof import("bootstrap-vue-next/components/BListGroup")['BListGroupItem']
    'BModal': typeof import("bootstrap-vue-next/components/BModal")['BModal']
    'BModalOrchestrator': typeof import("bootstrap-vue-next/components/BModal")['BModalOrchestrator']
    'BNav': typeof import("bootstrap-vue-next/components/BNav")['BNav']
    'BNavForm': typeof import("bootstrap-vue-next/components/BNav")['BNavForm']
    'BNavItem': typeof import("bootstrap-vue-next/components/BNav")['BNavItem']
    'BNavItemDropdown': typeof import("bootstrap-vue-next/components/BNav")['BNavItemDropdown']
    'BNavText': typeof import("bootstrap-vue-next/components/BNav")['BNavText']
    'BNavbar': typeof import("bootstrap-vue-next/components/BNavbar")['BNavbar']
    'BNavbarBrand': typeof import("bootstrap-vue-next/components/BNavbar")['BNavbarBrand']
    'BNavbarNav': typeof import("bootstrap-vue-next/components/BNavbar")['BNavbarNav']
    'BNavbarToggle': typeof import("bootstrap-vue-next/components/BNavbar")['BNavbarToggle']
    'BOffcanvas': typeof import("bootstrap-vue-next/components/BOffcanvas")['BOffcanvas']
    'BOverlay': typeof import("bootstrap-vue-next/components/BOverlay")['BOverlay']
    'BPagination': typeof import("bootstrap-vue-next/components/BPagination")['BPagination']
    'BPlaceholder': typeof import("bootstrap-vue-next/components/BPlaceholder")['BPlaceholder']
    'BPlaceholderButton': typeof import("bootstrap-vue-next/components/BPlaceholder")['BPlaceholderButton']
    'BPlaceholderCard': typeof import("bootstrap-vue-next/components/BPlaceholder")['BPlaceholderCard']
    'BPlaceholderTable': typeof import("bootstrap-vue-next/components/BPlaceholder")['BPlaceholderTable']
    'BPlaceholderWrapper': typeof import("bootstrap-vue-next/components/BPlaceholder")['BPlaceholderWrapper']
    'BPopover': typeof import("bootstrap-vue-next/components/BPopover")['BPopover']
    'BProgress': typeof import("bootstrap-vue-next/components/BProgress")['BProgress']
    'BRow': typeof import("bootstrap-vue-next/components/BContainer")['BRow']
    'BSpinner': typeof import("bootstrap-vue-next/components/BSpinner")['BSpinner']
    'BTab': typeof import("bootstrap-vue-next/components/BTabs")['BTab']
    'BTabs': typeof import("bootstrap-vue-next/components/BTabs")['BTabs']
    'BToast': typeof import("bootstrap-vue-next/components/BToast")['BToast']
    'BToastOrchestrator': typeof import("bootstrap-vue-next/components/BToast")['BToastOrchestrator']
    'BTooltip': typeof import("bootstrap-vue-next/components/BTooltip")['BTooltip']
    'BLink': typeof import("bootstrap-vue-next/components/BLink")['BLink']
    'BProgressBar': typeof import("bootstrap-vue-next/components/BProgress")['BProgressBar']
    'BTableSimple': typeof import("bootstrap-vue-next/components/BTable")['BTableSimple']
    'BTableLite': typeof import("bootstrap-vue-next/components/BTable")['BTableLite']
    'BTable': typeof import("bootstrap-vue-next/components/BTable")['BTable']
    'BTbody': typeof import("bootstrap-vue-next/components/BTable")['BTbody']
    'BTd': typeof import("bootstrap-vue-next/components/BTable")['BTd']
    'BTh': typeof import("bootstrap-vue-next/components/BTable")['BTh']
    'BThead': typeof import("bootstrap-vue-next/components/BTable")['BThead']
    'BTfoot': typeof import("bootstrap-vue-next/components/BTable")['BTfoot']
    'BTr': typeof import("bootstrap-vue-next/components/BTable")['BTr']
    'BPopoverOrchestrator': typeof import("bootstrap-vue-next/components/BPopover")['BPopoverOrchestrator']
    'BTooltipOrchestrator': typeof import("bootstrap-vue-next/components/BTooltip")['BTooltipOrchestrator']
    'Swiper': typeof import("swiper/vue")['Swiper']
    'SwiperSlide': typeof import("swiper/vue")['SwiperSlide']
    'ActivityIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ActivityIcon")['default']
    'AirplayIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/AirplayIcon")['default']
    'AlertCircleIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/AlertCircleIcon")['default']
    'AlertOctagonIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/AlertOctagonIcon")['default']
    'AlertTriangleIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/AlertTriangleIcon")['default']
    'AlignCenterIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/AlignCenterIcon")['default']
    'AlignJustifyIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/AlignJustifyIcon")['default']
    'AlignLeftIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/AlignLeftIcon")['default']
    'AlignRightIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/AlignRightIcon")['default']
    'AnchorIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/AnchorIcon")['default']
    'ApertureIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ApertureIcon")['default']
    'ArchiveIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ArchiveIcon")['default']
    'ArrowDownCircleIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ArrowDownCircleIcon")['default']
    'ArrowDownLeftIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ArrowDownLeftIcon")['default']
    'ArrowDownRightIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ArrowDownRightIcon")['default']
    'ArrowDownIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ArrowDownIcon")['default']
    'ArrowLeftCircleIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ArrowLeftCircleIcon")['default']
    'ArrowLeftIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ArrowLeftIcon")['default']
    'ArrowRightCircleIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ArrowRightCircleIcon")['default']
    'ArrowRightIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ArrowRightIcon")['default']
    'ArrowUpCircleIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ArrowUpCircleIcon")['default']
    'ArrowUpLeftIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ArrowUpLeftIcon")['default']
    'ArrowUpRightIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ArrowUpRightIcon")['default']
    'ArrowUpIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ArrowUpIcon")['default']
    'AtSignIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/AtSignIcon")['default']
    'AwardIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/AwardIcon")['default']
    'BarChart2Icon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/BarChart2Icon")['default']
    'BarChartIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/BarChartIcon")['default']
    'BatteryChargingIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/BatteryChargingIcon")['default']
    'BatteryIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/BatteryIcon")['default']
    'BellOffIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/BellOffIcon")['default']
    'BellIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/BellIcon")['default']
    'BluetoothIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/BluetoothIcon")['default']
    'BoldIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/BoldIcon")['default']
    'BookOpenIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/BookOpenIcon")['default']
    'BookIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/BookIcon")['default']
    'BookmarkIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/BookmarkIcon")['default']
    'BoxIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/BoxIcon")['default']
    'BriefcaseIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/BriefcaseIcon")['default']
    'CalendarIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CalendarIcon")['default']
    'CameraOffIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CameraOffIcon")['default']
    'CameraIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CameraIcon")['default']
    'CastIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CastIcon")['default']
    'CheckCircleIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CheckCircleIcon")['default']
    'CheckSquareIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CheckSquareIcon")['default']
    'CheckIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CheckIcon")['default']
    'ChevronDownIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ChevronDownIcon")['default']
    'ChevronLeftIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ChevronLeftIcon")['default']
    'ChevronRightIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ChevronRightIcon")['default']
    'ChevronUpIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ChevronUpIcon")['default']
    'ChevronsDownIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ChevronsDownIcon")['default']
    'ChevronsLeftIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ChevronsLeftIcon")['default']
    'ChevronsRightIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ChevronsRightIcon")['default']
    'ChevronsUpIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ChevronsUpIcon")['default']
    'ChromeIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ChromeIcon")['default']
    'CircleIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CircleIcon")['default']
    'ClipboardIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ClipboardIcon")['default']
    'ClockIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ClockIcon")['default']
    'CloudDrizzleIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CloudDrizzleIcon")['default']
    'CloudLightningIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CloudLightningIcon")['default']
    'CloudOffIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CloudOffIcon")['default']
    'CloudRainIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CloudRainIcon")['default']
    'CloudSnowIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CloudSnowIcon")['default']
    'CloudIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CloudIcon")['default']
    'CodeIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CodeIcon")['default']
    'CodepenIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CodepenIcon")['default']
    'CodesandboxIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CodesandboxIcon")['default']
    'CoffeeIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CoffeeIcon")['default']
    'ColumnsIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ColumnsIcon")['default']
    'CommandIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CommandIcon")['default']
    'CompassIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CompassIcon")['default']
    'CopyIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CopyIcon")['default']
    'CornerDownLeftIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CornerDownLeftIcon")['default']
    'CornerDownRightIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CornerDownRightIcon")['default']
    'CornerLeftDownIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CornerLeftDownIcon")['default']
    'CornerLeftUpIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CornerLeftUpIcon")['default']
    'CornerRightDownIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CornerRightDownIcon")['default']
    'CornerRightUpIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CornerRightUpIcon")['default']
    'CornerUpLeftIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CornerUpLeftIcon")['default']
    'CornerUpRightIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CornerUpRightIcon")['default']
    'CpuIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CpuIcon")['default']
    'CreditCardIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CreditCardIcon")['default']
    'CropIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CropIcon")['default']
    'CrosshairIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CrosshairIcon")['default']
    'DatabaseIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/DatabaseIcon")['default']
    'DeleteIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/DeleteIcon")['default']
    'DiscIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/DiscIcon")['default']
    'DivideCircleIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/DivideCircleIcon")['default']
    'DivideSquareIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/DivideSquareIcon")['default']
    'DivideIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/DivideIcon")['default']
    'DollarSignIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/DollarSignIcon")['default']
    'DownloadCloudIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/DownloadCloudIcon")['default']
    'DownloadIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/DownloadIcon")['default']
    'DribbbleIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/DribbbleIcon")['default']
    'DropletIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/DropletIcon")['default']
    'Edit2Icon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/Edit2Icon")['default']
    'Edit3Icon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/Edit3Icon")['default']
    'EditIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/EditIcon")['default']
    'ExternalLinkIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ExternalLinkIcon")['default']
    'EyeOffIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/EyeOffIcon")['default']
    'EyeIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/EyeIcon")['default']
    'FacebookIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/FacebookIcon")['default']
    'FastForwardIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/FastForwardIcon")['default']
    'FeatherIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/FeatherIcon")['default']
    'FigmaIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/FigmaIcon")['default']
    'FileMinusIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/FileMinusIcon")['default']
    'FilePlusIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/FilePlusIcon")['default']
    'FileTextIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/FileTextIcon")['default']
    'FileIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/FileIcon")['default']
    'FilmIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/FilmIcon")['default']
    'FilterIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/FilterIcon")['default']
    'FlagIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/FlagIcon")['default']
    'FolderMinusIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/FolderMinusIcon")['default']
    'FolderPlusIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/FolderPlusIcon")['default']
    'FolderIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/FolderIcon")['default']
    'FramerIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/FramerIcon")['default']
    'FrownIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/FrownIcon")['default']
    'GiftIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/GiftIcon")['default']
    'GitBranchIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/GitBranchIcon")['default']
    'GitCommitIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/GitCommitIcon")['default']
    'GitMergeIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/GitMergeIcon")['default']
    'GitPullRequestIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/GitPullRequestIcon")['default']
    'GithubIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/GithubIcon")['default']
    'GitlabIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/GitlabIcon")['default']
    'GlobeIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/GlobeIcon")['default']
    'GridIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/GridIcon")['default']
    'HardDriveIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/HardDriveIcon")['default']
    'HashIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/HashIcon")['default']
    'HeadphonesIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/HeadphonesIcon")['default']
    'HeartIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/HeartIcon")['default']
    'HelpCircleIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/HelpCircleIcon")['default']
    'HexagonIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/HexagonIcon")['default']
    'HomeIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/HomeIcon")['default']
    'ImageIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ImageIcon")['default']
    'InboxIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/InboxIcon")['default']
    'InfoIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/InfoIcon")['default']
    'InstagramIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/InstagramIcon")['default']
    'ItalicIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ItalicIcon")['default']
    'KeyIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/KeyIcon")['default']
    'LayersIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/LayersIcon")['default']
    'LayoutIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/LayoutIcon")['default']
    'LifeBuoyIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/LifeBuoyIcon")['default']
    'Link2Icon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/Link2Icon")['default']
    'LinkIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/LinkIcon")['default']
    'LinkedinIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/LinkedinIcon")['default']
    'ListIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ListIcon")['default']
    'LoaderIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/LoaderIcon")['default']
    'LockIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/LockIcon")['default']
    'LogInIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/LogInIcon")['default']
    'LogOutIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/LogOutIcon")['default']
    'MailIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/MailIcon")['default']
    'MapPinIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/MapPinIcon")['default']
    'MapIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/MapIcon")['default']
    'Maximize2Icon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/Maximize2Icon")['default']
    'MaximizeIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/MaximizeIcon")['default']
    'MehIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/MehIcon")['default']
    'MenuIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/MenuIcon")['default']
    'MessageCircleIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/MessageCircleIcon")['default']
    'MessageSquareIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/MessageSquareIcon")['default']
    'MicOffIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/MicOffIcon")['default']
    'MicIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/MicIcon")['default']
    'Minimize2Icon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/Minimize2Icon")['default']
    'MinimizeIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/MinimizeIcon")['default']
    'MinusCircleIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/MinusCircleIcon")['default']
    'MinusSquareIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/MinusSquareIcon")['default']
    'MinusIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/MinusIcon")['default']
    'MonitorIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/MonitorIcon")['default']
    'MoonIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/MoonIcon")['default']
    'MoreHorizontalIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/MoreHorizontalIcon")['default']
    'MoreVerticalIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/MoreVerticalIcon")['default']
    'MousePointerIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/MousePointerIcon")['default']
    'MoveIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/MoveIcon")['default']
    'MusicIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/MusicIcon")['default']
    'Navigation2Icon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/Navigation2Icon")['default']
    'NavigationIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/NavigationIcon")['default']
    'OctagonIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/OctagonIcon")['default']
    'PackageIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/PackageIcon")['default']
    'PaperclipIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/PaperclipIcon")['default']
    'PauseCircleIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/PauseCircleIcon")['default']
    'PauseIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/PauseIcon")['default']
    'PenToolIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/PenToolIcon")['default']
    'PercentIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/PercentIcon")['default']
    'PhoneCallIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/PhoneCallIcon")['default']
    'PhoneForwardedIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/PhoneForwardedIcon")['default']
    'PhoneIncomingIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/PhoneIncomingIcon")['default']
    'PhoneMissedIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/PhoneMissedIcon")['default']
    'PhoneOffIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/PhoneOffIcon")['default']
    'PhoneOutgoingIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/PhoneOutgoingIcon")['default']
    'PhoneIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/PhoneIcon")['default']
    'PieChartIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/PieChartIcon")['default']
    'PlayCircleIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/PlayCircleIcon")['default']
    'PlayIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/PlayIcon")['default']
    'PlusCircleIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/PlusCircleIcon")['default']
    'PlusSquareIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/PlusSquareIcon")['default']
    'PlusIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/PlusIcon")['default']
    'PocketIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/PocketIcon")['default']
    'PowerIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/PowerIcon")['default']
    'PrinterIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/PrinterIcon")['default']
    'RadioIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/RadioIcon")['default']
    'RefreshCcwIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/RefreshCcwIcon")['default']
    'RefreshCwIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/RefreshCwIcon")['default']
    'RepeatIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/RepeatIcon")['default']
    'RewindIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/RewindIcon")['default']
    'RotateCcwIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/RotateCcwIcon")['default']
    'RotateCwIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/RotateCwIcon")['default']
    'RssIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/RssIcon")['default']
    'SaveIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/SaveIcon")['default']
    'ScissorsIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ScissorsIcon")['default']
    'SearchIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/SearchIcon")['default']
    'SendIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/SendIcon")['default']
    'ServerIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ServerIcon")['default']
    'SettingsIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/SettingsIcon")['default']
    'Share2Icon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/Share2Icon")['default']
    'ShareIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ShareIcon")['default']
    'ShieldOffIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ShieldOffIcon")['default']
    'ShieldIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ShieldIcon")['default']
    'ShoppingBagIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ShoppingBagIcon")['default']
    'ShoppingCartIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ShoppingCartIcon")['default']
    'ShuffleIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ShuffleIcon")['default']
    'SidebarIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/SidebarIcon")['default']
    'SkipBackIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/SkipBackIcon")['default']
    'SkipForwardIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/SkipForwardIcon")['default']
    'SlackIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/SlackIcon")['default']
    'SlashIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/SlashIcon")['default']
    'SlidersIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/SlidersIcon")['default']
    'SmartphoneIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/SmartphoneIcon")['default']
    'SmileIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/SmileIcon")['default']
    'SpeakerIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/SpeakerIcon")['default']
    'SquareIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/SquareIcon")['default']
    'StarIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/StarIcon")['default']
    'StopCircleIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/StopCircleIcon")['default']
    'SunIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/SunIcon")['default']
    'SunriseIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/SunriseIcon")['default']
    'SunsetIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/SunsetIcon")['default']
    'TableIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/TableIcon")['default']
    'TabletIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/TabletIcon")['default']
    'TagIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/TagIcon")['default']
    'TargetIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/TargetIcon")['default']
    'TerminalIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/TerminalIcon")['default']
    'ThermometerIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ThermometerIcon")['default']
    'ThumbsDownIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ThumbsDownIcon")['default']
    'ThumbsUpIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ThumbsUpIcon")['default']
    'ToggleLeftIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ToggleLeftIcon")['default']
    'ToggleRightIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ToggleRightIcon")['default']
    'ToolIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ToolIcon")['default']
    'Trash2Icon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/Trash2Icon")['default']
    'TrashIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/TrashIcon")['default']
    'TrelloIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/TrelloIcon")['default']
    'TrendingDownIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/TrendingDownIcon")['default']
    'TrendingUpIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/TrendingUpIcon")['default']
    'TriangleIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/TriangleIcon")['default']
    'TruckIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/TruckIcon")['default']
    'TvIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/TvIcon")['default']
    'TwitchIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/TwitchIcon")['default']
    'TwitterIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/TwitterIcon")['default']
    'TypeIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/TypeIcon")['default']
    'UmbrellaIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/UmbrellaIcon")['default']
    'UnderlineIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/UnderlineIcon")['default']
    'UnlockIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/UnlockIcon")['default']
    'UploadCloudIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/UploadCloudIcon")['default']
    'UploadIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/UploadIcon")['default']
    'UserCheckIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/UserCheckIcon")['default']
    'UserMinusIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/UserMinusIcon")['default']
    'UserPlusIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/UserPlusIcon")['default']
    'UserXIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/UserXIcon")['default']
    'UserIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/UserIcon")['default']
    'UsersIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/UsersIcon")['default']
    'VideoOffIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/VideoOffIcon")['default']
    'VideoIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/VideoIcon")['default']
    'VoicemailIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/VoicemailIcon")['default']
    'Volume1Icon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/Volume1Icon")['default']
    'Volume2Icon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/Volume2Icon")['default']
    'VolumeXIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/VolumeXIcon")['default']
    'VolumeIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/VolumeIcon")['default']
    'WatchIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/WatchIcon")['default']
    'WifiOffIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/WifiOffIcon")['default']
    'WifiIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/WifiIcon")['default']
    'WindIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/WindIcon")['default']
    'XCircleIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/XCircleIcon")['default']
    'XOctagonIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/XOctagonIcon")['default']
    'XSquareIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/XSquareIcon")['default']
    'XIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/XIcon")['default']
    'YoutubeIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/YoutubeIcon")['default']
    'ZapOffIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ZapOffIcon")['default']
    'ZapIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ZapIcon")['default']
    'ZoomInIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ZoomInIcon")['default']
    'ZoomOutIcon': typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ZoomOutIcon")['default']
    'NuxtPage': typeof import("../node_modules/nuxt/dist/pages/runtime/page")['default']
    'NoScript': typeof import("../node_modules/nuxt/dist/head/runtime/components")['NoScript']
    'Link': typeof import("../node_modules/nuxt/dist/head/runtime/components")['Link']
    'Base': typeof import("../node_modules/nuxt/dist/head/runtime/components")['Base']
    'Title': typeof import("../node_modules/nuxt/dist/head/runtime/components")['Title']
    'Meta': typeof import("../node_modules/nuxt/dist/head/runtime/components")['Meta']
    'Style': typeof import("../node_modules/nuxt/dist/head/runtime/components")['Style']
    'Head': typeof import("../node_modules/nuxt/dist/head/runtime/components")['Head']
    'Html': typeof import("../node_modules/nuxt/dist/head/runtime/components")['Html']
    'Body': typeof import("../node_modules/nuxt/dist/head/runtime/components")['Body']
    'NuxtIsland': typeof import("../node_modules/nuxt/dist/app/components/nuxt-island")['default']
    'NuxtRouteAnnouncer': typeof import("../node_modules/nuxt/dist/app/components/server-placeholder")['default']
      'LazyApexChartsBasicBarAreaChart': LazyComponent<typeof import("../components/ApexCharts/BasicBarAreaChart.vue")['default']>
    'LazyApexChartsBasicColumnAreaChart': LazyComponent<typeof import("../components/ApexCharts/BasicColumnAreaChart.vue")['default']>
    'LazyApexChartsBasicLineChart': LazyComponent<typeof import("../components/ApexCharts/BasicLineChart.vue")['default']>
    'LazyApexChartsColumnWithDataLabelsChart': LazyComponent<typeof import("../components/ApexCharts/ColumnWithDataLabelsChart.vue")['default']>
    'LazyApexChartsDashedChart': LazyComponent<typeof import("../components/ApexCharts/DashedChart.vue")['default']>
    'LazyApexChartsGroupedChart': LazyComponent<typeof import("../components/ApexCharts/GroupedChart.vue")['default']>
    'LazyApexChartsLineWithDataLabelsChart': LazyComponent<typeof import("../components/ApexCharts/LineWithDataLabelsChart.vue")['default']>
    'LazyApexChartsNegativeAreaChart': LazyComponent<typeof import("../components/ApexCharts/NegativeAreaChart.vue")['default']>
    'LazyApexChartsSplineAreaChart': LazyComponent<typeof import("../components/ApexCharts/SplineAreaChart.vue")['default']>
    'LazyApexChartsSteplineChart': LazyComponent<typeof import("../components/ApexCharts/SteplineChart.vue")['default']>
    'LazyApexCharts': LazyComponent<typeof import("../components/ApexCharts/index.vue")['default']>
    'LazyAppsCalendarContent': LazyComponent<typeof import("../components/Apps/Calendar/CalendarContent.vue")['default']>
    'LazyAppsCalendarWorkingSchedule': LazyComponent<typeof import("../components/Apps/Calendar/WorkingSchedule.vue")['default']>
    'LazyAppsChat': LazyComponent<typeof import("../components/Apps/Chat/index.vue")['default']>
    'LazyAppsContactsList': LazyComponent<typeof import("../components/Apps/Contacts/ContactsList.vue")['default']>
    'LazyAppsEmailCompose': LazyComponent<typeof import("../components/Apps/Email/Compose/index.vue")['default']>
    'LazyAppsEmailDraft': LazyComponent<typeof import("../components/Apps/Email/Draft/index.vue")['default']>
    'LazyAppsEmailSidebar': LazyComponent<typeof import("../components/Apps/Email/EmailSidebar.vue")['default']>
    'LazyAppsEmailImportant': LazyComponent<typeof import("../components/Apps/Email/Important/index.vue")['default']>
    'LazyAppsEmailInbox': LazyComponent<typeof import("../components/Apps/Email/Inbox/index.vue")['default']>
    'LazyAppsEmailReadEmail': LazyComponent<typeof import("../components/Apps/Email/ReadEmail/index.vue")['default']>
    'LazyAppsEmailSentMail': LazyComponent<typeof import("../components/Apps/Email/SentMail/index.vue")['default']>
    'LazyAppsEmailSnoozed': LazyComponent<typeof import("../components/Apps/Email/Snoozed/index.vue")['default']>
    'LazyAppsEmailSpam': LazyComponent<typeof import("../components/Apps/Email/Spam/index.vue")['default']>
    'LazyAppsEmailStarred': LazyComponent<typeof import("../components/Apps/Email/Starred/index.vue")['default']>
    'LazyAppsEmailTrash': LazyComponent<typeof import("../components/Apps/Email/Trash/index.vue")['default']>
    'LazyAppsFileManagerApplications': LazyComponent<typeof import("../components/Apps/FileManager/Applications/index.vue")['default']>
    'LazyAppsFileManagerAssets': LazyComponent<typeof import("../components/Apps/FileManager/Assets/index.vue")['default']>
    'LazyAppsFileManagerDocuments': LazyComponent<typeof import("../components/Apps/FileManager/Documents/index.vue")['default']>
    'LazyAppsFileManagerImportant': LazyComponent<typeof import("../components/Apps/FileManager/Important/index.vue")['default']>
    'LazyAppsFileManagerMedia': LazyComponent<typeof import("../components/Apps/FileManager/Media/index.vue")['default']>
    'LazyAppsFileManagerMyDriveFiles': LazyComponent<typeof import("../components/Apps/FileManager/MyDrive/MyDriveFiles.vue")['default']>
    'LazyAppsFileManagerMyDriveRecentFiles': LazyComponent<typeof import("../components/Apps/FileManager/MyDrive/RecentFiles.vue")['default']>
    'LazyAppsFileManagerPersonal': LazyComponent<typeof import("../components/Apps/FileManager/Personal/index.vue")['default']>
    'LazyAppsFileManagerProjects': LazyComponent<typeof import("../components/Apps/FileManager/Projects/index.vue")['default']>
    'LazyAppsFileManagerRecants': LazyComponent<typeof import("../components/Apps/FileManager/Recants/index.vue")['default']>
    'LazyAppsFileManagerSidebar': LazyComponent<typeof import("../components/Apps/FileManager/Sidebar.vue")['default']>
    'LazyAppsFileManagerSpam': LazyComponent<typeof import("../components/Apps/FileManager/Spam/index.vue")['default']>
    'LazyAppsFileManagerTrash': LazyComponent<typeof import("../components/Apps/FileManager/Trash/index.vue")['default']>
    'LazyAppsKanbanBoard': LazyComponent<typeof import("../components/Apps/KanbanBoard/index.vue")['default']>
    'LazyAppsToDoList': LazyComponent<typeof import("../components/Apps/ToDoList/index.vue")['default']>
    'LazyCommonCalendarContent': LazyComponent<typeof import("../components/Common/CalendarContent.vue")['default']>
    'LazyCommonDatePicker': LazyComponent<typeof import("../components/Common/DatePicker.vue")['default']>
    'LazyCommonPageTitle': LazyComponent<typeof import("../components/Common/PageTitle.vue")['default']>
    'LazyCommonPagination': LazyComponent<typeof import("../components/Common/Pagination.vue")['default']>
    'LazyCommonPaginationTwo': LazyComponent<typeof import("../components/Common/PaginationTwo.vue")['default']>
    'LazyCommonTextEditor': LazyComponent<typeof import("../components/Common/TextEditor.vue")['default']>
    'LazyDashboardAnalyticsOverviewChart': LazyComponent<typeof import("../components/Dashboard/Analytics/AnalyticsOverviewChart.vue")['default']>
    'LazyDashboardAnalyticsBrowserUsedByUsers': LazyComponent<typeof import("../components/Dashboard/Analytics/BrowserUsedByUsers.vue")['default']>
    'LazyDashboardAnalyticsBrowserUsedByUsersChart': LazyComponent<typeof import("../components/Dashboard/Analytics/BrowserUsedByUsersChart.vue")['default']>
    'LazyDashboardAnalyticsClicksChart': LazyComponent<typeof import("../components/Dashboard/Analytics/ClicksChart.vue")['default']>
    'LazyDashboardAnalyticsClicksImpressionsByKeywords': LazyComponent<typeof import("../components/Dashboard/Analytics/ClicksImpressionsByKeywords.vue")['default']>
    'LazyDashboardAnalyticsImpressionsChart': LazyComponent<typeof import("../components/Dashboard/Analytics/ImpressionsChart.vue")['default']>
    'LazyDashboardAnalyticsNewRegistersChart': LazyComponent<typeof import("../components/Dashboard/Analytics/NewRegistersChart.vue")['default']>
    'LazyDashboardAnalyticsRealtimeActiveUsersChart': LazyComponent<typeof import("../components/Dashboard/Analytics/RealtimeActiveUsersChart.vue")['default']>
    'LazyDashboardAnalyticsSessionsByChannelChart': LazyComponent<typeof import("../components/Dashboard/Analytics/SessionsByChannelChart.vue")['default']>
    'LazyDashboardAnalyticsSessionsChart': LazyComponent<typeof import("../components/Dashboard/Analytics/SessionsChart.vue")['default']>
    'LazyDashboardAnalyticsTopBrowsingPagesToday': LazyComponent<typeof import("../components/Dashboard/Analytics/TopBrowsingPagesToday.vue")['default']>
    'LazyDashboardAnalyticsUsersByCountry': LazyComponent<typeof import("../components/Dashboard/Analytics/UsersByCountry.vue")['default']>
    'LazyDashboardAnalyticsWebsiteVisitsChart': LazyComponent<typeof import("../components/Dashboard/Analytics/WebsiteVisitsChart.vue")['default']>
    'LazyDashboardBeautySalonCustomerSatisfactionRateChart': LazyComponent<typeof import("../components/Dashboard/BeautySalon/CustomerSatisfactionRateChart.vue")['default']>
    'LazyDashboardBeautySalonCustomersFromChannels': LazyComponent<typeof import("../components/Dashboard/BeautySalon/CustomersFromChannels.vue")['default']>
    'LazyDashboardBeautySalonFeaturedServices': LazyComponent<typeof import("../components/Dashboard/BeautySalon/FeaturedServices.vue")['default']>
    'LazyDashboardBeautySalonNewCustomers': LazyComponent<typeof import("../components/Dashboard/BeautySalon/NewCustomers.vue")['default']>
    'LazyDashboardBeautySalonRecentAppointments': LazyComponent<typeof import("../components/Dashboard/BeautySalon/RecentAppointments.vue")['default']>
    'LazyDashboardBeautySalonRevenueByServicesChart': LazyComponent<typeof import("../components/Dashboard/BeautySalon/RevenueByServicesChart.vue")['default']>
    'LazyDashboardBeautySalonTopCustomers': LazyComponent<typeof import("../components/Dashboard/BeautySalon/TopCustomers.vue")['default']>
    'LazyDashboardBeautySalonTopSellingProducts': LazyComponent<typeof import("../components/Dashboard/BeautySalon/TopSellingProducts.vue")['default']>
    'LazyDashboardBeautySalonTopStylistPerformance': LazyComponent<typeof import("../components/Dashboard/BeautySalon/TopStylistPerformance.vue")['default']>
    'LazyDashboardBeautySalonWelcomeBeautySalon': LazyComponent<typeof import("../components/Dashboard/BeautySalon/WelcomeBeautySalon.vue")['default']>
    'LazyDashboardCRMAnnualProfitChart': LazyComponent<typeof import("../components/Dashboard/CRM/AnnualProfitChart.vue")['default']>
    'LazyDashboardCRMBalanceOverviewChart': LazyComponent<typeof import("../components/Dashboard/CRM/BalanceOverviewChart.vue")['default']>
    'LazyDashboardCRMLeadConversionChart': LazyComponent<typeof import("../components/Dashboard/CRM/LeadConversionChart.vue")['default']>
    'LazyDashboardCRMLeadsBySourceChart': LazyComponent<typeof import("../components/Dashboard/CRM/LeadsBySourceChart.vue")['default']>
    'LazyDashboardCRMRecentLeads': LazyComponent<typeof import("../components/Dashboard/CRM/RecentLeads.vue")['default']>
    'LazyDashboardCRMRevenueGrowthChart': LazyComponent<typeof import("../components/Dashboard/CRM/RevenueGrowthChart.vue")['default']>
    'LazyDashboardCRMSalesReportChart': LazyComponent<typeof import("../components/Dashboard/CRM/SalesReportChart.vue")['default']>
    'LazyDashboardCRMTopPerformers': LazyComponent<typeof import("../components/Dashboard/CRM/TopPerformers.vue")['default']>
    'LazyDashboardCRMTopProductsBySales': LazyComponent<typeof import("../components/Dashboard/CRM/TopProductsBySales.vue")['default']>
    'LazyDashboardCRMTotalOrdersChart': LazyComponent<typeof import("../components/Dashboard/CRM/TotalOrdersChart.vue")['default']>
    'LazyDashboardCallCenterAgentAvgEarningsChart': LazyComponent<typeof import("../components/Dashboard/CallCenter/AgentAvgEarnings/AgentAvgEarningsChart.vue")['default']>
    'LazyDashboardCallCenterAgentAvgEarningsFiveChart': LazyComponent<typeof import("../components/Dashboard/CallCenter/AgentAvgEarnings/AgentAvgEarningsFiveChart.vue")['default']>
    'LazyDashboardCallCenterAgentAvgEarningsFourChart': LazyComponent<typeof import("../components/Dashboard/CallCenter/AgentAvgEarnings/AgentAvgEarningsFourChart.vue")['default']>
    'LazyDashboardCallCenterAgentAvgEarningsThreeChart': LazyComponent<typeof import("../components/Dashboard/CallCenter/AgentAvgEarnings/AgentAvgEarningsThreeChart.vue")['default']>
    'LazyDashboardCallCenterAgentAvgEarningsTwoChart': LazyComponent<typeof import("../components/Dashboard/CallCenter/AgentAvgEarnings/AgentAvgEarningsTwoChart.vue")['default']>
    'LazyDashboardCallCenterAgentAvgEarnings': LazyComponent<typeof import("../components/Dashboard/CallCenter/AgentAvgEarnings/index.vue")['default']>
    'LazyDashboardCallCenterAgentsPerformanceOverview': LazyComponent<typeof import("../components/Dashboard/CallCenter/AgentsPerformanceOverview.vue")['default']>
    'LazyDashboardCallCenterGeography': LazyComponent<typeof import("../components/Dashboard/CallCenter/CallCenterGeography.vue")['default']>
    'LazyDashboardCallCenterInboundCallsChart': LazyComponent<typeof import("../components/Dashboard/CallCenter/InboundCallsChart.vue")['default']>
    'LazyDashboardCallCenterOutboundCallsChart': LazyComponent<typeof import("../components/Dashboard/CallCenter/OutboundCallsChart.vue")['default']>
    'LazyDashboardCallCenterOverviewAnsweredCallsChart': LazyComponent<typeof import("../components/Dashboard/CallCenter/Overview/AnsweredCallsChart.vue")['default']>
    'LazyDashboardCallCenterOverviewMissedCallsChart': LazyComponent<typeof import("../components/Dashboard/CallCenter/Overview/MissedCallsChart.vue")['default']>
    'LazyDashboardCallCenterOverviewTotalCallsChart': LazyComponent<typeof import("../components/Dashboard/CallCenter/Overview/TotalCallsChart.vue")['default']>
    'LazyDashboardCallCenterOverview': LazyComponent<typeof import("../components/Dashboard/CallCenter/Overview/index.vue")['default']>
    'LazyDashboardCallCenterRecentCalls': LazyComponent<typeof import("../components/Dashboard/CallCenter/RecentCalls.vue")['default']>
    'LazyDashboardCreditCardCardsWithAmountChart': LazyComponent<typeof import("../components/Dashboard/CreditCard/CardsWithAmountChart.vue")['default']>
    'LazyDashboardCreditCardCreditUtilizationRatioChart': LazyComponent<typeof import("../components/Dashboard/CreditCard/CreditUtilizationRatioChart.vue")['default']>
    'LazyDashboardCreditCardDailyLimit': LazyComponent<typeof import("../components/Dashboard/CreditCard/DailyLimit.vue")['default']>
    'LazyDashboardCreditCardInterestChargeFeesChart': LazyComponent<typeof import("../components/Dashboard/CreditCard/InterestChargeFeesChart.vue")['default']>
    'LazyDashboardCreditCardMonthlySpendingChart': LazyComponent<typeof import("../components/Dashboard/CreditCard/MonthlySpendingChart.vue")['default']>
    'LazyDashboardCreditCardMyCards': LazyComponent<typeof import("../components/Dashboard/CreditCard/MyCards.vue")['default']>
    'LazyDashboardCreditCardQuickTransfer': LazyComponent<typeof import("../components/Dashboard/CreditCard/QuickTransfer.vue")['default']>
    'LazyDashboardCreditCardRecentTransactions': LazyComponent<typeof import("../components/Dashboard/CreditCard/RecentTransactions.vue")['default']>
    'LazyDashboardCreditCardSpendingBreakdownChart': LazyComponent<typeof import("../components/Dashboard/CreditCard/SpendingBreakdownChart.vue")['default']>
    'LazyDashboardCreditCardStatisticsChart': LazyComponent<typeof import("../components/Dashboard/CreditCard/StatisticsChart.vue")['default']>
    'LazyDashboardCreditCardTotalBalance': LazyComponent<typeof import("../components/Dashboard/CreditCard/TotalBalance.vue")['default']>
    'LazyDashboardCreditCardTotalExpense': LazyComponent<typeof import("../components/Dashboard/CreditCard/TotalExpense.vue")['default']>
    'LazyDashboardCryptoBinanceChart': LazyComponent<typeof import("../components/Dashboard/Crypto/BinanceChart.vue")['default']>
    'LazyDashboardCryptoBitcoinChart': LazyComponent<typeof import("../components/Dashboard/Crypto/BitcoinChart.vue")['default']>
    'LazyDashboardCryptoCardanoChart': LazyComponent<typeof import("../components/Dashboard/Crypto/CardanoChart.vue")['default']>
    'LazyDashboardCryptoRankings': LazyComponent<typeof import("../components/Dashboard/Crypto/CryptoRankings.vue")['default']>
    'LazyDashboardCryptoCryptocurrencyWatchList': LazyComponent<typeof import("../components/Dashboard/Crypto/CryptocurrencyWatchList.vue")['default']>
    'LazyDashboardCryptoEthereumChart': LazyComponent<typeof import("../components/Dashboard/Crypto/EthereumChart.vue")['default']>
    'LazyDashboardCryptoExchangeCoin': LazyComponent<typeof import("../components/Dashboard/Crypto/ExchangeCoin.vue")['default']>
    'LazyDashboardCryptoMarketPriceStatisticsChart': LazyComponent<typeof import("../components/Dashboard/Crypto/MarketPriceStatisticsChart.vue")['default']>
    'LazyDashboardCryptoPortfolio': LazyComponent<typeof import("../components/Dashboard/Crypto/Portfolio.vue")['default']>
    'LazyDashboardCryptoSolanaChart': LazyComponent<typeof import("../components/Dashboard/Crypto/SolanaChart.vue")['default']>
    'LazyDashboardCryptoTransactionHistory': LazyComponent<typeof import("../components/Dashboard/Crypto/TransactionHistory.vue")['default']>
    'LazyDashboardCryptoPerformanceBreadcrumb': LazyComponent<typeof import("../components/Dashboard/CryptoPerformance/Breadcrumb.vue")['default']>
    'LazyDashboardCryptoPerformanceComparativeAnalysisChart': LazyComponent<typeof import("../components/Dashboard/CryptoPerformance/ComparativeAnalysisChart.vue")['default']>
    'LazyDashboardCryptoPerformanceCryptoMarketCap': LazyComponent<typeof import("../components/Dashboard/CryptoPerformance/CryptoMarketCap.vue")['default']>
    'LazyDashboardCryptoPerformanceIndividualAssetPerformance': LazyComponent<typeof import("../components/Dashboard/CryptoPerformance/IndividualAssetPerformance.vue")['default']>
    'LazyDashboardCryptoPerformanceMarketPerformanceChart': LazyComponent<typeof import("../components/Dashboard/CryptoPerformance/MarketPerformanceChart.vue")['default']>
    'LazyDashboardCryptoPerformanceMetricsChart': LazyComponent<typeof import("../components/Dashboard/CryptoPerformance/PerformanceMetricsChart.vue")['default']>
    'LazyDashboardCryptoPerformancePerInvestmentChart': LazyComponent<typeof import("../components/Dashboard/CryptoPerformance/PerformancePerInvestmentChart.vue")['default']>
    'LazyDashboardCryptoPerformancePortfolioValue': LazyComponent<typeof import("../components/Dashboard/CryptoPerformance/PortfolioValue.vue")['default']>
    'LazyDashboardCryptoPerformanceRiskStabilityIndicatorsChart': LazyComponent<typeof import("../components/Dashboard/CryptoPerformance/RiskStabilityIndicatorsChart.vue")['default']>
    'LazyDashboardCryptoPerformanceTransactionsHistory': LazyComponent<typeof import("../components/Dashboard/CryptoPerformance/TransactionsHistory.vue")['default']>
    'LazyDashboardCryptoTraderAssetAllocationChart': LazyComponent<typeof import("../components/Dashboard/CryptoTrader/AssetAllocationChart.vue")['default']>
    'LazyDashboardCryptoTraderCryptoStatsPanel': LazyComponent<typeof import("../components/Dashboard/CryptoTrader/CryptoStatsPanel.vue")['default']>
    'LazyDashboardCryptoTraderGainersLosers': LazyComponent<typeof import("../components/Dashboard/CryptoTrader/GainersLosers.vue")['default']>
    'LazyDashboardCryptoTraderLivePriceTracker': LazyComponent<typeof import("../components/Dashboard/CryptoTrader/LivePriceTracker.vue")['default']>
    'LazyDashboardCryptoTraderMarketSentimentIndicatorChart': LazyComponent<typeof import("../components/Dashboard/CryptoTrader/MarketSentimentIndicatorChart.vue")['default']>
    'LazyDashboardCryptoTraderPortfolioDistributionChart': LazyComponent<typeof import("../components/Dashboard/CryptoTrader/PortfolioDistributionChart.vue")['default']>
    'LazyDashboardCryptoTraderPriceMovementChart': LazyComponent<typeof import("../components/Dashboard/CryptoTrader/PriceMovementChart.vue")['default']>
    'LazyDashboardCryptoTraderProfitLossChart': LazyComponent<typeof import("../components/Dashboard/CryptoTrader/ProfitLossChart.vue")['default']>
    'LazyDashboardCryptoTraderRecentTransactions': LazyComponent<typeof import("../components/Dashboard/CryptoTrader/RecentTransactions.vue")['default']>
    'LazyDashboardCryptoTraderRiskExposureChart': LazyComponent<typeof import("../components/Dashboard/CryptoTrader/RiskExposureChart.vue")['default']>
    'LazyDashboardCryptoTraderTradesPerMonthChart': LazyComponent<typeof import("../components/Dashboard/CryptoTrader/TradesPerMonthChart.vue")['default']>
    'LazyDashboardCryptoTraderTradingVolumeChart': LazyComponent<typeof import("../components/Dashboard/CryptoTrader/TradingVolumeChart.vue")['default']>
    'LazyDashboardDoctorWelcome': LazyComponent<typeof import("../components/Dashboard/Doctor/DoctorWelcome.vue")['default']>
    'LazyDashboardDoctorIncomeExpenseChart': LazyComponent<typeof import("../components/Dashboard/Doctor/IncomeExpenseChart.vue")['default']>
    'LazyDashboardDoctorMyRecentPatients': LazyComponent<typeof import("../components/Dashboard/Doctor/MyRecentPatients.vue")['default']>
    'LazyDashboardDoctorPatientDistributionChart': LazyComponent<typeof import("../components/Dashboard/Doctor/PatientDistributionChart.vue")['default']>
    'LazyDashboardDoctorPatientRetentionChart': LazyComponent<typeof import("../components/Dashboard/Doctor/PatientRetentionChart.vue")['default']>
    'LazyDashboardDoctorRecentLabReports': LazyComponent<typeof import("../components/Dashboard/Doctor/RecentLabReports.vue")['default']>
    'LazyDashboardDoctorStatsAppointments': LazyComponent<typeof import("../components/Dashboard/Doctor/Stats/Appointments.vue")['default']>
    'LazyDashboardDoctorStatsEarnings': LazyComponent<typeof import("../components/Dashboard/Doctor/Stats/Earnings.vue")['default']>
    'LazyDashboardDoctorStatsOperations': LazyComponent<typeof import("../components/Dashboard/Doctor/Stats/Operations.vue")['default']>
    'LazyDashboardDoctorStatsPatients': LazyComponent<typeof import("../components/Dashboard/Doctor/Stats/Patients.vue")['default']>
    'LazyDashboardDoctorStats': LazyComponent<typeof import("../components/Dashboard/Doctor/Stats/index.vue")['default']>
    'LazyDashboardDoctorTodaySchedule': LazyComponent<typeof import("../components/Dashboard/Doctor/TodaySchedule.vue")['default']>
    'LazyDashboardDoctorUpgradePlan': LazyComponent<typeof import("../components/Dashboard/Doctor/UpgradePlan.vue")['default']>
    'LazyDashboardFinanceAccountPayable': LazyComponent<typeof import("../components/Dashboard/Finance/AccountPayable.vue")['default']>
    'LazyDashboardFinanceAccountsReceivable': LazyComponent<typeof import("../components/Dashboard/Finance/AccountsReceivable.vue")['default']>
    'LazyDashboardFinanceAddCardDetailModal': LazyComponent<typeof import("../components/Dashboard/Finance/AddCardDetailModal.vue")['default']>
    'LazyDashboardFinanceCashEndOfTheMonthChart': LazyComponent<typeof import("../components/Dashboard/Finance/CashEndOfTheMonthChart.vue")['default']>
    'LazyDashboardFinanceDebitCard': LazyComponent<typeof import("../components/Dashboard/Finance/DebitCard.vue")['default']>
    'LazyDashboardFinanceExpenseBreakdownChart': LazyComponent<typeof import("../components/Dashboard/Finance/ExpenseBreakdownChart.vue")['default']>
    'LazyDashboardFinanceIncomeSourceChart': LazyComponent<typeof import("../components/Dashboard/Finance/IncomeSourceChart.vue")['default']>
    'LazyDashboardFinanceNetProfitChart': LazyComponent<typeof import("../components/Dashboard/Finance/NetProfitChart.vue")['default']>
    'LazyDashboardFinanceStaticChart': LazyComponent<typeof import("../components/Dashboard/Finance/StaticChart.vue")['default']>
    'LazyDashboardFinanceTotalExpenses': LazyComponent<typeof import("../components/Dashboard/Finance/TotalExpenses.vue")['default']>
    'LazyDashboardFinanceTotalIncome': LazyComponent<typeof import("../components/Dashboard/Finance/TotalIncome.vue")['default']>
    'LazyDashboardFinanceTransactionHistory': LazyComponent<typeof import("../components/Dashboard/Finance/TransactionHistory.vue")['default']>
    'LazyDashboardFinanceWeeklyExpensesChart': LazyComponent<typeof import("../components/Dashboard/Finance/WeeklyExpensesChart.vue")['default']>
    'LazyDashboardHRMDateRangePicker': LazyComponent<typeof import("../components/Dashboard/HRM/DateRangePicker.vue")['default']>
    'LazyDashboardHRMEmployeeAttendanceTrendsChart': LazyComponent<typeof import("../components/Dashboard/HRM/EmployeeAttendanceTrendsChart.vue")['default']>
    'LazyDashboardHRMEmployeeLeaveRequest': LazyComponent<typeof import("../components/Dashboard/HRM/EmployeeLeaveRequest.vue")['default']>
    'LazyDashboardHRMEmployeeList': LazyComponent<typeof import("../components/Dashboard/HRM/EmployeeList.vue")['default']>
    'LazyDashboardHRMEmployeeSalaryChart': LazyComponent<typeof import("../components/Dashboard/HRM/EmployeeSalaryChart.vue")['default']>
    'LazyDashboardHRMEmployeeWorkFormatChart': LazyComponent<typeof import("../components/Dashboard/HRM/EmployeeWorkFormatChart.vue")['default']>
    'LazyDashboardHRMNewEmployees': LazyComponent<typeof import("../components/Dashboard/HRM/NewEmployees.vue")['default']>
    'LazyDashboardHRMResignedEmployees': LazyComponent<typeof import("../components/Dashboard/HRM/ResignedEmployees.vue")['default']>
    'LazyDashboardHRMTotalEmployees': LazyComponent<typeof import("../components/Dashboard/HRM/TotalEmployees.vue")['default']>
    'LazyDashboardHRMWelcomeBack': LazyComponent<typeof import("../components/Dashboard/HRM/WelcomeBack.vue")['default']>
    'LazyDashboardHelpDeskCongratulations': LazyComponent<typeof import("../components/Dashboard/HelpDesk/Congratulations.vue")['default']>
    'LazyDashboardHelpDeskCustomerSatisfactionChart': LazyComponent<typeof import("../components/Dashboard/HelpDesk/CustomerSatisfactionChart.vue")['default']>
    'LazyDashboardHelpDeskNewAndSolvedTicketsChart': LazyComponent<typeof import("../components/Dashboard/HelpDesk/NewAndSolvedTicketsChart.vue")['default']>
    'LazyDashboardHelpDeskPerformanceOfAgents': LazyComponent<typeof import("../components/Dashboard/HelpDesk/PerformanceOfAgents.vue")['default']>
    'LazyDashboardHelpDeskRecentCustomerRatings': LazyComponent<typeof import("../components/Dashboard/HelpDesk/RecentCustomerRatings.vue")['default']>
    'LazyDashboardHelpDeskResponseTimeChart': LazyComponent<typeof import("../components/Dashboard/HelpDesk/ResponseTimeChart.vue")['default']>
    'LazyDashboardHelpDeskSupportOverviewChart': LazyComponent<typeof import("../components/Dashboard/HelpDesk/SupportOverviewChart.vue")['default']>
    'LazyDashboardHelpDeskTicketsDueChart': LazyComponent<typeof import("../components/Dashboard/HelpDesk/TicketsDueChart.vue")['default']>
    'LazyDashboardHelpDeskTicketsInProgressChart': LazyComponent<typeof import("../components/Dashboard/HelpDesk/TicketsInProgressChart.vue")['default']>
    'LazyDashboardHelpDeskTicketsNewOpenChart': LazyComponent<typeof import("../components/Dashboard/HelpDesk/TicketsNewOpenChart.vue")['default']>
    'LazyDashboardHelpDeskTicketsResolvedChart': LazyComponent<typeof import("../components/Dashboard/HelpDesk/TicketsResolvedChart.vue")['default']>
    'LazyDashboardHelpDeskTicketsStatusChart': LazyComponent<typeof import("../components/Dashboard/HelpDesk/TicketsStatusChart.vue")['default']>
    'LazyDashboardHelpDeskToDoList': LazyComponent<typeof import("../components/Dashboard/HelpDesk/ToDoList.vue")['default']>
    'LazyDashboardHospitalBedOccupancyRateChart': LazyComponent<typeof import("../components/Dashboard/Hospital/BedOccupancyRateChart.vue")['default']>
    'LazyDashboardHospitalCriticalPatientsChart': LazyComponent<typeof import("../components/Dashboard/Hospital/CriticalPatientsChart.vue")['default']>
    'LazyDashboardHospitalDateRangePicker': LazyComponent<typeof import("../components/Dashboard/Hospital/DateRangePicker.vue")['default']>
    'LazyDashboardHospitalEmergencyRoomVisitsChart': LazyComponent<typeof import("../components/Dashboard/Hospital/EmergencyRoomVisitsChart.vue")['default']>
    'LazyDashboardHospitalEarnings': LazyComponent<typeof import("../components/Dashboard/Hospital/HospitalEarnings.vue")['default']>
    'LazyDashboardHospitalOverallVisitorsChart': LazyComponent<typeof import("../components/Dashboard/Hospital/OverallVisitorsChart.vue")['default']>
    'LazyDashboardHospitalPatientAdmissionsDischargesChart': LazyComponent<typeof import("../components/Dashboard/Hospital/PatientAdmissionsDischargesChart.vue")['default']>
    'LazyDashboardHospitalPatientAppointments': LazyComponent<typeof import("../components/Dashboard/Hospital/PatientAppointments.vue")['default']>
    'LazyDashboardHospitalPatientByAgeChart': LazyComponent<typeof import("../components/Dashboard/Hospital/PatientByAgeChart.vue")['default']>
    'LazyDashboardHospitalPatientsChart': LazyComponent<typeof import("../components/Dashboard/Hospital/PatientsChart.vue")['default']>
    'LazyDashboardHospitalScheduleAppointment': LazyComponent<typeof import("../components/Dashboard/Hospital/ScheduleAppointment.vue")['default']>
    'LazyDashboardHospitalYourScheduleToday': LazyComponent<typeof import("../components/Dashboard/Hospital/YourScheduleToday.vue")['default']>
    'LazyDashboardHotelCustomerReviews': LazyComponent<typeof import("../components/Dashboard/Hotel/CustomerReviews.vue")['default']>
    'LazyDashboardHotelGuestActivityChart': LazyComponent<typeof import("../components/Dashboard/Hotel/GuestActivityChart.vue")['default']>
    'LazyDashboardHotelPopularRooms': LazyComponent<typeof import("../components/Dashboard/Hotel/PopularRooms.vue")['default']>
    'LazyDashboardHotelRecentBookings': LazyComponent<typeof import("../components/Dashboard/Hotel/RecentBookings.vue")['default']>
    'LazyDashboardHotelRoomsAvailabilityChart': LazyComponent<typeof import("../components/Dashboard/Hotel/RoomsAvailabilityChart.vue")['default']>
    'LazyDashboardHotelStatsCheckIn': LazyComponent<typeof import("../components/Dashboard/Hotel/Stats/CheckIn.vue")['default']>
    'LazyDashboardHotelStatsCheckOut': LazyComponent<typeof import("../components/Dashboard/Hotel/Stats/CheckOut.vue")['default']>
    'LazyDashboardHotelStatsNewBookings': LazyComponent<typeof import("../components/Dashboard/Hotel/Stats/NewBookings.vue")['default']>
    'LazyDashboardHotelStats': LazyComponent<typeof import("../components/Dashboard/Hotel/Stats/index.vue")['default']>
    'LazyDashboardHotelUpcomingVIPReservations': LazyComponent<typeof import("../components/Dashboard/Hotel/UpcomingVIPReservations.vue")['default']>
    'LazyDashboardLMSCourses': LazyComponent<typeof import("../components/Dashboard/LMS/Courses.vue")['default']>
    'LazyDashboardLMSCoursesSalesChart': LazyComponent<typeof import("../components/Dashboard/LMS/CoursesSalesChart.vue")['default']>
    'LazyDashboardLMSEnrolledByCountries': LazyComponent<typeof import("../components/Dashboard/LMS/EnrolledByCountries.vue")['default']>
    'LazyDashboardLMSGroupLessons': LazyComponent<typeof import("../components/Dashboard/LMS/GroupLessons.vue")['default']>
    'LazyDashboardLMSOurTopCourses': LazyComponent<typeof import("../components/Dashboard/LMS/OurTopCourses.vue")['default']>
    'LazyDashboardLMSStudentsInterestedTopicsChart': LazyComponent<typeof import("../components/Dashboard/LMS/StudentsInterestedTopicsChart.vue")['default']>
    'LazyDashboardLMSStudentsProgress': LazyComponent<typeof import("../components/Dashboard/LMS/StudentsProgress.vue")['default']>
    'LazyDashboardLMSTimeSpentChart': LazyComponent<typeof import("../components/Dashboard/LMS/TimeSpentChart.vue")['default']>
    'LazyDashboardLMSTopInstructors': LazyComponent<typeof import("../components/Dashboard/LMS/TopInstructors.vue")['default']>
    'LazyDashboardLMSTotalCourses': LazyComponent<typeof import("../components/Dashboard/LMS/TotalCourses.vue")['default']>
    'LazyDashboardLMSTotalEnrolled': LazyComponent<typeof import("../components/Dashboard/LMS/TotalEnrolled.vue")['default']>
    'LazyDashboardLMSTotalMentors': LazyComponent<typeof import("../components/Dashboard/LMS/TotalMentors.vue")['default']>
    'LazyDashboardLMSWelcomeDashboard': LazyComponent<typeof import("../components/Dashboard/LMS/WelcomeDashboard.vue")['default']>
    'LazyDashboardMarketingAvatarPreview': LazyComponent<typeof import("../components/Dashboard/Marketing/AvatarPreview.vue")['default']>
    'LazyDashboardMarketingCampaignsContent': LazyComponent<typeof import("../components/Dashboard/Marketing/CampaignsContent.vue")['default']>
    'LazyDashboardMarketingChannelsContent': LazyComponent<typeof import("../components/Dashboard/Marketing/ChannelsContent.vue")['default']>
    'LazyDashboardMarketingCreateCampaignsModal': LazyComponent<typeof import("../components/Dashboard/Marketing/CreateCampaignsModal.vue")['default']>
    'LazyDashboardMarketingExternalLinks': LazyComponent<typeof import("../components/Dashboard/Marketing/ExternalLinks.vue")['default']>
    'LazyDashboardMarketingHighlightsContent': LazyComponent<typeof import("../components/Dashboard/Marketing/HighlightsContent.vue")['default']>
    'LazyDashboardMarketingInstagramCampaignsChart': LazyComponent<typeof import("../components/Dashboard/Marketing/InstagramCampaignsChart.vue")['default']>
    'LazyDashboardMarketingInstagramSubscriberChart': LazyComponent<typeof import("../components/Dashboard/Marketing/InstagramSubscriberChart.vue")['default']>
    'LazyDashboardMarketingNewMarketingTool': LazyComponent<typeof import("../components/Dashboard/Marketing/NewMarketingTool.vue")['default']>
    'LazyDashboardMarketingNewMobileApp': LazyComponent<typeof import("../components/Dashboard/Marketing/NewMobileApp.vue")['default']>
    'LazyDashboardMarketingPerformanceOverviewChart': LazyComponent<typeof import("../components/Dashboard/Marketing/PerformanceOverviewChart.vue")['default']>
    'LazyDashboardMarketingStatusContent': LazyComponent<typeof import("../components/Dashboard/Marketing/StatusContent.vue")['default']>
    'LazyDashboardNFTActiveAuctions': LazyComponent<typeof import("../components/Dashboard/NFT/ActiveAuctions.vue")['default']>
    'LazyDashboardNFTCreateNFT': LazyComponent<typeof import("../components/Dashboard/NFT/CreateNFT.vue")['default']>
    'LazyDashboardNFTEthereumRateChart': LazyComponent<typeof import("../components/Dashboard/NFT/EthereumRateChart.vue")['default']>
    'LazyDashboardNFTEthereumRateFiveChart': LazyComponent<typeof import("../components/Dashboard/NFT/EthereumRateFiveChart.vue")['default']>
    'LazyDashboardNFTEthereumRateFourChart': LazyComponent<typeof import("../components/Dashboard/NFT/EthereumRateFourChart.vue")['default']>
    'LazyDashboardNFTEthereumRateTab': LazyComponent<typeof import("../components/Dashboard/NFT/EthereumRateTab.vue")['default']>
    'LazyDashboardNFTEthereumRateThreeChart': LazyComponent<typeof import("../components/Dashboard/NFT/EthereumRateThreeChart.vue")['default']>
    'LazyDashboardNFTEthereumRateTwoChart': LazyComponent<typeof import("../components/Dashboard/NFT/EthereumRateTwoChart.vue")['default']>
    'LazyDashboardNFTFeaturedNFTArtworks': LazyComponent<typeof import("../components/Dashboard/NFT/FeaturedNFTArtworks.vue")['default']>
    'LazyDashboardNFTHistoryOfBids': LazyComponent<typeof import("../components/Dashboard/NFT/HistoryOfBids.vue")['default']>
    'LazyDashboardNFTManageYourNFT': LazyComponent<typeof import("../components/Dashboard/NFT/ManageYourNFT.vue")['default']>
    'LazyDashboardNFTMostPopularSellers': LazyComponent<typeof import("../components/Dashboard/NFT/MostPopularSellers.vue")['default']>
    'LazyDashboardNFTSlideItem': LazyComponent<typeof import("../components/Dashboard/NFT/NFTSlideItem.vue")['default']>
    'LazyDashboardNFTNewMobileApp': LazyComponent<typeof import("../components/Dashboard/NFT/NewMobileApp.vue")['default']>
    'LazyDashboardNFTTopCollections': LazyComponent<typeof import("../components/Dashboard/NFT/TopCollections.vue")['default']>
    'LazyDashboardNFTTopNFTs': LazyComponent<typeof import("../components/Dashboard/NFT/TopNFTs.vue")['default']>
    'LazyDashboardNFTWorldwideTopCreators': LazyComponent<typeof import("../components/Dashboard/NFT/WorldwideTopCreators.vue")['default']>
    'LazyDashboardPOSSystemCategoriesTab': LazyComponent<typeof import("../components/Dashboard/POSSystem/CategoriesTab.vue")['default']>
    'LazyDashboardPOSSystemCustomerSegmentation': LazyComponent<typeof import("../components/Dashboard/POSSystem/CustomerSegmentation.vue")['default']>
    'LazyDashboardPOSSystemOrderDetails': LazyComponent<typeof import("../components/Dashboard/POSSystem/OrderDetails.vue")['default']>
    'LazyDashboardPOSSystemQuantityCounter': LazyComponent<typeof import("../components/Dashboard/POSSystem/QuantityCounter.vue")['default']>
    'LazyDashboardPOSSystemSalesAnalyticsSalesByCategory': LazyComponent<typeof import("../components/Dashboard/POSSystem/SalesAnalytics/SalesByCategory.vue")['default']>
    'LazyDashboardPOSSystemSalesAnalyticsSalesOverTime': LazyComponent<typeof import("../components/Dashboard/POSSystem/SalesAnalytics/SalesOverTime.vue")['default']>
    'LazyDashboardPOSSystemSalesAnalytics': LazyComponent<typeof import("../components/Dashboard/POSSystem/SalesAnalytics/index.vue")['default']>
    'LazyDashboardPOSSystemStats': LazyComponent<typeof import("../components/Dashboard/POSSystem/Stats.vue")['default']>
    'LazyDashboardPodcastFeatured': LazyComponent<typeof import("../components/Dashboard/Podcast/Featured.vue")['default']>
    'LazyDashboardPodcastListenerAnalyticsChart': LazyComponent<typeof import("../components/Dashboard/Podcast/ListenerAnalyticsChart.vue")['default']>
    'LazyDashboardPodcastMostPopular': LazyComponent<typeof import("../components/Dashboard/Podcast/MostPopular.vue")['default']>
    'LazyDashboardPodcastPlayer': LazyComponent<typeof import("../components/Dashboard/Podcast/Player.vue")['default']>
    'LazyDashboardPodcastPopularHosts': LazyComponent<typeof import("../components/Dashboard/Podcast/PopularHosts.vue")['default']>
    'LazyDashboardPodcastRecentlyPlayed': LazyComponent<typeof import("../components/Dashboard/Podcast/RecentlyPlayed.vue")['default']>
    'LazyDashboardPodcastSalesByGenderChart': LazyComponent<typeof import("../components/Dashboard/Podcast/SalesByGenderChart.vue")['default']>
    'LazyDashboardPodcastTodayEarningsChart': LazyComponent<typeof import("../components/Dashboard/Podcast/TodayEarningsChart.vue")['default']>
    'LazyDashboardPodcastTopPodcasts': LazyComponent<typeof import("../components/Dashboard/Podcast/TopPodcasts.vue")['default']>
    'LazyDashboardPodcastUpcomingEpisodes': LazyComponent<typeof import("../components/Dashboard/Podcast/UpcomingEpisodes.vue")['default']>
    'LazyDashboardProjectManagementAllProjects': LazyComponent<typeof import("../components/Dashboard/ProjectManagement/AllProjects.vue")['default']>
    'LazyDashboardProjectManagementMyTasks': LazyComponent<typeof import("../components/Dashboard/ProjectManagement/MyTasks.vue")['default']>
    'LazyDashboardProjectManagementProjectsAnalysisChart': LazyComponent<typeof import("../components/Dashboard/ProjectManagement/ProjectsAnalysisChart.vue")['default']>
    'LazyDashboardProjectManagementProjectsOverview': LazyComponent<typeof import("../components/Dashboard/ProjectManagement/ProjectsOverview.vue")['default']>
    'LazyDashboardProjectManagementProjectsProgressChart': LazyComponent<typeof import("../components/Dashboard/ProjectManagement/ProjectsProgressChart.vue")['default']>
    'LazyDashboardProjectManagementProjectsRoadmapChart': LazyComponent<typeof import("../components/Dashboard/ProjectManagement/ProjectsRoadmapChart.vue")['default']>
    'LazyDashboardProjectManagementTasksOverviewChart': LazyComponent<typeof import("../components/Dashboard/ProjectManagement/TasksOverviewChart.vue")['default']>
    'LazyDashboardProjectManagementTeamMembers': LazyComponent<typeof import("../components/Dashboard/ProjectManagement/TeamMembers.vue")['default']>
    'LazyDashboardProjectManagementToDoList': LazyComponent<typeof import("../components/Dashboard/ProjectManagement/ToDoList.vue")['default']>
    'LazyDashboardProjectManagementWorkingSchedule': LazyComponent<typeof import("../components/Dashboard/ProjectManagement/WorkingSchedule.vue")['default']>
    'LazyDashboardRealEstateActiveTotalProperty': LazyComponent<typeof import("../components/Dashboard/RealEstate/ActiveTotalProperty.vue")['default']>
    'LazyDashboardRealEstateCustomerReviews': LazyComponent<typeof import("../components/Dashboard/RealEstate/CustomerReviews.vue")['default']>
    'LazyDashboardRealEstateLatestTransaction': LazyComponent<typeof import("../components/Dashboard/RealEstate/LatestTransaction.vue")['default']>
    'LazyDashboardRealEstateMostSalesLocation': LazyComponent<typeof import("../components/Dashboard/RealEstate/MostSalesLocation.vue")['default']>
    'LazyDashboardRealEstateNewCustomers': LazyComponent<typeof import("../components/Dashboard/RealEstate/NewCustomers.vue")['default']>
    'LazyDashboardRealEstateNewListingsSoldPropertiesChart': LazyComponent<typeof import("../components/Dashboard/RealEstate/NewListingsSoldPropertiesChart.vue")['default']>
    'LazyDashboardRealEstatePropertiesForRentChart': LazyComponent<typeof import("../components/Dashboard/RealEstate/PropertiesForRentChart.vue")['default']>
    'LazyDashboardRealEstatePropertiesForSaleChart': LazyComponent<typeof import("../components/Dashboard/RealEstate/PropertiesForSaleChart.vue")['default']>
    'LazyDashboardRealEstateRecentProperty': LazyComponent<typeof import("../components/Dashboard/RealEstate/RecentProperty.vue")['default']>
    'LazyDashboardRealEstateRentalIncomeChart': LazyComponent<typeof import("../components/Dashboard/RealEstate/RentalIncomeChart.vue")['default']>
    'LazyDashboardRealEstateRevenueChart': LazyComponent<typeof import("../components/Dashboard/RealEstate/RevenueChart.vue")['default']>
    'LazyDashboardRealEstateSocialSearchChart': LazyComponent<typeof import("../components/Dashboard/RealEstate/SocialSearchChart.vue")['default']>
    'LazyDashboardRealEstateTopProperty': LazyComponent<typeof import("../components/Dashboard/RealEstate/TopProperty.vue")['default']>
    'LazyDashboardRealEstateAgentClientRatings': LazyComponent<typeof import("../components/Dashboard/RealEstateAgent/ClientRatings.vue")['default']>
    'LazyDashboardRealEstateAgentDownloadApp': LazyComponent<typeof import("../components/Dashboard/RealEstateAgent/DownloadApp.vue")['default']>
    'LazyDashboardRealEstateAgentLatestTransactions': LazyComponent<typeof import("../components/Dashboard/RealEstateAgent/LatestTransactions.vue")['default']>
    'LazyDashboardRealEstateAgentMyFeaturedListings': LazyComponent<typeof import("../components/Dashboard/RealEstateAgent/MyFeaturedListings.vue")['default']>
    'LazyDashboardRealEstateAgentRecentClients': LazyComponent<typeof import("../components/Dashboard/RealEstateAgent/RecentClients.vue")['default']>
    'LazyDashboardRealEstateAgentRevenueGoalProgress': LazyComponent<typeof import("../components/Dashboard/RealEstateAgent/RevenueGoalProgress.vue")['default']>
    'LazyDashboardRealEstateAgentSalesByCountry': LazyComponent<typeof import("../components/Dashboard/RealEstateAgent/SalesByCountry.vue")['default']>
    'LazyDashboardRealEstateAgentStats': LazyComponent<typeof import("../components/Dashboard/RealEstateAgent/Stats.vue")['default']>
    'LazyDashboardRealEstateAgentTopChannels': LazyComponent<typeof import("../components/Dashboard/RealEstateAgent/TopChannels.vue")['default']>
    'LazyDashboardRealEstateAgentTotalRevenueChart': LazyComponent<typeof import("../components/Dashboard/RealEstateAgent/TotalRevenueChart.vue")['default']>
    'LazyDashboardRealEstateAgentWelcomeRealEstateAgent': LazyComponent<typeof import("../components/Dashboard/RealEstateAgent/WelcomeRealEstateAgent.vue")['default']>
    'LazyDashboardRestaurantCustomerRatings': LazyComponent<typeof import("../components/Dashboard/Restaurant/CustomerRatings.vue")['default']>
    'LazyDashboardRestaurantExpense': LazyComponent<typeof import("../components/Dashboard/Restaurant/Expense.vue")['default']>
    'LazyDashboardRestaurantLowStockAlerts': LazyComponent<typeof import("../components/Dashboard/Restaurant/LowStockAlerts.vue")['default']>
    'LazyDashboardRestaurantOrderSummaryChart': LazyComponent<typeof import("../components/Dashboard/Restaurant/OrderSummaryChart.vue")['default']>
    'LazyDashboardRestaurantPendingOrdersChart': LazyComponent<typeof import("../components/Dashboard/Restaurant/PendingOrdersChart.vue")['default']>
    'LazyDashboardRestaurantRecentOrdersList': LazyComponent<typeof import("../components/Dashboard/Restaurant/RecentOrdersList.vue")['default']>
    'LazyDashboardRestaurantStatsToday': LazyComponent<typeof import("../components/Dashboard/Restaurant/RestaurantStatsToday.vue")['default']>
    'LazyDashboardRestaurantRevenue': LazyComponent<typeof import("../components/Dashboard/Restaurant/Revenue.vue")['default']>
    'LazyDashboardRestaurantRevenueByBranches': LazyComponent<typeof import("../components/Dashboard/Restaurant/RevenueByBranches.vue")['default']>
    'LazyDashboardRestaurantRevenueExpenseChart': LazyComponent<typeof import("../components/Dashboard/Restaurant/RevenueExpenseChart.vue")['default']>
    'LazyDashboardRestaurantStaffPerformanceScores': LazyComponent<typeof import("../components/Dashboard/Restaurant/StaffPerformanceScores.vue")['default']>
    'LazyDashboardRestaurantTickets': LazyComponent<typeof import("../components/Dashboard/Restaurant/Tickets.vue")['default']>
    'LazyDashboardRestaurantTopSellingItems': LazyComponent<typeof import("../components/Dashboard/Restaurant/TopSellingItems.vue")['default']>
    'LazyDashboardRestaurantTotalOrdersChart': LazyComponent<typeof import("../components/Dashboard/Restaurant/TotalOrdersChart.vue")['default']>
    'LazyDashboardSaaSActiveUserChart': LazyComponent<typeof import("../components/Dashboard/SaaS/ActiveUserChart.vue")['default']>
    'LazyDashboardSaaSActiveUsers': LazyComponent<typeof import("../components/Dashboard/SaaS/ActiveUsers.vue")['default']>
    'LazyDashboardSaaSActiveUsersChart': LazyComponent<typeof import("../components/Dashboard/SaaS/ActiveUsersChart.vue")['default']>
    'LazyDashboardSaaSConversionChart': LazyComponent<typeof import("../components/Dashboard/SaaS/ConversionChart.vue")['default']>
    'LazyDashboardSaaSGrossRevenueChart': LazyComponent<typeof import("../components/Dashboard/SaaS/GrossRevenueChart.vue")['default']>
    'LazyDashboardSaaSLatestTransaction': LazyComponent<typeof import("../components/Dashboard/SaaS/LatestTransaction.vue")['default']>
    'LazyDashboardSaaSPaymentChart': LazyComponent<typeof import("../components/Dashboard/SaaS/PaymentChart.vue")['default']>
    'LazyDashboardSaaSProductTradeConditionChart': LazyComponent<typeof import("../components/Dashboard/SaaS/ProductTradeConditionChart.vue")['default']>
    'LazyDashboardSaaSRevenueChart': LazyComponent<typeof import("../components/Dashboard/SaaS/RevenueChart.vue")['default']>
    'LazyDashboardSaaSSalesByCountry': LazyComponent<typeof import("../components/Dashboard/SaaS/SalesByCountry.vue")['default']>
    'LazyDashboardSaaSTopRefers': LazyComponent<typeof import("../components/Dashboard/SaaS/TopRefers.vue")['default']>
    'LazyDashboardSaaSUpgradePlans': LazyComponent<typeof import("../components/Dashboard/SaaS/UpgradePlans.vue")['default']>
    'LazyDashboardSalesGrossEarningsChart': LazyComponent<typeof import("../components/Dashboard/Sales/GrossEarningsChart.vue")['default']>
    'LazyDashboardSalesRealTimeSalesChart': LazyComponent<typeof import("../components/Dashboard/Sales/RealTimeSalesChart.vue")['default']>
    'LazyDashboardSalesRecentEarningsChart': LazyComponent<typeof import("../components/Dashboard/Sales/RecentEarningsChart.vue")['default']>
    'LazyDashboardSalesRecentOrders': LazyComponent<typeof import("../components/Dashboard/Sales/RecentOrders.vue")['default']>
    'LazyDashboardSalesByLocations': LazyComponent<typeof import("../components/Dashboard/Sales/SalesByLocations.vue")['default']>
    'LazyDashboardSalesOverviewChart': LazyComponent<typeof import("../components/Dashboard/Sales/SalesOverviewChart.vue")['default']>
    'LazyDashboardSalesTotalOrdersChart': LazyComponent<typeof import("../components/Dashboard/Sales/TotalOrdersChart.vue")['default']>
    'LazyDashboardSalesTotalProfitChart': LazyComponent<typeof import("../components/Dashboard/Sales/TotalProfitChart.vue")['default']>
    'LazyDashboardSalesTotalRevenueChart': LazyComponent<typeof import("../components/Dashboard/Sales/TotalRevenueChart.vue")['default']>
    'LazyDashboardSalesTotalSalesChart': LazyComponent<typeof import("../components/Dashboard/Sales/TotalSalesChart.vue")['default']>
    'LazyDashboardSalesTransactionHistory': LazyComponent<typeof import("../components/Dashboard/Sales/TransactionHistory.vue")['default']>
    'LazyDashboardSalesWelcomeBack': LazyComponent<typeof import("../components/Dashboard/Sales/WelcomeBack.vue")['default']>
    'LazyDashboardSchoolAttendanceAnalyticsChart': LazyComponent<typeof import("../components/Dashboard/School/AttendanceAnalyticsChart.vue")['default']>
    'LazyDashboardSchoolNewAdmissionsChart': LazyComponent<typeof import("../components/Dashboard/School/NewAdmissionsChart.vue")['default']>
    'LazyDashboardSchoolNoticeBoard': LazyComponent<typeof import("../components/Dashboard/School/NoticeBoard.vue")['default']>
    'LazyDashboardSchoolOverview': LazyComponent<typeof import("../components/Dashboard/School/SchoolOverview.vue")['default']>
    'LazyDashboardSchoolStatsAttendanceToday': LazyComponent<typeof import("../components/Dashboard/School/Stats/AttendanceToday.vue")['default']>
    'LazyDashboardSchoolStatsTotalStudents': LazyComponent<typeof import("../components/Dashboard/School/Stats/TotalStudents.vue")['default']>
    'LazyDashboardSchoolStatsTotalTeachers': LazyComponent<typeof import("../components/Dashboard/School/Stats/TotalTeachers.vue")['default']>
    'LazyDashboardSchoolStats': LazyComponent<typeof import("../components/Dashboard/School/Stats/index.vue")['default']>
    'LazyDashboardSchoolStudentsList': LazyComponent<typeof import("../components/Dashboard/School/StudentsList.vue")['default']>
    'LazyDashboardSchoolStudentsOverviewChart': LazyComponent<typeof import("../components/Dashboard/School/StudentsOverviewChart.vue")['default']>
    'LazyDashboardSchoolTeachers': LazyComponent<typeof import("../components/Dashboard/School/Teachers.vue")['default']>
    'LazyDashboardSchoolUpcomingEvents': LazyComponent<typeof import("../components/Dashboard/School/UpcomingEvents.vue")['default']>
    'LazyDashboardShipmentAverageDeliveryTimeChart': LazyComponent<typeof import("../components/Dashboard/Shipment/AverageDeliveryTimeChart.vue")['default']>
    'LazyDashboardShipmentChatContent': LazyComponent<typeof import("../components/Dashboard/Shipment/ChatContent.vue")['default']>
    'LazyDashboardShipmentLiveShipmentStatusChart': LazyComponent<typeof import("../components/Dashboard/Shipment/LiveShipmentStatusChart.vue")['default']>
    'LazyDashboardShipmentOnTimeDeliveryChart': LazyComponent<typeof import("../components/Dashboard/Shipment/OnTimeDeliveryChart.vue")['default']>
    'LazyDashboardShipmentDeliveredChart': LazyComponent<typeof import("../components/Dashboard/Shipment/ShipmentDeliveredChart.vue")['default']>
    'LazyDashboardShipmentList': LazyComponent<typeof import("../components/Dashboard/Shipment/ShipmentList.vue")['default']>
    'LazyDashboardShipmentToTopCountries': LazyComponent<typeof import("../components/Dashboard/Shipment/ShipmentToTopCountries.vue")['default']>
    'LazyDashboardShipmentTodaysShipmentsChart': LazyComponent<typeof import("../components/Dashboard/Shipment/TodaysShipmentsChart.vue")['default']>
    'LazyDashboardShipmentTopShippingMethodsChart': LazyComponent<typeof import("../components/Dashboard/Shipment/TopShippingMethodsChart.vue")['default']>
    'LazyDashboardShipmentTotalCustomer': LazyComponent<typeof import("../components/Dashboard/Shipment/TotalCustomer.vue")['default']>
    'LazyDashboardShipmentTotalIncome': LazyComponent<typeof import("../components/Dashboard/Shipment/TotalIncome.vue")['default']>
    'LazyDashboardShipmentTotalOrder': LazyComponent<typeof import("../components/Dashboard/Shipment/TotalOrder.vue")['default']>
    'LazyDashboardShipmentTotalShipment': LazyComponent<typeof import("../components/Dashboard/Shipment/TotalShipment.vue")['default']>
    'LazyDashboardShipmentTrackingOrder': LazyComponent<typeof import("../components/Dashboard/Shipment/TrackingOrder.vue")['default']>
    'LazyDashboardSocialMediaFacebookCampaignOverviewChart': LazyComponent<typeof import("../components/Dashboard/SocialMedia/FacebookCampaignOverviewChart.vue")['default']>
    'LazyDashboardSocialMediaFacebookFollowers': LazyComponent<typeof import("../components/Dashboard/SocialMedia/FacebookFollowers.vue")['default']>
    'LazyDashboardSocialMediaFollowersByGenderChart': LazyComponent<typeof import("../components/Dashboard/SocialMedia/FollowersByGenderChart.vue")['default']>
    'LazyDashboardSocialMediaInstagramFollowers': LazyComponent<typeof import("../components/Dashboard/SocialMedia/InstagramFollowers.vue")['default']>
    'LazyDashboardSocialMediaLinkedInFollowers': LazyComponent<typeof import("../components/Dashboard/SocialMedia/LinkedInFollowers.vue")['default']>
    'LazyDashboardSocialMediaLinkedInNetFollowersChart': LazyComponent<typeof import("../components/Dashboard/SocialMedia/LinkedInNetFollowersChart.vue")['default']>
    'LazyDashboardSocialMediaRecentInstagramFollowers': LazyComponent<typeof import("../components/Dashboard/SocialMedia/RecentInstagramFollowers.vue")['default']>
    'LazyDashboardSocialMediaSuggestions': LazyComponent<typeof import("../components/Dashboard/SocialMedia/Suggestions.vue")['default']>
    'LazyDashboardSocialMediaTikTokFollowers': LazyComponent<typeof import("../components/Dashboard/SocialMedia/TikTokFollowers.vue")['default']>
    'LazyDashboardSocialMediaUpgradePlan': LazyComponent<typeof import("../components/Dashboard/SocialMedia/UpgradePlan.vue")['default']>
    'LazyDashboardSocialMediaXFollowers': LazyComponent<typeof import("../components/Dashboard/SocialMedia/XFollowers.vue")['default']>
    'LazyDashboardSocialMediaYouTubeSubscribers': LazyComponent<typeof import("../components/Dashboard/SocialMedia/YouTubeSubscribers.vue")['default']>
    'LazyDashboardStoreAnalysisCustomerVisits': LazyComponent<typeof import("../components/Dashboard/StoreAnalysis/CustomerVisits.vue")['default']>
    'LazyDashboardStoreAnalysisGrossRevenue': LazyComponent<typeof import("../components/Dashboard/StoreAnalysis/GrossRevenue.vue")['default']>
    'LazyDashboardStoreAnalysisRecentSales': LazyComponent<typeof import("../components/Dashboard/StoreAnalysis/RecentSales.vue")['default']>
    'LazyDashboardStoreAnalysisSAWelcome': LazyComponent<typeof import("../components/Dashboard/StoreAnalysis/SAWelcome.vue")['default']>
    'LazyDashboardStoreAnalysisSalesByCategoryChart': LazyComponent<typeof import("../components/Dashboard/StoreAnalysis/SalesByCategoryChart.vue")['default']>
    'LazyDashboardStoreAnalysisSalesByGenderChart': LazyComponent<typeof import("../components/Dashboard/StoreAnalysis/SalesByGenderChart.vue")['default']>
    'LazyDashboardStoreAnalysisSalesThisMonthChart': LazyComponent<typeof import("../components/Dashboard/StoreAnalysis/SalesThisMonthChart.vue")['default']>
    'LazyDashboardStoreAnalysisStats': LazyComponent<typeof import("../components/Dashboard/StoreAnalysis/Stats.vue")['default']>
    'LazyDashboardStoreAnalysisStockAlerts': LazyComponent<typeof import("../components/Dashboard/StoreAnalysis/StockAlerts.vue")['default']>
    'LazyDashboardStoreAnalysisTopSellingProducts': LazyComponent<typeof import("../components/Dashboard/StoreAnalysis/TopSellingProducts.vue")['default']>
    'LazyDashboardECommerceOrderSummaryChart': LazyComponent<typeof import("../components/Dashboard/eCommerce/OrderSummaryChart.vue")['default']>
    'LazyDashboardECommerceRecentOrders': LazyComponent<typeof import("../components/Dashboard/eCommerce/RecentOrders.vue")['default']>
    'LazyDashboardECommerceRecentTransactions': LazyComponent<typeof import("../components/Dashboard/eCommerce/RecentTransactions.vue")['default']>
    'LazyDashboardECommerceReturningCustomerRateChart': LazyComponent<typeof import("../components/Dashboard/eCommerce/ReturningCustomerRateChart.vue")['default']>
    'LazyDashboardECommerceSalesByLocations': LazyComponent<typeof import("../components/Dashboard/eCommerce/SalesByLocations.vue")['default']>
    'LazyDashboardECommerceTopSellingProducts': LazyComponent<typeof import("../components/Dashboard/eCommerce/TopSellingProducts.vue")['default']>
    'LazyDashboardECommerceTotalCustomersChart': LazyComponent<typeof import("../components/Dashboard/eCommerce/TotalCustomersChart.vue")['default']>
    'LazyDashboardECommerceTotalOrdersChart': LazyComponent<typeof import("../components/Dashboard/eCommerce/TotalOrdersChart.vue")['default']>
    'LazyDashboardECommerceTotalRevenueChart': LazyComponent<typeof import("../components/Dashboard/eCommerce/TotalRevenueChart.vue")['default']>
    'LazyDashboardECommerceTotalSalesChart': LazyComponent<typeof import("../components/Dashboard/eCommerce/TotalSalesChart.vue")['default']>
    'LazyDashboardECommerceWelcomeDashboard': LazyComponent<typeof import("../components/Dashboard/eCommerce/WelcomeDashboard.vue")['default']>
    'LazyFrontPagesCommonBackToUp': LazyComponent<typeof import("../components/FrontPages/Common/BackToUp.vue")['default']>
    'LazyFrontPagesCommonCTA': LazyComponent<typeof import("../components/FrontPages/Common/CTA.vue")['default']>
    'LazyFrontPagesCommonContactUs': LazyComponent<typeof import("../components/FrontPages/Common/ContactUs.vue")['default']>
    'LazyFrontPagesCommonCopyRight': LazyComponent<typeof import("../components/FrontPages/Common/CopyRight.vue")['default']>
    'LazyFrontPagesCommonFAQ': LazyComponent<typeof import("../components/FrontPages/Common/FAQ.vue")['default']>
    'LazyFrontPagesCommonFooter': LazyComponent<typeof import("../components/FrontPages/Common/Footer.vue")['default']>
    'LazyFrontPagesCommonKeyFeatures': LazyComponent<typeof import("../components/FrontPages/Common/KeyFeatures.vue")['default']>
    'LazyFrontPagesCommonNavbar': LazyComponent<typeof import("../components/FrontPages/Common/Navbar.vue")['default']>
    'LazyFrontPagesCommonOurTeam': LazyComponent<typeof import("../components/FrontPages/Common/OurTeam.vue")['default']>
    'LazyFrontPagesCommonPageTitle': LazyComponent<typeof import("../components/FrontPages/Common/PageTitle.vue")['default']>
    'LazyFrontPagesHomeBanner': LazyComponent<typeof import("../components/FrontPages/Home/Banner.vue")['default']>
    'LazyFrontPagesHomeTailorYourDashboard': LazyComponent<typeof import("../components/FrontPages/Home/TailorYourDashboard.vue")['default']>
    'LazyFrontPagesHomeTestimonials': LazyComponent<typeof import("../components/FrontPages/Home/Testimonials.vue")['default']>
    'LazyLayoutAddNewCardModal': LazyComponent<typeof import("../components/Layout/AddNewCardModal.vue")['default']>
    'LazyLayoutAddNewCategorieModal': LazyComponent<typeof import("../components/Layout/AddNewCategorieModal.vue")['default']>
    'LazyLayoutAddNewContactModal': LazyComponent<typeof import("../components/Layout/AddNewContactModal.vue")['default']>
    'LazyLayoutAddNewCustomerModal': LazyComponent<typeof import("../components/Layout/AddNewCustomerModal.vue")['default']>
    'LazyLayoutAddNewDealsModal': LazyComponent<typeof import("../components/Layout/AddNewDealsModal.vue")['default']>
    'LazyLayoutAddNewFileModal': LazyComponent<typeof import("../components/Layout/AddNewFileModal.vue")['default']>
    'LazyLayoutAddNewInstructorsModal': LazyComponent<typeof import("../components/Layout/AddNewInstructorsModal.vue")['default']>
    'LazyLayoutAddNewLabelModal': LazyComponent<typeof import("../components/Layout/AddNewLabelModal.vue")['default']>
    'LazyLayoutAddNewLeadModal': LazyComponent<typeof import("../components/Layout/AddNewLeadModal.vue")['default']>
    'LazyLayoutAddNewOrderModal': LazyComponent<typeof import("../components/Layout/AddNewOrderModal.vue")['default']>
    'LazyLayoutAddNewUserModal': LazyComponent<typeof import("../components/Layout/AddNewUserModal.vue")['default']>
    'LazyLayoutCreateTaskModal': LazyComponent<typeof import("../components/Layout/CreateTaskModal.vue")['default']>
    'LazyLayoutLeftSidebar': LazyComponent<typeof import("../components/Layout/LeftSidebar/index.vue")['default']>
    'LazyLayoutMainFooter': LazyComponent<typeof import("../components/Layout/MainFooter.vue")['default']>
    'LazyLayoutPreloader': LazyComponent<typeof import("../components/Layout/Preloader.vue")['default']>
    'LazyLayoutSettingsSidebarCardStyleBG': LazyComponent<typeof import("../components/Layout/SettingsSidebar/CardStyleBG.vue")['default']>
    'LazyLayoutSettingsSidebarCardStyleRadius': LazyComponent<typeof import("../components/Layout/SettingsSidebar/CardStyleRadius.vue")['default']>
    'LazyLayoutSettingsSidebarContainerStyleBtn': LazyComponent<typeof import("../components/Layout/SettingsSidebar/ContainerStyleBtn.vue")['default']>
    'LazyLayoutSettingsSidebarHorizontalLayout': LazyComponent<typeof import("../components/Layout/SettingsSidebar/HorizontalLayout.vue")['default']>
    'LazyLayoutSettingsSidebarOnlyFooterDark': LazyComponent<typeof import("../components/Layout/SettingsSidebar/OnlyFooterDark.vue")['default']>
    'LazyLayoutSettingsSidebarOnlyHeaderDark': LazyComponent<typeof import("../components/Layout/SettingsSidebar/OnlyHeaderDark.vue")['default']>
    'LazyLayoutSettingsSidebarOnlySidebarDark': LazyComponent<typeof import("../components/Layout/SettingsSidebar/OnlySidebarDark.vue")['default']>
    'LazyLayoutSettingsSidebarRTLModeSwitch': LazyComponent<typeof import("../components/Layout/SettingsSidebar/RTLModeSwitch.vue")['default']>
    'LazyLayoutSettingsSidebar': LazyComponent<typeof import("../components/Layout/SettingsSidebar/index.vue")['default']>
    'LazyLayoutTopHeaderAdminProfile': LazyComponent<typeof import("../components/Layout/TopHeader/AdminProfile.vue")['default']>
    'LazyLayoutTopHeaderDarkSwtichBtn': LazyComponent<typeof import("../components/Layout/TopHeader/DarkSwtichBtn.vue")['default']>
    'LazyLayoutTopHeaderLanguageMenu': LazyComponent<typeof import("../components/Layout/TopHeader/LanguageMenu.vue")['default']>
    'LazyLayoutTopHeaderNavbar': LazyComponent<typeof import("../components/Layout/TopHeader/Navbar.vue")['default']>
    'LazyLayoutTopHeaderNotificationsLists': LazyComponent<typeof import("../components/Layout/TopHeader/NotificationsLists.vue")['default']>
    'LazyLayoutTopHeaderSearchFrom': LazyComponent<typeof import("../components/Layout/TopHeader/SearchFrom.vue")['default']>
    'LazyLayoutTopHeaderSettingsBtn': LazyComponent<typeof import("../components/Layout/TopHeader/SettingsBtn.vue")['default']>
    'LazyLayoutTopHeaderToggleFullscreenBtn': LazyComponent<typeof import("../components/Layout/TopHeader/ToggleFullscreenBtn.vue")['default']>
    'LazyLayoutTopHeaderWebApps': LazyComponent<typeof import("../components/Layout/TopHeader/WebApps.vue")['default']>
    'LazyLayoutTopHeader': LazyComponent<typeof import("../components/Layout/TopHeader/index.vue")['default']>
    'LazyModulesAuthenticationConfirmMail': LazyComponent<typeof import("../components/Modules/Authentication/ConfirmMail/index.vue")['default']>
    'LazyModulesAuthenticationForgetPassword': LazyComponent<typeof import("../components/Modules/Authentication/ForgetPassword/index.vue")['default']>
    'LazyModulesAuthenticationLockScreen': LazyComponent<typeof import("../components/Modules/Authentication/LockScreen/index.vue")['default']>
    'LazyModulesAuthenticationLogOut': LazyComponent<typeof import("../components/Modules/Authentication/LogOut/index.vue")['default']>
    'LazyModulesAuthenticationLogin': LazyComponent<typeof import("../components/Modules/Authentication/Login/index.vue")['default']>
    'LazyModulesAuthenticationRegister': LazyComponent<typeof import("../components/Modules/Authentication/Register/index.vue")['default']>
    'LazyModulesAuthenticationResetPassword': LazyComponent<typeof import("../components/Modules/Authentication/ResetPassword/index.vue")['default']>
    'LazyModulesExtraPagesAnimation': LazyComponent<typeof import("../components/Modules/ExtraPages/Animation/index.vue")['default']>
    'LazyModulesExtraPagesCheckRadio': LazyComponent<typeof import("../components/Modules/ExtraPages/CheckRadio/index.vue")['default']>
    'LazyModulesExtraPagesClipBoard': LazyComponent<typeof import("../components/Modules/ExtraPages/ClipBoard/index.vue")['default']>
    'LazyModulesExtraPagesDragDrop': LazyComponent<typeof import("../components/Modules/ExtraPages/DragDrop/index.vue")['default']>
    'LazyModulesExtraPagesFAQ': LazyComponent<typeof import("../components/Modules/ExtraPages/FAQ/index.vue")['default']>
    'LazyModulesExtraPagesGallery': LazyComponent<typeof import("../components/Modules/ExtraPages/Gallery/index.vue")['default']>
    'LazyModulesExtraPagesPricingStyleOne': LazyComponent<typeof import("../components/Modules/ExtraPages/Pricing/PricingStyleOne.vue")['default']>
    'LazyModulesExtraPagesPricingStyleThree': LazyComponent<typeof import("../components/Modules/ExtraPages/Pricing/PricingStyleThree.vue")['default']>
    'LazyModulesExtraPagesPricingStyleTwo': LazyComponent<typeof import("../components/Modules/ExtraPages/Pricing/PricingStyleTwo.vue")['default']>
    'LazyModulesExtraPagesPricing': LazyComponent<typeof import("../components/Modules/ExtraPages/Pricing/index.vue")['default']>
    'LazyModulesExtraPagesRangeSlider': LazyComponent<typeof import("../components/Modules/ExtraPages/RangeSlider/index.vue")['default']>
    'LazyModulesExtraPagesRatingsInteractiveRating': LazyComponent<typeof import("../components/Modules/ExtraPages/Ratings/InteractiveRating.vue")['default']>
    'LazyModulesExtraPagesRatingsRTLSupport': LazyComponent<typeof import("../components/Modules/ExtraPages/Ratings/RTLSupport.vue")['default']>
    'LazyModulesExtraPagesRatingsReadOnlyPresetValue': LazyComponent<typeof import("../components/Modules/ExtraPages/Ratings/ReadOnlyPresetValue.vue")['default']>
    'LazyModulesExtraPagesRatingsSettingGettingValues': LazyComponent<typeof import("../components/Modules/ExtraPages/Ratings/SettingGettingValues.vue")['default']>
    'LazyModulesExtraPagesRatings': LazyComponent<typeof import("../components/Modules/ExtraPages/Ratings/index.vue")['default']>
    'LazyModulesExtraPagesScrollbar': LazyComponent<typeof import("../components/Modules/ExtraPages/Scrollbar/index.vue")['default']>
    'LazyModulesExtraPagesSearch': LazyComponent<typeof import("../components/Modules/ExtraPages/Search/index.vue")['default']>
    'LazyModulesExtraPagesSelect': LazyComponent<typeof import("../components/Modules/ExtraPages/Select/index.vue")['default']>
    'LazyModulesExtraPagesTimelineAdvancedTimeline': LazyComponent<typeof import("../components/Modules/ExtraPages/Timeline/AdvancedTimeline.vue")['default']>
    'LazyModulesExtraPagesTimelineBasicTimeline': LazyComponent<typeof import("../components/Modules/ExtraPages/Timeline/BasicTimeline.vue")['default']>
    'LazyModulesExtraPagesTimeline': LazyComponent<typeof import("../components/Modules/ExtraPages/Timeline/index.vue")['default']>
    'LazyModulesExtraPagesToasts': LazyComponent<typeof import("../components/Modules/ExtraPages/Toasts/index.vue")['default']>
    'LazyModulesExtraPagesTypography': LazyComponent<typeof import("../components/Modules/ExtraPages/Typography/index.vue")['default']>
    'LazyModulesFormsAdvancedElementsQuantityCounter': LazyComponent<typeof import("../components/Modules/Forms/AdvancedElements/QuantityCounter.vue")['default']>
    'LazyModulesFormsAdvancedElementsQuantityCounterTwo': LazyComponent<typeof import("../components/Modules/Forms/AdvancedElements/QuantityCounterTwo.vue")['default']>
    'LazyModulesFormsAdvancedElements': LazyComponent<typeof import("../components/Modules/Forms/AdvancedElements/index.vue")['default']>
    'LazyModulesFormsBasicElements': LazyComponent<typeof import("../components/Modules/Forms/BasicElements/index.vue")['default']>
    'LazyModulesFormsEditors': LazyComponent<typeof import("../components/Modules/Forms/Editors/index.vue")['default']>
    'LazyModulesFormsFileUpload': LazyComponent<typeof import("../components/Modules/Forms/FileUpload/index.vue")['default']>
    'LazyModulesFormsValidation': LazyComponent<typeof import("../components/Modules/Forms/Validation/index.vue")['default']>
    'LazyModulesFormsWizard': LazyComponent<typeof import("../components/Modules/Forms/Wizard/index.vue")['default']>
    'LazyModulesGoogleMap': LazyComponent<typeof import("../components/Modules/GoogleMap/index.vue")['default']>
    'LazyModulesIconsFeatherIcon': LazyComponent<typeof import("../components/Modules/Icons/FeatherIcon/index.vue")['default']>
    'LazyModulesIconsMaterialSymbolsIcon': LazyComponent<typeof import("../components/Modules/Icons/MaterialSymbolsIcon/index.vue")['default']>
    'LazyModulesIconsRemixIcon': LazyComponent<typeof import("../components/Modules/Icons/RemixIcon/index.vue")['default']>
    'LazyModulesInternalError': LazyComponent<typeof import("../components/Modules/InternalError/index.vue")['default']>
    'LazyModulesMembers': LazyComponent<typeof import("../components/Modules/Members/index.vue")['default']>
    'LazyModulesNotification': LazyComponent<typeof import("../components/Modules/Notification/index.vue")['default']>
    'LazyModulesTablesBasicTable': LazyComponent<typeof import("../components/Modules/Tables/BasicTable/index.vue")['default']>
    'LazyModulesTablesDataTable': LazyComponent<typeof import("../components/Modules/Tables/DataTable/index.vue")['default']>
    'LazyModulesUIElementsAccordions': LazyComponent<typeof import("../components/Modules/UIElements/Accordions/index.vue")['default']>
    'LazyModulesUIElementsAlertsAdditionalContentAlerts': LazyComponent<typeof import("../components/Modules/UIElements/Alerts/AdditionalContentAlerts.vue")['default']>
    'LazyModulesUIElementsAlertsWithIcon': LazyComponent<typeof import("../components/Modules/UIElements/Alerts/AlertsWithIcon.vue")['default']>
    'LazyModulesUIElementsAlertsBGAlertsWithIcon': LazyComponent<typeof import("../components/Modules/UIElements/Alerts/BGAlertsWithIcon.vue")['default']>
    'LazyModulesUIElementsAlertsBGBasicAlerts': LazyComponent<typeof import("../components/Modules/UIElements/Alerts/BGBasicAlerts.vue")['default']>
    'LazyModulesUIElementsAlertsBGOutlineAlerts': LazyComponent<typeof import("../components/Modules/UIElements/Alerts/BGOutlineAlerts.vue")['default']>
    'LazyModulesUIElementsAlertsBasicAlerts': LazyComponent<typeof import("../components/Modules/UIElements/Alerts/BasicAlerts.vue")['default']>
    'LazyModulesUIElementsAlertsDismissingAlerts': LazyComponent<typeof import("../components/Modules/UIElements/Alerts/DismissingAlerts.vue")['default']>
    'LazyModulesUIElementsAlertsOutlineAlerts': LazyComponent<typeof import("../components/Modules/UIElements/Alerts/OutlineAlerts.vue")['default']>
    'LazyModulesUIElementsAlerts': LazyComponent<typeof import("../components/Modules/UIElements/Alerts/index.vue")['default']>
    'LazyModulesUIElementsAvatarSizeRoundedCircleExample': LazyComponent<typeof import("../components/Modules/UIElements/Avatar/AvatarSizeRoundedCircleExample.vue")['default']>
    'LazyModulesUIElementsAvatarSizeSimpleRoundedExample': LazyComponent<typeof import("../components/Modules/UIElements/Avatar/AvatarSizeSimpleRoundedExample.vue")['default']>
    'LazyModulesUIElementsAvatarGroupUserExample': LazyComponent<typeof import("../components/Modules/UIElements/Avatar/GroupUserExample.vue")['default']>
    'LazyModulesUIElementsAvatarSingleUserExample': LazyComponent<typeof import("../components/Modules/UIElements/Avatar/SingleUserExample.vue")['default']>
    'LazyModulesUIElementsAvatarSingleUserWithBadgeExample': LazyComponent<typeof import("../components/Modules/UIElements/Avatar/SingleUserWithBadgeExample.vue")['default']>
    'LazyModulesUIElementsAvatarTextAvatarSizeRoundedCircleExample': LazyComponent<typeof import("../components/Modules/UIElements/Avatar/TextAvatarSizeRoundedCircleExample.vue")['default']>
    'LazyModulesUIElementsAvatarTextAvatarSizeSimpleRoundedExample': LazyComponent<typeof import("../components/Modules/UIElements/Avatar/TextAvatarSizeSimpleRoundedExample.vue")['default']>
    'LazyModulesUIElementsAvatar': LazyComponent<typeof import("../components/Modules/UIElements/Avatar/index.vue")['default']>
    'LazyModulesUIElementsBadgesWithIcons': LazyComponent<typeof import("../components/Modules/UIElements/Badges/BadgesWithIcons.vue")['default']>
    'LazyModulesUIElementsBadgesDefaultBadges': LazyComponent<typeof import("../components/Modules/UIElements/Badges/DefaultBadges.vue")['default']>
    'LazyModulesUIElementsBadgesHeadingsBadges': LazyComponent<typeof import("../components/Modules/UIElements/Badges/HeadingsBadges.vue")['default']>
    'LazyModulesUIElementsBadgesOtherBadges': LazyComponent<typeof import("../components/Modules/UIElements/Badges/OtherBadges.vue")['default']>
    'LazyModulesUIElementsBadgesRoundedPillBadges': LazyComponent<typeof import("../components/Modules/UIElements/Badges/RoundedPillBadges.vue")['default']>
    'LazyModulesUIElementsBadgesRoundedPillBadgesTwo': LazyComponent<typeof import("../components/Modules/UIElements/Badges/RoundedPillBadgesTwo.vue")['default']>
    'LazyModulesUIElementsBadgesSoftBadges': LazyComponent<typeof import("../components/Modules/UIElements/Badges/SoftBadges.vue")['default']>
    'LazyModulesUIElementsBadges': LazyComponent<typeof import("../components/Modules/UIElements/Badges/index.vue")['default']>
    'LazyModulesUIElementsButtonsBlockButtons': LazyComponent<typeof import("../components/Modules/UIElements/Buttons/BlockButtons.vue")['default']>
    'LazyModulesUIElementsButtonsWithIcon': LazyComponent<typeof import("../components/Modules/UIElements/Buttons/ButtonsWithIcon.vue")['default']>
    'LazyModulesUIElementsButtonsDefaultButtons': LazyComponent<typeof import("../components/Modules/UIElements/Buttons/DefaultButtons.vue")['default']>
    'LazyModulesUIElementsButtonsOutlineButtons': LazyComponent<typeof import("../components/Modules/UIElements/Buttons/OutlineButtons.vue")['default']>
    'LazyModulesUIElementsButtonsOutlineRoundedButtons': LazyComponent<typeof import("../components/Modules/UIElements/Buttons/OutlineRoundedButtons.vue")['default']>
    'LazyModulesUIElementsButtonsRoundedButtons': LazyComponent<typeof import("../components/Modules/UIElements/Buttons/RoundedButtons.vue")['default']>
    'LazyModulesUIElementsButtonsSoftButtons': LazyComponent<typeof import("../components/Modules/UIElements/Buttons/SoftButtons.vue")['default']>
    'LazyModulesUIElementsButtons': LazyComponent<typeof import("../components/Modules/UIElements/Buttons/index.vue")['default']>
    'LazyModulesUIElementsCardsCardWithBgImage': LazyComponent<typeof import("../components/Modules/UIElements/Cards/CardWithBgImage.vue")['default']>
    'LazyModulesUIElementsCardsCardWithImage': LazyComponent<typeof import("../components/Modules/UIElements/Cards/CardWithImage.vue")['default']>
    'LazyModulesUIElementsCardsCardWithList': LazyComponent<typeof import("../components/Modules/UIElements/Cards/CardWithList.vue")['default']>
    'LazyModulesUIElementsCardsDefaultCard': LazyComponent<typeof import("../components/Modules/UIElements/Cards/DefaultCard.vue")['default']>
    'LazyModulesUIElementsCards': LazyComponent<typeof import("../components/Modules/UIElements/Cards/index.vue")['default']>
    'LazyModulesUIElementsCarouselsSlidesOnly': LazyComponent<typeof import("../components/Modules/UIElements/Carousels/SlidesOnly.vue")['default']>
    'LazyModulesUIElementsCarouselsSlidesWithControls': LazyComponent<typeof import("../components/Modules/UIElements/Carousels/SlidesWithControls.vue")['default']>
    'LazyModulesUIElementsCarousels': LazyComponent<typeof import("../components/Modules/UIElements/Carousels/index.vue")['default']>
    'LazyModulesUIElementsDateTimePicker': LazyComponent<typeof import("../components/Modules/UIElements/DateTimePicker/index.vue")['default']>
    'LazyModulesUIElementsDropdownsDropdownDefaultButtons': LazyComponent<typeof import("../components/Modules/UIElements/Dropdowns/DropdownDefaultButtons.vue")['default']>
    'LazyModulesUIElementsDropdowns': LazyComponent<typeof import("../components/Modules/UIElements/Dropdowns/index.vue")['default']>
    'LazyModulesUIElementsGrids': LazyComponent<typeof import("../components/Modules/UIElements/Grids/index.vue")['default']>
    'LazyModulesUIElementsImages': LazyComponent<typeof import("../components/Modules/UIElements/Images/index.vue")['default']>
    'LazyModulesUIElementsList': LazyComponent<typeof import("../components/Modules/UIElements/List/index.vue")['default']>
    'LazyModulesUIElementsModals': LazyComponent<typeof import("../components/Modules/UIElements/Modals/index.vue")['default']>
    'LazyModulesUIElementsNavs': LazyComponent<typeof import("../components/Modules/UIElements/Navs/index.vue")['default']>
    'LazyModulesUIElementsPaginations': LazyComponent<typeof import("../components/Modules/UIElements/Paginations/index.vue")['default']>
    'LazyModulesUIElementsPopoverTooltips': LazyComponent<typeof import("../components/Modules/UIElements/PopoverTooltips/index.vue")['default']>
    'LazyModulesUIElementsProgress': LazyComponent<typeof import("../components/Modules/UIElements/Progress/index.vue")['default']>
    'LazyModulesUIElementsSpinners': LazyComponent<typeof import("../components/Modules/UIElements/Spinners/index.vue")['default']>
    'LazyModulesUIElementsTabs': LazyComponent<typeof import("../components/Modules/UIElements/Tabs/index.vue")['default']>
    'LazyModulesUIElementsVideos': LazyComponent<typeof import("../components/Modules/UIElements/Videos/index.vue")['default']>
    'LazyModulesWidgetsAnnualProfitChart': LazyComponent<typeof import("../components/Modules/Widgets/AnnualProfitChart.vue")['default']>
    'LazyModulesWidgetsCoursesSalesChart': LazyComponent<typeof import("../components/Modules/Widgets/CoursesSalesChart.vue")['default']>
    'LazyModulesWidgetsInProgressChart': LazyComponent<typeof import("../components/Modules/Widgets/InProgressChart.vue")['default']>
    'LazyModulesWidgetsLeadConversionChart': LazyComponent<typeof import("../components/Modules/Widgets/LeadConversionChart.vue")['default']>
    'LazyModulesWidgetsOurTopCourses': LazyComponent<typeof import("../components/Modules/Widgets/OurTopCourses.vue")['default']>
    'LazyModulesWidgetsProjectsAnalysisChart': LazyComponent<typeof import("../components/Modules/Widgets/ProjectsAnalysisChart.vue")['default']>
    'LazyModulesWidgetsProjectsOverview': LazyComponent<typeof import("../components/Modules/Widgets/ProjectsOverview.vue")['default']>
    'LazyModulesWidgetsProjectsRoadmapChart': LazyComponent<typeof import("../components/Modules/Widgets/ProjectsRoadmapChart.vue")['default']>
    'LazyModulesWidgetsRevenueGrowthChart': LazyComponent<typeof import("../components/Modules/Widgets/RevenueGrowthChart.vue")['default']>
    'LazyModulesWidgetsTeamMembers': LazyComponent<typeof import("../components/Modules/Widgets/TeamMembers.vue")['default']>
    'LazyModulesWidgetsTicketsDueChart': LazyComponent<typeof import("../components/Modules/Widgets/TicketsDueChart.vue")['default']>
    'LazyModulesWidgetsTicketsNewOpenChart': LazyComponent<typeof import("../components/Modules/Widgets/TicketsNewOpenChart.vue")['default']>
    'LazyModulesWidgetsTicketsResolvedChart': LazyComponent<typeof import("../components/Modules/Widgets/TicketsResolvedChart.vue")['default']>
    'LazyModulesWidgetsTimeSpentChart': LazyComponent<typeof import("../components/Modules/Widgets/TimeSpentChart.vue")['default']>
    'LazyModulesWidgetsTotalCourses': LazyComponent<typeof import("../components/Modules/Widgets/TotalCourses.vue")['default']>
    'LazyModulesWidgetsTotalCustomersChart': LazyComponent<typeof import("../components/Modules/Widgets/TotalCustomersChart.vue")['default']>
    'LazyModulesWidgetsTotalEnrolled': LazyComponent<typeof import("../components/Modules/Widgets/TotalEnrolled.vue")['default']>
    'LazyModulesWidgetsTotalMentors': LazyComponent<typeof import("../components/Modules/Widgets/TotalMentors.vue")['default']>
    'LazyModulesWidgetsTotalOrdersChart': LazyComponent<typeof import("../components/Modules/Widgets/TotalOrdersChart.vue")['default']>
    'LazyModulesWidgetsTotalOrdersChartTwo': LazyComponent<typeof import("../components/Modules/Widgets/TotalOrdersChartTwo.vue")['default']>
    'LazyModulesWidgetsTotalRevenueChart': LazyComponent<typeof import("../components/Modules/Widgets/TotalRevenueChart.vue")['default']>
    'LazyModulesWidgetsWelcomeBack': LazyComponent<typeof import("../components/Modules/Widgets/WelcomeBack.vue")['default']>
    'LazyModulesWidgetsWorkingSchedule': LazyComponent<typeof import("../components/Modules/Widgets/WorkingSchedule.vue")['default']>
    'LazyModulesWidgets': LazyComponent<typeof import("../components/Modules/Widgets/index.vue")['default']>
    'LazyOthersMyProfileAdditionalInformation': LazyComponent<typeof import("../components/Others/MyProfile/AdditionalInformation.vue")['default']>
    'LazyOthersMyProfileInformation': LazyComponent<typeof import("../components/Others/MyProfile/ProfileInformation.vue")['default']>
    'LazyOthersMyProfileIntro': LazyComponent<typeof import("../components/Others/MyProfile/ProfileIntro.vue")['default']>
    'LazyOthersMyProfileProjectsAnalysisChart': LazyComponent<typeof import("../components/Others/MyProfile/ProjectsAnalysisChart.vue")['default']>
    'LazyOthersMyProfileRecentActivity': LazyComponent<typeof import("../components/Others/MyProfile/RecentActivity.vue")['default']>
    'LazyOthersMyProfileToDoList': LazyComponent<typeof import("../components/Others/MyProfile/ToDoList.vue")['default']>
    'LazyOthersMyProfileTotalOrders': LazyComponent<typeof import("../components/Others/MyProfile/TotalOrders.vue")['default']>
    'LazyOthersMyProfileTotalProjects': LazyComponent<typeof import("../components/Others/MyProfile/TotalProjects.vue")['default']>
    'LazyOthersMyProfileTotalRevenue': LazyComponent<typeof import("../components/Others/MyProfile/TotalRevenue.vue")['default']>
    'LazyOthersMyProfileWelcomeBack': LazyComponent<typeof import("../components/Others/MyProfile/WelcomeBack.vue")['default']>
    'LazyOthersMyProfile': LazyComponent<typeof import("../components/Others/MyProfile/index.vue")['default']>
    'LazyOthersSettingsAccountSettings': LazyComponent<typeof import("../components/Others/Settings/AccountSettings/index.vue")['default']>
    'LazyOthersSettingsChangePassword': LazyComponent<typeof import("../components/Others/Settings/ChangePassword/index.vue")['default']>
    'LazyOthersSettingsConnections': LazyComponent<typeof import("../components/Others/Settings/Connections/index.vue")['default']>
    'LazyOthersSettingsPrivacyPolicy': LazyComponent<typeof import("../components/Others/Settings/PrivacyPolicy/index.vue")['default']>
    'LazyOthersSettingsMenu': LazyComponent<typeof import("../components/Others/Settings/SettingsMenu.vue")['default']>
    'LazyOthersSettingsTermsConditions': LazyComponent<typeof import("../components/Others/Settings/TermsConditions/index.vue")['default']>
    'LazyPagesCRMContacts': LazyComponent<typeof import("../components/Pages/CRM/Contacts/index.vue")['default']>
    'LazyPagesCRMCustomers': LazyComponent<typeof import("../components/Pages/CRM/Customers/index.vue")['default']>
    'LazyPagesCRMDeals': LazyComponent<typeof import("../components/Pages/CRM/Deals/index.vue")['default']>
    'LazyPagesCRMLeadsAnnualProfitChart': LazyComponent<typeof import("../components/Pages/CRM/Leads/AnnualProfitChart.vue")['default']>
    'LazyPagesCRMLeadsLeadConversionChart': LazyComponent<typeof import("../components/Pages/CRM/Leads/LeadConversionChart.vue")['default']>
    'LazyPagesCRMLeadsRevenueGrowthChart': LazyComponent<typeof import("../components/Pages/CRM/Leads/RevenueGrowthChart.vue")['default']>
    'LazyPagesCRMLeadsTotalOrdersChart': LazyComponent<typeof import("../components/Pages/CRM/Leads/TotalOrdersChart.vue")['default']>
    'LazyPagesCRMLeads': LazyComponent<typeof import("../components/Pages/CRM/Leads/index.vue")['default']>
    'LazyPagesCryptoTraderCTWallet': LazyComponent<typeof import("../components/Pages/CryptoTrader/CTWallet/index.vue")['default']>
    'LazyPagesCryptoTraderGainersLosers': LazyComponent<typeof import("../components/Pages/CryptoTrader/GainersLosers/index.vue")['default']>
    'LazyPagesCryptoTraderTransactions': LazyComponent<typeof import("../components/Pages/CryptoTrader/Transactions/index.vue")['default']>
    'LazyPagesDoctorAddPatient': LazyComponent<typeof import("../components/Pages/Doctor/AddPatient/index.vue")['default']>
    'LazyPagesDoctorAppointmentsTodayAppointments': LazyComponent<typeof import("../components/Pages/Doctor/Appointments/TodayAppointments.vue")['default']>
    'LazyPagesDoctorAppointmentsTodaySchedule': LazyComponent<typeof import("../components/Pages/Doctor/Appointments/TodaySchedule.vue")['default']>
    'LazyPagesDoctorAppointments': LazyComponent<typeof import("../components/Pages/Doctor/Appointments/index.vue")['default']>
    'LazyPagesDoctorPatientDetails': LazyComponent<typeof import("../components/Pages/Doctor/PatientDetails/index.vue")['default']>
    'LazyPagesDoctorPatientsList': LazyComponent<typeof import("../components/Pages/Doctor/PatientsList/index.vue")['default']>
    'LazyPagesDoctorPrescriptions': LazyComponent<typeof import("../components/Pages/Doctor/Prescriptions/index.vue")['default']>
    'LazyPagesDoctorWritePrescription': LazyComponent<typeof import("../components/Pages/Doctor/WritePrescription/index.vue")['default']>
    'LazyPagesEcommerceCartQuantityCounter': LazyComponent<typeof import("../components/Pages/Ecommerce/Cart/QuantityCounter.vue")['default']>
    'LazyPagesEcommerceCart': LazyComponent<typeof import("../components/Pages/Ecommerce/Cart/index.vue")['default']>
    'LazyPagesEcommerceCategories': LazyComponent<typeof import("../components/Pages/Ecommerce/Categories/index.vue")['default']>
    'LazyPagesEcommerceCheckout': LazyComponent<typeof import("../components/Pages/Ecommerce/Checkout/index.vue")['default']>
    'LazyPagesEcommerceCreateOrderBillingInformation': LazyComponent<typeof import("../components/Pages/Ecommerce/CreateOrder/BillingInformation.vue")['default']>
    'LazyPagesEcommerceCreateOrderPaymentMethod': LazyComponent<typeof import("../components/Pages/Ecommerce/CreateOrder/PaymentMethod.vue")['default']>
    'LazyPagesEcommerceCreateOrderYourOrder': LazyComponent<typeof import("../components/Pages/Ecommerce/CreateOrder/YourOrder.vue")['default']>
    'LazyPagesEcommerceCreateOrder': LazyComponent<typeof import("../components/Pages/Ecommerce/CreateOrder/index.vue")['default']>
    'LazyPagesEcommerceCreateProduct': LazyComponent<typeof import("../components/Pages/Ecommerce/CreateProduct/index.vue")['default']>
    'LazyPagesEcommerceCreateSeller': LazyComponent<typeof import("../components/Pages/Ecommerce/CreateSeller/index.vue")['default']>
    'LazyPagesEcommerceCustomerDetailsTransactionsHistory': LazyComponent<typeof import("../components/Pages/Ecommerce/CustomerDetails/TransactionsHistory.vue")['default']>
    'LazyPagesEcommerceCustomerDetailsUserCard': LazyComponent<typeof import("../components/Pages/Ecommerce/CustomerDetails/UserCard.vue")['default']>
    'LazyPagesEcommerceCustomerDetails': LazyComponent<typeof import("../components/Pages/Ecommerce/CustomerDetails/index.vue")['default']>
    'LazyPagesEcommerceCustomers': LazyComponent<typeof import("../components/Pages/Ecommerce/Customers/index.vue")['default']>
    'LazyPagesEcommerceEditProduct': LazyComponent<typeof import("../components/Pages/Ecommerce/EditProduct/index.vue")['default']>
    'LazyPagesEcommerceOrderDetailsBillingDetails': LazyComponent<typeof import("../components/Pages/Ecommerce/OrderDetails/BillingDetails.vue")['default']>
    'LazyPagesEcommerceOrderDetailsDeliveryDetails': LazyComponent<typeof import("../components/Pages/Ecommerce/OrderDetails/DeliveryDetails.vue")['default']>
    'LazyPagesEcommerceOrderDetailsOrderSummary': LazyComponent<typeof import("../components/Pages/Ecommerce/OrderDetails/OrderSummary.vue")['default']>
    'LazyPagesEcommerceOrderDetailsQuantityCounter': LazyComponent<typeof import("../components/Pages/Ecommerce/OrderDetails/QuantityCounter.vue")['default']>
    'LazyPagesEcommerceOrderDetailsRecentOrders': LazyComponent<typeof import("../components/Pages/Ecommerce/OrderDetails/RecentOrders.vue")['default']>
    'LazyPagesEcommerceOrderDetailsShippingDetails': LazyComponent<typeof import("../components/Pages/Ecommerce/OrderDetails/ShippingDetails.vue")['default']>
    'LazyPagesEcommerceOrderDetailsTrackingID': LazyComponent<typeof import("../components/Pages/Ecommerce/OrderDetails/TrackingID.vue")['default']>
    'LazyPagesEcommerceOrderDetails': LazyComponent<typeof import("../components/Pages/Ecommerce/OrderDetails/index.vue")['default']>
    'LazyPagesEcommerceOrderTracking': LazyComponent<typeof import("../components/Pages/Ecommerce/OrderTracking/index.vue")['default']>
    'LazyPagesEcommerceOrders': LazyComponent<typeof import("../components/Pages/Ecommerce/Orders/index.vue")['default']>
    'LazyPagesEcommerceProductsDetailsTabs': LazyComponent<typeof import("../components/Pages/Ecommerce/ProductsDetails/ProductsDetailsTabs.vue")['default']>
    'LazyPagesEcommerceProductsDetailsProductsFilter': LazyComponent<typeof import("../components/Pages/Ecommerce/ProductsDetails/ProductsFilter.vue")['default']>
    'LazyPagesEcommerceProductsDetails': LazyComponent<typeof import("../components/Pages/Ecommerce/ProductsDetails/index.vue")['default']>
    'LazyPagesEcommerceProductsGridProductsFilter': LazyComponent<typeof import("../components/Pages/Ecommerce/ProductsGrid/ProductsFilter.vue")['default']>
    'LazyPagesEcommerceProductsGrid': LazyComponent<typeof import("../components/Pages/Ecommerce/ProductsGrid/index.vue")['default']>
    'LazyPagesEcommerceProductsList': LazyComponent<typeof import("../components/Pages/Ecommerce/ProductsList/index.vue")['default']>
    'LazyPagesEcommerceRefunds': LazyComponent<typeof import("../components/Pages/Ecommerce/Refunds/index.vue")['default']>
    'LazyPagesEcommerceReviews': LazyComponent<typeof import("../components/Pages/Ecommerce/Reviews/index.vue")['default']>
    'LazyPagesEcommerceSellerDetailsProductsList': LazyComponent<typeof import("../components/Pages/Ecommerce/SellerDetails/ProductsList.vue")['default']>
    'LazyPagesEcommerceSellerDetailsRevenueChart': LazyComponent<typeof import("../components/Pages/Ecommerce/SellerDetails/RevenueChart.vue")['default']>
    'LazyPagesEcommerceSellerDetailsSellerID': LazyComponent<typeof import("../components/Pages/Ecommerce/SellerDetails/SellerID.vue")['default']>
    'LazyPagesEcommerceSellerDetailsSellerOverview': LazyComponent<typeof import("../components/Pages/Ecommerce/SellerDetails/SellerOverview.vue")['default']>
    'LazyPagesEcommerceSellerDetails': LazyComponent<typeof import("../components/Pages/Ecommerce/SellerDetails/index.vue")['default']>
    'LazyPagesEcommerceSellers': LazyComponent<typeof import("../components/Pages/Ecommerce/Sellers/index.vue")['default']>
    'LazyPagesEventsCreateAnEvent': LazyComponent<typeof import("../components/Pages/Events/CreateAnEvent/index.vue")['default']>
    'LazyPagesEventsEditAnEvent': LazyComponent<typeof import("../components/Pages/Events/EditAnEvent/index.vue")['default']>
    'LazyPagesEventsEventDetailsAboutThisEvent': LazyComponent<typeof import("../components/Pages/Events/EventDetails/AboutThisEvent.vue")['default']>
    'LazyPagesEventsEventDetailsAnnualConference': LazyComponent<typeof import("../components/Pages/Events/EventDetails/AnnualConference.vue")['default']>
    'LazyPagesEventsEventDetailsEventInfo': LazyComponent<typeof import("../components/Pages/Events/EventDetails/EventInfo.vue")['default']>
    'LazyPagesEventsEventDetailsSpeakerTopic': LazyComponent<typeof import("../components/Pages/Events/EventDetails/SpeakerTopic.vue")['default']>
    'LazyPagesEventsEventDetails': LazyComponent<typeof import("../components/Pages/Events/EventDetails/index.vue")['default']>
    'LazyPagesEventsEventsGrid': LazyComponent<typeof import("../components/Pages/Events/EventsGrid/index.vue")['default']>
    'LazyPagesEventsEventsList': LazyComponent<typeof import("../components/Pages/Events/EventsList/index.vue")['default']>
    'LazyPagesFinanceTransactionAddNewTransactionModal': LazyComponent<typeof import("../components/Pages/Finance/Transaction/AddNewTransactionModal.vue")['default']>
    'LazyPagesFinanceTransaction': LazyComponent<typeof import("../components/Pages/Finance/Transaction/index.vue")['default']>
    'LazyPagesFinanceWalletAddCardDetailModal': LazyComponent<typeof import("../components/Pages/Finance/Wallet/AddCardDetailModal.vue")['default']>
    'LazyPagesFinanceWalletDebitCard': LazyComponent<typeof import("../components/Pages/Finance/Wallet/DebitCard.vue")['default']>
    'LazyPagesFinanceWalletStaticChart': LazyComponent<typeof import("../components/Pages/Finance/Wallet/StaticChart.vue")['default']>
    'LazyPagesFinanceWalletTotalExpenses': LazyComponent<typeof import("../components/Pages/Finance/Wallet/TotalExpenses.vue")['default']>
    'LazyPagesFinanceWalletTotalIncome': LazyComponent<typeof import("../components/Pages/Finance/Wallet/TotalIncome.vue")['default']>
    'LazyPagesFinanceWalletTransactionHistory': LazyComponent<typeof import("../components/Pages/Finance/Wallet/TransactionHistory.vue")['default']>
    'LazyPagesFinanceWallet': LazyComponent<typeof import("../components/Pages/Finance/Wallet/index.vue")['default']>
    'LazyPagesHelpDeskAgents': LazyComponent<typeof import("../components/Pages/HelpDesk/Agents/index.vue")['default']>
    'LazyPagesHelpDeskReportsCustomerSatisfactionChart': LazyComponent<typeof import("../components/Pages/HelpDesk/Reports/CustomerSatisfactionChart.vue")['default']>
    'LazyPagesHelpDeskReportsNewAndSolvedTicketsChart': LazyComponent<typeof import("../components/Pages/HelpDesk/Reports/NewAndSolvedTicketsChart.vue")['default']>
    'LazyPagesHelpDeskReportsPerformanceOfAgents': LazyComponent<typeof import("../components/Pages/HelpDesk/Reports/PerformanceOfAgents.vue")['default']>
    'LazyPagesHelpDeskReportsResponseTimeChart': LazyComponent<typeof import("../components/Pages/HelpDesk/Reports/ResponseTimeChart.vue")['default']>
    'LazyPagesHelpDeskReportsTasksOverviewChart': LazyComponent<typeof import("../components/Pages/HelpDesk/Reports/TasksOverviewChart.vue")['default']>
    'LazyPagesHelpDeskReportsTicketsStatusChart': LazyComponent<typeof import("../components/Pages/HelpDesk/Reports/TicketsStatusChart.vue")['default']>
    'LazyPagesHelpDeskReports': LazyComponent<typeof import("../components/Pages/HelpDesk/Reports/index.vue")['default']>
    'LazyPagesHelpDeskTicketDetailsAttachments': LazyComponent<typeof import("../components/Pages/HelpDesk/TicketDetails/Attachments.vue")['default']>
    'LazyPagesHelpDeskTicketDetailsComments': LazyComponent<typeof import("../components/Pages/HelpDesk/TicketDetails/Comments.vue")['default']>
    'LazyPagesHelpDeskTicketDetailsTicket': LazyComponent<typeof import("../components/Pages/HelpDesk/TicketDetails/Ticket.vue")['default']>
    'LazyPagesHelpDeskTicketDetailsTicketDescription': LazyComponent<typeof import("../components/Pages/HelpDesk/TicketDetails/TicketDescription.vue")['default']>
    'LazyPagesHelpDeskTicketDetails': LazyComponent<typeof import("../components/Pages/HelpDesk/TicketDetails/index.vue")['default']>
    'LazyPagesHelpDeskTicketsAllTickets': LazyComponent<typeof import("../components/Pages/HelpDesk/Tickets/AllTickets.vue")['default']>
    'LazyPagesHelpDeskTicketsDueChart': LazyComponent<typeof import("../components/Pages/HelpDesk/Tickets/TicketsDueChart.vue")['default']>
    'LazyPagesHelpDeskTicketsInProgressChart': LazyComponent<typeof import("../components/Pages/HelpDesk/Tickets/TicketsInProgressChart.vue")['default']>
    'LazyPagesHelpDeskTicketsNewOpenChart': LazyComponent<typeof import("../components/Pages/HelpDesk/Tickets/TicketsNewOpenChart.vue")['default']>
    'LazyPagesHelpDeskTicketsResolvedChart': LazyComponent<typeof import("../components/Pages/HelpDesk/Tickets/TicketsResolvedChart.vue")['default']>
    'LazyPagesHelpDeskTickets': LazyComponent<typeof import("../components/Pages/HelpDesk/Tickets/index.vue")['default']>
    'LazyPagesHotelGuestsList': LazyComponent<typeof import("../components/Pages/Hotel/GuestsList/index.vue")['default']>
    'LazyPagesHotelRoomDetailsReviews': LazyComponent<typeof import("../components/Pages/Hotel/RoomDetails/Reviews.vue")['default']>
    'LazyPagesHotelRoomDetails': LazyComponent<typeof import("../components/Pages/Hotel/RoomDetails/index.vue")['default']>
    'LazyPagesHotelRoomsList': LazyComponent<typeof import("../components/Pages/Hotel/RoomsList/index.vue")['default']>
    'LazyPagesInvoicesCreateInvoice': LazyComponent<typeof import("../components/Pages/Invoices/CreateInvoice/index.vue")['default']>
    'LazyPagesInvoicesEditInvoice': LazyComponent<typeof import("../components/Pages/Invoices/EditInvoice/index.vue")['default']>
    'LazyPagesInvoicesInvoiceDetails': LazyComponent<typeof import("../components/Pages/Invoices/InvoiceDetails/index.vue")['default']>
    'LazyPagesInvoicesInvoicesList': LazyComponent<typeof import("../components/Pages/Invoices/InvoicesList/index.vue")['default']>
    'LazyPagesLMSCourseDetailsCourse': LazyComponent<typeof import("../components/Pages/LMS/CourseDetails/Course.vue")['default']>
    'LazyPagesLMSCourseDetailsCourseInstructor': LazyComponent<typeof import("../components/Pages/LMS/CourseDetails/CourseInstructor.vue")['default']>
    'LazyPagesLMSCourseDetailsEnrolledStudents': LazyComponent<typeof import("../components/Pages/LMS/CourseDetails/EnrolledStudents.vue")['default']>
    'LazyPagesLMSCourseDetailsManageReviews': LazyComponent<typeof import("../components/Pages/LMS/CourseDetails/ManageReviews.vue")['default']>
    'LazyPagesLMSCourseDetailsRatings': LazyComponent<typeof import("../components/Pages/LMS/CourseDetails/Ratings.vue")['default']>
    'LazyPagesLMSCourseDetailsTablesOfContent': LazyComponent<typeof import("../components/Pages/LMS/CourseDetails/TablesOfContent.vue")['default']>
    'LazyPagesLMSCourseDetailsWriteFeedbackHere': LazyComponent<typeof import("../components/Pages/LMS/CourseDetails/WriteFeedbackHere.vue")['default']>
    'LazyPagesLMSCourseDetails': LazyComponent<typeof import("../components/Pages/LMS/CourseDetails/index.vue")['default']>
    'LazyPagesLMSCoursesList': LazyComponent<typeof import("../components/Pages/LMS/CoursesList/index.vue")['default']>
    'LazyPagesLMSCreateCourse': LazyComponent<typeof import("../components/Pages/LMS/CreateCourse/index.vue")['default']>
    'LazyPagesLMSEditCourse': LazyComponent<typeof import("../components/Pages/LMS/EditCourse/index.vue")['default']>
    'LazyPagesLMSInstructors': LazyComponent<typeof import("../components/Pages/LMS/Instructors/index.vue")['default']>
    'LazyPagesLMSLessonPreview': LazyComponent<typeof import("../components/Pages/LMS/LessonPreview/index.vue")['default']>
    'LazyPagesLMSAdminInstituteType': LazyComponent<typeof import("../components/Pages/LMS/admin/institute-type.vue")['default']>
    'LazyPagesNFTMarketplaceCreatorDetailsCarterID': LazyComponent<typeof import("../components/Pages/NFTMarketplace/CreatorDetails/CarterID.vue")['default']>
    'LazyPagesNFTMarketplaceCreatorDetailsCarterNFTs': LazyComponent<typeof import("../components/Pages/NFTMarketplace/CreatorDetails/CarterNFTs.vue")['default']>
    'LazyPagesNFTMarketplaceCreatorDetails': LazyComponent<typeof import("../components/Pages/NFTMarketplace/CreatorDetails/index.vue")['default']>
    'LazyPagesNFTMarketplaceCreatorsFilterContent': LazyComponent<typeof import("../components/Pages/NFTMarketplace/Creators/FilterContent.vue")['default']>
    'LazyPagesNFTMarketplaceCreators': LazyComponent<typeof import("../components/Pages/NFTMarketplace/Creators/index.vue")['default']>
    'LazyPagesNFTMarketplaceExploreAllPriceFilter': LazyComponent<typeof import("../components/Pages/NFTMarketplace/ExploreAll/PriceFilter.vue")['default']>
    'LazyPagesNFTMarketplaceExploreAll': LazyComponent<typeof import("../components/Pages/NFTMarketplace/ExploreAll/index.vue")['default']>
    'LazyPagesNFTMarketplaceLiveAuctionCountdownTimer': LazyComponent<typeof import("../components/Pages/NFTMarketplace/LiveAuction/CountdownTimer.vue")['default']>
    'LazyPagesNFTMarketplaceLiveAuctionHistoryOfBids': LazyComponent<typeof import("../components/Pages/NFTMarketplace/LiveAuction/HistoryOfBids.vue")['default']>
    'LazyPagesNFTMarketplaceLiveAuctionNewMobileApp': LazyComponent<typeof import("../components/Pages/NFTMarketplace/LiveAuction/NewMobileApp.vue")['default']>
    'LazyPagesNFTMarketplaceLiveAuction': LazyComponent<typeof import("../components/Pages/NFTMarketplace/LiveAuction/index.vue")['default']>
    'LazyPagesNFTMarketplaceMarketplaceCreateNFT': LazyComponent<typeof import("../components/Pages/NFTMarketplace/Marketplace/CreateNFT.vue")['default']>
    'LazyPagesNFTMarketplaceMarketplaceFeaturedNFTArtworks': LazyComponent<typeof import("../components/Pages/NFTMarketplace/Marketplace/FeaturedNFTArtworks.vue")['default']>
    'LazyPagesNFTMarketplaceMarketplaceManageYourNFT': LazyComponent<typeof import("../components/Pages/NFTMarketplace/Marketplace/ManageYourNFT.vue")['default']>
    'LazyPagesNFTMarketplaceMarketplaceTopCreators': LazyComponent<typeof import("../components/Pages/NFTMarketplace/Marketplace/TopCreators.vue")['default']>
    'LazyPagesNFTMarketplaceNFTDetailsCountdownTimer': LazyComponent<typeof import("../components/Pages/NFTMarketplace/NFTDetails/CountdownTimer.vue")['default']>
    'LazyPagesNFTMarketplaceNFTDetails': LazyComponent<typeof import("../components/Pages/NFTMarketplace/NFTDetails/index.vue")['default']>
    'LazyPagesNFTMarketplaceWalletConnect': LazyComponent<typeof import("../components/Pages/NFTMarketplace/WalletConnect/index.vue")['default']>
    'LazyPagesProfileCover': LazyComponent<typeof import("../components/Pages/Profile/ProfileCover.vue")['default']>
    'LazyPagesProfileMenu': LazyComponent<typeof import("../components/Pages/Profile/ProfileMenu.vue")['default']>
    'LazyPagesProfileProjects': LazyComponent<typeof import("../components/Pages/Profile/Projects/index.vue")['default']>
    'LazyPagesProfileTeams': LazyComponent<typeof import("../components/Pages/Profile/Teams/index.vue")['default']>
    'LazyPagesProfileUserProfileAboutMe': LazyComponent<typeof import("../components/Pages/Profile/UserProfile/AboutMe.vue")['default']>
    'LazyPagesProfileUserProfileFollowers': LazyComponent<typeof import("../components/Pages/Profile/UserProfile/Followers.vue")['default']>
    'LazyPagesProfileUserProfileMyProjects': LazyComponent<typeof import("../components/Pages/Profile/UserProfile/MyProjects.vue")['default']>
    'LazyPagesProfileUserProfile': LazyComponent<typeof import("../components/Pages/Profile/UserProfile/index.vue")['default']>
    'LazyPagesProjectManagementClients': LazyComponent<typeof import("../components/Pages/ProjectManagement/Clients/index.vue")['default']>
    'LazyPagesProjectManagementCreateProject': LazyComponent<typeof import("../components/Pages/ProjectManagement/CreateProject/index.vue")['default']>
    'LazyPagesProjectManagementKanbanBoard': LazyComponent<typeof import("../components/Pages/ProjectManagement/KanbanBoard/index.vue")['default']>
    'LazyPagesProjectManagementProjectOverviewProjectRoadmapChart': LazyComponent<typeof import("../components/Pages/ProjectManagement/ProjectOverview/ProjectRoadmapChart.vue")['default']>
    'LazyPagesProjectManagementProjectOverviewProjectsOverview': LazyComponent<typeof import("../components/Pages/ProjectManagement/ProjectOverview/ProjectsOverview.vue")['default']>
    'LazyPagesProjectManagementProjectOverviewRecentActivity': LazyComponent<typeof import("../components/Pages/ProjectManagement/ProjectOverview/RecentActivity.vue")['default']>
    'LazyPagesProjectManagementProjectOverviewTasksOverviewChart': LazyComponent<typeof import("../components/Pages/ProjectManagement/ProjectOverview/TasksOverviewChart.vue")['default']>
    'LazyPagesProjectManagementProjectOverviewTeamMembers': LazyComponent<typeof import("../components/Pages/ProjectManagement/ProjectOverview/TeamMembers.vue")['default']>
    'LazyPagesProjectManagementProjectOverviewThemeDevelopment': LazyComponent<typeof import("../components/Pages/ProjectManagement/ProjectOverview/ThemeDevelopment.vue")['default']>
    'LazyPagesProjectManagementProjectOverviewToDoList': LazyComponent<typeof import("../components/Pages/ProjectManagement/ProjectOverview/ToDoList.vue")['default']>
    'LazyPagesProjectManagementProjectOverview': LazyComponent<typeof import("../components/Pages/ProjectManagement/ProjectOverview/index.vue")['default']>
    'LazyPagesProjectManagementProjectsList': LazyComponent<typeof import("../components/Pages/ProjectManagement/ProjectsList/index.vue")['default']>
    'LazyPagesProjectManagementTeams': LazyComponent<typeof import("../components/Pages/ProjectManagement/Teams/index.vue")['default']>
    'LazyPagesProjectManagementUsers': LazyComponent<typeof import("../components/Pages/ProjectManagement/Users/index.vue")['default']>
    'LazyPagesRealEstateAddAgent': LazyComponent<typeof import("../components/Pages/RealEstate/AddAgent/index.vue")['default']>
    'LazyPagesRealEstateAddProperty': LazyComponent<typeof import("../components/Pages/RealEstate/AddProperty/index.vue")['default']>
    'LazyPagesRealEstateAgentList': LazyComponent<typeof import("../components/Pages/RealEstate/AgentList/index.vue")['default']>
    'LazyPagesRealEstateAgentOverviewClientTestimonials': LazyComponent<typeof import("../components/Pages/RealEstate/AgentOverview/ClientTestimonials.vue")['default']>
    'LazyPagesRealEstateAgentOverviewProfile': LazyComponent<typeof import("../components/Pages/RealEstate/AgentOverview/Profile.vue")['default']>
    'LazyPagesRealEstateAgentOverviewPropertyStatusPropertiesForRentChart': LazyComponent<typeof import("../components/Pages/RealEstate/AgentOverview/PropertyStatus/PropertiesForRentChart.vue")['default']>
    'LazyPagesRealEstateAgentOverviewPropertyStatusPropertiesForSaleChart': LazyComponent<typeof import("../components/Pages/RealEstate/AgentOverview/PropertyStatus/PropertiesForSaleChart.vue")['default']>
    'LazyPagesRealEstateAgentOverviewPropertyStatus': LazyComponent<typeof import("../components/Pages/RealEstate/AgentOverview/PropertyStatus/index.vue")['default']>
    'LazyPagesRealEstateAgentOverview': LazyComponent<typeof import("../components/Pages/RealEstate/AgentOverview/index.vue")['default']>
    'LazyPagesRealEstatePropertyListAddProperty': LazyComponent<typeof import("../components/Pages/RealEstate/PropertyList/AddProperty.vue")['default']>
    'LazyPagesRealEstatePropertyList': LazyComponent<typeof import("../components/Pages/RealEstate/PropertyList/index.vue")['default']>
    'LazyPagesRealEstatePropertyOverviewProfile': LazyComponent<typeof import("../components/Pages/RealEstate/PropertyOverview/Profile/index.vue")['default']>
    'LazyPagesRealEstatePropertyOverview': LazyComponent<typeof import("../components/Pages/RealEstate/PropertyOverview/index.vue")['default']>
    'LazyPagesRealEstateRealEstateCustomersAddNewCustomer': LazyComponent<typeof import("../components/Pages/RealEstate/RealEstateCustomers/AddNewCustomer.vue")['default']>
    'LazyPagesRealEstateRealEstateCustomersAddNewCustomerModal': LazyComponent<typeof import("../components/Pages/RealEstate/RealEstateCustomers/AddNewCustomerModal.vue")['default']>
    'LazyPagesRealEstateRealEstateCustomers': LazyComponent<typeof import("../components/Pages/RealEstate/RealEstateCustomers/index.vue")['default']>
    'LazyPagesRealEstateAgentProperties': LazyComponent<typeof import("../components/Pages/RealEstateAgent/Properties/index.vue")['default']>
    'LazyPagesRealEstateAgentPropertyDetailsReviews': LazyComponent<typeof import("../components/Pages/RealEstateAgent/PropertyDetails/Reviews.vue")['default']>
    'LazyPagesRealEstateAgentPropertyDetails': LazyComponent<typeof import("../components/Pages/RealEstateAgent/PropertyDetails/index.vue")['default']>
    'LazyPagesRestaurantDishDetailsReviewsComponent': LazyComponent<typeof import("../components/Pages/Restaurant/DishDetails/ReviewsComponent.vue")['default']>
    'LazyPagesRestaurantDishDetails': LazyComponent<typeof import("../components/Pages/Restaurant/DishDetails/index.vue")['default']>
    'LazyPagesRestaurantMenus': LazyComponent<typeof import("../components/Pages/Restaurant/Menus/index.vue")['default']>
    'LazyPagesSocialProfile': LazyComponent<typeof import("../components/Pages/Social/Profile/index.vue")['default']>
    'LazyPagesSocialSettings': LazyComponent<typeof import("../components/Pages/Social/Settings/index.vue")['default']>
    'LazyPagesStarter': LazyComponent<typeof import("../components/Pages/Starter/index.vue")['default']>
    'LazyPagesUsersAddUser': LazyComponent<typeof import("../components/Pages/Users/AddUser/index.vue")['default']>
    'LazyPagesUsersTeamMembers': LazyComponent<typeof import("../components/Pages/Users/TeamMembers/index.vue")['default']>
    'LazyPagesUsersUsersList': LazyComponent<typeof import("../components/Pages/Users/UsersList/index.vue")['default']>
    'LazyNuxtWelcome': LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/welcome.vue")['default']>
    'LazyNuxtLayout': LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-layout")['default']>
    'LazyNuxtErrorBoundary': LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-error-boundary.vue")['default']>
    'LazyClientOnly': LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/client-only")['default']>
    'LazyDevOnly': LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/dev-only")['default']>
    'LazyServerPlaceholder': LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/server-placeholder")['default']>
    'LazyNuxtLink': LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-link")['default']>
    'LazyNuxtLoadingIndicator': LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-loading-indicator")['default']>
    'LazyNuxtTime': LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-time.vue")['default']>
    'LazyNuxtRouteAnnouncer': LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-route-announcer")['default']>
    'LazyNuxtImg': LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-stubs")['NuxtImg']>
    'LazyNuxtPicture': LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-stubs")['NuxtPicture']>
    'LazyBAccordion': LazyComponent<typeof import("bootstrap-vue-next/components/BAccordion")['BAccordion']>
    'LazyBAccordionItem': LazyComponent<typeof import("bootstrap-vue-next/components/BAccordion")['BAccordionItem']>
    'LazyBAlert': LazyComponent<typeof import("bootstrap-vue-next/components/BAlert")['BAlert']>
    'LazyBAvatar': LazyComponent<typeof import("bootstrap-vue-next/components/BAvatar")['BAvatar']>
    'LazyBAvatarGroup': LazyComponent<typeof import("bootstrap-vue-next/components/BAvatar")['BAvatarGroup']>
    'LazyBBadge': LazyComponent<typeof import("bootstrap-vue-next/components/BBadge")['BBadge']>
    'LazyBBreadcrumb': LazyComponent<typeof import("bootstrap-vue-next/components/BBreadcrumb")['BBreadcrumb']>
    'LazyBBreadcrumbItem': LazyComponent<typeof import("bootstrap-vue-next/components/BBreadcrumb")['BBreadcrumbItem']>
    'LazyBButton': LazyComponent<typeof import("bootstrap-vue-next/components/BButton")['BButton']>
    'LazyBButtonGroup': LazyComponent<typeof import("bootstrap-vue-next/components/BButton")['BButtonGroup']>
    'LazyBButtonToolbar': LazyComponent<typeof import("bootstrap-vue-next/components/BButton")['BButtonToolbar']>
    'LazyBCloseButton': LazyComponent<typeof import("bootstrap-vue-next/components/BButton")['BCloseButton']>
    'LazyBCard': LazyComponent<typeof import("bootstrap-vue-next/components/BCard")['BCard']>
    'LazyBCardBody': LazyComponent<typeof import("bootstrap-vue-next/components/BCard")['BCardBody']>
    'LazyBCardFooter': LazyComponent<typeof import("bootstrap-vue-next/components/BCard")['BCardFooter']>
    'LazyBCardGroup': LazyComponent<typeof import("bootstrap-vue-next/components/BCard")['BCardGroup']>
    'LazyBCardHeader': LazyComponent<typeof import("bootstrap-vue-next/components/BCard")['BCardHeader']>
    'LazyBCardImg': LazyComponent<typeof import("bootstrap-vue-next/components/BCard")['BCardImg']>
    'LazyBCardSubtitle': LazyComponent<typeof import("bootstrap-vue-next/components/BCard")['BCardSubtitle']>
    'LazyBCardText': LazyComponent<typeof import("bootstrap-vue-next/components/BCard")['BCardText']>
    'LazyBCardTitle': LazyComponent<typeof import("bootstrap-vue-next/components/BCard")['BCardTitle']>
    'LazyBCarousel': LazyComponent<typeof import("bootstrap-vue-next/components/BCarousel")['BCarousel']>
    'LazyBCarouselSlide': LazyComponent<typeof import("bootstrap-vue-next/components/BCarousel")['BCarouselSlide']>
    'LazyBCol': LazyComponent<typeof import("bootstrap-vue-next/components/BContainer")['BCol']>
    'LazyBCollapse': LazyComponent<typeof import("bootstrap-vue-next/components/BCollapse")['BCollapse']>
    'LazyBContainer': LazyComponent<typeof import("bootstrap-vue-next/components/BContainer")['BContainer']>
    'LazyBDropdown': LazyComponent<typeof import("bootstrap-vue-next/components/BDropdown")['BDropdown']>
    'LazyBDropdownDivider': LazyComponent<typeof import("bootstrap-vue-next/components/BDropdown")['BDropdownDivider']>
    'LazyBDropdownForm': LazyComponent<typeof import("bootstrap-vue-next/components/BDropdown")['BDropdownForm']>
    'LazyBDropdownGroup': LazyComponent<typeof import("bootstrap-vue-next/components/BDropdown")['BDropdownGroup']>
    'LazyBDropdownHeader': LazyComponent<typeof import("bootstrap-vue-next/components/BDropdown")['BDropdownHeader']>
    'LazyBDropdownItem': LazyComponent<typeof import("bootstrap-vue-next/components/BDropdown")['BDropdownItem']>
    'LazyBDropdownItemButton': LazyComponent<typeof import("bootstrap-vue-next/components/BDropdown")['BDropdownItemButton']>
    'LazyBDropdownText': LazyComponent<typeof import("bootstrap-vue-next/components/BDropdown")['BDropdownText']>
    'LazyBForm': LazyComponent<typeof import("bootstrap-vue-next/components/BForm")['BForm']>
    'LazyBFormCheckbox': LazyComponent<typeof import("bootstrap-vue-next/components/BFormCheckbox")['BFormCheckbox']>
    'LazyBFormCheckboxGroup': LazyComponent<typeof import("bootstrap-vue-next/components/BFormCheckbox")['BFormCheckboxGroup']>
    'LazyBFormDatalist': LazyComponent<typeof import("bootstrap-vue-next/components/BForm")['BFormDatalist']>
    'LazyBFormFile': LazyComponent<typeof import("bootstrap-vue-next/components/BFormFile")['BFormFile']>
    'LazyBFormFloatingLabel': LazyComponent<typeof import("bootstrap-vue-next/components/BForm")['BFormFloatingLabel']>
    'LazyBFormGroup': LazyComponent<typeof import("bootstrap-vue-next/components/BFormGroup")['BFormGroup']>
    'LazyBFormInput': LazyComponent<typeof import("bootstrap-vue-next/components/BFormInput")['BFormInput']>
    'LazyBFormInvalidFeedback': LazyComponent<typeof import("bootstrap-vue-next/components/BForm")['BFormInvalidFeedback']>
    'LazyBFormRadio': LazyComponent<typeof import("bootstrap-vue-next/components/BFormRadio")['BFormRadio']>
    'LazyBFormRadioGroup': LazyComponent<typeof import("bootstrap-vue-next/components/BFormRadio")['BFormRadioGroup']>
    'LazyBFormRow': LazyComponent<typeof import("bootstrap-vue-next/components/BForm")['BFormRow']>
    'LazyBFormSelect': LazyComponent<typeof import("bootstrap-vue-next/components/BFormSelect")['BFormSelect']>
    'LazyBFormSelectOption': LazyComponent<typeof import("bootstrap-vue-next/components/BFormSelect")['BFormSelectOption']>
    'LazyBFormSelectOptionGroup': LazyComponent<typeof import("bootstrap-vue-next/components/BFormSelect")['BFormSelectOptionGroup']>
    'LazyBFormSpinbutton': LazyComponent<typeof import("bootstrap-vue-next/components/BFormSpinbutton")['BFormSpinbutton']>
    'LazyBFormTag': LazyComponent<typeof import("bootstrap-vue-next/components/BFormTags")['BFormTag']>
    'LazyBFormTags': LazyComponent<typeof import("bootstrap-vue-next/components/BFormTags")['BFormTags']>
    'LazyBFormText': LazyComponent<typeof import("bootstrap-vue-next/components/BForm")['BFormText']>
    'LazyBFormTextarea': LazyComponent<typeof import("bootstrap-vue-next/components/BFormTextarea")['BFormTextarea']>
    'LazyBFormValidFeedback': LazyComponent<typeof import("bootstrap-vue-next/components/BForm")['BFormValidFeedback']>
    'LazyBImg': LazyComponent<typeof import("bootstrap-vue-next/components/BImg")['BImg']>
    'LazyBInput': LazyComponent<typeof import("bootstrap-vue-next/components/BFormInput")['BInput']>
    'LazyBInputGroup': LazyComponent<typeof import("bootstrap-vue-next/components/BInputGroup")['BInputGroup']>
    'LazyBInputGroupText': LazyComponent<typeof import("bootstrap-vue-next/components/BInputGroup")['BInputGroupText']>
    'LazyBListGroup': LazyComponent<typeof import("bootstrap-vue-next/components/BListGroup")['BListGroup']>
    'LazyBListGroupItem': LazyComponent<typeof import("bootstrap-vue-next/components/BListGroup")['BListGroupItem']>
    'LazyBModal': LazyComponent<typeof import("bootstrap-vue-next/components/BModal")['BModal']>
    'LazyBModalOrchestrator': LazyComponent<typeof import("bootstrap-vue-next/components/BModal")['BModalOrchestrator']>
    'LazyBNav': LazyComponent<typeof import("bootstrap-vue-next/components/BNav")['BNav']>
    'LazyBNavForm': LazyComponent<typeof import("bootstrap-vue-next/components/BNav")['BNavForm']>
    'LazyBNavItem': LazyComponent<typeof import("bootstrap-vue-next/components/BNav")['BNavItem']>
    'LazyBNavItemDropdown': LazyComponent<typeof import("bootstrap-vue-next/components/BNav")['BNavItemDropdown']>
    'LazyBNavText': LazyComponent<typeof import("bootstrap-vue-next/components/BNav")['BNavText']>
    'LazyBNavbar': LazyComponent<typeof import("bootstrap-vue-next/components/BNavbar")['BNavbar']>
    'LazyBNavbarBrand': LazyComponent<typeof import("bootstrap-vue-next/components/BNavbar")['BNavbarBrand']>
    'LazyBNavbarNav': LazyComponent<typeof import("bootstrap-vue-next/components/BNavbar")['BNavbarNav']>
    'LazyBNavbarToggle': LazyComponent<typeof import("bootstrap-vue-next/components/BNavbar")['BNavbarToggle']>
    'LazyBOffcanvas': LazyComponent<typeof import("bootstrap-vue-next/components/BOffcanvas")['BOffcanvas']>
    'LazyBOverlay': LazyComponent<typeof import("bootstrap-vue-next/components/BOverlay")['BOverlay']>
    'LazyBPagination': LazyComponent<typeof import("bootstrap-vue-next/components/BPagination")['BPagination']>
    'LazyBPlaceholder': LazyComponent<typeof import("bootstrap-vue-next/components/BPlaceholder")['BPlaceholder']>
    'LazyBPlaceholderButton': LazyComponent<typeof import("bootstrap-vue-next/components/BPlaceholder")['BPlaceholderButton']>
    'LazyBPlaceholderCard': LazyComponent<typeof import("bootstrap-vue-next/components/BPlaceholder")['BPlaceholderCard']>
    'LazyBPlaceholderTable': LazyComponent<typeof import("bootstrap-vue-next/components/BPlaceholder")['BPlaceholderTable']>
    'LazyBPlaceholderWrapper': LazyComponent<typeof import("bootstrap-vue-next/components/BPlaceholder")['BPlaceholderWrapper']>
    'LazyBPopover': LazyComponent<typeof import("bootstrap-vue-next/components/BPopover")['BPopover']>
    'LazyBProgress': LazyComponent<typeof import("bootstrap-vue-next/components/BProgress")['BProgress']>
    'LazyBRow': LazyComponent<typeof import("bootstrap-vue-next/components/BContainer")['BRow']>
    'LazyBSpinner': LazyComponent<typeof import("bootstrap-vue-next/components/BSpinner")['BSpinner']>
    'LazyBTab': LazyComponent<typeof import("bootstrap-vue-next/components/BTabs")['BTab']>
    'LazyBTabs': LazyComponent<typeof import("bootstrap-vue-next/components/BTabs")['BTabs']>
    'LazyBToast': LazyComponent<typeof import("bootstrap-vue-next/components/BToast")['BToast']>
    'LazyBToastOrchestrator': LazyComponent<typeof import("bootstrap-vue-next/components/BToast")['BToastOrchestrator']>
    'LazyBTooltip': LazyComponent<typeof import("bootstrap-vue-next/components/BTooltip")['BTooltip']>
    'LazyBLink': LazyComponent<typeof import("bootstrap-vue-next/components/BLink")['BLink']>
    'LazyBProgressBar': LazyComponent<typeof import("bootstrap-vue-next/components/BProgress")['BProgressBar']>
    'LazyBTableSimple': LazyComponent<typeof import("bootstrap-vue-next/components/BTable")['BTableSimple']>
    'LazyBTableLite': LazyComponent<typeof import("bootstrap-vue-next/components/BTable")['BTableLite']>
    'LazyBTable': LazyComponent<typeof import("bootstrap-vue-next/components/BTable")['BTable']>
    'LazyBTbody': LazyComponent<typeof import("bootstrap-vue-next/components/BTable")['BTbody']>
    'LazyBTd': LazyComponent<typeof import("bootstrap-vue-next/components/BTable")['BTd']>
    'LazyBTh': LazyComponent<typeof import("bootstrap-vue-next/components/BTable")['BTh']>
    'LazyBThead': LazyComponent<typeof import("bootstrap-vue-next/components/BTable")['BThead']>
    'LazyBTfoot': LazyComponent<typeof import("bootstrap-vue-next/components/BTable")['BTfoot']>
    'LazyBTr': LazyComponent<typeof import("bootstrap-vue-next/components/BTable")['BTr']>
    'LazyBPopoverOrchestrator': LazyComponent<typeof import("bootstrap-vue-next/components/BPopover")['BPopoverOrchestrator']>
    'LazyBTooltipOrchestrator': LazyComponent<typeof import("bootstrap-vue-next/components/BTooltip")['BTooltipOrchestrator']>
    'LazySwiper': LazyComponent<typeof import("swiper/vue")['Swiper']>
    'LazySwiperSlide': LazyComponent<typeof import("swiper/vue")['SwiperSlide']>
    'LazyActivityIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ActivityIcon")['default']>
    'LazyAirplayIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/AirplayIcon")['default']>
    'LazyAlertCircleIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/AlertCircleIcon")['default']>
    'LazyAlertOctagonIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/AlertOctagonIcon")['default']>
    'LazyAlertTriangleIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/AlertTriangleIcon")['default']>
    'LazyAlignCenterIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/AlignCenterIcon")['default']>
    'LazyAlignJustifyIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/AlignJustifyIcon")['default']>
    'LazyAlignLeftIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/AlignLeftIcon")['default']>
    'LazyAlignRightIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/AlignRightIcon")['default']>
    'LazyAnchorIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/AnchorIcon")['default']>
    'LazyApertureIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ApertureIcon")['default']>
    'LazyArchiveIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ArchiveIcon")['default']>
    'LazyArrowDownCircleIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ArrowDownCircleIcon")['default']>
    'LazyArrowDownLeftIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ArrowDownLeftIcon")['default']>
    'LazyArrowDownRightIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ArrowDownRightIcon")['default']>
    'LazyArrowDownIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ArrowDownIcon")['default']>
    'LazyArrowLeftCircleIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ArrowLeftCircleIcon")['default']>
    'LazyArrowLeftIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ArrowLeftIcon")['default']>
    'LazyArrowRightCircleIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ArrowRightCircleIcon")['default']>
    'LazyArrowRightIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ArrowRightIcon")['default']>
    'LazyArrowUpCircleIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ArrowUpCircleIcon")['default']>
    'LazyArrowUpLeftIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ArrowUpLeftIcon")['default']>
    'LazyArrowUpRightIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ArrowUpRightIcon")['default']>
    'LazyArrowUpIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ArrowUpIcon")['default']>
    'LazyAtSignIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/AtSignIcon")['default']>
    'LazyAwardIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/AwardIcon")['default']>
    'LazyBarChart2Icon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/BarChart2Icon")['default']>
    'LazyBarChartIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/BarChartIcon")['default']>
    'LazyBatteryChargingIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/BatteryChargingIcon")['default']>
    'LazyBatteryIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/BatteryIcon")['default']>
    'LazyBellOffIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/BellOffIcon")['default']>
    'LazyBellIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/BellIcon")['default']>
    'LazyBluetoothIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/BluetoothIcon")['default']>
    'LazyBoldIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/BoldIcon")['default']>
    'LazyBookOpenIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/BookOpenIcon")['default']>
    'LazyBookIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/BookIcon")['default']>
    'LazyBookmarkIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/BookmarkIcon")['default']>
    'LazyBoxIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/BoxIcon")['default']>
    'LazyBriefcaseIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/BriefcaseIcon")['default']>
    'LazyCalendarIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CalendarIcon")['default']>
    'LazyCameraOffIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CameraOffIcon")['default']>
    'LazyCameraIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CameraIcon")['default']>
    'LazyCastIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CastIcon")['default']>
    'LazyCheckCircleIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CheckCircleIcon")['default']>
    'LazyCheckSquareIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CheckSquareIcon")['default']>
    'LazyCheckIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CheckIcon")['default']>
    'LazyChevronDownIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ChevronDownIcon")['default']>
    'LazyChevronLeftIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ChevronLeftIcon")['default']>
    'LazyChevronRightIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ChevronRightIcon")['default']>
    'LazyChevronUpIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ChevronUpIcon")['default']>
    'LazyChevronsDownIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ChevronsDownIcon")['default']>
    'LazyChevronsLeftIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ChevronsLeftIcon")['default']>
    'LazyChevronsRightIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ChevronsRightIcon")['default']>
    'LazyChevronsUpIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ChevronsUpIcon")['default']>
    'LazyChromeIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ChromeIcon")['default']>
    'LazyCircleIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CircleIcon")['default']>
    'LazyClipboardIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ClipboardIcon")['default']>
    'LazyClockIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ClockIcon")['default']>
    'LazyCloudDrizzleIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CloudDrizzleIcon")['default']>
    'LazyCloudLightningIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CloudLightningIcon")['default']>
    'LazyCloudOffIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CloudOffIcon")['default']>
    'LazyCloudRainIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CloudRainIcon")['default']>
    'LazyCloudSnowIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CloudSnowIcon")['default']>
    'LazyCloudIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CloudIcon")['default']>
    'LazyCodeIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CodeIcon")['default']>
    'LazyCodepenIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CodepenIcon")['default']>
    'LazyCodesandboxIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CodesandboxIcon")['default']>
    'LazyCoffeeIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CoffeeIcon")['default']>
    'LazyColumnsIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ColumnsIcon")['default']>
    'LazyCommandIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CommandIcon")['default']>
    'LazyCompassIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CompassIcon")['default']>
    'LazyCopyIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CopyIcon")['default']>
    'LazyCornerDownLeftIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CornerDownLeftIcon")['default']>
    'LazyCornerDownRightIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CornerDownRightIcon")['default']>
    'LazyCornerLeftDownIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CornerLeftDownIcon")['default']>
    'LazyCornerLeftUpIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CornerLeftUpIcon")['default']>
    'LazyCornerRightDownIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CornerRightDownIcon")['default']>
    'LazyCornerRightUpIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CornerRightUpIcon")['default']>
    'LazyCornerUpLeftIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CornerUpLeftIcon")['default']>
    'LazyCornerUpRightIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CornerUpRightIcon")['default']>
    'LazyCpuIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CpuIcon")['default']>
    'LazyCreditCardIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CreditCardIcon")['default']>
    'LazyCropIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CropIcon")['default']>
    'LazyCrosshairIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CrosshairIcon")['default']>
    'LazyDatabaseIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/DatabaseIcon")['default']>
    'LazyDeleteIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/DeleteIcon")['default']>
    'LazyDiscIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/DiscIcon")['default']>
    'LazyDivideCircleIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/DivideCircleIcon")['default']>
    'LazyDivideSquareIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/DivideSquareIcon")['default']>
    'LazyDivideIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/DivideIcon")['default']>
    'LazyDollarSignIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/DollarSignIcon")['default']>
    'LazyDownloadCloudIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/DownloadCloudIcon")['default']>
    'LazyDownloadIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/DownloadIcon")['default']>
    'LazyDribbbleIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/DribbbleIcon")['default']>
    'LazyDropletIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/DropletIcon")['default']>
    'LazyEdit2Icon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/Edit2Icon")['default']>
    'LazyEdit3Icon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/Edit3Icon")['default']>
    'LazyEditIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/EditIcon")['default']>
    'LazyExternalLinkIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ExternalLinkIcon")['default']>
    'LazyEyeOffIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/EyeOffIcon")['default']>
    'LazyEyeIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/EyeIcon")['default']>
    'LazyFacebookIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/FacebookIcon")['default']>
    'LazyFastForwardIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/FastForwardIcon")['default']>
    'LazyFeatherIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/FeatherIcon")['default']>
    'LazyFigmaIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/FigmaIcon")['default']>
    'LazyFileMinusIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/FileMinusIcon")['default']>
    'LazyFilePlusIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/FilePlusIcon")['default']>
    'LazyFileTextIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/FileTextIcon")['default']>
    'LazyFileIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/FileIcon")['default']>
    'LazyFilmIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/FilmIcon")['default']>
    'LazyFilterIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/FilterIcon")['default']>
    'LazyFlagIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/FlagIcon")['default']>
    'LazyFolderMinusIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/FolderMinusIcon")['default']>
    'LazyFolderPlusIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/FolderPlusIcon")['default']>
    'LazyFolderIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/FolderIcon")['default']>
    'LazyFramerIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/FramerIcon")['default']>
    'LazyFrownIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/FrownIcon")['default']>
    'LazyGiftIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/GiftIcon")['default']>
    'LazyGitBranchIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/GitBranchIcon")['default']>
    'LazyGitCommitIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/GitCommitIcon")['default']>
    'LazyGitMergeIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/GitMergeIcon")['default']>
    'LazyGitPullRequestIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/GitPullRequestIcon")['default']>
    'LazyGithubIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/GithubIcon")['default']>
    'LazyGitlabIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/GitlabIcon")['default']>
    'LazyGlobeIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/GlobeIcon")['default']>
    'LazyGridIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/GridIcon")['default']>
    'LazyHardDriveIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/HardDriveIcon")['default']>
    'LazyHashIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/HashIcon")['default']>
    'LazyHeadphonesIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/HeadphonesIcon")['default']>
    'LazyHeartIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/HeartIcon")['default']>
    'LazyHelpCircleIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/HelpCircleIcon")['default']>
    'LazyHexagonIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/HexagonIcon")['default']>
    'LazyHomeIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/HomeIcon")['default']>
    'LazyImageIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ImageIcon")['default']>
    'LazyInboxIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/InboxIcon")['default']>
    'LazyInfoIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/InfoIcon")['default']>
    'LazyInstagramIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/InstagramIcon")['default']>
    'LazyItalicIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ItalicIcon")['default']>
    'LazyKeyIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/KeyIcon")['default']>
    'LazyLayersIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/LayersIcon")['default']>
    'LazyLayoutIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/LayoutIcon")['default']>
    'LazyLifeBuoyIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/LifeBuoyIcon")['default']>
    'LazyLink2Icon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/Link2Icon")['default']>
    'LazyLinkIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/LinkIcon")['default']>
    'LazyLinkedinIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/LinkedinIcon")['default']>
    'LazyListIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ListIcon")['default']>
    'LazyLoaderIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/LoaderIcon")['default']>
    'LazyLockIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/LockIcon")['default']>
    'LazyLogInIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/LogInIcon")['default']>
    'LazyLogOutIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/LogOutIcon")['default']>
    'LazyMailIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/MailIcon")['default']>
    'LazyMapPinIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/MapPinIcon")['default']>
    'LazyMapIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/MapIcon")['default']>
    'LazyMaximize2Icon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/Maximize2Icon")['default']>
    'LazyMaximizeIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/MaximizeIcon")['default']>
    'LazyMehIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/MehIcon")['default']>
    'LazyMenuIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/MenuIcon")['default']>
    'LazyMessageCircleIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/MessageCircleIcon")['default']>
    'LazyMessageSquareIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/MessageSquareIcon")['default']>
    'LazyMicOffIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/MicOffIcon")['default']>
    'LazyMicIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/MicIcon")['default']>
    'LazyMinimize2Icon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/Minimize2Icon")['default']>
    'LazyMinimizeIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/MinimizeIcon")['default']>
    'LazyMinusCircleIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/MinusCircleIcon")['default']>
    'LazyMinusSquareIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/MinusSquareIcon")['default']>
    'LazyMinusIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/MinusIcon")['default']>
    'LazyMonitorIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/MonitorIcon")['default']>
    'LazyMoonIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/MoonIcon")['default']>
    'LazyMoreHorizontalIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/MoreHorizontalIcon")['default']>
    'LazyMoreVerticalIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/MoreVerticalIcon")['default']>
    'LazyMousePointerIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/MousePointerIcon")['default']>
    'LazyMoveIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/MoveIcon")['default']>
    'LazyMusicIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/MusicIcon")['default']>
    'LazyNavigation2Icon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/Navigation2Icon")['default']>
    'LazyNavigationIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/NavigationIcon")['default']>
    'LazyOctagonIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/OctagonIcon")['default']>
    'LazyPackageIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/PackageIcon")['default']>
    'LazyPaperclipIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/PaperclipIcon")['default']>
    'LazyPauseCircleIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/PauseCircleIcon")['default']>
    'LazyPauseIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/PauseIcon")['default']>
    'LazyPenToolIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/PenToolIcon")['default']>
    'LazyPercentIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/PercentIcon")['default']>
    'LazyPhoneCallIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/PhoneCallIcon")['default']>
    'LazyPhoneForwardedIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/PhoneForwardedIcon")['default']>
    'LazyPhoneIncomingIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/PhoneIncomingIcon")['default']>
    'LazyPhoneMissedIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/PhoneMissedIcon")['default']>
    'LazyPhoneOffIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/PhoneOffIcon")['default']>
    'LazyPhoneOutgoingIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/PhoneOutgoingIcon")['default']>
    'LazyPhoneIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/PhoneIcon")['default']>
    'LazyPieChartIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/PieChartIcon")['default']>
    'LazyPlayCircleIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/PlayCircleIcon")['default']>
    'LazyPlayIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/PlayIcon")['default']>
    'LazyPlusCircleIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/PlusCircleIcon")['default']>
    'LazyPlusSquareIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/PlusSquareIcon")['default']>
    'LazyPlusIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/PlusIcon")['default']>
    'LazyPocketIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/PocketIcon")['default']>
    'LazyPowerIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/PowerIcon")['default']>
    'LazyPrinterIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/PrinterIcon")['default']>
    'LazyRadioIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/RadioIcon")['default']>
    'LazyRefreshCcwIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/RefreshCcwIcon")['default']>
    'LazyRefreshCwIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/RefreshCwIcon")['default']>
    'LazyRepeatIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/RepeatIcon")['default']>
    'LazyRewindIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/RewindIcon")['default']>
    'LazyRotateCcwIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/RotateCcwIcon")['default']>
    'LazyRotateCwIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/RotateCwIcon")['default']>
    'LazyRssIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/RssIcon")['default']>
    'LazySaveIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/SaveIcon")['default']>
    'LazyScissorsIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ScissorsIcon")['default']>
    'LazySearchIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/SearchIcon")['default']>
    'LazySendIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/SendIcon")['default']>
    'LazyServerIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ServerIcon")['default']>
    'LazySettingsIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/SettingsIcon")['default']>
    'LazyShare2Icon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/Share2Icon")['default']>
    'LazyShareIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ShareIcon")['default']>
    'LazyShieldOffIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ShieldOffIcon")['default']>
    'LazyShieldIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ShieldIcon")['default']>
    'LazyShoppingBagIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ShoppingBagIcon")['default']>
    'LazyShoppingCartIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ShoppingCartIcon")['default']>
    'LazyShuffleIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ShuffleIcon")['default']>
    'LazySidebarIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/SidebarIcon")['default']>
    'LazySkipBackIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/SkipBackIcon")['default']>
    'LazySkipForwardIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/SkipForwardIcon")['default']>
    'LazySlackIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/SlackIcon")['default']>
    'LazySlashIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/SlashIcon")['default']>
    'LazySlidersIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/SlidersIcon")['default']>
    'LazySmartphoneIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/SmartphoneIcon")['default']>
    'LazySmileIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/SmileIcon")['default']>
    'LazySpeakerIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/SpeakerIcon")['default']>
    'LazySquareIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/SquareIcon")['default']>
    'LazyStarIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/StarIcon")['default']>
    'LazyStopCircleIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/StopCircleIcon")['default']>
    'LazySunIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/SunIcon")['default']>
    'LazySunriseIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/SunriseIcon")['default']>
    'LazySunsetIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/SunsetIcon")['default']>
    'LazyTableIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/TableIcon")['default']>
    'LazyTabletIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/TabletIcon")['default']>
    'LazyTagIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/TagIcon")['default']>
    'LazyTargetIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/TargetIcon")['default']>
    'LazyTerminalIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/TerminalIcon")['default']>
    'LazyThermometerIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ThermometerIcon")['default']>
    'LazyThumbsDownIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ThumbsDownIcon")['default']>
    'LazyThumbsUpIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ThumbsUpIcon")['default']>
    'LazyToggleLeftIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ToggleLeftIcon")['default']>
    'LazyToggleRightIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ToggleRightIcon")['default']>
    'LazyToolIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ToolIcon")['default']>
    'LazyTrash2Icon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/Trash2Icon")['default']>
    'LazyTrashIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/TrashIcon")['default']>
    'LazyTrelloIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/TrelloIcon")['default']>
    'LazyTrendingDownIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/TrendingDownIcon")['default']>
    'LazyTrendingUpIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/TrendingUpIcon")['default']>
    'LazyTriangleIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/TriangleIcon")['default']>
    'LazyTruckIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/TruckIcon")['default']>
    'LazyTvIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/TvIcon")['default']>
    'LazyTwitchIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/TwitchIcon")['default']>
    'LazyTwitterIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/TwitterIcon")['default']>
    'LazyTypeIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/TypeIcon")['default']>
    'LazyUmbrellaIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/UmbrellaIcon")['default']>
    'LazyUnderlineIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/UnderlineIcon")['default']>
    'LazyUnlockIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/UnlockIcon")['default']>
    'LazyUploadCloudIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/UploadCloudIcon")['default']>
    'LazyUploadIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/UploadIcon")['default']>
    'LazyUserCheckIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/UserCheckIcon")['default']>
    'LazyUserMinusIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/UserMinusIcon")['default']>
    'LazyUserPlusIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/UserPlusIcon")['default']>
    'LazyUserXIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/UserXIcon")['default']>
    'LazyUserIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/UserIcon")['default']>
    'LazyUsersIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/UsersIcon")['default']>
    'LazyVideoOffIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/VideoOffIcon")['default']>
    'LazyVideoIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/VideoIcon")['default']>
    'LazyVoicemailIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/VoicemailIcon")['default']>
    'LazyVolume1Icon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/Volume1Icon")['default']>
    'LazyVolume2Icon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/Volume2Icon")['default']>
    'LazyVolumeXIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/VolumeXIcon")['default']>
    'LazyVolumeIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/VolumeIcon")['default']>
    'LazyWatchIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/WatchIcon")['default']>
    'LazyWifiOffIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/WifiOffIcon")['default']>
    'LazyWifiIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/WifiIcon")['default']>
    'LazyWindIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/WindIcon")['default']>
    'LazyXCircleIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/XCircleIcon")['default']>
    'LazyXOctagonIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/XOctagonIcon")['default']>
    'LazyXSquareIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/XSquareIcon")['default']>
    'LazyXIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/XIcon")['default']>
    'LazyYoutubeIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/YoutubeIcon")['default']>
    'LazyZapOffIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ZapOffIcon")['default']>
    'LazyZapIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ZapIcon")['default']>
    'LazyZoomInIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ZoomInIcon")['default']>
    'LazyZoomOutIcon': LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ZoomOutIcon")['default']>
    'LazyNuxtPage': LazyComponent<typeof import("../node_modules/nuxt/dist/pages/runtime/page")['default']>
    'LazyNoScript': LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['NoScript']>
    'LazyLink': LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Link']>
    'LazyBase': LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Base']>
    'LazyTitle': LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Title']>
    'LazyMeta': LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Meta']>
    'LazyStyle': LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Style']>
    'LazyHead': LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Head']>
    'LazyHtml': LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Html']>
    'LazyBody': LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Body']>
    'LazyNuxtIsland': LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-island")['default']>
    'LazyNuxtRouteAnnouncer': LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/server-placeholder")['default']>
}

declare module 'vue' {
  export interface GlobalComponents extends _GlobalComponents { }
}

export const ApexChartsBasicBarAreaChart: typeof import("../components/ApexCharts/BasicBarAreaChart.vue")['default']
export const ApexChartsBasicColumnAreaChart: typeof import("../components/ApexCharts/BasicColumnAreaChart.vue")['default']
export const ApexChartsBasicLineChart: typeof import("../components/ApexCharts/BasicLineChart.vue")['default']
export const ApexChartsColumnWithDataLabelsChart: typeof import("../components/ApexCharts/ColumnWithDataLabelsChart.vue")['default']
export const ApexChartsDashedChart: typeof import("../components/ApexCharts/DashedChart.vue")['default']
export const ApexChartsGroupedChart: typeof import("../components/ApexCharts/GroupedChart.vue")['default']
export const ApexChartsLineWithDataLabelsChart: typeof import("../components/ApexCharts/LineWithDataLabelsChart.vue")['default']
export const ApexChartsNegativeAreaChart: typeof import("../components/ApexCharts/NegativeAreaChart.vue")['default']
export const ApexChartsSplineAreaChart: typeof import("../components/ApexCharts/SplineAreaChart.vue")['default']
export const ApexChartsSteplineChart: typeof import("../components/ApexCharts/SteplineChart.vue")['default']
export const ApexCharts: typeof import("../components/ApexCharts/index.vue")['default']
export const AppsCalendarContent: typeof import("../components/Apps/Calendar/CalendarContent.vue")['default']
export const AppsCalendarWorkingSchedule: typeof import("../components/Apps/Calendar/WorkingSchedule.vue")['default']
export const AppsChat: typeof import("../components/Apps/Chat/index.vue")['default']
export const AppsContactsList: typeof import("../components/Apps/Contacts/ContactsList.vue")['default']
export const AppsEmailCompose: typeof import("../components/Apps/Email/Compose/index.vue")['default']
export const AppsEmailDraft: typeof import("../components/Apps/Email/Draft/index.vue")['default']
export const AppsEmailSidebar: typeof import("../components/Apps/Email/EmailSidebar.vue")['default']
export const AppsEmailImportant: typeof import("../components/Apps/Email/Important/index.vue")['default']
export const AppsEmailInbox: typeof import("../components/Apps/Email/Inbox/index.vue")['default']
export const AppsEmailReadEmail: typeof import("../components/Apps/Email/ReadEmail/index.vue")['default']
export const AppsEmailSentMail: typeof import("../components/Apps/Email/SentMail/index.vue")['default']
export const AppsEmailSnoozed: typeof import("../components/Apps/Email/Snoozed/index.vue")['default']
export const AppsEmailSpam: typeof import("../components/Apps/Email/Spam/index.vue")['default']
export const AppsEmailStarred: typeof import("../components/Apps/Email/Starred/index.vue")['default']
export const AppsEmailTrash: typeof import("../components/Apps/Email/Trash/index.vue")['default']
export const AppsFileManagerApplications: typeof import("../components/Apps/FileManager/Applications/index.vue")['default']
export const AppsFileManagerAssets: typeof import("../components/Apps/FileManager/Assets/index.vue")['default']
export const AppsFileManagerDocuments: typeof import("../components/Apps/FileManager/Documents/index.vue")['default']
export const AppsFileManagerImportant: typeof import("../components/Apps/FileManager/Important/index.vue")['default']
export const AppsFileManagerMedia: typeof import("../components/Apps/FileManager/Media/index.vue")['default']
export const AppsFileManagerMyDriveFiles: typeof import("../components/Apps/FileManager/MyDrive/MyDriveFiles.vue")['default']
export const AppsFileManagerMyDriveRecentFiles: typeof import("../components/Apps/FileManager/MyDrive/RecentFiles.vue")['default']
export const AppsFileManagerPersonal: typeof import("../components/Apps/FileManager/Personal/index.vue")['default']
export const AppsFileManagerProjects: typeof import("../components/Apps/FileManager/Projects/index.vue")['default']
export const AppsFileManagerRecants: typeof import("../components/Apps/FileManager/Recants/index.vue")['default']
export const AppsFileManagerSidebar: typeof import("../components/Apps/FileManager/Sidebar.vue")['default']
export const AppsFileManagerSpam: typeof import("../components/Apps/FileManager/Spam/index.vue")['default']
export const AppsFileManagerTrash: typeof import("../components/Apps/FileManager/Trash/index.vue")['default']
export const AppsKanbanBoard: typeof import("../components/Apps/KanbanBoard/index.vue")['default']
export const AppsToDoList: typeof import("../components/Apps/ToDoList/index.vue")['default']
export const CommonCalendarContent: typeof import("../components/Common/CalendarContent.vue")['default']
export const CommonDatePicker: typeof import("../components/Common/DatePicker.vue")['default']
export const CommonPageTitle: typeof import("../components/Common/PageTitle.vue")['default']
export const CommonPagination: typeof import("../components/Common/Pagination.vue")['default']
export const CommonPaginationTwo: typeof import("../components/Common/PaginationTwo.vue")['default']
export const CommonTextEditor: typeof import("../components/Common/TextEditor.vue")['default']
export const DashboardAnalyticsOverviewChart: typeof import("../components/Dashboard/Analytics/AnalyticsOverviewChart.vue")['default']
export const DashboardAnalyticsBrowserUsedByUsers: typeof import("../components/Dashboard/Analytics/BrowserUsedByUsers.vue")['default']
export const DashboardAnalyticsBrowserUsedByUsersChart: typeof import("../components/Dashboard/Analytics/BrowserUsedByUsersChart.vue")['default']
export const DashboardAnalyticsClicksChart: typeof import("../components/Dashboard/Analytics/ClicksChart.vue")['default']
export const DashboardAnalyticsClicksImpressionsByKeywords: typeof import("../components/Dashboard/Analytics/ClicksImpressionsByKeywords.vue")['default']
export const DashboardAnalyticsImpressionsChart: typeof import("../components/Dashboard/Analytics/ImpressionsChart.vue")['default']
export const DashboardAnalyticsNewRegistersChart: typeof import("../components/Dashboard/Analytics/NewRegistersChart.vue")['default']
export const DashboardAnalyticsRealtimeActiveUsersChart: typeof import("../components/Dashboard/Analytics/RealtimeActiveUsersChart.vue")['default']
export const DashboardAnalyticsSessionsByChannelChart: typeof import("../components/Dashboard/Analytics/SessionsByChannelChart.vue")['default']
export const DashboardAnalyticsSessionsChart: typeof import("../components/Dashboard/Analytics/SessionsChart.vue")['default']
export const DashboardAnalyticsTopBrowsingPagesToday: typeof import("../components/Dashboard/Analytics/TopBrowsingPagesToday.vue")['default']
export const DashboardAnalyticsUsersByCountry: typeof import("../components/Dashboard/Analytics/UsersByCountry.vue")['default']
export const DashboardAnalyticsWebsiteVisitsChart: typeof import("../components/Dashboard/Analytics/WebsiteVisitsChart.vue")['default']
export const DashboardBeautySalonCustomerSatisfactionRateChart: typeof import("../components/Dashboard/BeautySalon/CustomerSatisfactionRateChart.vue")['default']
export const DashboardBeautySalonCustomersFromChannels: typeof import("../components/Dashboard/BeautySalon/CustomersFromChannels.vue")['default']
export const DashboardBeautySalonFeaturedServices: typeof import("../components/Dashboard/BeautySalon/FeaturedServices.vue")['default']
export const DashboardBeautySalonNewCustomers: typeof import("../components/Dashboard/BeautySalon/NewCustomers.vue")['default']
export const DashboardBeautySalonRecentAppointments: typeof import("../components/Dashboard/BeautySalon/RecentAppointments.vue")['default']
export const DashboardBeautySalonRevenueByServicesChart: typeof import("../components/Dashboard/BeautySalon/RevenueByServicesChart.vue")['default']
export const DashboardBeautySalonTopCustomers: typeof import("../components/Dashboard/BeautySalon/TopCustomers.vue")['default']
export const DashboardBeautySalonTopSellingProducts: typeof import("../components/Dashboard/BeautySalon/TopSellingProducts.vue")['default']
export const DashboardBeautySalonTopStylistPerformance: typeof import("../components/Dashboard/BeautySalon/TopStylistPerformance.vue")['default']
export const DashboardBeautySalonWelcomeBeautySalon: typeof import("../components/Dashboard/BeautySalon/WelcomeBeautySalon.vue")['default']
export const DashboardCRMAnnualProfitChart: typeof import("../components/Dashboard/CRM/AnnualProfitChart.vue")['default']
export const DashboardCRMBalanceOverviewChart: typeof import("../components/Dashboard/CRM/BalanceOverviewChart.vue")['default']
export const DashboardCRMLeadConversionChart: typeof import("../components/Dashboard/CRM/LeadConversionChart.vue")['default']
export const DashboardCRMLeadsBySourceChart: typeof import("../components/Dashboard/CRM/LeadsBySourceChart.vue")['default']
export const DashboardCRMRecentLeads: typeof import("../components/Dashboard/CRM/RecentLeads.vue")['default']
export const DashboardCRMRevenueGrowthChart: typeof import("../components/Dashboard/CRM/RevenueGrowthChart.vue")['default']
export const DashboardCRMSalesReportChart: typeof import("../components/Dashboard/CRM/SalesReportChart.vue")['default']
export const DashboardCRMTopPerformers: typeof import("../components/Dashboard/CRM/TopPerformers.vue")['default']
export const DashboardCRMTopProductsBySales: typeof import("../components/Dashboard/CRM/TopProductsBySales.vue")['default']
export const DashboardCRMTotalOrdersChart: typeof import("../components/Dashboard/CRM/TotalOrdersChart.vue")['default']
export const DashboardCallCenterAgentAvgEarningsChart: typeof import("../components/Dashboard/CallCenter/AgentAvgEarnings/AgentAvgEarningsChart.vue")['default']
export const DashboardCallCenterAgentAvgEarningsFiveChart: typeof import("../components/Dashboard/CallCenter/AgentAvgEarnings/AgentAvgEarningsFiveChart.vue")['default']
export const DashboardCallCenterAgentAvgEarningsFourChart: typeof import("../components/Dashboard/CallCenter/AgentAvgEarnings/AgentAvgEarningsFourChart.vue")['default']
export const DashboardCallCenterAgentAvgEarningsThreeChart: typeof import("../components/Dashboard/CallCenter/AgentAvgEarnings/AgentAvgEarningsThreeChart.vue")['default']
export const DashboardCallCenterAgentAvgEarningsTwoChart: typeof import("../components/Dashboard/CallCenter/AgentAvgEarnings/AgentAvgEarningsTwoChart.vue")['default']
export const DashboardCallCenterAgentAvgEarnings: typeof import("../components/Dashboard/CallCenter/AgentAvgEarnings/index.vue")['default']
export const DashboardCallCenterAgentsPerformanceOverview: typeof import("../components/Dashboard/CallCenter/AgentsPerformanceOverview.vue")['default']
export const DashboardCallCenterGeography: typeof import("../components/Dashboard/CallCenter/CallCenterGeography.vue")['default']
export const DashboardCallCenterInboundCallsChart: typeof import("../components/Dashboard/CallCenter/InboundCallsChart.vue")['default']
export const DashboardCallCenterOutboundCallsChart: typeof import("../components/Dashboard/CallCenter/OutboundCallsChart.vue")['default']
export const DashboardCallCenterOverviewAnsweredCallsChart: typeof import("../components/Dashboard/CallCenter/Overview/AnsweredCallsChart.vue")['default']
export const DashboardCallCenterOverviewMissedCallsChart: typeof import("../components/Dashboard/CallCenter/Overview/MissedCallsChart.vue")['default']
export const DashboardCallCenterOverviewTotalCallsChart: typeof import("../components/Dashboard/CallCenter/Overview/TotalCallsChart.vue")['default']
export const DashboardCallCenterOverview: typeof import("../components/Dashboard/CallCenter/Overview/index.vue")['default']
export const DashboardCallCenterRecentCalls: typeof import("../components/Dashboard/CallCenter/RecentCalls.vue")['default']
export const DashboardCreditCardCardsWithAmountChart: typeof import("../components/Dashboard/CreditCard/CardsWithAmountChart.vue")['default']
export const DashboardCreditCardCreditUtilizationRatioChart: typeof import("../components/Dashboard/CreditCard/CreditUtilizationRatioChart.vue")['default']
export const DashboardCreditCardDailyLimit: typeof import("../components/Dashboard/CreditCard/DailyLimit.vue")['default']
export const DashboardCreditCardInterestChargeFeesChart: typeof import("../components/Dashboard/CreditCard/InterestChargeFeesChart.vue")['default']
export const DashboardCreditCardMonthlySpendingChart: typeof import("../components/Dashboard/CreditCard/MonthlySpendingChart.vue")['default']
export const DashboardCreditCardMyCards: typeof import("../components/Dashboard/CreditCard/MyCards.vue")['default']
export const DashboardCreditCardQuickTransfer: typeof import("../components/Dashboard/CreditCard/QuickTransfer.vue")['default']
export const DashboardCreditCardRecentTransactions: typeof import("../components/Dashboard/CreditCard/RecentTransactions.vue")['default']
export const DashboardCreditCardSpendingBreakdownChart: typeof import("../components/Dashboard/CreditCard/SpendingBreakdownChart.vue")['default']
export const DashboardCreditCardStatisticsChart: typeof import("../components/Dashboard/CreditCard/StatisticsChart.vue")['default']
export const DashboardCreditCardTotalBalance: typeof import("../components/Dashboard/CreditCard/TotalBalance.vue")['default']
export const DashboardCreditCardTotalExpense: typeof import("../components/Dashboard/CreditCard/TotalExpense.vue")['default']
export const DashboardCryptoBinanceChart: typeof import("../components/Dashboard/Crypto/BinanceChart.vue")['default']
export const DashboardCryptoBitcoinChart: typeof import("../components/Dashboard/Crypto/BitcoinChart.vue")['default']
export const DashboardCryptoCardanoChart: typeof import("../components/Dashboard/Crypto/CardanoChart.vue")['default']
export const DashboardCryptoRankings: typeof import("../components/Dashboard/Crypto/CryptoRankings.vue")['default']
export const DashboardCryptoCryptocurrencyWatchList: typeof import("../components/Dashboard/Crypto/CryptocurrencyWatchList.vue")['default']
export const DashboardCryptoEthereumChart: typeof import("../components/Dashboard/Crypto/EthereumChart.vue")['default']
export const DashboardCryptoExchangeCoin: typeof import("../components/Dashboard/Crypto/ExchangeCoin.vue")['default']
export const DashboardCryptoMarketPriceStatisticsChart: typeof import("../components/Dashboard/Crypto/MarketPriceStatisticsChart.vue")['default']
export const DashboardCryptoPortfolio: typeof import("../components/Dashboard/Crypto/Portfolio.vue")['default']
export const DashboardCryptoSolanaChart: typeof import("../components/Dashboard/Crypto/SolanaChart.vue")['default']
export const DashboardCryptoTransactionHistory: typeof import("../components/Dashboard/Crypto/TransactionHistory.vue")['default']
export const DashboardCryptoPerformanceBreadcrumb: typeof import("../components/Dashboard/CryptoPerformance/Breadcrumb.vue")['default']
export const DashboardCryptoPerformanceComparativeAnalysisChart: typeof import("../components/Dashboard/CryptoPerformance/ComparativeAnalysisChart.vue")['default']
export const DashboardCryptoPerformanceCryptoMarketCap: typeof import("../components/Dashboard/CryptoPerformance/CryptoMarketCap.vue")['default']
export const DashboardCryptoPerformanceIndividualAssetPerformance: typeof import("../components/Dashboard/CryptoPerformance/IndividualAssetPerformance.vue")['default']
export const DashboardCryptoPerformanceMarketPerformanceChart: typeof import("../components/Dashboard/CryptoPerformance/MarketPerformanceChart.vue")['default']
export const DashboardCryptoPerformanceMetricsChart: typeof import("../components/Dashboard/CryptoPerformance/PerformanceMetricsChart.vue")['default']
export const DashboardCryptoPerformancePerInvestmentChart: typeof import("../components/Dashboard/CryptoPerformance/PerformancePerInvestmentChart.vue")['default']
export const DashboardCryptoPerformancePortfolioValue: typeof import("../components/Dashboard/CryptoPerformance/PortfolioValue.vue")['default']
export const DashboardCryptoPerformanceRiskStabilityIndicatorsChart: typeof import("../components/Dashboard/CryptoPerformance/RiskStabilityIndicatorsChart.vue")['default']
export const DashboardCryptoPerformanceTransactionsHistory: typeof import("../components/Dashboard/CryptoPerformance/TransactionsHistory.vue")['default']
export const DashboardCryptoTraderAssetAllocationChart: typeof import("../components/Dashboard/CryptoTrader/AssetAllocationChart.vue")['default']
export const DashboardCryptoTraderCryptoStatsPanel: typeof import("../components/Dashboard/CryptoTrader/CryptoStatsPanel.vue")['default']
export const DashboardCryptoTraderGainersLosers: typeof import("../components/Dashboard/CryptoTrader/GainersLosers.vue")['default']
export const DashboardCryptoTraderLivePriceTracker: typeof import("../components/Dashboard/CryptoTrader/LivePriceTracker.vue")['default']
export const DashboardCryptoTraderMarketSentimentIndicatorChart: typeof import("../components/Dashboard/CryptoTrader/MarketSentimentIndicatorChart.vue")['default']
export const DashboardCryptoTraderPortfolioDistributionChart: typeof import("../components/Dashboard/CryptoTrader/PortfolioDistributionChart.vue")['default']
export const DashboardCryptoTraderPriceMovementChart: typeof import("../components/Dashboard/CryptoTrader/PriceMovementChart.vue")['default']
export const DashboardCryptoTraderProfitLossChart: typeof import("../components/Dashboard/CryptoTrader/ProfitLossChart.vue")['default']
export const DashboardCryptoTraderRecentTransactions: typeof import("../components/Dashboard/CryptoTrader/RecentTransactions.vue")['default']
export const DashboardCryptoTraderRiskExposureChart: typeof import("../components/Dashboard/CryptoTrader/RiskExposureChart.vue")['default']
export const DashboardCryptoTraderTradesPerMonthChart: typeof import("../components/Dashboard/CryptoTrader/TradesPerMonthChart.vue")['default']
export const DashboardCryptoTraderTradingVolumeChart: typeof import("../components/Dashboard/CryptoTrader/TradingVolumeChart.vue")['default']
export const DashboardDoctorWelcome: typeof import("../components/Dashboard/Doctor/DoctorWelcome.vue")['default']
export const DashboardDoctorIncomeExpenseChart: typeof import("../components/Dashboard/Doctor/IncomeExpenseChart.vue")['default']
export const DashboardDoctorMyRecentPatients: typeof import("../components/Dashboard/Doctor/MyRecentPatients.vue")['default']
export const DashboardDoctorPatientDistributionChart: typeof import("../components/Dashboard/Doctor/PatientDistributionChart.vue")['default']
export const DashboardDoctorPatientRetentionChart: typeof import("../components/Dashboard/Doctor/PatientRetentionChart.vue")['default']
export const DashboardDoctorRecentLabReports: typeof import("../components/Dashboard/Doctor/RecentLabReports.vue")['default']
export const DashboardDoctorStatsAppointments: typeof import("../components/Dashboard/Doctor/Stats/Appointments.vue")['default']
export const DashboardDoctorStatsEarnings: typeof import("../components/Dashboard/Doctor/Stats/Earnings.vue")['default']
export const DashboardDoctorStatsOperations: typeof import("../components/Dashboard/Doctor/Stats/Operations.vue")['default']
export const DashboardDoctorStatsPatients: typeof import("../components/Dashboard/Doctor/Stats/Patients.vue")['default']
export const DashboardDoctorStats: typeof import("../components/Dashboard/Doctor/Stats/index.vue")['default']
export const DashboardDoctorTodaySchedule: typeof import("../components/Dashboard/Doctor/TodaySchedule.vue")['default']
export const DashboardDoctorUpgradePlan: typeof import("../components/Dashboard/Doctor/UpgradePlan.vue")['default']
export const DashboardFinanceAccountPayable: typeof import("../components/Dashboard/Finance/AccountPayable.vue")['default']
export const DashboardFinanceAccountsReceivable: typeof import("../components/Dashboard/Finance/AccountsReceivable.vue")['default']
export const DashboardFinanceAddCardDetailModal: typeof import("../components/Dashboard/Finance/AddCardDetailModal.vue")['default']
export const DashboardFinanceCashEndOfTheMonthChart: typeof import("../components/Dashboard/Finance/CashEndOfTheMonthChart.vue")['default']
export const DashboardFinanceDebitCard: typeof import("../components/Dashboard/Finance/DebitCard.vue")['default']
export const DashboardFinanceExpenseBreakdownChart: typeof import("../components/Dashboard/Finance/ExpenseBreakdownChart.vue")['default']
export const DashboardFinanceIncomeSourceChart: typeof import("../components/Dashboard/Finance/IncomeSourceChart.vue")['default']
export const DashboardFinanceNetProfitChart: typeof import("../components/Dashboard/Finance/NetProfitChart.vue")['default']
export const DashboardFinanceStaticChart: typeof import("../components/Dashboard/Finance/StaticChart.vue")['default']
export const DashboardFinanceTotalExpenses: typeof import("../components/Dashboard/Finance/TotalExpenses.vue")['default']
export const DashboardFinanceTotalIncome: typeof import("../components/Dashboard/Finance/TotalIncome.vue")['default']
export const DashboardFinanceTransactionHistory: typeof import("../components/Dashboard/Finance/TransactionHistory.vue")['default']
export const DashboardFinanceWeeklyExpensesChart: typeof import("../components/Dashboard/Finance/WeeklyExpensesChart.vue")['default']
export const DashboardHRMDateRangePicker: typeof import("../components/Dashboard/HRM/DateRangePicker.vue")['default']
export const DashboardHRMEmployeeAttendanceTrendsChart: typeof import("../components/Dashboard/HRM/EmployeeAttendanceTrendsChart.vue")['default']
export const DashboardHRMEmployeeLeaveRequest: typeof import("../components/Dashboard/HRM/EmployeeLeaveRequest.vue")['default']
export const DashboardHRMEmployeeList: typeof import("../components/Dashboard/HRM/EmployeeList.vue")['default']
export const DashboardHRMEmployeeSalaryChart: typeof import("../components/Dashboard/HRM/EmployeeSalaryChart.vue")['default']
export const DashboardHRMEmployeeWorkFormatChart: typeof import("../components/Dashboard/HRM/EmployeeWorkFormatChart.vue")['default']
export const DashboardHRMNewEmployees: typeof import("../components/Dashboard/HRM/NewEmployees.vue")['default']
export const DashboardHRMResignedEmployees: typeof import("../components/Dashboard/HRM/ResignedEmployees.vue")['default']
export const DashboardHRMTotalEmployees: typeof import("../components/Dashboard/HRM/TotalEmployees.vue")['default']
export const DashboardHRMWelcomeBack: typeof import("../components/Dashboard/HRM/WelcomeBack.vue")['default']
export const DashboardHelpDeskCongratulations: typeof import("../components/Dashboard/HelpDesk/Congratulations.vue")['default']
export const DashboardHelpDeskCustomerSatisfactionChart: typeof import("../components/Dashboard/HelpDesk/CustomerSatisfactionChart.vue")['default']
export const DashboardHelpDeskNewAndSolvedTicketsChart: typeof import("../components/Dashboard/HelpDesk/NewAndSolvedTicketsChart.vue")['default']
export const DashboardHelpDeskPerformanceOfAgents: typeof import("../components/Dashboard/HelpDesk/PerformanceOfAgents.vue")['default']
export const DashboardHelpDeskRecentCustomerRatings: typeof import("../components/Dashboard/HelpDesk/RecentCustomerRatings.vue")['default']
export const DashboardHelpDeskResponseTimeChart: typeof import("../components/Dashboard/HelpDesk/ResponseTimeChart.vue")['default']
export const DashboardHelpDeskSupportOverviewChart: typeof import("../components/Dashboard/HelpDesk/SupportOverviewChart.vue")['default']
export const DashboardHelpDeskTicketsDueChart: typeof import("../components/Dashboard/HelpDesk/TicketsDueChart.vue")['default']
export const DashboardHelpDeskTicketsInProgressChart: typeof import("../components/Dashboard/HelpDesk/TicketsInProgressChart.vue")['default']
export const DashboardHelpDeskTicketsNewOpenChart: typeof import("../components/Dashboard/HelpDesk/TicketsNewOpenChart.vue")['default']
export const DashboardHelpDeskTicketsResolvedChart: typeof import("../components/Dashboard/HelpDesk/TicketsResolvedChart.vue")['default']
export const DashboardHelpDeskTicketsStatusChart: typeof import("../components/Dashboard/HelpDesk/TicketsStatusChart.vue")['default']
export const DashboardHelpDeskToDoList: typeof import("../components/Dashboard/HelpDesk/ToDoList.vue")['default']
export const DashboardHospitalBedOccupancyRateChart: typeof import("../components/Dashboard/Hospital/BedOccupancyRateChart.vue")['default']
export const DashboardHospitalCriticalPatientsChart: typeof import("../components/Dashboard/Hospital/CriticalPatientsChart.vue")['default']
export const DashboardHospitalDateRangePicker: typeof import("../components/Dashboard/Hospital/DateRangePicker.vue")['default']
export const DashboardHospitalEmergencyRoomVisitsChart: typeof import("../components/Dashboard/Hospital/EmergencyRoomVisitsChart.vue")['default']
export const DashboardHospitalEarnings: typeof import("../components/Dashboard/Hospital/HospitalEarnings.vue")['default']
export const DashboardHospitalOverallVisitorsChart: typeof import("../components/Dashboard/Hospital/OverallVisitorsChart.vue")['default']
export const DashboardHospitalPatientAdmissionsDischargesChart: typeof import("../components/Dashboard/Hospital/PatientAdmissionsDischargesChart.vue")['default']
export const DashboardHospitalPatientAppointments: typeof import("../components/Dashboard/Hospital/PatientAppointments.vue")['default']
export const DashboardHospitalPatientByAgeChart: typeof import("../components/Dashboard/Hospital/PatientByAgeChart.vue")['default']
export const DashboardHospitalPatientsChart: typeof import("../components/Dashboard/Hospital/PatientsChart.vue")['default']
export const DashboardHospitalScheduleAppointment: typeof import("../components/Dashboard/Hospital/ScheduleAppointment.vue")['default']
export const DashboardHospitalYourScheduleToday: typeof import("../components/Dashboard/Hospital/YourScheduleToday.vue")['default']
export const DashboardHotelCustomerReviews: typeof import("../components/Dashboard/Hotel/CustomerReviews.vue")['default']
export const DashboardHotelGuestActivityChart: typeof import("../components/Dashboard/Hotel/GuestActivityChart.vue")['default']
export const DashboardHotelPopularRooms: typeof import("../components/Dashboard/Hotel/PopularRooms.vue")['default']
export const DashboardHotelRecentBookings: typeof import("../components/Dashboard/Hotel/RecentBookings.vue")['default']
export const DashboardHotelRoomsAvailabilityChart: typeof import("../components/Dashboard/Hotel/RoomsAvailabilityChart.vue")['default']
export const DashboardHotelStatsCheckIn: typeof import("../components/Dashboard/Hotel/Stats/CheckIn.vue")['default']
export const DashboardHotelStatsCheckOut: typeof import("../components/Dashboard/Hotel/Stats/CheckOut.vue")['default']
export const DashboardHotelStatsNewBookings: typeof import("../components/Dashboard/Hotel/Stats/NewBookings.vue")['default']
export const DashboardHotelStats: typeof import("../components/Dashboard/Hotel/Stats/index.vue")['default']
export const DashboardHotelUpcomingVIPReservations: typeof import("../components/Dashboard/Hotel/UpcomingVIPReservations.vue")['default']
export const DashboardLMSCourses: typeof import("../components/Dashboard/LMS/Courses.vue")['default']
export const DashboardLMSCoursesSalesChart: typeof import("../components/Dashboard/LMS/CoursesSalesChart.vue")['default']
export const DashboardLMSEnrolledByCountries: typeof import("../components/Dashboard/LMS/EnrolledByCountries.vue")['default']
export const DashboardLMSGroupLessons: typeof import("../components/Dashboard/LMS/GroupLessons.vue")['default']
export const DashboardLMSOurTopCourses: typeof import("../components/Dashboard/LMS/OurTopCourses.vue")['default']
export const DashboardLMSStudentsInterestedTopicsChart: typeof import("../components/Dashboard/LMS/StudentsInterestedTopicsChart.vue")['default']
export const DashboardLMSStudentsProgress: typeof import("../components/Dashboard/LMS/StudentsProgress.vue")['default']
export const DashboardLMSTimeSpentChart: typeof import("../components/Dashboard/LMS/TimeSpentChart.vue")['default']
export const DashboardLMSTopInstructors: typeof import("../components/Dashboard/LMS/TopInstructors.vue")['default']
export const DashboardLMSTotalCourses: typeof import("../components/Dashboard/LMS/TotalCourses.vue")['default']
export const DashboardLMSTotalEnrolled: typeof import("../components/Dashboard/LMS/TotalEnrolled.vue")['default']
export const DashboardLMSTotalMentors: typeof import("../components/Dashboard/LMS/TotalMentors.vue")['default']
export const DashboardLMSWelcomeDashboard: typeof import("../components/Dashboard/LMS/WelcomeDashboard.vue")['default']
export const DashboardMarketingAvatarPreview: typeof import("../components/Dashboard/Marketing/AvatarPreview.vue")['default']
export const DashboardMarketingCampaignsContent: typeof import("../components/Dashboard/Marketing/CampaignsContent.vue")['default']
export const DashboardMarketingChannelsContent: typeof import("../components/Dashboard/Marketing/ChannelsContent.vue")['default']
export const DashboardMarketingCreateCampaignsModal: typeof import("../components/Dashboard/Marketing/CreateCampaignsModal.vue")['default']
export const DashboardMarketingExternalLinks: typeof import("../components/Dashboard/Marketing/ExternalLinks.vue")['default']
export const DashboardMarketingHighlightsContent: typeof import("../components/Dashboard/Marketing/HighlightsContent.vue")['default']
export const DashboardMarketingInstagramCampaignsChart: typeof import("../components/Dashboard/Marketing/InstagramCampaignsChart.vue")['default']
export const DashboardMarketingInstagramSubscriberChart: typeof import("../components/Dashboard/Marketing/InstagramSubscriberChart.vue")['default']
export const DashboardMarketingNewMarketingTool: typeof import("../components/Dashboard/Marketing/NewMarketingTool.vue")['default']
export const DashboardMarketingNewMobileApp: typeof import("../components/Dashboard/Marketing/NewMobileApp.vue")['default']
export const DashboardMarketingPerformanceOverviewChart: typeof import("../components/Dashboard/Marketing/PerformanceOverviewChart.vue")['default']
export const DashboardMarketingStatusContent: typeof import("../components/Dashboard/Marketing/StatusContent.vue")['default']
export const DashboardNFTActiveAuctions: typeof import("../components/Dashboard/NFT/ActiveAuctions.vue")['default']
export const DashboardNFTCreateNFT: typeof import("../components/Dashboard/NFT/CreateNFT.vue")['default']
export const DashboardNFTEthereumRateChart: typeof import("../components/Dashboard/NFT/EthereumRateChart.vue")['default']
export const DashboardNFTEthereumRateFiveChart: typeof import("../components/Dashboard/NFT/EthereumRateFiveChart.vue")['default']
export const DashboardNFTEthereumRateFourChart: typeof import("../components/Dashboard/NFT/EthereumRateFourChart.vue")['default']
export const DashboardNFTEthereumRateTab: typeof import("../components/Dashboard/NFT/EthereumRateTab.vue")['default']
export const DashboardNFTEthereumRateThreeChart: typeof import("../components/Dashboard/NFT/EthereumRateThreeChart.vue")['default']
export const DashboardNFTEthereumRateTwoChart: typeof import("../components/Dashboard/NFT/EthereumRateTwoChart.vue")['default']
export const DashboardNFTFeaturedNFTArtworks: typeof import("../components/Dashboard/NFT/FeaturedNFTArtworks.vue")['default']
export const DashboardNFTHistoryOfBids: typeof import("../components/Dashboard/NFT/HistoryOfBids.vue")['default']
export const DashboardNFTManageYourNFT: typeof import("../components/Dashboard/NFT/ManageYourNFT.vue")['default']
export const DashboardNFTMostPopularSellers: typeof import("../components/Dashboard/NFT/MostPopularSellers.vue")['default']
export const DashboardNFTSlideItem: typeof import("../components/Dashboard/NFT/NFTSlideItem.vue")['default']
export const DashboardNFTNewMobileApp: typeof import("../components/Dashboard/NFT/NewMobileApp.vue")['default']
export const DashboardNFTTopCollections: typeof import("../components/Dashboard/NFT/TopCollections.vue")['default']
export const DashboardNFTTopNFTs: typeof import("../components/Dashboard/NFT/TopNFTs.vue")['default']
export const DashboardNFTWorldwideTopCreators: typeof import("../components/Dashboard/NFT/WorldwideTopCreators.vue")['default']
export const DashboardPOSSystemCategoriesTab: typeof import("../components/Dashboard/POSSystem/CategoriesTab.vue")['default']
export const DashboardPOSSystemCustomerSegmentation: typeof import("../components/Dashboard/POSSystem/CustomerSegmentation.vue")['default']
export const DashboardPOSSystemOrderDetails: typeof import("../components/Dashboard/POSSystem/OrderDetails.vue")['default']
export const DashboardPOSSystemQuantityCounter: typeof import("../components/Dashboard/POSSystem/QuantityCounter.vue")['default']
export const DashboardPOSSystemSalesAnalyticsSalesByCategory: typeof import("../components/Dashboard/POSSystem/SalesAnalytics/SalesByCategory.vue")['default']
export const DashboardPOSSystemSalesAnalyticsSalesOverTime: typeof import("../components/Dashboard/POSSystem/SalesAnalytics/SalesOverTime.vue")['default']
export const DashboardPOSSystemSalesAnalytics: typeof import("../components/Dashboard/POSSystem/SalesAnalytics/index.vue")['default']
export const DashboardPOSSystemStats: typeof import("../components/Dashboard/POSSystem/Stats.vue")['default']
export const DashboardPodcastFeatured: typeof import("../components/Dashboard/Podcast/Featured.vue")['default']
export const DashboardPodcastListenerAnalyticsChart: typeof import("../components/Dashboard/Podcast/ListenerAnalyticsChart.vue")['default']
export const DashboardPodcastMostPopular: typeof import("../components/Dashboard/Podcast/MostPopular.vue")['default']
export const DashboardPodcastPlayer: typeof import("../components/Dashboard/Podcast/Player.vue")['default']
export const DashboardPodcastPopularHosts: typeof import("../components/Dashboard/Podcast/PopularHosts.vue")['default']
export const DashboardPodcastRecentlyPlayed: typeof import("../components/Dashboard/Podcast/RecentlyPlayed.vue")['default']
export const DashboardPodcastSalesByGenderChart: typeof import("../components/Dashboard/Podcast/SalesByGenderChart.vue")['default']
export const DashboardPodcastTodayEarningsChart: typeof import("../components/Dashboard/Podcast/TodayEarningsChart.vue")['default']
export const DashboardPodcastTopPodcasts: typeof import("../components/Dashboard/Podcast/TopPodcasts.vue")['default']
export const DashboardPodcastUpcomingEpisodes: typeof import("../components/Dashboard/Podcast/UpcomingEpisodes.vue")['default']
export const DashboardProjectManagementAllProjects: typeof import("../components/Dashboard/ProjectManagement/AllProjects.vue")['default']
export const DashboardProjectManagementMyTasks: typeof import("../components/Dashboard/ProjectManagement/MyTasks.vue")['default']
export const DashboardProjectManagementProjectsAnalysisChart: typeof import("../components/Dashboard/ProjectManagement/ProjectsAnalysisChart.vue")['default']
export const DashboardProjectManagementProjectsOverview: typeof import("../components/Dashboard/ProjectManagement/ProjectsOverview.vue")['default']
export const DashboardProjectManagementProjectsProgressChart: typeof import("../components/Dashboard/ProjectManagement/ProjectsProgressChart.vue")['default']
export const DashboardProjectManagementProjectsRoadmapChart: typeof import("../components/Dashboard/ProjectManagement/ProjectsRoadmapChart.vue")['default']
export const DashboardProjectManagementTasksOverviewChart: typeof import("../components/Dashboard/ProjectManagement/TasksOverviewChart.vue")['default']
export const DashboardProjectManagementTeamMembers: typeof import("../components/Dashboard/ProjectManagement/TeamMembers.vue")['default']
export const DashboardProjectManagementToDoList: typeof import("../components/Dashboard/ProjectManagement/ToDoList.vue")['default']
export const DashboardProjectManagementWorkingSchedule: typeof import("../components/Dashboard/ProjectManagement/WorkingSchedule.vue")['default']
export const DashboardRealEstateActiveTotalProperty: typeof import("../components/Dashboard/RealEstate/ActiveTotalProperty.vue")['default']
export const DashboardRealEstateCustomerReviews: typeof import("../components/Dashboard/RealEstate/CustomerReviews.vue")['default']
export const DashboardRealEstateLatestTransaction: typeof import("../components/Dashboard/RealEstate/LatestTransaction.vue")['default']
export const DashboardRealEstateMostSalesLocation: typeof import("../components/Dashboard/RealEstate/MostSalesLocation.vue")['default']
export const DashboardRealEstateNewCustomers: typeof import("../components/Dashboard/RealEstate/NewCustomers.vue")['default']
export const DashboardRealEstateNewListingsSoldPropertiesChart: typeof import("../components/Dashboard/RealEstate/NewListingsSoldPropertiesChart.vue")['default']
export const DashboardRealEstatePropertiesForRentChart: typeof import("../components/Dashboard/RealEstate/PropertiesForRentChart.vue")['default']
export const DashboardRealEstatePropertiesForSaleChart: typeof import("../components/Dashboard/RealEstate/PropertiesForSaleChart.vue")['default']
export const DashboardRealEstateRecentProperty: typeof import("../components/Dashboard/RealEstate/RecentProperty.vue")['default']
export const DashboardRealEstateRentalIncomeChart: typeof import("../components/Dashboard/RealEstate/RentalIncomeChart.vue")['default']
export const DashboardRealEstateRevenueChart: typeof import("../components/Dashboard/RealEstate/RevenueChart.vue")['default']
export const DashboardRealEstateSocialSearchChart: typeof import("../components/Dashboard/RealEstate/SocialSearchChart.vue")['default']
export const DashboardRealEstateTopProperty: typeof import("../components/Dashboard/RealEstate/TopProperty.vue")['default']
export const DashboardRealEstateAgentClientRatings: typeof import("../components/Dashboard/RealEstateAgent/ClientRatings.vue")['default']
export const DashboardRealEstateAgentDownloadApp: typeof import("../components/Dashboard/RealEstateAgent/DownloadApp.vue")['default']
export const DashboardRealEstateAgentLatestTransactions: typeof import("../components/Dashboard/RealEstateAgent/LatestTransactions.vue")['default']
export const DashboardRealEstateAgentMyFeaturedListings: typeof import("../components/Dashboard/RealEstateAgent/MyFeaturedListings.vue")['default']
export const DashboardRealEstateAgentRecentClients: typeof import("../components/Dashboard/RealEstateAgent/RecentClients.vue")['default']
export const DashboardRealEstateAgentRevenueGoalProgress: typeof import("../components/Dashboard/RealEstateAgent/RevenueGoalProgress.vue")['default']
export const DashboardRealEstateAgentSalesByCountry: typeof import("../components/Dashboard/RealEstateAgent/SalesByCountry.vue")['default']
export const DashboardRealEstateAgentStats: typeof import("../components/Dashboard/RealEstateAgent/Stats.vue")['default']
export const DashboardRealEstateAgentTopChannels: typeof import("../components/Dashboard/RealEstateAgent/TopChannels.vue")['default']
export const DashboardRealEstateAgentTotalRevenueChart: typeof import("../components/Dashboard/RealEstateAgent/TotalRevenueChart.vue")['default']
export const DashboardRealEstateAgentWelcomeRealEstateAgent: typeof import("../components/Dashboard/RealEstateAgent/WelcomeRealEstateAgent.vue")['default']
export const DashboardRestaurantCustomerRatings: typeof import("../components/Dashboard/Restaurant/CustomerRatings.vue")['default']
export const DashboardRestaurantExpense: typeof import("../components/Dashboard/Restaurant/Expense.vue")['default']
export const DashboardRestaurantLowStockAlerts: typeof import("../components/Dashboard/Restaurant/LowStockAlerts.vue")['default']
export const DashboardRestaurantOrderSummaryChart: typeof import("../components/Dashboard/Restaurant/OrderSummaryChart.vue")['default']
export const DashboardRestaurantPendingOrdersChart: typeof import("../components/Dashboard/Restaurant/PendingOrdersChart.vue")['default']
export const DashboardRestaurantRecentOrdersList: typeof import("../components/Dashboard/Restaurant/RecentOrdersList.vue")['default']
export const DashboardRestaurantStatsToday: typeof import("../components/Dashboard/Restaurant/RestaurantStatsToday.vue")['default']
export const DashboardRestaurantRevenue: typeof import("../components/Dashboard/Restaurant/Revenue.vue")['default']
export const DashboardRestaurantRevenueByBranches: typeof import("../components/Dashboard/Restaurant/RevenueByBranches.vue")['default']
export const DashboardRestaurantRevenueExpenseChart: typeof import("../components/Dashboard/Restaurant/RevenueExpenseChart.vue")['default']
export const DashboardRestaurantStaffPerformanceScores: typeof import("../components/Dashboard/Restaurant/StaffPerformanceScores.vue")['default']
export const DashboardRestaurantTickets: typeof import("../components/Dashboard/Restaurant/Tickets.vue")['default']
export const DashboardRestaurantTopSellingItems: typeof import("../components/Dashboard/Restaurant/TopSellingItems.vue")['default']
export const DashboardRestaurantTotalOrdersChart: typeof import("../components/Dashboard/Restaurant/TotalOrdersChart.vue")['default']
export const DashboardSaaSActiveUserChart: typeof import("../components/Dashboard/SaaS/ActiveUserChart.vue")['default']
export const DashboardSaaSActiveUsers: typeof import("../components/Dashboard/SaaS/ActiveUsers.vue")['default']
export const DashboardSaaSActiveUsersChart: typeof import("../components/Dashboard/SaaS/ActiveUsersChart.vue")['default']
export const DashboardSaaSConversionChart: typeof import("../components/Dashboard/SaaS/ConversionChart.vue")['default']
export const DashboardSaaSGrossRevenueChart: typeof import("../components/Dashboard/SaaS/GrossRevenueChart.vue")['default']
export const DashboardSaaSLatestTransaction: typeof import("../components/Dashboard/SaaS/LatestTransaction.vue")['default']
export const DashboardSaaSPaymentChart: typeof import("../components/Dashboard/SaaS/PaymentChart.vue")['default']
export const DashboardSaaSProductTradeConditionChart: typeof import("../components/Dashboard/SaaS/ProductTradeConditionChart.vue")['default']
export const DashboardSaaSRevenueChart: typeof import("../components/Dashboard/SaaS/RevenueChart.vue")['default']
export const DashboardSaaSSalesByCountry: typeof import("../components/Dashboard/SaaS/SalesByCountry.vue")['default']
export const DashboardSaaSTopRefers: typeof import("../components/Dashboard/SaaS/TopRefers.vue")['default']
export const DashboardSaaSUpgradePlans: typeof import("../components/Dashboard/SaaS/UpgradePlans.vue")['default']
export const DashboardSalesGrossEarningsChart: typeof import("../components/Dashboard/Sales/GrossEarningsChart.vue")['default']
export const DashboardSalesRealTimeSalesChart: typeof import("../components/Dashboard/Sales/RealTimeSalesChart.vue")['default']
export const DashboardSalesRecentEarningsChart: typeof import("../components/Dashboard/Sales/RecentEarningsChart.vue")['default']
export const DashboardSalesRecentOrders: typeof import("../components/Dashboard/Sales/RecentOrders.vue")['default']
export const DashboardSalesByLocations: typeof import("../components/Dashboard/Sales/SalesByLocations.vue")['default']
export const DashboardSalesOverviewChart: typeof import("../components/Dashboard/Sales/SalesOverviewChart.vue")['default']
export const DashboardSalesTotalOrdersChart: typeof import("../components/Dashboard/Sales/TotalOrdersChart.vue")['default']
export const DashboardSalesTotalProfitChart: typeof import("../components/Dashboard/Sales/TotalProfitChart.vue")['default']
export const DashboardSalesTotalRevenueChart: typeof import("../components/Dashboard/Sales/TotalRevenueChart.vue")['default']
export const DashboardSalesTotalSalesChart: typeof import("../components/Dashboard/Sales/TotalSalesChart.vue")['default']
export const DashboardSalesTransactionHistory: typeof import("../components/Dashboard/Sales/TransactionHistory.vue")['default']
export const DashboardSalesWelcomeBack: typeof import("../components/Dashboard/Sales/WelcomeBack.vue")['default']
export const DashboardSchoolAttendanceAnalyticsChart: typeof import("../components/Dashboard/School/AttendanceAnalyticsChart.vue")['default']
export const DashboardSchoolNewAdmissionsChart: typeof import("../components/Dashboard/School/NewAdmissionsChart.vue")['default']
export const DashboardSchoolNoticeBoard: typeof import("../components/Dashboard/School/NoticeBoard.vue")['default']
export const DashboardSchoolOverview: typeof import("../components/Dashboard/School/SchoolOverview.vue")['default']
export const DashboardSchoolStatsAttendanceToday: typeof import("../components/Dashboard/School/Stats/AttendanceToday.vue")['default']
export const DashboardSchoolStatsTotalStudents: typeof import("../components/Dashboard/School/Stats/TotalStudents.vue")['default']
export const DashboardSchoolStatsTotalTeachers: typeof import("../components/Dashboard/School/Stats/TotalTeachers.vue")['default']
export const DashboardSchoolStats: typeof import("../components/Dashboard/School/Stats/index.vue")['default']
export const DashboardSchoolStudentsList: typeof import("../components/Dashboard/School/StudentsList.vue")['default']
export const DashboardSchoolStudentsOverviewChart: typeof import("../components/Dashboard/School/StudentsOverviewChart.vue")['default']
export const DashboardSchoolTeachers: typeof import("../components/Dashboard/School/Teachers.vue")['default']
export const DashboardSchoolUpcomingEvents: typeof import("../components/Dashboard/School/UpcomingEvents.vue")['default']
export const DashboardShipmentAverageDeliveryTimeChart: typeof import("../components/Dashboard/Shipment/AverageDeliveryTimeChart.vue")['default']
export const DashboardShipmentChatContent: typeof import("../components/Dashboard/Shipment/ChatContent.vue")['default']
export const DashboardShipmentLiveShipmentStatusChart: typeof import("../components/Dashboard/Shipment/LiveShipmentStatusChart.vue")['default']
export const DashboardShipmentOnTimeDeliveryChart: typeof import("../components/Dashboard/Shipment/OnTimeDeliveryChart.vue")['default']
export const DashboardShipmentDeliveredChart: typeof import("../components/Dashboard/Shipment/ShipmentDeliveredChart.vue")['default']
export const DashboardShipmentList: typeof import("../components/Dashboard/Shipment/ShipmentList.vue")['default']
export const DashboardShipmentToTopCountries: typeof import("../components/Dashboard/Shipment/ShipmentToTopCountries.vue")['default']
export const DashboardShipmentTodaysShipmentsChart: typeof import("../components/Dashboard/Shipment/TodaysShipmentsChart.vue")['default']
export const DashboardShipmentTopShippingMethodsChart: typeof import("../components/Dashboard/Shipment/TopShippingMethodsChart.vue")['default']
export const DashboardShipmentTotalCustomer: typeof import("../components/Dashboard/Shipment/TotalCustomer.vue")['default']
export const DashboardShipmentTotalIncome: typeof import("../components/Dashboard/Shipment/TotalIncome.vue")['default']
export const DashboardShipmentTotalOrder: typeof import("../components/Dashboard/Shipment/TotalOrder.vue")['default']
export const DashboardShipmentTotalShipment: typeof import("../components/Dashboard/Shipment/TotalShipment.vue")['default']
export const DashboardShipmentTrackingOrder: typeof import("../components/Dashboard/Shipment/TrackingOrder.vue")['default']
export const DashboardSocialMediaFacebookCampaignOverviewChart: typeof import("../components/Dashboard/SocialMedia/FacebookCampaignOverviewChart.vue")['default']
export const DashboardSocialMediaFacebookFollowers: typeof import("../components/Dashboard/SocialMedia/FacebookFollowers.vue")['default']
export const DashboardSocialMediaFollowersByGenderChart: typeof import("../components/Dashboard/SocialMedia/FollowersByGenderChart.vue")['default']
export const DashboardSocialMediaInstagramFollowers: typeof import("../components/Dashboard/SocialMedia/InstagramFollowers.vue")['default']
export const DashboardSocialMediaLinkedInFollowers: typeof import("../components/Dashboard/SocialMedia/LinkedInFollowers.vue")['default']
export const DashboardSocialMediaLinkedInNetFollowersChart: typeof import("../components/Dashboard/SocialMedia/LinkedInNetFollowersChart.vue")['default']
export const DashboardSocialMediaRecentInstagramFollowers: typeof import("../components/Dashboard/SocialMedia/RecentInstagramFollowers.vue")['default']
export const DashboardSocialMediaSuggestions: typeof import("../components/Dashboard/SocialMedia/Suggestions.vue")['default']
export const DashboardSocialMediaTikTokFollowers: typeof import("../components/Dashboard/SocialMedia/TikTokFollowers.vue")['default']
export const DashboardSocialMediaUpgradePlan: typeof import("../components/Dashboard/SocialMedia/UpgradePlan.vue")['default']
export const DashboardSocialMediaXFollowers: typeof import("../components/Dashboard/SocialMedia/XFollowers.vue")['default']
export const DashboardSocialMediaYouTubeSubscribers: typeof import("../components/Dashboard/SocialMedia/YouTubeSubscribers.vue")['default']
export const DashboardStoreAnalysisCustomerVisits: typeof import("../components/Dashboard/StoreAnalysis/CustomerVisits.vue")['default']
export const DashboardStoreAnalysisGrossRevenue: typeof import("../components/Dashboard/StoreAnalysis/GrossRevenue.vue")['default']
export const DashboardStoreAnalysisRecentSales: typeof import("../components/Dashboard/StoreAnalysis/RecentSales.vue")['default']
export const DashboardStoreAnalysisSAWelcome: typeof import("../components/Dashboard/StoreAnalysis/SAWelcome.vue")['default']
export const DashboardStoreAnalysisSalesByCategoryChart: typeof import("../components/Dashboard/StoreAnalysis/SalesByCategoryChart.vue")['default']
export const DashboardStoreAnalysisSalesByGenderChart: typeof import("../components/Dashboard/StoreAnalysis/SalesByGenderChart.vue")['default']
export const DashboardStoreAnalysisSalesThisMonthChart: typeof import("../components/Dashboard/StoreAnalysis/SalesThisMonthChart.vue")['default']
export const DashboardStoreAnalysisStats: typeof import("../components/Dashboard/StoreAnalysis/Stats.vue")['default']
export const DashboardStoreAnalysisStockAlerts: typeof import("../components/Dashboard/StoreAnalysis/StockAlerts.vue")['default']
export const DashboardStoreAnalysisTopSellingProducts: typeof import("../components/Dashboard/StoreAnalysis/TopSellingProducts.vue")['default']
export const DashboardECommerceOrderSummaryChart: typeof import("../components/Dashboard/eCommerce/OrderSummaryChart.vue")['default']
export const DashboardECommerceRecentOrders: typeof import("../components/Dashboard/eCommerce/RecentOrders.vue")['default']
export const DashboardECommerceRecentTransactions: typeof import("../components/Dashboard/eCommerce/RecentTransactions.vue")['default']
export const DashboardECommerceReturningCustomerRateChart: typeof import("../components/Dashboard/eCommerce/ReturningCustomerRateChart.vue")['default']
export const DashboardECommerceSalesByLocations: typeof import("../components/Dashboard/eCommerce/SalesByLocations.vue")['default']
export const DashboardECommerceTopSellingProducts: typeof import("../components/Dashboard/eCommerce/TopSellingProducts.vue")['default']
export const DashboardECommerceTotalCustomersChart: typeof import("../components/Dashboard/eCommerce/TotalCustomersChart.vue")['default']
export const DashboardECommerceTotalOrdersChart: typeof import("../components/Dashboard/eCommerce/TotalOrdersChart.vue")['default']
export const DashboardECommerceTotalRevenueChart: typeof import("../components/Dashboard/eCommerce/TotalRevenueChart.vue")['default']
export const DashboardECommerceTotalSalesChart: typeof import("../components/Dashboard/eCommerce/TotalSalesChart.vue")['default']
export const DashboardECommerceWelcomeDashboard: typeof import("../components/Dashboard/eCommerce/WelcomeDashboard.vue")['default']
export const FrontPagesCommonBackToUp: typeof import("../components/FrontPages/Common/BackToUp.vue")['default']
export const FrontPagesCommonCTA: typeof import("../components/FrontPages/Common/CTA.vue")['default']
export const FrontPagesCommonContactUs: typeof import("../components/FrontPages/Common/ContactUs.vue")['default']
export const FrontPagesCommonCopyRight: typeof import("../components/FrontPages/Common/CopyRight.vue")['default']
export const FrontPagesCommonFAQ: typeof import("../components/FrontPages/Common/FAQ.vue")['default']
export const FrontPagesCommonFooter: typeof import("../components/FrontPages/Common/Footer.vue")['default']
export const FrontPagesCommonKeyFeatures: typeof import("../components/FrontPages/Common/KeyFeatures.vue")['default']
export const FrontPagesCommonNavbar: typeof import("../components/FrontPages/Common/Navbar.vue")['default']
export const FrontPagesCommonOurTeam: typeof import("../components/FrontPages/Common/OurTeam.vue")['default']
export const FrontPagesCommonPageTitle: typeof import("../components/FrontPages/Common/PageTitle.vue")['default']
export const FrontPagesHomeBanner: typeof import("../components/FrontPages/Home/Banner.vue")['default']
export const FrontPagesHomeTailorYourDashboard: typeof import("../components/FrontPages/Home/TailorYourDashboard.vue")['default']
export const FrontPagesHomeTestimonials: typeof import("../components/FrontPages/Home/Testimonials.vue")['default']
export const LayoutAddNewCardModal: typeof import("../components/Layout/AddNewCardModal.vue")['default']
export const LayoutAddNewCategorieModal: typeof import("../components/Layout/AddNewCategorieModal.vue")['default']
export const LayoutAddNewContactModal: typeof import("../components/Layout/AddNewContactModal.vue")['default']
export const LayoutAddNewCustomerModal: typeof import("../components/Layout/AddNewCustomerModal.vue")['default']
export const LayoutAddNewDealsModal: typeof import("../components/Layout/AddNewDealsModal.vue")['default']
export const LayoutAddNewFileModal: typeof import("../components/Layout/AddNewFileModal.vue")['default']
export const LayoutAddNewInstructorsModal: typeof import("../components/Layout/AddNewInstructorsModal.vue")['default']
export const LayoutAddNewLabelModal: typeof import("../components/Layout/AddNewLabelModal.vue")['default']
export const LayoutAddNewLeadModal: typeof import("../components/Layout/AddNewLeadModal.vue")['default']
export const LayoutAddNewOrderModal: typeof import("../components/Layout/AddNewOrderModal.vue")['default']
export const LayoutAddNewUserModal: typeof import("../components/Layout/AddNewUserModal.vue")['default']
export const LayoutCreateTaskModal: typeof import("../components/Layout/CreateTaskModal.vue")['default']
export const LayoutLeftSidebar: typeof import("../components/Layout/LeftSidebar/index.vue")['default']
export const LayoutMainFooter: typeof import("../components/Layout/MainFooter.vue")['default']
export const LayoutPreloader: typeof import("../components/Layout/Preloader.vue")['default']
export const LayoutSettingsSidebarCardStyleBG: typeof import("../components/Layout/SettingsSidebar/CardStyleBG.vue")['default']
export const LayoutSettingsSidebarCardStyleRadius: typeof import("../components/Layout/SettingsSidebar/CardStyleRadius.vue")['default']
export const LayoutSettingsSidebarContainerStyleBtn: typeof import("../components/Layout/SettingsSidebar/ContainerStyleBtn.vue")['default']
export const LayoutSettingsSidebarHorizontalLayout: typeof import("../components/Layout/SettingsSidebar/HorizontalLayout.vue")['default']
export const LayoutSettingsSidebarOnlyFooterDark: typeof import("../components/Layout/SettingsSidebar/OnlyFooterDark.vue")['default']
export const LayoutSettingsSidebarOnlyHeaderDark: typeof import("../components/Layout/SettingsSidebar/OnlyHeaderDark.vue")['default']
export const LayoutSettingsSidebarOnlySidebarDark: typeof import("../components/Layout/SettingsSidebar/OnlySidebarDark.vue")['default']
export const LayoutSettingsSidebarRTLModeSwitch: typeof import("../components/Layout/SettingsSidebar/RTLModeSwitch.vue")['default']
export const LayoutSettingsSidebar: typeof import("../components/Layout/SettingsSidebar/index.vue")['default']
export const LayoutTopHeaderAdminProfile: typeof import("../components/Layout/TopHeader/AdminProfile.vue")['default']
export const LayoutTopHeaderDarkSwtichBtn: typeof import("../components/Layout/TopHeader/DarkSwtichBtn.vue")['default']
export const LayoutTopHeaderLanguageMenu: typeof import("../components/Layout/TopHeader/LanguageMenu.vue")['default']
export const LayoutTopHeaderNavbar: typeof import("../components/Layout/TopHeader/Navbar.vue")['default']
export const LayoutTopHeaderNotificationsLists: typeof import("../components/Layout/TopHeader/NotificationsLists.vue")['default']
export const LayoutTopHeaderSearchFrom: typeof import("../components/Layout/TopHeader/SearchFrom.vue")['default']
export const LayoutTopHeaderSettingsBtn: typeof import("../components/Layout/TopHeader/SettingsBtn.vue")['default']
export const LayoutTopHeaderToggleFullscreenBtn: typeof import("../components/Layout/TopHeader/ToggleFullscreenBtn.vue")['default']
export const LayoutTopHeaderWebApps: typeof import("../components/Layout/TopHeader/WebApps.vue")['default']
export const LayoutTopHeader: typeof import("../components/Layout/TopHeader/index.vue")['default']
export const ModulesAuthenticationConfirmMail: typeof import("../components/Modules/Authentication/ConfirmMail/index.vue")['default']
export const ModulesAuthenticationForgetPassword: typeof import("../components/Modules/Authentication/ForgetPassword/index.vue")['default']
export const ModulesAuthenticationLockScreen: typeof import("../components/Modules/Authentication/LockScreen/index.vue")['default']
export const ModulesAuthenticationLogOut: typeof import("../components/Modules/Authentication/LogOut/index.vue")['default']
export const ModulesAuthenticationLogin: typeof import("../components/Modules/Authentication/Login/index.vue")['default']
export const ModulesAuthenticationRegister: typeof import("../components/Modules/Authentication/Register/index.vue")['default']
export const ModulesAuthenticationResetPassword: typeof import("../components/Modules/Authentication/ResetPassword/index.vue")['default']
export const ModulesExtraPagesAnimation: typeof import("../components/Modules/ExtraPages/Animation/index.vue")['default']
export const ModulesExtraPagesCheckRadio: typeof import("../components/Modules/ExtraPages/CheckRadio/index.vue")['default']
export const ModulesExtraPagesClipBoard: typeof import("../components/Modules/ExtraPages/ClipBoard/index.vue")['default']
export const ModulesExtraPagesDragDrop: typeof import("../components/Modules/ExtraPages/DragDrop/index.vue")['default']
export const ModulesExtraPagesFAQ: typeof import("../components/Modules/ExtraPages/FAQ/index.vue")['default']
export const ModulesExtraPagesGallery: typeof import("../components/Modules/ExtraPages/Gallery/index.vue")['default']
export const ModulesExtraPagesPricingStyleOne: typeof import("../components/Modules/ExtraPages/Pricing/PricingStyleOne.vue")['default']
export const ModulesExtraPagesPricingStyleThree: typeof import("../components/Modules/ExtraPages/Pricing/PricingStyleThree.vue")['default']
export const ModulesExtraPagesPricingStyleTwo: typeof import("../components/Modules/ExtraPages/Pricing/PricingStyleTwo.vue")['default']
export const ModulesExtraPagesPricing: typeof import("../components/Modules/ExtraPages/Pricing/index.vue")['default']
export const ModulesExtraPagesRangeSlider: typeof import("../components/Modules/ExtraPages/RangeSlider/index.vue")['default']
export const ModulesExtraPagesRatingsInteractiveRating: typeof import("../components/Modules/ExtraPages/Ratings/InteractiveRating.vue")['default']
export const ModulesExtraPagesRatingsRTLSupport: typeof import("../components/Modules/ExtraPages/Ratings/RTLSupport.vue")['default']
export const ModulesExtraPagesRatingsReadOnlyPresetValue: typeof import("../components/Modules/ExtraPages/Ratings/ReadOnlyPresetValue.vue")['default']
export const ModulesExtraPagesRatingsSettingGettingValues: typeof import("../components/Modules/ExtraPages/Ratings/SettingGettingValues.vue")['default']
export const ModulesExtraPagesRatings: typeof import("../components/Modules/ExtraPages/Ratings/index.vue")['default']
export const ModulesExtraPagesScrollbar: typeof import("../components/Modules/ExtraPages/Scrollbar/index.vue")['default']
export const ModulesExtraPagesSearch: typeof import("../components/Modules/ExtraPages/Search/index.vue")['default']
export const ModulesExtraPagesSelect: typeof import("../components/Modules/ExtraPages/Select/index.vue")['default']
export const ModulesExtraPagesTimelineAdvancedTimeline: typeof import("../components/Modules/ExtraPages/Timeline/AdvancedTimeline.vue")['default']
export const ModulesExtraPagesTimelineBasicTimeline: typeof import("../components/Modules/ExtraPages/Timeline/BasicTimeline.vue")['default']
export const ModulesExtraPagesTimeline: typeof import("../components/Modules/ExtraPages/Timeline/index.vue")['default']
export const ModulesExtraPagesToasts: typeof import("../components/Modules/ExtraPages/Toasts/index.vue")['default']
export const ModulesExtraPagesTypography: typeof import("../components/Modules/ExtraPages/Typography/index.vue")['default']
export const ModulesFormsAdvancedElementsQuantityCounter: typeof import("../components/Modules/Forms/AdvancedElements/QuantityCounter.vue")['default']
export const ModulesFormsAdvancedElementsQuantityCounterTwo: typeof import("../components/Modules/Forms/AdvancedElements/QuantityCounterTwo.vue")['default']
export const ModulesFormsAdvancedElements: typeof import("../components/Modules/Forms/AdvancedElements/index.vue")['default']
export const ModulesFormsBasicElements: typeof import("../components/Modules/Forms/BasicElements/index.vue")['default']
export const ModulesFormsEditors: typeof import("../components/Modules/Forms/Editors/index.vue")['default']
export const ModulesFormsFileUpload: typeof import("../components/Modules/Forms/FileUpload/index.vue")['default']
export const ModulesFormsValidation: typeof import("../components/Modules/Forms/Validation/index.vue")['default']
export const ModulesFormsWizard: typeof import("../components/Modules/Forms/Wizard/index.vue")['default']
export const ModulesGoogleMap: typeof import("../components/Modules/GoogleMap/index.vue")['default']
export const ModulesIconsFeatherIcon: typeof import("../components/Modules/Icons/FeatherIcon/index.vue")['default']
export const ModulesIconsMaterialSymbolsIcon: typeof import("../components/Modules/Icons/MaterialSymbolsIcon/index.vue")['default']
export const ModulesIconsRemixIcon: typeof import("../components/Modules/Icons/RemixIcon/index.vue")['default']
export const ModulesInternalError: typeof import("../components/Modules/InternalError/index.vue")['default']
export const ModulesMembers: typeof import("../components/Modules/Members/index.vue")['default']
export const ModulesNotification: typeof import("../components/Modules/Notification/index.vue")['default']
export const ModulesTablesBasicTable: typeof import("../components/Modules/Tables/BasicTable/index.vue")['default']
export const ModulesTablesDataTable: typeof import("../components/Modules/Tables/DataTable/index.vue")['default']
export const ModulesUIElementsAccordions: typeof import("../components/Modules/UIElements/Accordions/index.vue")['default']
export const ModulesUIElementsAlertsAdditionalContentAlerts: typeof import("../components/Modules/UIElements/Alerts/AdditionalContentAlerts.vue")['default']
export const ModulesUIElementsAlertsWithIcon: typeof import("../components/Modules/UIElements/Alerts/AlertsWithIcon.vue")['default']
export const ModulesUIElementsAlertsBGAlertsWithIcon: typeof import("../components/Modules/UIElements/Alerts/BGAlertsWithIcon.vue")['default']
export const ModulesUIElementsAlertsBGBasicAlerts: typeof import("../components/Modules/UIElements/Alerts/BGBasicAlerts.vue")['default']
export const ModulesUIElementsAlertsBGOutlineAlerts: typeof import("../components/Modules/UIElements/Alerts/BGOutlineAlerts.vue")['default']
export const ModulesUIElementsAlertsBasicAlerts: typeof import("../components/Modules/UIElements/Alerts/BasicAlerts.vue")['default']
export const ModulesUIElementsAlertsDismissingAlerts: typeof import("../components/Modules/UIElements/Alerts/DismissingAlerts.vue")['default']
export const ModulesUIElementsAlertsOutlineAlerts: typeof import("../components/Modules/UIElements/Alerts/OutlineAlerts.vue")['default']
export const ModulesUIElementsAlerts: typeof import("../components/Modules/UIElements/Alerts/index.vue")['default']
export const ModulesUIElementsAvatarSizeRoundedCircleExample: typeof import("../components/Modules/UIElements/Avatar/AvatarSizeRoundedCircleExample.vue")['default']
export const ModulesUIElementsAvatarSizeSimpleRoundedExample: typeof import("../components/Modules/UIElements/Avatar/AvatarSizeSimpleRoundedExample.vue")['default']
export const ModulesUIElementsAvatarGroupUserExample: typeof import("../components/Modules/UIElements/Avatar/GroupUserExample.vue")['default']
export const ModulesUIElementsAvatarSingleUserExample: typeof import("../components/Modules/UIElements/Avatar/SingleUserExample.vue")['default']
export const ModulesUIElementsAvatarSingleUserWithBadgeExample: typeof import("../components/Modules/UIElements/Avatar/SingleUserWithBadgeExample.vue")['default']
export const ModulesUIElementsAvatarTextAvatarSizeRoundedCircleExample: typeof import("../components/Modules/UIElements/Avatar/TextAvatarSizeRoundedCircleExample.vue")['default']
export const ModulesUIElementsAvatarTextAvatarSizeSimpleRoundedExample: typeof import("../components/Modules/UIElements/Avatar/TextAvatarSizeSimpleRoundedExample.vue")['default']
export const ModulesUIElementsAvatar: typeof import("../components/Modules/UIElements/Avatar/index.vue")['default']
export const ModulesUIElementsBadgesWithIcons: typeof import("../components/Modules/UIElements/Badges/BadgesWithIcons.vue")['default']
export const ModulesUIElementsBadgesDefaultBadges: typeof import("../components/Modules/UIElements/Badges/DefaultBadges.vue")['default']
export const ModulesUIElementsBadgesHeadingsBadges: typeof import("../components/Modules/UIElements/Badges/HeadingsBadges.vue")['default']
export const ModulesUIElementsBadgesOtherBadges: typeof import("../components/Modules/UIElements/Badges/OtherBadges.vue")['default']
export const ModulesUIElementsBadgesRoundedPillBadges: typeof import("../components/Modules/UIElements/Badges/RoundedPillBadges.vue")['default']
export const ModulesUIElementsBadgesRoundedPillBadgesTwo: typeof import("../components/Modules/UIElements/Badges/RoundedPillBadgesTwo.vue")['default']
export const ModulesUIElementsBadgesSoftBadges: typeof import("../components/Modules/UIElements/Badges/SoftBadges.vue")['default']
export const ModulesUIElementsBadges: typeof import("../components/Modules/UIElements/Badges/index.vue")['default']
export const ModulesUIElementsButtonsBlockButtons: typeof import("../components/Modules/UIElements/Buttons/BlockButtons.vue")['default']
export const ModulesUIElementsButtonsWithIcon: typeof import("../components/Modules/UIElements/Buttons/ButtonsWithIcon.vue")['default']
export const ModulesUIElementsButtonsDefaultButtons: typeof import("../components/Modules/UIElements/Buttons/DefaultButtons.vue")['default']
export const ModulesUIElementsButtonsOutlineButtons: typeof import("../components/Modules/UIElements/Buttons/OutlineButtons.vue")['default']
export const ModulesUIElementsButtonsOutlineRoundedButtons: typeof import("../components/Modules/UIElements/Buttons/OutlineRoundedButtons.vue")['default']
export const ModulesUIElementsButtonsRoundedButtons: typeof import("../components/Modules/UIElements/Buttons/RoundedButtons.vue")['default']
export const ModulesUIElementsButtonsSoftButtons: typeof import("../components/Modules/UIElements/Buttons/SoftButtons.vue")['default']
export const ModulesUIElementsButtons: typeof import("../components/Modules/UIElements/Buttons/index.vue")['default']
export const ModulesUIElementsCardsCardWithBgImage: typeof import("../components/Modules/UIElements/Cards/CardWithBgImage.vue")['default']
export const ModulesUIElementsCardsCardWithImage: typeof import("../components/Modules/UIElements/Cards/CardWithImage.vue")['default']
export const ModulesUIElementsCardsCardWithList: typeof import("../components/Modules/UIElements/Cards/CardWithList.vue")['default']
export const ModulesUIElementsCardsDefaultCard: typeof import("../components/Modules/UIElements/Cards/DefaultCard.vue")['default']
export const ModulesUIElementsCards: typeof import("../components/Modules/UIElements/Cards/index.vue")['default']
export const ModulesUIElementsCarouselsSlidesOnly: typeof import("../components/Modules/UIElements/Carousels/SlidesOnly.vue")['default']
export const ModulesUIElementsCarouselsSlidesWithControls: typeof import("../components/Modules/UIElements/Carousels/SlidesWithControls.vue")['default']
export const ModulesUIElementsCarousels: typeof import("../components/Modules/UIElements/Carousels/index.vue")['default']
export const ModulesUIElementsDateTimePicker: typeof import("../components/Modules/UIElements/DateTimePicker/index.vue")['default']
export const ModulesUIElementsDropdownsDropdownDefaultButtons: typeof import("../components/Modules/UIElements/Dropdowns/DropdownDefaultButtons.vue")['default']
export const ModulesUIElementsDropdowns: typeof import("../components/Modules/UIElements/Dropdowns/index.vue")['default']
export const ModulesUIElementsGrids: typeof import("../components/Modules/UIElements/Grids/index.vue")['default']
export const ModulesUIElementsImages: typeof import("../components/Modules/UIElements/Images/index.vue")['default']
export const ModulesUIElementsList: typeof import("../components/Modules/UIElements/List/index.vue")['default']
export const ModulesUIElementsModals: typeof import("../components/Modules/UIElements/Modals/index.vue")['default']
export const ModulesUIElementsNavs: typeof import("../components/Modules/UIElements/Navs/index.vue")['default']
export const ModulesUIElementsPaginations: typeof import("../components/Modules/UIElements/Paginations/index.vue")['default']
export const ModulesUIElementsPopoverTooltips: typeof import("../components/Modules/UIElements/PopoverTooltips/index.vue")['default']
export const ModulesUIElementsProgress: typeof import("../components/Modules/UIElements/Progress/index.vue")['default']
export const ModulesUIElementsSpinners: typeof import("../components/Modules/UIElements/Spinners/index.vue")['default']
export const ModulesUIElementsTabs: typeof import("../components/Modules/UIElements/Tabs/index.vue")['default']
export const ModulesUIElementsVideos: typeof import("../components/Modules/UIElements/Videos/index.vue")['default']
export const ModulesWidgetsAnnualProfitChart: typeof import("../components/Modules/Widgets/AnnualProfitChart.vue")['default']
export const ModulesWidgetsCoursesSalesChart: typeof import("../components/Modules/Widgets/CoursesSalesChart.vue")['default']
export const ModulesWidgetsInProgressChart: typeof import("../components/Modules/Widgets/InProgressChart.vue")['default']
export const ModulesWidgetsLeadConversionChart: typeof import("../components/Modules/Widgets/LeadConversionChart.vue")['default']
export const ModulesWidgetsOurTopCourses: typeof import("../components/Modules/Widgets/OurTopCourses.vue")['default']
export const ModulesWidgetsProjectsAnalysisChart: typeof import("../components/Modules/Widgets/ProjectsAnalysisChart.vue")['default']
export const ModulesWidgetsProjectsOverview: typeof import("../components/Modules/Widgets/ProjectsOverview.vue")['default']
export const ModulesWidgetsProjectsRoadmapChart: typeof import("../components/Modules/Widgets/ProjectsRoadmapChart.vue")['default']
export const ModulesWidgetsRevenueGrowthChart: typeof import("../components/Modules/Widgets/RevenueGrowthChart.vue")['default']
export const ModulesWidgetsTeamMembers: typeof import("../components/Modules/Widgets/TeamMembers.vue")['default']
export const ModulesWidgetsTicketsDueChart: typeof import("../components/Modules/Widgets/TicketsDueChart.vue")['default']
export const ModulesWidgetsTicketsNewOpenChart: typeof import("../components/Modules/Widgets/TicketsNewOpenChart.vue")['default']
export const ModulesWidgetsTicketsResolvedChart: typeof import("../components/Modules/Widgets/TicketsResolvedChart.vue")['default']
export const ModulesWidgetsTimeSpentChart: typeof import("../components/Modules/Widgets/TimeSpentChart.vue")['default']
export const ModulesWidgetsTotalCourses: typeof import("../components/Modules/Widgets/TotalCourses.vue")['default']
export const ModulesWidgetsTotalCustomersChart: typeof import("../components/Modules/Widgets/TotalCustomersChart.vue")['default']
export const ModulesWidgetsTotalEnrolled: typeof import("../components/Modules/Widgets/TotalEnrolled.vue")['default']
export const ModulesWidgetsTotalMentors: typeof import("../components/Modules/Widgets/TotalMentors.vue")['default']
export const ModulesWidgetsTotalOrdersChart: typeof import("../components/Modules/Widgets/TotalOrdersChart.vue")['default']
export const ModulesWidgetsTotalOrdersChartTwo: typeof import("../components/Modules/Widgets/TotalOrdersChartTwo.vue")['default']
export const ModulesWidgetsTotalRevenueChart: typeof import("../components/Modules/Widgets/TotalRevenueChart.vue")['default']
export const ModulesWidgetsWelcomeBack: typeof import("../components/Modules/Widgets/WelcomeBack.vue")['default']
export const ModulesWidgetsWorkingSchedule: typeof import("../components/Modules/Widgets/WorkingSchedule.vue")['default']
export const ModulesWidgets: typeof import("../components/Modules/Widgets/index.vue")['default']
export const OthersMyProfileAdditionalInformation: typeof import("../components/Others/MyProfile/AdditionalInformation.vue")['default']
export const OthersMyProfileInformation: typeof import("../components/Others/MyProfile/ProfileInformation.vue")['default']
export const OthersMyProfileIntro: typeof import("../components/Others/MyProfile/ProfileIntro.vue")['default']
export const OthersMyProfileProjectsAnalysisChart: typeof import("../components/Others/MyProfile/ProjectsAnalysisChart.vue")['default']
export const OthersMyProfileRecentActivity: typeof import("../components/Others/MyProfile/RecentActivity.vue")['default']
export const OthersMyProfileToDoList: typeof import("../components/Others/MyProfile/ToDoList.vue")['default']
export const OthersMyProfileTotalOrders: typeof import("../components/Others/MyProfile/TotalOrders.vue")['default']
export const OthersMyProfileTotalProjects: typeof import("../components/Others/MyProfile/TotalProjects.vue")['default']
export const OthersMyProfileTotalRevenue: typeof import("../components/Others/MyProfile/TotalRevenue.vue")['default']
export const OthersMyProfileWelcomeBack: typeof import("../components/Others/MyProfile/WelcomeBack.vue")['default']
export const OthersMyProfile: typeof import("../components/Others/MyProfile/index.vue")['default']
export const OthersSettingsAccountSettings: typeof import("../components/Others/Settings/AccountSettings/index.vue")['default']
export const OthersSettingsChangePassword: typeof import("../components/Others/Settings/ChangePassword/index.vue")['default']
export const OthersSettingsConnections: typeof import("../components/Others/Settings/Connections/index.vue")['default']
export const OthersSettingsPrivacyPolicy: typeof import("../components/Others/Settings/PrivacyPolicy/index.vue")['default']
export const OthersSettingsMenu: typeof import("../components/Others/Settings/SettingsMenu.vue")['default']
export const OthersSettingsTermsConditions: typeof import("../components/Others/Settings/TermsConditions/index.vue")['default']
export const PagesCRMContacts: typeof import("../components/Pages/CRM/Contacts/index.vue")['default']
export const PagesCRMCustomers: typeof import("../components/Pages/CRM/Customers/index.vue")['default']
export const PagesCRMDeals: typeof import("../components/Pages/CRM/Deals/index.vue")['default']
export const PagesCRMLeadsAnnualProfitChart: typeof import("../components/Pages/CRM/Leads/AnnualProfitChart.vue")['default']
export const PagesCRMLeadsLeadConversionChart: typeof import("../components/Pages/CRM/Leads/LeadConversionChart.vue")['default']
export const PagesCRMLeadsRevenueGrowthChart: typeof import("../components/Pages/CRM/Leads/RevenueGrowthChart.vue")['default']
export const PagesCRMLeadsTotalOrdersChart: typeof import("../components/Pages/CRM/Leads/TotalOrdersChart.vue")['default']
export const PagesCRMLeads: typeof import("../components/Pages/CRM/Leads/index.vue")['default']
export const PagesCryptoTraderCTWallet: typeof import("../components/Pages/CryptoTrader/CTWallet/index.vue")['default']
export const PagesCryptoTraderGainersLosers: typeof import("../components/Pages/CryptoTrader/GainersLosers/index.vue")['default']
export const PagesCryptoTraderTransactions: typeof import("../components/Pages/CryptoTrader/Transactions/index.vue")['default']
export const PagesDoctorAddPatient: typeof import("../components/Pages/Doctor/AddPatient/index.vue")['default']
export const PagesDoctorAppointmentsTodayAppointments: typeof import("../components/Pages/Doctor/Appointments/TodayAppointments.vue")['default']
export const PagesDoctorAppointmentsTodaySchedule: typeof import("../components/Pages/Doctor/Appointments/TodaySchedule.vue")['default']
export const PagesDoctorAppointments: typeof import("../components/Pages/Doctor/Appointments/index.vue")['default']
export const PagesDoctorPatientDetails: typeof import("../components/Pages/Doctor/PatientDetails/index.vue")['default']
export const PagesDoctorPatientsList: typeof import("../components/Pages/Doctor/PatientsList/index.vue")['default']
export const PagesDoctorPrescriptions: typeof import("../components/Pages/Doctor/Prescriptions/index.vue")['default']
export const PagesDoctorWritePrescription: typeof import("../components/Pages/Doctor/WritePrescription/index.vue")['default']
export const PagesEcommerceCartQuantityCounter: typeof import("../components/Pages/Ecommerce/Cart/QuantityCounter.vue")['default']
export const PagesEcommerceCart: typeof import("../components/Pages/Ecommerce/Cart/index.vue")['default']
export const PagesEcommerceCategories: typeof import("../components/Pages/Ecommerce/Categories/index.vue")['default']
export const PagesEcommerceCheckout: typeof import("../components/Pages/Ecommerce/Checkout/index.vue")['default']
export const PagesEcommerceCreateOrderBillingInformation: typeof import("../components/Pages/Ecommerce/CreateOrder/BillingInformation.vue")['default']
export const PagesEcommerceCreateOrderPaymentMethod: typeof import("../components/Pages/Ecommerce/CreateOrder/PaymentMethod.vue")['default']
export const PagesEcommerceCreateOrderYourOrder: typeof import("../components/Pages/Ecommerce/CreateOrder/YourOrder.vue")['default']
export const PagesEcommerceCreateOrder: typeof import("../components/Pages/Ecommerce/CreateOrder/index.vue")['default']
export const PagesEcommerceCreateProduct: typeof import("../components/Pages/Ecommerce/CreateProduct/index.vue")['default']
export const PagesEcommerceCreateSeller: typeof import("../components/Pages/Ecommerce/CreateSeller/index.vue")['default']
export const PagesEcommerceCustomerDetailsTransactionsHistory: typeof import("../components/Pages/Ecommerce/CustomerDetails/TransactionsHistory.vue")['default']
export const PagesEcommerceCustomerDetailsUserCard: typeof import("../components/Pages/Ecommerce/CustomerDetails/UserCard.vue")['default']
export const PagesEcommerceCustomerDetails: typeof import("../components/Pages/Ecommerce/CustomerDetails/index.vue")['default']
export const PagesEcommerceCustomers: typeof import("../components/Pages/Ecommerce/Customers/index.vue")['default']
export const PagesEcommerceEditProduct: typeof import("../components/Pages/Ecommerce/EditProduct/index.vue")['default']
export const PagesEcommerceOrderDetailsBillingDetails: typeof import("../components/Pages/Ecommerce/OrderDetails/BillingDetails.vue")['default']
export const PagesEcommerceOrderDetailsDeliveryDetails: typeof import("../components/Pages/Ecommerce/OrderDetails/DeliveryDetails.vue")['default']
export const PagesEcommerceOrderDetailsOrderSummary: typeof import("../components/Pages/Ecommerce/OrderDetails/OrderSummary.vue")['default']
export const PagesEcommerceOrderDetailsQuantityCounter: typeof import("../components/Pages/Ecommerce/OrderDetails/QuantityCounter.vue")['default']
export const PagesEcommerceOrderDetailsRecentOrders: typeof import("../components/Pages/Ecommerce/OrderDetails/RecentOrders.vue")['default']
export const PagesEcommerceOrderDetailsShippingDetails: typeof import("../components/Pages/Ecommerce/OrderDetails/ShippingDetails.vue")['default']
export const PagesEcommerceOrderDetailsTrackingID: typeof import("../components/Pages/Ecommerce/OrderDetails/TrackingID.vue")['default']
export const PagesEcommerceOrderDetails: typeof import("../components/Pages/Ecommerce/OrderDetails/index.vue")['default']
export const PagesEcommerceOrderTracking: typeof import("../components/Pages/Ecommerce/OrderTracking/index.vue")['default']
export const PagesEcommerceOrders: typeof import("../components/Pages/Ecommerce/Orders/index.vue")['default']
export const PagesEcommerceProductsDetailsTabs: typeof import("../components/Pages/Ecommerce/ProductsDetails/ProductsDetailsTabs.vue")['default']
export const PagesEcommerceProductsDetailsProductsFilter: typeof import("../components/Pages/Ecommerce/ProductsDetails/ProductsFilter.vue")['default']
export const PagesEcommerceProductsDetails: typeof import("../components/Pages/Ecommerce/ProductsDetails/index.vue")['default']
export const PagesEcommerceProductsGridProductsFilter: typeof import("../components/Pages/Ecommerce/ProductsGrid/ProductsFilter.vue")['default']
export const PagesEcommerceProductsGrid: typeof import("../components/Pages/Ecommerce/ProductsGrid/index.vue")['default']
export const PagesEcommerceProductsList: typeof import("../components/Pages/Ecommerce/ProductsList/index.vue")['default']
export const PagesEcommerceRefunds: typeof import("../components/Pages/Ecommerce/Refunds/index.vue")['default']
export const PagesEcommerceReviews: typeof import("../components/Pages/Ecommerce/Reviews/index.vue")['default']
export const PagesEcommerceSellerDetailsProductsList: typeof import("../components/Pages/Ecommerce/SellerDetails/ProductsList.vue")['default']
export const PagesEcommerceSellerDetailsRevenueChart: typeof import("../components/Pages/Ecommerce/SellerDetails/RevenueChart.vue")['default']
export const PagesEcommerceSellerDetailsSellerID: typeof import("../components/Pages/Ecommerce/SellerDetails/SellerID.vue")['default']
export const PagesEcommerceSellerDetailsSellerOverview: typeof import("../components/Pages/Ecommerce/SellerDetails/SellerOverview.vue")['default']
export const PagesEcommerceSellerDetails: typeof import("../components/Pages/Ecommerce/SellerDetails/index.vue")['default']
export const PagesEcommerceSellers: typeof import("../components/Pages/Ecommerce/Sellers/index.vue")['default']
export const PagesEventsCreateAnEvent: typeof import("../components/Pages/Events/CreateAnEvent/index.vue")['default']
export const PagesEventsEditAnEvent: typeof import("../components/Pages/Events/EditAnEvent/index.vue")['default']
export const PagesEventsEventDetailsAboutThisEvent: typeof import("../components/Pages/Events/EventDetails/AboutThisEvent.vue")['default']
export const PagesEventsEventDetailsAnnualConference: typeof import("../components/Pages/Events/EventDetails/AnnualConference.vue")['default']
export const PagesEventsEventDetailsEventInfo: typeof import("../components/Pages/Events/EventDetails/EventInfo.vue")['default']
export const PagesEventsEventDetailsSpeakerTopic: typeof import("../components/Pages/Events/EventDetails/SpeakerTopic.vue")['default']
export const PagesEventsEventDetails: typeof import("../components/Pages/Events/EventDetails/index.vue")['default']
export const PagesEventsEventsGrid: typeof import("../components/Pages/Events/EventsGrid/index.vue")['default']
export const PagesEventsEventsList: typeof import("../components/Pages/Events/EventsList/index.vue")['default']
export const PagesFinanceTransactionAddNewTransactionModal: typeof import("../components/Pages/Finance/Transaction/AddNewTransactionModal.vue")['default']
export const PagesFinanceTransaction: typeof import("../components/Pages/Finance/Transaction/index.vue")['default']
export const PagesFinanceWalletAddCardDetailModal: typeof import("../components/Pages/Finance/Wallet/AddCardDetailModal.vue")['default']
export const PagesFinanceWalletDebitCard: typeof import("../components/Pages/Finance/Wallet/DebitCard.vue")['default']
export const PagesFinanceWalletStaticChart: typeof import("../components/Pages/Finance/Wallet/StaticChart.vue")['default']
export const PagesFinanceWalletTotalExpenses: typeof import("../components/Pages/Finance/Wallet/TotalExpenses.vue")['default']
export const PagesFinanceWalletTotalIncome: typeof import("../components/Pages/Finance/Wallet/TotalIncome.vue")['default']
export const PagesFinanceWalletTransactionHistory: typeof import("../components/Pages/Finance/Wallet/TransactionHistory.vue")['default']
export const PagesFinanceWallet: typeof import("../components/Pages/Finance/Wallet/index.vue")['default']
export const PagesHelpDeskAgents: typeof import("../components/Pages/HelpDesk/Agents/index.vue")['default']
export const PagesHelpDeskReportsCustomerSatisfactionChart: typeof import("../components/Pages/HelpDesk/Reports/CustomerSatisfactionChart.vue")['default']
export const PagesHelpDeskReportsNewAndSolvedTicketsChart: typeof import("../components/Pages/HelpDesk/Reports/NewAndSolvedTicketsChart.vue")['default']
export const PagesHelpDeskReportsPerformanceOfAgents: typeof import("../components/Pages/HelpDesk/Reports/PerformanceOfAgents.vue")['default']
export const PagesHelpDeskReportsResponseTimeChart: typeof import("../components/Pages/HelpDesk/Reports/ResponseTimeChart.vue")['default']
export const PagesHelpDeskReportsTasksOverviewChart: typeof import("../components/Pages/HelpDesk/Reports/TasksOverviewChart.vue")['default']
export const PagesHelpDeskReportsTicketsStatusChart: typeof import("../components/Pages/HelpDesk/Reports/TicketsStatusChart.vue")['default']
export const PagesHelpDeskReports: typeof import("../components/Pages/HelpDesk/Reports/index.vue")['default']
export const PagesHelpDeskTicketDetailsAttachments: typeof import("../components/Pages/HelpDesk/TicketDetails/Attachments.vue")['default']
export const PagesHelpDeskTicketDetailsComments: typeof import("../components/Pages/HelpDesk/TicketDetails/Comments.vue")['default']
export const PagesHelpDeskTicketDetailsTicket: typeof import("../components/Pages/HelpDesk/TicketDetails/Ticket.vue")['default']
export const PagesHelpDeskTicketDetailsTicketDescription: typeof import("../components/Pages/HelpDesk/TicketDetails/TicketDescription.vue")['default']
export const PagesHelpDeskTicketDetails: typeof import("../components/Pages/HelpDesk/TicketDetails/index.vue")['default']
export const PagesHelpDeskTicketsAllTickets: typeof import("../components/Pages/HelpDesk/Tickets/AllTickets.vue")['default']
export const PagesHelpDeskTicketsDueChart: typeof import("../components/Pages/HelpDesk/Tickets/TicketsDueChart.vue")['default']
export const PagesHelpDeskTicketsInProgressChart: typeof import("../components/Pages/HelpDesk/Tickets/TicketsInProgressChart.vue")['default']
export const PagesHelpDeskTicketsNewOpenChart: typeof import("../components/Pages/HelpDesk/Tickets/TicketsNewOpenChart.vue")['default']
export const PagesHelpDeskTicketsResolvedChart: typeof import("../components/Pages/HelpDesk/Tickets/TicketsResolvedChart.vue")['default']
export const PagesHelpDeskTickets: typeof import("../components/Pages/HelpDesk/Tickets/index.vue")['default']
export const PagesHotelGuestsList: typeof import("../components/Pages/Hotel/GuestsList/index.vue")['default']
export const PagesHotelRoomDetailsReviews: typeof import("../components/Pages/Hotel/RoomDetails/Reviews.vue")['default']
export const PagesHotelRoomDetails: typeof import("../components/Pages/Hotel/RoomDetails/index.vue")['default']
export const PagesHotelRoomsList: typeof import("../components/Pages/Hotel/RoomsList/index.vue")['default']
export const PagesInvoicesCreateInvoice: typeof import("../components/Pages/Invoices/CreateInvoice/index.vue")['default']
export const PagesInvoicesEditInvoice: typeof import("../components/Pages/Invoices/EditInvoice/index.vue")['default']
export const PagesInvoicesInvoiceDetails: typeof import("../components/Pages/Invoices/InvoiceDetails/index.vue")['default']
export const PagesInvoicesInvoicesList: typeof import("../components/Pages/Invoices/InvoicesList/index.vue")['default']
export const PagesLMSCourseDetailsCourse: typeof import("../components/Pages/LMS/CourseDetails/Course.vue")['default']
export const PagesLMSCourseDetailsCourseInstructor: typeof import("../components/Pages/LMS/CourseDetails/CourseInstructor.vue")['default']
export const PagesLMSCourseDetailsEnrolledStudents: typeof import("../components/Pages/LMS/CourseDetails/EnrolledStudents.vue")['default']
export const PagesLMSCourseDetailsManageReviews: typeof import("../components/Pages/LMS/CourseDetails/ManageReviews.vue")['default']
export const PagesLMSCourseDetailsRatings: typeof import("../components/Pages/LMS/CourseDetails/Ratings.vue")['default']
export const PagesLMSCourseDetailsTablesOfContent: typeof import("../components/Pages/LMS/CourseDetails/TablesOfContent.vue")['default']
export const PagesLMSCourseDetailsWriteFeedbackHere: typeof import("../components/Pages/LMS/CourseDetails/WriteFeedbackHere.vue")['default']
export const PagesLMSCourseDetails: typeof import("../components/Pages/LMS/CourseDetails/index.vue")['default']
export const PagesLMSCoursesList: typeof import("../components/Pages/LMS/CoursesList/index.vue")['default']
export const PagesLMSCreateCourse: typeof import("../components/Pages/LMS/CreateCourse/index.vue")['default']
export const PagesLMSEditCourse: typeof import("../components/Pages/LMS/EditCourse/index.vue")['default']
export const PagesLMSInstructors: typeof import("../components/Pages/LMS/Instructors/index.vue")['default']
export const PagesLMSLessonPreview: typeof import("../components/Pages/LMS/LessonPreview/index.vue")['default']
export const PagesLMSAdminInstituteType: typeof import("../components/Pages/LMS/admin/institute-type.vue")['default']
export const PagesNFTMarketplaceCreatorDetailsCarterID: typeof import("../components/Pages/NFTMarketplace/CreatorDetails/CarterID.vue")['default']
export const PagesNFTMarketplaceCreatorDetailsCarterNFTs: typeof import("../components/Pages/NFTMarketplace/CreatorDetails/CarterNFTs.vue")['default']
export const PagesNFTMarketplaceCreatorDetails: typeof import("../components/Pages/NFTMarketplace/CreatorDetails/index.vue")['default']
export const PagesNFTMarketplaceCreatorsFilterContent: typeof import("../components/Pages/NFTMarketplace/Creators/FilterContent.vue")['default']
export const PagesNFTMarketplaceCreators: typeof import("../components/Pages/NFTMarketplace/Creators/index.vue")['default']
export const PagesNFTMarketplaceExploreAllPriceFilter: typeof import("../components/Pages/NFTMarketplace/ExploreAll/PriceFilter.vue")['default']
export const PagesNFTMarketplaceExploreAll: typeof import("../components/Pages/NFTMarketplace/ExploreAll/index.vue")['default']
export const PagesNFTMarketplaceLiveAuctionCountdownTimer: typeof import("../components/Pages/NFTMarketplace/LiveAuction/CountdownTimer.vue")['default']
export const PagesNFTMarketplaceLiveAuctionHistoryOfBids: typeof import("../components/Pages/NFTMarketplace/LiveAuction/HistoryOfBids.vue")['default']
export const PagesNFTMarketplaceLiveAuctionNewMobileApp: typeof import("../components/Pages/NFTMarketplace/LiveAuction/NewMobileApp.vue")['default']
export const PagesNFTMarketplaceLiveAuction: typeof import("../components/Pages/NFTMarketplace/LiveAuction/index.vue")['default']
export const PagesNFTMarketplaceMarketplaceCreateNFT: typeof import("../components/Pages/NFTMarketplace/Marketplace/CreateNFT.vue")['default']
export const PagesNFTMarketplaceMarketplaceFeaturedNFTArtworks: typeof import("../components/Pages/NFTMarketplace/Marketplace/FeaturedNFTArtworks.vue")['default']
export const PagesNFTMarketplaceMarketplaceManageYourNFT: typeof import("../components/Pages/NFTMarketplace/Marketplace/ManageYourNFT.vue")['default']
export const PagesNFTMarketplaceMarketplaceTopCreators: typeof import("../components/Pages/NFTMarketplace/Marketplace/TopCreators.vue")['default']
export const PagesNFTMarketplaceNFTDetailsCountdownTimer: typeof import("../components/Pages/NFTMarketplace/NFTDetails/CountdownTimer.vue")['default']
export const PagesNFTMarketplaceNFTDetails: typeof import("../components/Pages/NFTMarketplace/NFTDetails/index.vue")['default']
export const PagesNFTMarketplaceWalletConnect: typeof import("../components/Pages/NFTMarketplace/WalletConnect/index.vue")['default']
export const PagesProfileCover: typeof import("../components/Pages/Profile/ProfileCover.vue")['default']
export const PagesProfileMenu: typeof import("../components/Pages/Profile/ProfileMenu.vue")['default']
export const PagesProfileProjects: typeof import("../components/Pages/Profile/Projects/index.vue")['default']
export const PagesProfileTeams: typeof import("../components/Pages/Profile/Teams/index.vue")['default']
export const PagesProfileUserProfileAboutMe: typeof import("../components/Pages/Profile/UserProfile/AboutMe.vue")['default']
export const PagesProfileUserProfileFollowers: typeof import("../components/Pages/Profile/UserProfile/Followers.vue")['default']
export const PagesProfileUserProfileMyProjects: typeof import("../components/Pages/Profile/UserProfile/MyProjects.vue")['default']
export const PagesProfileUserProfile: typeof import("../components/Pages/Profile/UserProfile/index.vue")['default']
export const PagesProjectManagementClients: typeof import("../components/Pages/ProjectManagement/Clients/index.vue")['default']
export const PagesProjectManagementCreateProject: typeof import("../components/Pages/ProjectManagement/CreateProject/index.vue")['default']
export const PagesProjectManagementKanbanBoard: typeof import("../components/Pages/ProjectManagement/KanbanBoard/index.vue")['default']
export const PagesProjectManagementProjectOverviewProjectRoadmapChart: typeof import("../components/Pages/ProjectManagement/ProjectOverview/ProjectRoadmapChart.vue")['default']
export const PagesProjectManagementProjectOverviewProjectsOverview: typeof import("../components/Pages/ProjectManagement/ProjectOverview/ProjectsOverview.vue")['default']
export const PagesProjectManagementProjectOverviewRecentActivity: typeof import("../components/Pages/ProjectManagement/ProjectOverview/RecentActivity.vue")['default']
export const PagesProjectManagementProjectOverviewTasksOverviewChart: typeof import("../components/Pages/ProjectManagement/ProjectOverview/TasksOverviewChart.vue")['default']
export const PagesProjectManagementProjectOverviewTeamMembers: typeof import("../components/Pages/ProjectManagement/ProjectOverview/TeamMembers.vue")['default']
export const PagesProjectManagementProjectOverviewThemeDevelopment: typeof import("../components/Pages/ProjectManagement/ProjectOverview/ThemeDevelopment.vue")['default']
export const PagesProjectManagementProjectOverviewToDoList: typeof import("../components/Pages/ProjectManagement/ProjectOverview/ToDoList.vue")['default']
export const PagesProjectManagementProjectOverview: typeof import("../components/Pages/ProjectManagement/ProjectOverview/index.vue")['default']
export const PagesProjectManagementProjectsList: typeof import("../components/Pages/ProjectManagement/ProjectsList/index.vue")['default']
export const PagesProjectManagementTeams: typeof import("../components/Pages/ProjectManagement/Teams/index.vue")['default']
export const PagesProjectManagementUsers: typeof import("../components/Pages/ProjectManagement/Users/index.vue")['default']
export const PagesRealEstateAddAgent: typeof import("../components/Pages/RealEstate/AddAgent/index.vue")['default']
export const PagesRealEstateAddProperty: typeof import("../components/Pages/RealEstate/AddProperty/index.vue")['default']
export const PagesRealEstateAgentList: typeof import("../components/Pages/RealEstate/AgentList/index.vue")['default']
export const PagesRealEstateAgentOverviewClientTestimonials: typeof import("../components/Pages/RealEstate/AgentOverview/ClientTestimonials.vue")['default']
export const PagesRealEstateAgentOverviewProfile: typeof import("../components/Pages/RealEstate/AgentOverview/Profile.vue")['default']
export const PagesRealEstateAgentOverviewPropertyStatusPropertiesForRentChart: typeof import("../components/Pages/RealEstate/AgentOverview/PropertyStatus/PropertiesForRentChart.vue")['default']
export const PagesRealEstateAgentOverviewPropertyStatusPropertiesForSaleChart: typeof import("../components/Pages/RealEstate/AgentOverview/PropertyStatus/PropertiesForSaleChart.vue")['default']
export const PagesRealEstateAgentOverviewPropertyStatus: typeof import("../components/Pages/RealEstate/AgentOverview/PropertyStatus/index.vue")['default']
export const PagesRealEstateAgentOverview: typeof import("../components/Pages/RealEstate/AgentOverview/index.vue")['default']
export const PagesRealEstatePropertyListAddProperty: typeof import("../components/Pages/RealEstate/PropertyList/AddProperty.vue")['default']
export const PagesRealEstatePropertyList: typeof import("../components/Pages/RealEstate/PropertyList/index.vue")['default']
export const PagesRealEstatePropertyOverviewProfile: typeof import("../components/Pages/RealEstate/PropertyOverview/Profile/index.vue")['default']
export const PagesRealEstatePropertyOverview: typeof import("../components/Pages/RealEstate/PropertyOverview/index.vue")['default']
export const PagesRealEstateRealEstateCustomersAddNewCustomer: typeof import("../components/Pages/RealEstate/RealEstateCustomers/AddNewCustomer.vue")['default']
export const PagesRealEstateRealEstateCustomersAddNewCustomerModal: typeof import("../components/Pages/RealEstate/RealEstateCustomers/AddNewCustomerModal.vue")['default']
export const PagesRealEstateRealEstateCustomers: typeof import("../components/Pages/RealEstate/RealEstateCustomers/index.vue")['default']
export const PagesRealEstateAgentProperties: typeof import("../components/Pages/RealEstateAgent/Properties/index.vue")['default']
export const PagesRealEstateAgentPropertyDetailsReviews: typeof import("../components/Pages/RealEstateAgent/PropertyDetails/Reviews.vue")['default']
export const PagesRealEstateAgentPropertyDetails: typeof import("../components/Pages/RealEstateAgent/PropertyDetails/index.vue")['default']
export const PagesRestaurantDishDetailsReviewsComponent: typeof import("../components/Pages/Restaurant/DishDetails/ReviewsComponent.vue")['default']
export const PagesRestaurantDishDetails: typeof import("../components/Pages/Restaurant/DishDetails/index.vue")['default']
export const PagesRestaurantMenus: typeof import("../components/Pages/Restaurant/Menus/index.vue")['default']
export const PagesSocialProfile: typeof import("../components/Pages/Social/Profile/index.vue")['default']
export const PagesSocialSettings: typeof import("../components/Pages/Social/Settings/index.vue")['default']
export const PagesStarter: typeof import("../components/Pages/Starter/index.vue")['default']
export const PagesUsersAddUser: typeof import("../components/Pages/Users/AddUser/index.vue")['default']
export const PagesUsersTeamMembers: typeof import("../components/Pages/Users/TeamMembers/index.vue")['default']
export const PagesUsersUsersList: typeof import("../components/Pages/Users/UsersList/index.vue")['default']
export const NuxtWelcome: typeof import("../node_modules/nuxt/dist/app/components/welcome.vue")['default']
export const NuxtLayout: typeof import("../node_modules/nuxt/dist/app/components/nuxt-layout")['default']
export const NuxtErrorBoundary: typeof import("../node_modules/nuxt/dist/app/components/nuxt-error-boundary.vue")['default']
export const ClientOnly: typeof import("../node_modules/nuxt/dist/app/components/client-only")['default']
export const DevOnly: typeof import("../node_modules/nuxt/dist/app/components/dev-only")['default']
export const ServerPlaceholder: typeof import("../node_modules/nuxt/dist/app/components/server-placeholder")['default']
export const NuxtLink: typeof import("../node_modules/nuxt/dist/app/components/nuxt-link")['default']
export const NuxtLoadingIndicator: typeof import("../node_modules/nuxt/dist/app/components/nuxt-loading-indicator")['default']
export const NuxtTime: typeof import("../node_modules/nuxt/dist/app/components/nuxt-time.vue")['default']
export const NuxtRouteAnnouncer: typeof import("../node_modules/nuxt/dist/app/components/nuxt-route-announcer")['default']
export const NuxtImg: typeof import("../node_modules/nuxt/dist/app/components/nuxt-stubs")['NuxtImg']
export const NuxtPicture: typeof import("../node_modules/nuxt/dist/app/components/nuxt-stubs")['NuxtPicture']
export const BAccordion: typeof import("bootstrap-vue-next/components/BAccordion")['BAccordion']
export const BAccordionItem: typeof import("bootstrap-vue-next/components/BAccordion")['BAccordionItem']
export const BAlert: typeof import("bootstrap-vue-next/components/BAlert")['BAlert']
export const BAvatar: typeof import("bootstrap-vue-next/components/BAvatar")['BAvatar']
export const BAvatarGroup: typeof import("bootstrap-vue-next/components/BAvatar")['BAvatarGroup']
export const BBadge: typeof import("bootstrap-vue-next/components/BBadge")['BBadge']
export const BBreadcrumb: typeof import("bootstrap-vue-next/components/BBreadcrumb")['BBreadcrumb']
export const BBreadcrumbItem: typeof import("bootstrap-vue-next/components/BBreadcrumb")['BBreadcrumbItem']
export const BButton: typeof import("bootstrap-vue-next/components/BButton")['BButton']
export const BButtonGroup: typeof import("bootstrap-vue-next/components/BButton")['BButtonGroup']
export const BButtonToolbar: typeof import("bootstrap-vue-next/components/BButton")['BButtonToolbar']
export const BCloseButton: typeof import("bootstrap-vue-next/components/BButton")['BCloseButton']
export const BCard: typeof import("bootstrap-vue-next/components/BCard")['BCard']
export const BCardBody: typeof import("bootstrap-vue-next/components/BCard")['BCardBody']
export const BCardFooter: typeof import("bootstrap-vue-next/components/BCard")['BCardFooter']
export const BCardGroup: typeof import("bootstrap-vue-next/components/BCard")['BCardGroup']
export const BCardHeader: typeof import("bootstrap-vue-next/components/BCard")['BCardHeader']
export const BCardImg: typeof import("bootstrap-vue-next/components/BCard")['BCardImg']
export const BCardSubtitle: typeof import("bootstrap-vue-next/components/BCard")['BCardSubtitle']
export const BCardText: typeof import("bootstrap-vue-next/components/BCard")['BCardText']
export const BCardTitle: typeof import("bootstrap-vue-next/components/BCard")['BCardTitle']
export const BCarousel: typeof import("bootstrap-vue-next/components/BCarousel")['BCarousel']
export const BCarouselSlide: typeof import("bootstrap-vue-next/components/BCarousel")['BCarouselSlide']
export const BCol: typeof import("bootstrap-vue-next/components/BContainer")['BCol']
export const BCollapse: typeof import("bootstrap-vue-next/components/BCollapse")['BCollapse']
export const BContainer: typeof import("bootstrap-vue-next/components/BContainer")['BContainer']
export const BDropdown: typeof import("bootstrap-vue-next/components/BDropdown")['BDropdown']
export const BDropdownDivider: typeof import("bootstrap-vue-next/components/BDropdown")['BDropdownDivider']
export const BDropdownForm: typeof import("bootstrap-vue-next/components/BDropdown")['BDropdownForm']
export const BDropdownGroup: typeof import("bootstrap-vue-next/components/BDropdown")['BDropdownGroup']
export const BDropdownHeader: typeof import("bootstrap-vue-next/components/BDropdown")['BDropdownHeader']
export const BDropdownItem: typeof import("bootstrap-vue-next/components/BDropdown")['BDropdownItem']
export const BDropdownItemButton: typeof import("bootstrap-vue-next/components/BDropdown")['BDropdownItemButton']
export const BDropdownText: typeof import("bootstrap-vue-next/components/BDropdown")['BDropdownText']
export const BForm: typeof import("bootstrap-vue-next/components/BForm")['BForm']
export const BFormCheckbox: typeof import("bootstrap-vue-next/components/BFormCheckbox")['BFormCheckbox']
export const BFormCheckboxGroup: typeof import("bootstrap-vue-next/components/BFormCheckbox")['BFormCheckboxGroup']
export const BFormDatalist: typeof import("bootstrap-vue-next/components/BForm")['BFormDatalist']
export const BFormFile: typeof import("bootstrap-vue-next/components/BFormFile")['BFormFile']
export const BFormFloatingLabel: typeof import("bootstrap-vue-next/components/BForm")['BFormFloatingLabel']
export const BFormGroup: typeof import("bootstrap-vue-next/components/BFormGroup")['BFormGroup']
export const BFormInput: typeof import("bootstrap-vue-next/components/BFormInput")['BFormInput']
export const BFormInvalidFeedback: typeof import("bootstrap-vue-next/components/BForm")['BFormInvalidFeedback']
export const BFormRadio: typeof import("bootstrap-vue-next/components/BFormRadio")['BFormRadio']
export const BFormRadioGroup: typeof import("bootstrap-vue-next/components/BFormRadio")['BFormRadioGroup']
export const BFormRow: typeof import("bootstrap-vue-next/components/BForm")['BFormRow']
export const BFormSelect: typeof import("bootstrap-vue-next/components/BFormSelect")['BFormSelect']
export const BFormSelectOption: typeof import("bootstrap-vue-next/components/BFormSelect")['BFormSelectOption']
export const BFormSelectOptionGroup: typeof import("bootstrap-vue-next/components/BFormSelect")['BFormSelectOptionGroup']
export const BFormSpinbutton: typeof import("bootstrap-vue-next/components/BFormSpinbutton")['BFormSpinbutton']
export const BFormTag: typeof import("bootstrap-vue-next/components/BFormTags")['BFormTag']
export const BFormTags: typeof import("bootstrap-vue-next/components/BFormTags")['BFormTags']
export const BFormText: typeof import("bootstrap-vue-next/components/BForm")['BFormText']
export const BFormTextarea: typeof import("bootstrap-vue-next/components/BFormTextarea")['BFormTextarea']
export const BFormValidFeedback: typeof import("bootstrap-vue-next/components/BForm")['BFormValidFeedback']
export const BImg: typeof import("bootstrap-vue-next/components/BImg")['BImg']
export const BInput: typeof import("bootstrap-vue-next/components/BFormInput")['BInput']
export const BInputGroup: typeof import("bootstrap-vue-next/components/BInputGroup")['BInputGroup']
export const BInputGroupText: typeof import("bootstrap-vue-next/components/BInputGroup")['BInputGroupText']
export const BListGroup: typeof import("bootstrap-vue-next/components/BListGroup")['BListGroup']
export const BListGroupItem: typeof import("bootstrap-vue-next/components/BListGroup")['BListGroupItem']
export const BModal: typeof import("bootstrap-vue-next/components/BModal")['BModal']
export const BModalOrchestrator: typeof import("bootstrap-vue-next/components/BModal")['BModalOrchestrator']
export const BNav: typeof import("bootstrap-vue-next/components/BNav")['BNav']
export const BNavForm: typeof import("bootstrap-vue-next/components/BNav")['BNavForm']
export const BNavItem: typeof import("bootstrap-vue-next/components/BNav")['BNavItem']
export const BNavItemDropdown: typeof import("bootstrap-vue-next/components/BNav")['BNavItemDropdown']
export const BNavText: typeof import("bootstrap-vue-next/components/BNav")['BNavText']
export const BNavbar: typeof import("bootstrap-vue-next/components/BNavbar")['BNavbar']
export const BNavbarBrand: typeof import("bootstrap-vue-next/components/BNavbar")['BNavbarBrand']
export const BNavbarNav: typeof import("bootstrap-vue-next/components/BNavbar")['BNavbarNav']
export const BNavbarToggle: typeof import("bootstrap-vue-next/components/BNavbar")['BNavbarToggle']
export const BOffcanvas: typeof import("bootstrap-vue-next/components/BOffcanvas")['BOffcanvas']
export const BOverlay: typeof import("bootstrap-vue-next/components/BOverlay")['BOverlay']
export const BPagination: typeof import("bootstrap-vue-next/components/BPagination")['BPagination']
export const BPlaceholder: typeof import("bootstrap-vue-next/components/BPlaceholder")['BPlaceholder']
export const BPlaceholderButton: typeof import("bootstrap-vue-next/components/BPlaceholder")['BPlaceholderButton']
export const BPlaceholderCard: typeof import("bootstrap-vue-next/components/BPlaceholder")['BPlaceholderCard']
export const BPlaceholderTable: typeof import("bootstrap-vue-next/components/BPlaceholder")['BPlaceholderTable']
export const BPlaceholderWrapper: typeof import("bootstrap-vue-next/components/BPlaceholder")['BPlaceholderWrapper']
export const BPopover: typeof import("bootstrap-vue-next/components/BPopover")['BPopover']
export const BProgress: typeof import("bootstrap-vue-next/components/BProgress")['BProgress']
export const BRow: typeof import("bootstrap-vue-next/components/BContainer")['BRow']
export const BSpinner: typeof import("bootstrap-vue-next/components/BSpinner")['BSpinner']
export const BTab: typeof import("bootstrap-vue-next/components/BTabs")['BTab']
export const BTabs: typeof import("bootstrap-vue-next/components/BTabs")['BTabs']
export const BToast: typeof import("bootstrap-vue-next/components/BToast")['BToast']
export const BToastOrchestrator: typeof import("bootstrap-vue-next/components/BToast")['BToastOrchestrator']
export const BTooltip: typeof import("bootstrap-vue-next/components/BTooltip")['BTooltip']
export const BLink: typeof import("bootstrap-vue-next/components/BLink")['BLink']
export const BProgressBar: typeof import("bootstrap-vue-next/components/BProgress")['BProgressBar']
export const BTableSimple: typeof import("bootstrap-vue-next/components/BTable")['BTableSimple']
export const BTableLite: typeof import("bootstrap-vue-next/components/BTable")['BTableLite']
export const BTable: typeof import("bootstrap-vue-next/components/BTable")['BTable']
export const BTbody: typeof import("bootstrap-vue-next/components/BTable")['BTbody']
export const BTd: typeof import("bootstrap-vue-next/components/BTable")['BTd']
export const BTh: typeof import("bootstrap-vue-next/components/BTable")['BTh']
export const BThead: typeof import("bootstrap-vue-next/components/BTable")['BThead']
export const BTfoot: typeof import("bootstrap-vue-next/components/BTable")['BTfoot']
export const BTr: typeof import("bootstrap-vue-next/components/BTable")['BTr']
export const BPopoverOrchestrator: typeof import("bootstrap-vue-next/components/BPopover")['BPopoverOrchestrator']
export const BTooltipOrchestrator: typeof import("bootstrap-vue-next/components/BTooltip")['BTooltipOrchestrator']
export const Swiper: typeof import("swiper/vue")['Swiper']
export const SwiperSlide: typeof import("swiper/vue")['SwiperSlide']
export const ActivityIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ActivityIcon")['default']
export const AirplayIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/AirplayIcon")['default']
export const AlertCircleIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/AlertCircleIcon")['default']
export const AlertOctagonIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/AlertOctagonIcon")['default']
export const AlertTriangleIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/AlertTriangleIcon")['default']
export const AlignCenterIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/AlignCenterIcon")['default']
export const AlignJustifyIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/AlignJustifyIcon")['default']
export const AlignLeftIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/AlignLeftIcon")['default']
export const AlignRightIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/AlignRightIcon")['default']
export const AnchorIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/AnchorIcon")['default']
export const ApertureIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ApertureIcon")['default']
export const ArchiveIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ArchiveIcon")['default']
export const ArrowDownCircleIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ArrowDownCircleIcon")['default']
export const ArrowDownLeftIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ArrowDownLeftIcon")['default']
export const ArrowDownRightIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ArrowDownRightIcon")['default']
export const ArrowDownIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ArrowDownIcon")['default']
export const ArrowLeftCircleIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ArrowLeftCircleIcon")['default']
export const ArrowLeftIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ArrowLeftIcon")['default']
export const ArrowRightCircleIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ArrowRightCircleIcon")['default']
export const ArrowRightIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ArrowRightIcon")['default']
export const ArrowUpCircleIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ArrowUpCircleIcon")['default']
export const ArrowUpLeftIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ArrowUpLeftIcon")['default']
export const ArrowUpRightIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ArrowUpRightIcon")['default']
export const ArrowUpIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ArrowUpIcon")['default']
export const AtSignIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/AtSignIcon")['default']
export const AwardIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/AwardIcon")['default']
export const BarChart2Icon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/BarChart2Icon")['default']
export const BarChartIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/BarChartIcon")['default']
export const BatteryChargingIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/BatteryChargingIcon")['default']
export const BatteryIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/BatteryIcon")['default']
export const BellOffIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/BellOffIcon")['default']
export const BellIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/BellIcon")['default']
export const BluetoothIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/BluetoothIcon")['default']
export const BoldIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/BoldIcon")['default']
export const BookOpenIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/BookOpenIcon")['default']
export const BookIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/BookIcon")['default']
export const BookmarkIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/BookmarkIcon")['default']
export const BoxIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/BoxIcon")['default']
export const BriefcaseIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/BriefcaseIcon")['default']
export const CalendarIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CalendarIcon")['default']
export const CameraOffIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CameraOffIcon")['default']
export const CameraIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CameraIcon")['default']
export const CastIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CastIcon")['default']
export const CheckCircleIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CheckCircleIcon")['default']
export const CheckSquareIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CheckSquareIcon")['default']
export const CheckIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CheckIcon")['default']
export const ChevronDownIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ChevronDownIcon")['default']
export const ChevronLeftIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ChevronLeftIcon")['default']
export const ChevronRightIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ChevronRightIcon")['default']
export const ChevronUpIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ChevronUpIcon")['default']
export const ChevronsDownIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ChevronsDownIcon")['default']
export const ChevronsLeftIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ChevronsLeftIcon")['default']
export const ChevronsRightIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ChevronsRightIcon")['default']
export const ChevronsUpIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ChevronsUpIcon")['default']
export const ChromeIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ChromeIcon")['default']
export const CircleIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CircleIcon")['default']
export const ClipboardIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ClipboardIcon")['default']
export const ClockIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ClockIcon")['default']
export const CloudDrizzleIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CloudDrizzleIcon")['default']
export const CloudLightningIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CloudLightningIcon")['default']
export const CloudOffIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CloudOffIcon")['default']
export const CloudRainIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CloudRainIcon")['default']
export const CloudSnowIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CloudSnowIcon")['default']
export const CloudIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CloudIcon")['default']
export const CodeIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CodeIcon")['default']
export const CodepenIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CodepenIcon")['default']
export const CodesandboxIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CodesandboxIcon")['default']
export const CoffeeIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CoffeeIcon")['default']
export const ColumnsIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ColumnsIcon")['default']
export const CommandIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CommandIcon")['default']
export const CompassIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CompassIcon")['default']
export const CopyIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CopyIcon")['default']
export const CornerDownLeftIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CornerDownLeftIcon")['default']
export const CornerDownRightIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CornerDownRightIcon")['default']
export const CornerLeftDownIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CornerLeftDownIcon")['default']
export const CornerLeftUpIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CornerLeftUpIcon")['default']
export const CornerRightDownIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CornerRightDownIcon")['default']
export const CornerRightUpIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CornerRightUpIcon")['default']
export const CornerUpLeftIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CornerUpLeftIcon")['default']
export const CornerUpRightIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CornerUpRightIcon")['default']
export const CpuIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CpuIcon")['default']
export const CreditCardIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CreditCardIcon")['default']
export const CropIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CropIcon")['default']
export const CrosshairIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CrosshairIcon")['default']
export const DatabaseIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/DatabaseIcon")['default']
export const DeleteIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/DeleteIcon")['default']
export const DiscIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/DiscIcon")['default']
export const DivideCircleIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/DivideCircleIcon")['default']
export const DivideSquareIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/DivideSquareIcon")['default']
export const DivideIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/DivideIcon")['default']
export const DollarSignIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/DollarSignIcon")['default']
export const DownloadCloudIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/DownloadCloudIcon")['default']
export const DownloadIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/DownloadIcon")['default']
export const DribbbleIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/DribbbleIcon")['default']
export const DropletIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/DropletIcon")['default']
export const Edit2Icon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/Edit2Icon")['default']
export const Edit3Icon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/Edit3Icon")['default']
export const EditIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/EditIcon")['default']
export const ExternalLinkIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ExternalLinkIcon")['default']
export const EyeOffIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/EyeOffIcon")['default']
export const EyeIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/EyeIcon")['default']
export const FacebookIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/FacebookIcon")['default']
export const FastForwardIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/FastForwardIcon")['default']
export const FeatherIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/FeatherIcon")['default']
export const FigmaIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/FigmaIcon")['default']
export const FileMinusIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/FileMinusIcon")['default']
export const FilePlusIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/FilePlusIcon")['default']
export const FileTextIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/FileTextIcon")['default']
export const FileIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/FileIcon")['default']
export const FilmIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/FilmIcon")['default']
export const FilterIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/FilterIcon")['default']
export const FlagIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/FlagIcon")['default']
export const FolderMinusIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/FolderMinusIcon")['default']
export const FolderPlusIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/FolderPlusIcon")['default']
export const FolderIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/FolderIcon")['default']
export const FramerIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/FramerIcon")['default']
export const FrownIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/FrownIcon")['default']
export const GiftIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/GiftIcon")['default']
export const GitBranchIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/GitBranchIcon")['default']
export const GitCommitIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/GitCommitIcon")['default']
export const GitMergeIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/GitMergeIcon")['default']
export const GitPullRequestIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/GitPullRequestIcon")['default']
export const GithubIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/GithubIcon")['default']
export const GitlabIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/GitlabIcon")['default']
export const GlobeIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/GlobeIcon")['default']
export const GridIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/GridIcon")['default']
export const HardDriveIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/HardDriveIcon")['default']
export const HashIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/HashIcon")['default']
export const HeadphonesIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/HeadphonesIcon")['default']
export const HeartIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/HeartIcon")['default']
export const HelpCircleIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/HelpCircleIcon")['default']
export const HexagonIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/HexagonIcon")['default']
export const HomeIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/HomeIcon")['default']
export const ImageIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ImageIcon")['default']
export const InboxIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/InboxIcon")['default']
export const InfoIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/InfoIcon")['default']
export const InstagramIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/InstagramIcon")['default']
export const ItalicIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ItalicIcon")['default']
export const KeyIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/KeyIcon")['default']
export const LayersIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/LayersIcon")['default']
export const LayoutIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/LayoutIcon")['default']
export const LifeBuoyIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/LifeBuoyIcon")['default']
export const Link2Icon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/Link2Icon")['default']
export const LinkIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/LinkIcon")['default']
export const LinkedinIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/LinkedinIcon")['default']
export const ListIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ListIcon")['default']
export const LoaderIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/LoaderIcon")['default']
export const LockIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/LockIcon")['default']
export const LogInIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/LogInIcon")['default']
export const LogOutIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/LogOutIcon")['default']
export const MailIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/MailIcon")['default']
export const MapPinIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/MapPinIcon")['default']
export const MapIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/MapIcon")['default']
export const Maximize2Icon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/Maximize2Icon")['default']
export const MaximizeIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/MaximizeIcon")['default']
export const MehIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/MehIcon")['default']
export const MenuIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/MenuIcon")['default']
export const MessageCircleIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/MessageCircleIcon")['default']
export const MessageSquareIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/MessageSquareIcon")['default']
export const MicOffIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/MicOffIcon")['default']
export const MicIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/MicIcon")['default']
export const Minimize2Icon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/Minimize2Icon")['default']
export const MinimizeIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/MinimizeIcon")['default']
export const MinusCircleIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/MinusCircleIcon")['default']
export const MinusSquareIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/MinusSquareIcon")['default']
export const MinusIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/MinusIcon")['default']
export const MonitorIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/MonitorIcon")['default']
export const MoonIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/MoonIcon")['default']
export const MoreHorizontalIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/MoreHorizontalIcon")['default']
export const MoreVerticalIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/MoreVerticalIcon")['default']
export const MousePointerIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/MousePointerIcon")['default']
export const MoveIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/MoveIcon")['default']
export const MusicIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/MusicIcon")['default']
export const Navigation2Icon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/Navigation2Icon")['default']
export const NavigationIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/NavigationIcon")['default']
export const OctagonIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/OctagonIcon")['default']
export const PackageIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/PackageIcon")['default']
export const PaperclipIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/PaperclipIcon")['default']
export const PauseCircleIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/PauseCircleIcon")['default']
export const PauseIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/PauseIcon")['default']
export const PenToolIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/PenToolIcon")['default']
export const PercentIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/PercentIcon")['default']
export const PhoneCallIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/PhoneCallIcon")['default']
export const PhoneForwardedIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/PhoneForwardedIcon")['default']
export const PhoneIncomingIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/PhoneIncomingIcon")['default']
export const PhoneMissedIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/PhoneMissedIcon")['default']
export const PhoneOffIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/PhoneOffIcon")['default']
export const PhoneOutgoingIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/PhoneOutgoingIcon")['default']
export const PhoneIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/PhoneIcon")['default']
export const PieChartIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/PieChartIcon")['default']
export const PlayCircleIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/PlayCircleIcon")['default']
export const PlayIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/PlayIcon")['default']
export const PlusCircleIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/PlusCircleIcon")['default']
export const PlusSquareIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/PlusSquareIcon")['default']
export const PlusIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/PlusIcon")['default']
export const PocketIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/PocketIcon")['default']
export const PowerIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/PowerIcon")['default']
export const PrinterIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/PrinterIcon")['default']
export const RadioIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/RadioIcon")['default']
export const RefreshCcwIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/RefreshCcwIcon")['default']
export const RefreshCwIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/RefreshCwIcon")['default']
export const RepeatIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/RepeatIcon")['default']
export const RewindIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/RewindIcon")['default']
export const RotateCcwIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/RotateCcwIcon")['default']
export const RotateCwIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/RotateCwIcon")['default']
export const RssIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/RssIcon")['default']
export const SaveIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/SaveIcon")['default']
export const ScissorsIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ScissorsIcon")['default']
export const SearchIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/SearchIcon")['default']
export const SendIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/SendIcon")['default']
export const ServerIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ServerIcon")['default']
export const SettingsIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/SettingsIcon")['default']
export const Share2Icon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/Share2Icon")['default']
export const ShareIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ShareIcon")['default']
export const ShieldOffIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ShieldOffIcon")['default']
export const ShieldIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ShieldIcon")['default']
export const ShoppingBagIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ShoppingBagIcon")['default']
export const ShoppingCartIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ShoppingCartIcon")['default']
export const ShuffleIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ShuffleIcon")['default']
export const SidebarIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/SidebarIcon")['default']
export const SkipBackIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/SkipBackIcon")['default']
export const SkipForwardIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/SkipForwardIcon")['default']
export const SlackIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/SlackIcon")['default']
export const SlashIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/SlashIcon")['default']
export const SlidersIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/SlidersIcon")['default']
export const SmartphoneIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/SmartphoneIcon")['default']
export const SmileIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/SmileIcon")['default']
export const SpeakerIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/SpeakerIcon")['default']
export const SquareIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/SquareIcon")['default']
export const StarIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/StarIcon")['default']
export const StopCircleIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/StopCircleIcon")['default']
export const SunIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/SunIcon")['default']
export const SunriseIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/SunriseIcon")['default']
export const SunsetIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/SunsetIcon")['default']
export const TableIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/TableIcon")['default']
export const TabletIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/TabletIcon")['default']
export const TagIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/TagIcon")['default']
export const TargetIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/TargetIcon")['default']
export const TerminalIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/TerminalIcon")['default']
export const ThermometerIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ThermometerIcon")['default']
export const ThumbsDownIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ThumbsDownIcon")['default']
export const ThumbsUpIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ThumbsUpIcon")['default']
export const ToggleLeftIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ToggleLeftIcon")['default']
export const ToggleRightIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ToggleRightIcon")['default']
export const ToolIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ToolIcon")['default']
export const Trash2Icon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/Trash2Icon")['default']
export const TrashIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/TrashIcon")['default']
export const TrelloIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/TrelloIcon")['default']
export const TrendingDownIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/TrendingDownIcon")['default']
export const TrendingUpIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/TrendingUpIcon")['default']
export const TriangleIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/TriangleIcon")['default']
export const TruckIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/TruckIcon")['default']
export const TvIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/TvIcon")['default']
export const TwitchIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/TwitchIcon")['default']
export const TwitterIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/TwitterIcon")['default']
export const TypeIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/TypeIcon")['default']
export const UmbrellaIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/UmbrellaIcon")['default']
export const UnderlineIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/UnderlineIcon")['default']
export const UnlockIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/UnlockIcon")['default']
export const UploadCloudIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/UploadCloudIcon")['default']
export const UploadIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/UploadIcon")['default']
export const UserCheckIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/UserCheckIcon")['default']
export const UserMinusIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/UserMinusIcon")['default']
export const UserPlusIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/UserPlusIcon")['default']
export const UserXIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/UserXIcon")['default']
export const UserIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/UserIcon")['default']
export const UsersIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/UsersIcon")['default']
export const VideoOffIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/VideoOffIcon")['default']
export const VideoIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/VideoIcon")['default']
export const VoicemailIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/VoicemailIcon")['default']
export const Volume1Icon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/Volume1Icon")['default']
export const Volume2Icon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/Volume2Icon")['default']
export const VolumeXIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/VolumeXIcon")['default']
export const VolumeIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/VolumeIcon")['default']
export const WatchIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/WatchIcon")['default']
export const WifiOffIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/WifiOffIcon")['default']
export const WifiIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/WifiIcon")['default']
export const WindIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/WindIcon")['default']
export const XCircleIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/XCircleIcon")['default']
export const XOctagonIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/XOctagonIcon")['default']
export const XSquareIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/XSquareIcon")['default']
export const XIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/XIcon")['default']
export const YoutubeIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/YoutubeIcon")['default']
export const ZapOffIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ZapOffIcon")['default']
export const ZapIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ZapIcon")['default']
export const ZoomInIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ZoomInIcon")['default']
export const ZoomOutIcon: typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ZoomOutIcon")['default']
export const NuxtPage: typeof import("../node_modules/nuxt/dist/pages/runtime/page")['default']
export const NoScript: typeof import("../node_modules/nuxt/dist/head/runtime/components")['NoScript']
export const Link: typeof import("../node_modules/nuxt/dist/head/runtime/components")['Link']
export const Base: typeof import("../node_modules/nuxt/dist/head/runtime/components")['Base']
export const Title: typeof import("../node_modules/nuxt/dist/head/runtime/components")['Title']
export const Meta: typeof import("../node_modules/nuxt/dist/head/runtime/components")['Meta']
export const Style: typeof import("../node_modules/nuxt/dist/head/runtime/components")['Style']
export const Head: typeof import("../node_modules/nuxt/dist/head/runtime/components")['Head']
export const Html: typeof import("../node_modules/nuxt/dist/head/runtime/components")['Html']
export const Body: typeof import("../node_modules/nuxt/dist/head/runtime/components")['Body']
export const NuxtIsland: typeof import("../node_modules/nuxt/dist/app/components/nuxt-island")['default']
export const NuxtRouteAnnouncer: typeof import("../node_modules/nuxt/dist/app/components/server-placeholder")['default']
export const LazyApexChartsBasicBarAreaChart: LazyComponent<typeof import("../components/ApexCharts/BasicBarAreaChart.vue")['default']>
export const LazyApexChartsBasicColumnAreaChart: LazyComponent<typeof import("../components/ApexCharts/BasicColumnAreaChart.vue")['default']>
export const LazyApexChartsBasicLineChart: LazyComponent<typeof import("../components/ApexCharts/BasicLineChart.vue")['default']>
export const LazyApexChartsColumnWithDataLabelsChart: LazyComponent<typeof import("../components/ApexCharts/ColumnWithDataLabelsChart.vue")['default']>
export const LazyApexChartsDashedChart: LazyComponent<typeof import("../components/ApexCharts/DashedChart.vue")['default']>
export const LazyApexChartsGroupedChart: LazyComponent<typeof import("../components/ApexCharts/GroupedChart.vue")['default']>
export const LazyApexChartsLineWithDataLabelsChart: LazyComponent<typeof import("../components/ApexCharts/LineWithDataLabelsChart.vue")['default']>
export const LazyApexChartsNegativeAreaChart: LazyComponent<typeof import("../components/ApexCharts/NegativeAreaChart.vue")['default']>
export const LazyApexChartsSplineAreaChart: LazyComponent<typeof import("../components/ApexCharts/SplineAreaChart.vue")['default']>
export const LazyApexChartsSteplineChart: LazyComponent<typeof import("../components/ApexCharts/SteplineChart.vue")['default']>
export const LazyApexCharts: LazyComponent<typeof import("../components/ApexCharts/index.vue")['default']>
export const LazyAppsCalendarContent: LazyComponent<typeof import("../components/Apps/Calendar/CalendarContent.vue")['default']>
export const LazyAppsCalendarWorkingSchedule: LazyComponent<typeof import("../components/Apps/Calendar/WorkingSchedule.vue")['default']>
export const LazyAppsChat: LazyComponent<typeof import("../components/Apps/Chat/index.vue")['default']>
export const LazyAppsContactsList: LazyComponent<typeof import("../components/Apps/Contacts/ContactsList.vue")['default']>
export const LazyAppsEmailCompose: LazyComponent<typeof import("../components/Apps/Email/Compose/index.vue")['default']>
export const LazyAppsEmailDraft: LazyComponent<typeof import("../components/Apps/Email/Draft/index.vue")['default']>
export const LazyAppsEmailSidebar: LazyComponent<typeof import("../components/Apps/Email/EmailSidebar.vue")['default']>
export const LazyAppsEmailImportant: LazyComponent<typeof import("../components/Apps/Email/Important/index.vue")['default']>
export const LazyAppsEmailInbox: LazyComponent<typeof import("../components/Apps/Email/Inbox/index.vue")['default']>
export const LazyAppsEmailReadEmail: LazyComponent<typeof import("../components/Apps/Email/ReadEmail/index.vue")['default']>
export const LazyAppsEmailSentMail: LazyComponent<typeof import("../components/Apps/Email/SentMail/index.vue")['default']>
export const LazyAppsEmailSnoozed: LazyComponent<typeof import("../components/Apps/Email/Snoozed/index.vue")['default']>
export const LazyAppsEmailSpam: LazyComponent<typeof import("../components/Apps/Email/Spam/index.vue")['default']>
export const LazyAppsEmailStarred: LazyComponent<typeof import("../components/Apps/Email/Starred/index.vue")['default']>
export const LazyAppsEmailTrash: LazyComponent<typeof import("../components/Apps/Email/Trash/index.vue")['default']>
export const LazyAppsFileManagerApplications: LazyComponent<typeof import("../components/Apps/FileManager/Applications/index.vue")['default']>
export const LazyAppsFileManagerAssets: LazyComponent<typeof import("../components/Apps/FileManager/Assets/index.vue")['default']>
export const LazyAppsFileManagerDocuments: LazyComponent<typeof import("../components/Apps/FileManager/Documents/index.vue")['default']>
export const LazyAppsFileManagerImportant: LazyComponent<typeof import("../components/Apps/FileManager/Important/index.vue")['default']>
export const LazyAppsFileManagerMedia: LazyComponent<typeof import("../components/Apps/FileManager/Media/index.vue")['default']>
export const LazyAppsFileManagerMyDriveFiles: LazyComponent<typeof import("../components/Apps/FileManager/MyDrive/MyDriveFiles.vue")['default']>
export const LazyAppsFileManagerMyDriveRecentFiles: LazyComponent<typeof import("../components/Apps/FileManager/MyDrive/RecentFiles.vue")['default']>
export const LazyAppsFileManagerPersonal: LazyComponent<typeof import("../components/Apps/FileManager/Personal/index.vue")['default']>
export const LazyAppsFileManagerProjects: LazyComponent<typeof import("../components/Apps/FileManager/Projects/index.vue")['default']>
export const LazyAppsFileManagerRecants: LazyComponent<typeof import("../components/Apps/FileManager/Recants/index.vue")['default']>
export const LazyAppsFileManagerSidebar: LazyComponent<typeof import("../components/Apps/FileManager/Sidebar.vue")['default']>
export const LazyAppsFileManagerSpam: LazyComponent<typeof import("../components/Apps/FileManager/Spam/index.vue")['default']>
export const LazyAppsFileManagerTrash: LazyComponent<typeof import("../components/Apps/FileManager/Trash/index.vue")['default']>
export const LazyAppsKanbanBoard: LazyComponent<typeof import("../components/Apps/KanbanBoard/index.vue")['default']>
export const LazyAppsToDoList: LazyComponent<typeof import("../components/Apps/ToDoList/index.vue")['default']>
export const LazyCommonCalendarContent: LazyComponent<typeof import("../components/Common/CalendarContent.vue")['default']>
export const LazyCommonDatePicker: LazyComponent<typeof import("../components/Common/DatePicker.vue")['default']>
export const LazyCommonPageTitle: LazyComponent<typeof import("../components/Common/PageTitle.vue")['default']>
export const LazyCommonPagination: LazyComponent<typeof import("../components/Common/Pagination.vue")['default']>
export const LazyCommonPaginationTwo: LazyComponent<typeof import("../components/Common/PaginationTwo.vue")['default']>
export const LazyCommonTextEditor: LazyComponent<typeof import("../components/Common/TextEditor.vue")['default']>
export const LazyDashboardAnalyticsOverviewChart: LazyComponent<typeof import("../components/Dashboard/Analytics/AnalyticsOverviewChart.vue")['default']>
export const LazyDashboardAnalyticsBrowserUsedByUsers: LazyComponent<typeof import("../components/Dashboard/Analytics/BrowserUsedByUsers.vue")['default']>
export const LazyDashboardAnalyticsBrowserUsedByUsersChart: LazyComponent<typeof import("../components/Dashboard/Analytics/BrowserUsedByUsersChart.vue")['default']>
export const LazyDashboardAnalyticsClicksChart: LazyComponent<typeof import("../components/Dashboard/Analytics/ClicksChart.vue")['default']>
export const LazyDashboardAnalyticsClicksImpressionsByKeywords: LazyComponent<typeof import("../components/Dashboard/Analytics/ClicksImpressionsByKeywords.vue")['default']>
export const LazyDashboardAnalyticsImpressionsChart: LazyComponent<typeof import("../components/Dashboard/Analytics/ImpressionsChart.vue")['default']>
export const LazyDashboardAnalyticsNewRegistersChart: LazyComponent<typeof import("../components/Dashboard/Analytics/NewRegistersChart.vue")['default']>
export const LazyDashboardAnalyticsRealtimeActiveUsersChart: LazyComponent<typeof import("../components/Dashboard/Analytics/RealtimeActiveUsersChart.vue")['default']>
export const LazyDashboardAnalyticsSessionsByChannelChart: LazyComponent<typeof import("../components/Dashboard/Analytics/SessionsByChannelChart.vue")['default']>
export const LazyDashboardAnalyticsSessionsChart: LazyComponent<typeof import("../components/Dashboard/Analytics/SessionsChart.vue")['default']>
export const LazyDashboardAnalyticsTopBrowsingPagesToday: LazyComponent<typeof import("../components/Dashboard/Analytics/TopBrowsingPagesToday.vue")['default']>
export const LazyDashboardAnalyticsUsersByCountry: LazyComponent<typeof import("../components/Dashboard/Analytics/UsersByCountry.vue")['default']>
export const LazyDashboardAnalyticsWebsiteVisitsChart: LazyComponent<typeof import("../components/Dashboard/Analytics/WebsiteVisitsChart.vue")['default']>
export const LazyDashboardBeautySalonCustomerSatisfactionRateChart: LazyComponent<typeof import("../components/Dashboard/BeautySalon/CustomerSatisfactionRateChart.vue")['default']>
export const LazyDashboardBeautySalonCustomersFromChannels: LazyComponent<typeof import("../components/Dashboard/BeautySalon/CustomersFromChannels.vue")['default']>
export const LazyDashboardBeautySalonFeaturedServices: LazyComponent<typeof import("../components/Dashboard/BeautySalon/FeaturedServices.vue")['default']>
export const LazyDashboardBeautySalonNewCustomers: LazyComponent<typeof import("../components/Dashboard/BeautySalon/NewCustomers.vue")['default']>
export const LazyDashboardBeautySalonRecentAppointments: LazyComponent<typeof import("../components/Dashboard/BeautySalon/RecentAppointments.vue")['default']>
export const LazyDashboardBeautySalonRevenueByServicesChart: LazyComponent<typeof import("../components/Dashboard/BeautySalon/RevenueByServicesChart.vue")['default']>
export const LazyDashboardBeautySalonTopCustomers: LazyComponent<typeof import("../components/Dashboard/BeautySalon/TopCustomers.vue")['default']>
export const LazyDashboardBeautySalonTopSellingProducts: LazyComponent<typeof import("../components/Dashboard/BeautySalon/TopSellingProducts.vue")['default']>
export const LazyDashboardBeautySalonTopStylistPerformance: LazyComponent<typeof import("../components/Dashboard/BeautySalon/TopStylistPerformance.vue")['default']>
export const LazyDashboardBeautySalonWelcomeBeautySalon: LazyComponent<typeof import("../components/Dashboard/BeautySalon/WelcomeBeautySalon.vue")['default']>
export const LazyDashboardCRMAnnualProfitChart: LazyComponent<typeof import("../components/Dashboard/CRM/AnnualProfitChart.vue")['default']>
export const LazyDashboardCRMBalanceOverviewChart: LazyComponent<typeof import("../components/Dashboard/CRM/BalanceOverviewChart.vue")['default']>
export const LazyDashboardCRMLeadConversionChart: LazyComponent<typeof import("../components/Dashboard/CRM/LeadConversionChart.vue")['default']>
export const LazyDashboardCRMLeadsBySourceChart: LazyComponent<typeof import("../components/Dashboard/CRM/LeadsBySourceChart.vue")['default']>
export const LazyDashboardCRMRecentLeads: LazyComponent<typeof import("../components/Dashboard/CRM/RecentLeads.vue")['default']>
export const LazyDashboardCRMRevenueGrowthChart: LazyComponent<typeof import("../components/Dashboard/CRM/RevenueGrowthChart.vue")['default']>
export const LazyDashboardCRMSalesReportChart: LazyComponent<typeof import("../components/Dashboard/CRM/SalesReportChart.vue")['default']>
export const LazyDashboardCRMTopPerformers: LazyComponent<typeof import("../components/Dashboard/CRM/TopPerformers.vue")['default']>
export const LazyDashboardCRMTopProductsBySales: LazyComponent<typeof import("../components/Dashboard/CRM/TopProductsBySales.vue")['default']>
export const LazyDashboardCRMTotalOrdersChart: LazyComponent<typeof import("../components/Dashboard/CRM/TotalOrdersChart.vue")['default']>
export const LazyDashboardCallCenterAgentAvgEarningsChart: LazyComponent<typeof import("../components/Dashboard/CallCenter/AgentAvgEarnings/AgentAvgEarningsChart.vue")['default']>
export const LazyDashboardCallCenterAgentAvgEarningsFiveChart: LazyComponent<typeof import("../components/Dashboard/CallCenter/AgentAvgEarnings/AgentAvgEarningsFiveChart.vue")['default']>
export const LazyDashboardCallCenterAgentAvgEarningsFourChart: LazyComponent<typeof import("../components/Dashboard/CallCenter/AgentAvgEarnings/AgentAvgEarningsFourChart.vue")['default']>
export const LazyDashboardCallCenterAgentAvgEarningsThreeChart: LazyComponent<typeof import("../components/Dashboard/CallCenter/AgentAvgEarnings/AgentAvgEarningsThreeChart.vue")['default']>
export const LazyDashboardCallCenterAgentAvgEarningsTwoChart: LazyComponent<typeof import("../components/Dashboard/CallCenter/AgentAvgEarnings/AgentAvgEarningsTwoChart.vue")['default']>
export const LazyDashboardCallCenterAgentAvgEarnings: LazyComponent<typeof import("../components/Dashboard/CallCenter/AgentAvgEarnings/index.vue")['default']>
export const LazyDashboardCallCenterAgentsPerformanceOverview: LazyComponent<typeof import("../components/Dashboard/CallCenter/AgentsPerformanceOverview.vue")['default']>
export const LazyDashboardCallCenterGeography: LazyComponent<typeof import("../components/Dashboard/CallCenter/CallCenterGeography.vue")['default']>
export const LazyDashboardCallCenterInboundCallsChart: LazyComponent<typeof import("../components/Dashboard/CallCenter/InboundCallsChart.vue")['default']>
export const LazyDashboardCallCenterOutboundCallsChart: LazyComponent<typeof import("../components/Dashboard/CallCenter/OutboundCallsChart.vue")['default']>
export const LazyDashboardCallCenterOverviewAnsweredCallsChart: LazyComponent<typeof import("../components/Dashboard/CallCenter/Overview/AnsweredCallsChart.vue")['default']>
export const LazyDashboardCallCenterOverviewMissedCallsChart: LazyComponent<typeof import("../components/Dashboard/CallCenter/Overview/MissedCallsChart.vue")['default']>
export const LazyDashboardCallCenterOverviewTotalCallsChart: LazyComponent<typeof import("../components/Dashboard/CallCenter/Overview/TotalCallsChart.vue")['default']>
export const LazyDashboardCallCenterOverview: LazyComponent<typeof import("../components/Dashboard/CallCenter/Overview/index.vue")['default']>
export const LazyDashboardCallCenterRecentCalls: LazyComponent<typeof import("../components/Dashboard/CallCenter/RecentCalls.vue")['default']>
export const LazyDashboardCreditCardCardsWithAmountChart: LazyComponent<typeof import("../components/Dashboard/CreditCard/CardsWithAmountChart.vue")['default']>
export const LazyDashboardCreditCardCreditUtilizationRatioChart: LazyComponent<typeof import("../components/Dashboard/CreditCard/CreditUtilizationRatioChart.vue")['default']>
export const LazyDashboardCreditCardDailyLimit: LazyComponent<typeof import("../components/Dashboard/CreditCard/DailyLimit.vue")['default']>
export const LazyDashboardCreditCardInterestChargeFeesChart: LazyComponent<typeof import("../components/Dashboard/CreditCard/InterestChargeFeesChart.vue")['default']>
export const LazyDashboardCreditCardMonthlySpendingChart: LazyComponent<typeof import("../components/Dashboard/CreditCard/MonthlySpendingChart.vue")['default']>
export const LazyDashboardCreditCardMyCards: LazyComponent<typeof import("../components/Dashboard/CreditCard/MyCards.vue")['default']>
export const LazyDashboardCreditCardQuickTransfer: LazyComponent<typeof import("../components/Dashboard/CreditCard/QuickTransfer.vue")['default']>
export const LazyDashboardCreditCardRecentTransactions: LazyComponent<typeof import("../components/Dashboard/CreditCard/RecentTransactions.vue")['default']>
export const LazyDashboardCreditCardSpendingBreakdownChart: LazyComponent<typeof import("../components/Dashboard/CreditCard/SpendingBreakdownChart.vue")['default']>
export const LazyDashboardCreditCardStatisticsChart: LazyComponent<typeof import("../components/Dashboard/CreditCard/StatisticsChart.vue")['default']>
export const LazyDashboardCreditCardTotalBalance: LazyComponent<typeof import("../components/Dashboard/CreditCard/TotalBalance.vue")['default']>
export const LazyDashboardCreditCardTotalExpense: LazyComponent<typeof import("../components/Dashboard/CreditCard/TotalExpense.vue")['default']>
export const LazyDashboardCryptoBinanceChart: LazyComponent<typeof import("../components/Dashboard/Crypto/BinanceChart.vue")['default']>
export const LazyDashboardCryptoBitcoinChart: LazyComponent<typeof import("../components/Dashboard/Crypto/BitcoinChart.vue")['default']>
export const LazyDashboardCryptoCardanoChart: LazyComponent<typeof import("../components/Dashboard/Crypto/CardanoChart.vue")['default']>
export const LazyDashboardCryptoRankings: LazyComponent<typeof import("../components/Dashboard/Crypto/CryptoRankings.vue")['default']>
export const LazyDashboardCryptoCryptocurrencyWatchList: LazyComponent<typeof import("../components/Dashboard/Crypto/CryptocurrencyWatchList.vue")['default']>
export const LazyDashboardCryptoEthereumChart: LazyComponent<typeof import("../components/Dashboard/Crypto/EthereumChart.vue")['default']>
export const LazyDashboardCryptoExchangeCoin: LazyComponent<typeof import("../components/Dashboard/Crypto/ExchangeCoin.vue")['default']>
export const LazyDashboardCryptoMarketPriceStatisticsChart: LazyComponent<typeof import("../components/Dashboard/Crypto/MarketPriceStatisticsChart.vue")['default']>
export const LazyDashboardCryptoPortfolio: LazyComponent<typeof import("../components/Dashboard/Crypto/Portfolio.vue")['default']>
export const LazyDashboardCryptoSolanaChart: LazyComponent<typeof import("../components/Dashboard/Crypto/SolanaChart.vue")['default']>
export const LazyDashboardCryptoTransactionHistory: LazyComponent<typeof import("../components/Dashboard/Crypto/TransactionHistory.vue")['default']>
export const LazyDashboardCryptoPerformanceBreadcrumb: LazyComponent<typeof import("../components/Dashboard/CryptoPerformance/Breadcrumb.vue")['default']>
export const LazyDashboardCryptoPerformanceComparativeAnalysisChart: LazyComponent<typeof import("../components/Dashboard/CryptoPerformance/ComparativeAnalysisChart.vue")['default']>
export const LazyDashboardCryptoPerformanceCryptoMarketCap: LazyComponent<typeof import("../components/Dashboard/CryptoPerformance/CryptoMarketCap.vue")['default']>
export const LazyDashboardCryptoPerformanceIndividualAssetPerformance: LazyComponent<typeof import("../components/Dashboard/CryptoPerformance/IndividualAssetPerformance.vue")['default']>
export const LazyDashboardCryptoPerformanceMarketPerformanceChart: LazyComponent<typeof import("../components/Dashboard/CryptoPerformance/MarketPerformanceChart.vue")['default']>
export const LazyDashboardCryptoPerformanceMetricsChart: LazyComponent<typeof import("../components/Dashboard/CryptoPerformance/PerformanceMetricsChart.vue")['default']>
export const LazyDashboardCryptoPerformancePerInvestmentChart: LazyComponent<typeof import("../components/Dashboard/CryptoPerformance/PerformancePerInvestmentChart.vue")['default']>
export const LazyDashboardCryptoPerformancePortfolioValue: LazyComponent<typeof import("../components/Dashboard/CryptoPerformance/PortfolioValue.vue")['default']>
export const LazyDashboardCryptoPerformanceRiskStabilityIndicatorsChart: LazyComponent<typeof import("../components/Dashboard/CryptoPerformance/RiskStabilityIndicatorsChart.vue")['default']>
export const LazyDashboardCryptoPerformanceTransactionsHistory: LazyComponent<typeof import("../components/Dashboard/CryptoPerformance/TransactionsHistory.vue")['default']>
export const LazyDashboardCryptoTraderAssetAllocationChart: LazyComponent<typeof import("../components/Dashboard/CryptoTrader/AssetAllocationChart.vue")['default']>
export const LazyDashboardCryptoTraderCryptoStatsPanel: LazyComponent<typeof import("../components/Dashboard/CryptoTrader/CryptoStatsPanel.vue")['default']>
export const LazyDashboardCryptoTraderGainersLosers: LazyComponent<typeof import("../components/Dashboard/CryptoTrader/GainersLosers.vue")['default']>
export const LazyDashboardCryptoTraderLivePriceTracker: LazyComponent<typeof import("../components/Dashboard/CryptoTrader/LivePriceTracker.vue")['default']>
export const LazyDashboardCryptoTraderMarketSentimentIndicatorChart: LazyComponent<typeof import("../components/Dashboard/CryptoTrader/MarketSentimentIndicatorChart.vue")['default']>
export const LazyDashboardCryptoTraderPortfolioDistributionChart: LazyComponent<typeof import("../components/Dashboard/CryptoTrader/PortfolioDistributionChart.vue")['default']>
export const LazyDashboardCryptoTraderPriceMovementChart: LazyComponent<typeof import("../components/Dashboard/CryptoTrader/PriceMovementChart.vue")['default']>
export const LazyDashboardCryptoTraderProfitLossChart: LazyComponent<typeof import("../components/Dashboard/CryptoTrader/ProfitLossChart.vue")['default']>
export const LazyDashboardCryptoTraderRecentTransactions: LazyComponent<typeof import("../components/Dashboard/CryptoTrader/RecentTransactions.vue")['default']>
export const LazyDashboardCryptoTraderRiskExposureChart: LazyComponent<typeof import("../components/Dashboard/CryptoTrader/RiskExposureChart.vue")['default']>
export const LazyDashboardCryptoTraderTradesPerMonthChart: LazyComponent<typeof import("../components/Dashboard/CryptoTrader/TradesPerMonthChart.vue")['default']>
export const LazyDashboardCryptoTraderTradingVolumeChart: LazyComponent<typeof import("../components/Dashboard/CryptoTrader/TradingVolumeChart.vue")['default']>
export const LazyDashboardDoctorWelcome: LazyComponent<typeof import("../components/Dashboard/Doctor/DoctorWelcome.vue")['default']>
export const LazyDashboardDoctorIncomeExpenseChart: LazyComponent<typeof import("../components/Dashboard/Doctor/IncomeExpenseChart.vue")['default']>
export const LazyDashboardDoctorMyRecentPatients: LazyComponent<typeof import("../components/Dashboard/Doctor/MyRecentPatients.vue")['default']>
export const LazyDashboardDoctorPatientDistributionChart: LazyComponent<typeof import("../components/Dashboard/Doctor/PatientDistributionChart.vue")['default']>
export const LazyDashboardDoctorPatientRetentionChart: LazyComponent<typeof import("../components/Dashboard/Doctor/PatientRetentionChart.vue")['default']>
export const LazyDashboardDoctorRecentLabReports: LazyComponent<typeof import("../components/Dashboard/Doctor/RecentLabReports.vue")['default']>
export const LazyDashboardDoctorStatsAppointments: LazyComponent<typeof import("../components/Dashboard/Doctor/Stats/Appointments.vue")['default']>
export const LazyDashboardDoctorStatsEarnings: LazyComponent<typeof import("../components/Dashboard/Doctor/Stats/Earnings.vue")['default']>
export const LazyDashboardDoctorStatsOperations: LazyComponent<typeof import("../components/Dashboard/Doctor/Stats/Operations.vue")['default']>
export const LazyDashboardDoctorStatsPatients: LazyComponent<typeof import("../components/Dashboard/Doctor/Stats/Patients.vue")['default']>
export const LazyDashboardDoctorStats: LazyComponent<typeof import("../components/Dashboard/Doctor/Stats/index.vue")['default']>
export const LazyDashboardDoctorTodaySchedule: LazyComponent<typeof import("../components/Dashboard/Doctor/TodaySchedule.vue")['default']>
export const LazyDashboardDoctorUpgradePlan: LazyComponent<typeof import("../components/Dashboard/Doctor/UpgradePlan.vue")['default']>
export const LazyDashboardFinanceAccountPayable: LazyComponent<typeof import("../components/Dashboard/Finance/AccountPayable.vue")['default']>
export const LazyDashboardFinanceAccountsReceivable: LazyComponent<typeof import("../components/Dashboard/Finance/AccountsReceivable.vue")['default']>
export const LazyDashboardFinanceAddCardDetailModal: LazyComponent<typeof import("../components/Dashboard/Finance/AddCardDetailModal.vue")['default']>
export const LazyDashboardFinanceCashEndOfTheMonthChart: LazyComponent<typeof import("../components/Dashboard/Finance/CashEndOfTheMonthChart.vue")['default']>
export const LazyDashboardFinanceDebitCard: LazyComponent<typeof import("../components/Dashboard/Finance/DebitCard.vue")['default']>
export const LazyDashboardFinanceExpenseBreakdownChart: LazyComponent<typeof import("../components/Dashboard/Finance/ExpenseBreakdownChart.vue")['default']>
export const LazyDashboardFinanceIncomeSourceChart: LazyComponent<typeof import("../components/Dashboard/Finance/IncomeSourceChart.vue")['default']>
export const LazyDashboardFinanceNetProfitChart: LazyComponent<typeof import("../components/Dashboard/Finance/NetProfitChart.vue")['default']>
export const LazyDashboardFinanceStaticChart: LazyComponent<typeof import("../components/Dashboard/Finance/StaticChart.vue")['default']>
export const LazyDashboardFinanceTotalExpenses: LazyComponent<typeof import("../components/Dashboard/Finance/TotalExpenses.vue")['default']>
export const LazyDashboardFinanceTotalIncome: LazyComponent<typeof import("../components/Dashboard/Finance/TotalIncome.vue")['default']>
export const LazyDashboardFinanceTransactionHistory: LazyComponent<typeof import("../components/Dashboard/Finance/TransactionHistory.vue")['default']>
export const LazyDashboardFinanceWeeklyExpensesChart: LazyComponent<typeof import("../components/Dashboard/Finance/WeeklyExpensesChart.vue")['default']>
export const LazyDashboardHRMDateRangePicker: LazyComponent<typeof import("../components/Dashboard/HRM/DateRangePicker.vue")['default']>
export const LazyDashboardHRMEmployeeAttendanceTrendsChart: LazyComponent<typeof import("../components/Dashboard/HRM/EmployeeAttendanceTrendsChart.vue")['default']>
export const LazyDashboardHRMEmployeeLeaveRequest: LazyComponent<typeof import("../components/Dashboard/HRM/EmployeeLeaveRequest.vue")['default']>
export const LazyDashboardHRMEmployeeList: LazyComponent<typeof import("../components/Dashboard/HRM/EmployeeList.vue")['default']>
export const LazyDashboardHRMEmployeeSalaryChart: LazyComponent<typeof import("../components/Dashboard/HRM/EmployeeSalaryChart.vue")['default']>
export const LazyDashboardHRMEmployeeWorkFormatChart: LazyComponent<typeof import("../components/Dashboard/HRM/EmployeeWorkFormatChart.vue")['default']>
export const LazyDashboardHRMNewEmployees: LazyComponent<typeof import("../components/Dashboard/HRM/NewEmployees.vue")['default']>
export const LazyDashboardHRMResignedEmployees: LazyComponent<typeof import("../components/Dashboard/HRM/ResignedEmployees.vue")['default']>
export const LazyDashboardHRMTotalEmployees: LazyComponent<typeof import("../components/Dashboard/HRM/TotalEmployees.vue")['default']>
export const LazyDashboardHRMWelcomeBack: LazyComponent<typeof import("../components/Dashboard/HRM/WelcomeBack.vue")['default']>
export const LazyDashboardHelpDeskCongratulations: LazyComponent<typeof import("../components/Dashboard/HelpDesk/Congratulations.vue")['default']>
export const LazyDashboardHelpDeskCustomerSatisfactionChart: LazyComponent<typeof import("../components/Dashboard/HelpDesk/CustomerSatisfactionChart.vue")['default']>
export const LazyDashboardHelpDeskNewAndSolvedTicketsChart: LazyComponent<typeof import("../components/Dashboard/HelpDesk/NewAndSolvedTicketsChart.vue")['default']>
export const LazyDashboardHelpDeskPerformanceOfAgents: LazyComponent<typeof import("../components/Dashboard/HelpDesk/PerformanceOfAgents.vue")['default']>
export const LazyDashboardHelpDeskRecentCustomerRatings: LazyComponent<typeof import("../components/Dashboard/HelpDesk/RecentCustomerRatings.vue")['default']>
export const LazyDashboardHelpDeskResponseTimeChart: LazyComponent<typeof import("../components/Dashboard/HelpDesk/ResponseTimeChart.vue")['default']>
export const LazyDashboardHelpDeskSupportOverviewChart: LazyComponent<typeof import("../components/Dashboard/HelpDesk/SupportOverviewChart.vue")['default']>
export const LazyDashboardHelpDeskTicketsDueChart: LazyComponent<typeof import("../components/Dashboard/HelpDesk/TicketsDueChart.vue")['default']>
export const LazyDashboardHelpDeskTicketsInProgressChart: LazyComponent<typeof import("../components/Dashboard/HelpDesk/TicketsInProgressChart.vue")['default']>
export const LazyDashboardHelpDeskTicketsNewOpenChart: LazyComponent<typeof import("../components/Dashboard/HelpDesk/TicketsNewOpenChart.vue")['default']>
export const LazyDashboardHelpDeskTicketsResolvedChart: LazyComponent<typeof import("../components/Dashboard/HelpDesk/TicketsResolvedChart.vue")['default']>
export const LazyDashboardHelpDeskTicketsStatusChart: LazyComponent<typeof import("../components/Dashboard/HelpDesk/TicketsStatusChart.vue")['default']>
export const LazyDashboardHelpDeskToDoList: LazyComponent<typeof import("../components/Dashboard/HelpDesk/ToDoList.vue")['default']>
export const LazyDashboardHospitalBedOccupancyRateChart: LazyComponent<typeof import("../components/Dashboard/Hospital/BedOccupancyRateChart.vue")['default']>
export const LazyDashboardHospitalCriticalPatientsChart: LazyComponent<typeof import("../components/Dashboard/Hospital/CriticalPatientsChart.vue")['default']>
export const LazyDashboardHospitalDateRangePicker: LazyComponent<typeof import("../components/Dashboard/Hospital/DateRangePicker.vue")['default']>
export const LazyDashboardHospitalEmergencyRoomVisitsChart: LazyComponent<typeof import("../components/Dashboard/Hospital/EmergencyRoomVisitsChart.vue")['default']>
export const LazyDashboardHospitalEarnings: LazyComponent<typeof import("../components/Dashboard/Hospital/HospitalEarnings.vue")['default']>
export const LazyDashboardHospitalOverallVisitorsChart: LazyComponent<typeof import("../components/Dashboard/Hospital/OverallVisitorsChart.vue")['default']>
export const LazyDashboardHospitalPatientAdmissionsDischargesChart: LazyComponent<typeof import("../components/Dashboard/Hospital/PatientAdmissionsDischargesChart.vue")['default']>
export const LazyDashboardHospitalPatientAppointments: LazyComponent<typeof import("../components/Dashboard/Hospital/PatientAppointments.vue")['default']>
export const LazyDashboardHospitalPatientByAgeChart: LazyComponent<typeof import("../components/Dashboard/Hospital/PatientByAgeChart.vue")['default']>
export const LazyDashboardHospitalPatientsChart: LazyComponent<typeof import("../components/Dashboard/Hospital/PatientsChart.vue")['default']>
export const LazyDashboardHospitalScheduleAppointment: LazyComponent<typeof import("../components/Dashboard/Hospital/ScheduleAppointment.vue")['default']>
export const LazyDashboardHospitalYourScheduleToday: LazyComponent<typeof import("../components/Dashboard/Hospital/YourScheduleToday.vue")['default']>
export const LazyDashboardHotelCustomerReviews: LazyComponent<typeof import("../components/Dashboard/Hotel/CustomerReviews.vue")['default']>
export const LazyDashboardHotelGuestActivityChart: LazyComponent<typeof import("../components/Dashboard/Hotel/GuestActivityChart.vue")['default']>
export const LazyDashboardHotelPopularRooms: LazyComponent<typeof import("../components/Dashboard/Hotel/PopularRooms.vue")['default']>
export const LazyDashboardHotelRecentBookings: LazyComponent<typeof import("../components/Dashboard/Hotel/RecentBookings.vue")['default']>
export const LazyDashboardHotelRoomsAvailabilityChart: LazyComponent<typeof import("../components/Dashboard/Hotel/RoomsAvailabilityChart.vue")['default']>
export const LazyDashboardHotelStatsCheckIn: LazyComponent<typeof import("../components/Dashboard/Hotel/Stats/CheckIn.vue")['default']>
export const LazyDashboardHotelStatsCheckOut: LazyComponent<typeof import("../components/Dashboard/Hotel/Stats/CheckOut.vue")['default']>
export const LazyDashboardHotelStatsNewBookings: LazyComponent<typeof import("../components/Dashboard/Hotel/Stats/NewBookings.vue")['default']>
export const LazyDashboardHotelStats: LazyComponent<typeof import("../components/Dashboard/Hotel/Stats/index.vue")['default']>
export const LazyDashboardHotelUpcomingVIPReservations: LazyComponent<typeof import("../components/Dashboard/Hotel/UpcomingVIPReservations.vue")['default']>
export const LazyDashboardLMSCourses: LazyComponent<typeof import("../components/Dashboard/LMS/Courses.vue")['default']>
export const LazyDashboardLMSCoursesSalesChart: LazyComponent<typeof import("../components/Dashboard/LMS/CoursesSalesChart.vue")['default']>
export const LazyDashboardLMSEnrolledByCountries: LazyComponent<typeof import("../components/Dashboard/LMS/EnrolledByCountries.vue")['default']>
export const LazyDashboardLMSGroupLessons: LazyComponent<typeof import("../components/Dashboard/LMS/GroupLessons.vue")['default']>
export const LazyDashboardLMSOurTopCourses: LazyComponent<typeof import("../components/Dashboard/LMS/OurTopCourses.vue")['default']>
export const LazyDashboardLMSStudentsInterestedTopicsChart: LazyComponent<typeof import("../components/Dashboard/LMS/StudentsInterestedTopicsChart.vue")['default']>
export const LazyDashboardLMSStudentsProgress: LazyComponent<typeof import("../components/Dashboard/LMS/StudentsProgress.vue")['default']>
export const LazyDashboardLMSTimeSpentChart: LazyComponent<typeof import("../components/Dashboard/LMS/TimeSpentChart.vue")['default']>
export const LazyDashboardLMSTopInstructors: LazyComponent<typeof import("../components/Dashboard/LMS/TopInstructors.vue")['default']>
export const LazyDashboardLMSTotalCourses: LazyComponent<typeof import("../components/Dashboard/LMS/TotalCourses.vue")['default']>
export const LazyDashboardLMSTotalEnrolled: LazyComponent<typeof import("../components/Dashboard/LMS/TotalEnrolled.vue")['default']>
export const LazyDashboardLMSTotalMentors: LazyComponent<typeof import("../components/Dashboard/LMS/TotalMentors.vue")['default']>
export const LazyDashboardLMSWelcomeDashboard: LazyComponent<typeof import("../components/Dashboard/LMS/WelcomeDashboard.vue")['default']>
export const LazyDashboardMarketingAvatarPreview: LazyComponent<typeof import("../components/Dashboard/Marketing/AvatarPreview.vue")['default']>
export const LazyDashboardMarketingCampaignsContent: LazyComponent<typeof import("../components/Dashboard/Marketing/CampaignsContent.vue")['default']>
export const LazyDashboardMarketingChannelsContent: LazyComponent<typeof import("../components/Dashboard/Marketing/ChannelsContent.vue")['default']>
export const LazyDashboardMarketingCreateCampaignsModal: LazyComponent<typeof import("../components/Dashboard/Marketing/CreateCampaignsModal.vue")['default']>
export const LazyDashboardMarketingExternalLinks: LazyComponent<typeof import("../components/Dashboard/Marketing/ExternalLinks.vue")['default']>
export const LazyDashboardMarketingHighlightsContent: LazyComponent<typeof import("../components/Dashboard/Marketing/HighlightsContent.vue")['default']>
export const LazyDashboardMarketingInstagramCampaignsChart: LazyComponent<typeof import("../components/Dashboard/Marketing/InstagramCampaignsChart.vue")['default']>
export const LazyDashboardMarketingInstagramSubscriberChart: LazyComponent<typeof import("../components/Dashboard/Marketing/InstagramSubscriberChart.vue")['default']>
export const LazyDashboardMarketingNewMarketingTool: LazyComponent<typeof import("../components/Dashboard/Marketing/NewMarketingTool.vue")['default']>
export const LazyDashboardMarketingNewMobileApp: LazyComponent<typeof import("../components/Dashboard/Marketing/NewMobileApp.vue")['default']>
export const LazyDashboardMarketingPerformanceOverviewChart: LazyComponent<typeof import("../components/Dashboard/Marketing/PerformanceOverviewChart.vue")['default']>
export const LazyDashboardMarketingStatusContent: LazyComponent<typeof import("../components/Dashboard/Marketing/StatusContent.vue")['default']>
export const LazyDashboardNFTActiveAuctions: LazyComponent<typeof import("../components/Dashboard/NFT/ActiveAuctions.vue")['default']>
export const LazyDashboardNFTCreateNFT: LazyComponent<typeof import("../components/Dashboard/NFT/CreateNFT.vue")['default']>
export const LazyDashboardNFTEthereumRateChart: LazyComponent<typeof import("../components/Dashboard/NFT/EthereumRateChart.vue")['default']>
export const LazyDashboardNFTEthereumRateFiveChart: LazyComponent<typeof import("../components/Dashboard/NFT/EthereumRateFiveChart.vue")['default']>
export const LazyDashboardNFTEthereumRateFourChart: LazyComponent<typeof import("../components/Dashboard/NFT/EthereumRateFourChart.vue")['default']>
export const LazyDashboardNFTEthereumRateTab: LazyComponent<typeof import("../components/Dashboard/NFT/EthereumRateTab.vue")['default']>
export const LazyDashboardNFTEthereumRateThreeChart: LazyComponent<typeof import("../components/Dashboard/NFT/EthereumRateThreeChart.vue")['default']>
export const LazyDashboardNFTEthereumRateTwoChart: LazyComponent<typeof import("../components/Dashboard/NFT/EthereumRateTwoChart.vue")['default']>
export const LazyDashboardNFTFeaturedNFTArtworks: LazyComponent<typeof import("../components/Dashboard/NFT/FeaturedNFTArtworks.vue")['default']>
export const LazyDashboardNFTHistoryOfBids: LazyComponent<typeof import("../components/Dashboard/NFT/HistoryOfBids.vue")['default']>
export const LazyDashboardNFTManageYourNFT: LazyComponent<typeof import("../components/Dashboard/NFT/ManageYourNFT.vue")['default']>
export const LazyDashboardNFTMostPopularSellers: LazyComponent<typeof import("../components/Dashboard/NFT/MostPopularSellers.vue")['default']>
export const LazyDashboardNFTSlideItem: LazyComponent<typeof import("../components/Dashboard/NFT/NFTSlideItem.vue")['default']>
export const LazyDashboardNFTNewMobileApp: LazyComponent<typeof import("../components/Dashboard/NFT/NewMobileApp.vue")['default']>
export const LazyDashboardNFTTopCollections: LazyComponent<typeof import("../components/Dashboard/NFT/TopCollections.vue")['default']>
export const LazyDashboardNFTTopNFTs: LazyComponent<typeof import("../components/Dashboard/NFT/TopNFTs.vue")['default']>
export const LazyDashboardNFTWorldwideTopCreators: LazyComponent<typeof import("../components/Dashboard/NFT/WorldwideTopCreators.vue")['default']>
export const LazyDashboardPOSSystemCategoriesTab: LazyComponent<typeof import("../components/Dashboard/POSSystem/CategoriesTab.vue")['default']>
export const LazyDashboardPOSSystemCustomerSegmentation: LazyComponent<typeof import("../components/Dashboard/POSSystem/CustomerSegmentation.vue")['default']>
export const LazyDashboardPOSSystemOrderDetails: LazyComponent<typeof import("../components/Dashboard/POSSystem/OrderDetails.vue")['default']>
export const LazyDashboardPOSSystemQuantityCounter: LazyComponent<typeof import("../components/Dashboard/POSSystem/QuantityCounter.vue")['default']>
export const LazyDashboardPOSSystemSalesAnalyticsSalesByCategory: LazyComponent<typeof import("../components/Dashboard/POSSystem/SalesAnalytics/SalesByCategory.vue")['default']>
export const LazyDashboardPOSSystemSalesAnalyticsSalesOverTime: LazyComponent<typeof import("../components/Dashboard/POSSystem/SalesAnalytics/SalesOverTime.vue")['default']>
export const LazyDashboardPOSSystemSalesAnalytics: LazyComponent<typeof import("../components/Dashboard/POSSystem/SalesAnalytics/index.vue")['default']>
export const LazyDashboardPOSSystemStats: LazyComponent<typeof import("../components/Dashboard/POSSystem/Stats.vue")['default']>
export const LazyDashboardPodcastFeatured: LazyComponent<typeof import("../components/Dashboard/Podcast/Featured.vue")['default']>
export const LazyDashboardPodcastListenerAnalyticsChart: LazyComponent<typeof import("../components/Dashboard/Podcast/ListenerAnalyticsChart.vue")['default']>
export const LazyDashboardPodcastMostPopular: LazyComponent<typeof import("../components/Dashboard/Podcast/MostPopular.vue")['default']>
export const LazyDashboardPodcastPlayer: LazyComponent<typeof import("../components/Dashboard/Podcast/Player.vue")['default']>
export const LazyDashboardPodcastPopularHosts: LazyComponent<typeof import("../components/Dashboard/Podcast/PopularHosts.vue")['default']>
export const LazyDashboardPodcastRecentlyPlayed: LazyComponent<typeof import("../components/Dashboard/Podcast/RecentlyPlayed.vue")['default']>
export const LazyDashboardPodcastSalesByGenderChart: LazyComponent<typeof import("../components/Dashboard/Podcast/SalesByGenderChart.vue")['default']>
export const LazyDashboardPodcastTodayEarningsChart: LazyComponent<typeof import("../components/Dashboard/Podcast/TodayEarningsChart.vue")['default']>
export const LazyDashboardPodcastTopPodcasts: LazyComponent<typeof import("../components/Dashboard/Podcast/TopPodcasts.vue")['default']>
export const LazyDashboardPodcastUpcomingEpisodes: LazyComponent<typeof import("../components/Dashboard/Podcast/UpcomingEpisodes.vue")['default']>
export const LazyDashboardProjectManagementAllProjects: LazyComponent<typeof import("../components/Dashboard/ProjectManagement/AllProjects.vue")['default']>
export const LazyDashboardProjectManagementMyTasks: LazyComponent<typeof import("../components/Dashboard/ProjectManagement/MyTasks.vue")['default']>
export const LazyDashboardProjectManagementProjectsAnalysisChart: LazyComponent<typeof import("../components/Dashboard/ProjectManagement/ProjectsAnalysisChart.vue")['default']>
export const LazyDashboardProjectManagementProjectsOverview: LazyComponent<typeof import("../components/Dashboard/ProjectManagement/ProjectsOverview.vue")['default']>
export const LazyDashboardProjectManagementProjectsProgressChart: LazyComponent<typeof import("../components/Dashboard/ProjectManagement/ProjectsProgressChart.vue")['default']>
export const LazyDashboardProjectManagementProjectsRoadmapChart: LazyComponent<typeof import("../components/Dashboard/ProjectManagement/ProjectsRoadmapChart.vue")['default']>
export const LazyDashboardProjectManagementTasksOverviewChart: LazyComponent<typeof import("../components/Dashboard/ProjectManagement/TasksOverviewChart.vue")['default']>
export const LazyDashboardProjectManagementTeamMembers: LazyComponent<typeof import("../components/Dashboard/ProjectManagement/TeamMembers.vue")['default']>
export const LazyDashboardProjectManagementToDoList: LazyComponent<typeof import("../components/Dashboard/ProjectManagement/ToDoList.vue")['default']>
export const LazyDashboardProjectManagementWorkingSchedule: LazyComponent<typeof import("../components/Dashboard/ProjectManagement/WorkingSchedule.vue")['default']>
export const LazyDashboardRealEstateActiveTotalProperty: LazyComponent<typeof import("../components/Dashboard/RealEstate/ActiveTotalProperty.vue")['default']>
export const LazyDashboardRealEstateCustomerReviews: LazyComponent<typeof import("../components/Dashboard/RealEstate/CustomerReviews.vue")['default']>
export const LazyDashboardRealEstateLatestTransaction: LazyComponent<typeof import("../components/Dashboard/RealEstate/LatestTransaction.vue")['default']>
export const LazyDashboardRealEstateMostSalesLocation: LazyComponent<typeof import("../components/Dashboard/RealEstate/MostSalesLocation.vue")['default']>
export const LazyDashboardRealEstateNewCustomers: LazyComponent<typeof import("../components/Dashboard/RealEstate/NewCustomers.vue")['default']>
export const LazyDashboardRealEstateNewListingsSoldPropertiesChart: LazyComponent<typeof import("../components/Dashboard/RealEstate/NewListingsSoldPropertiesChart.vue")['default']>
export const LazyDashboardRealEstatePropertiesForRentChart: LazyComponent<typeof import("../components/Dashboard/RealEstate/PropertiesForRentChart.vue")['default']>
export const LazyDashboardRealEstatePropertiesForSaleChart: LazyComponent<typeof import("../components/Dashboard/RealEstate/PropertiesForSaleChart.vue")['default']>
export const LazyDashboardRealEstateRecentProperty: LazyComponent<typeof import("../components/Dashboard/RealEstate/RecentProperty.vue")['default']>
export const LazyDashboardRealEstateRentalIncomeChart: LazyComponent<typeof import("../components/Dashboard/RealEstate/RentalIncomeChart.vue")['default']>
export const LazyDashboardRealEstateRevenueChart: LazyComponent<typeof import("../components/Dashboard/RealEstate/RevenueChart.vue")['default']>
export const LazyDashboardRealEstateSocialSearchChart: LazyComponent<typeof import("../components/Dashboard/RealEstate/SocialSearchChart.vue")['default']>
export const LazyDashboardRealEstateTopProperty: LazyComponent<typeof import("../components/Dashboard/RealEstate/TopProperty.vue")['default']>
export const LazyDashboardRealEstateAgentClientRatings: LazyComponent<typeof import("../components/Dashboard/RealEstateAgent/ClientRatings.vue")['default']>
export const LazyDashboardRealEstateAgentDownloadApp: LazyComponent<typeof import("../components/Dashboard/RealEstateAgent/DownloadApp.vue")['default']>
export const LazyDashboardRealEstateAgentLatestTransactions: LazyComponent<typeof import("../components/Dashboard/RealEstateAgent/LatestTransactions.vue")['default']>
export const LazyDashboardRealEstateAgentMyFeaturedListings: LazyComponent<typeof import("../components/Dashboard/RealEstateAgent/MyFeaturedListings.vue")['default']>
export const LazyDashboardRealEstateAgentRecentClients: LazyComponent<typeof import("../components/Dashboard/RealEstateAgent/RecentClients.vue")['default']>
export const LazyDashboardRealEstateAgentRevenueGoalProgress: LazyComponent<typeof import("../components/Dashboard/RealEstateAgent/RevenueGoalProgress.vue")['default']>
export const LazyDashboardRealEstateAgentSalesByCountry: LazyComponent<typeof import("../components/Dashboard/RealEstateAgent/SalesByCountry.vue")['default']>
export const LazyDashboardRealEstateAgentStats: LazyComponent<typeof import("../components/Dashboard/RealEstateAgent/Stats.vue")['default']>
export const LazyDashboardRealEstateAgentTopChannels: LazyComponent<typeof import("../components/Dashboard/RealEstateAgent/TopChannels.vue")['default']>
export const LazyDashboardRealEstateAgentTotalRevenueChart: LazyComponent<typeof import("../components/Dashboard/RealEstateAgent/TotalRevenueChart.vue")['default']>
export const LazyDashboardRealEstateAgentWelcomeRealEstateAgent: LazyComponent<typeof import("../components/Dashboard/RealEstateAgent/WelcomeRealEstateAgent.vue")['default']>
export const LazyDashboardRestaurantCustomerRatings: LazyComponent<typeof import("../components/Dashboard/Restaurant/CustomerRatings.vue")['default']>
export const LazyDashboardRestaurantExpense: LazyComponent<typeof import("../components/Dashboard/Restaurant/Expense.vue")['default']>
export const LazyDashboardRestaurantLowStockAlerts: LazyComponent<typeof import("../components/Dashboard/Restaurant/LowStockAlerts.vue")['default']>
export const LazyDashboardRestaurantOrderSummaryChart: LazyComponent<typeof import("../components/Dashboard/Restaurant/OrderSummaryChart.vue")['default']>
export const LazyDashboardRestaurantPendingOrdersChart: LazyComponent<typeof import("../components/Dashboard/Restaurant/PendingOrdersChart.vue")['default']>
export const LazyDashboardRestaurantRecentOrdersList: LazyComponent<typeof import("../components/Dashboard/Restaurant/RecentOrdersList.vue")['default']>
export const LazyDashboardRestaurantStatsToday: LazyComponent<typeof import("../components/Dashboard/Restaurant/RestaurantStatsToday.vue")['default']>
export const LazyDashboardRestaurantRevenue: LazyComponent<typeof import("../components/Dashboard/Restaurant/Revenue.vue")['default']>
export const LazyDashboardRestaurantRevenueByBranches: LazyComponent<typeof import("../components/Dashboard/Restaurant/RevenueByBranches.vue")['default']>
export const LazyDashboardRestaurantRevenueExpenseChart: LazyComponent<typeof import("../components/Dashboard/Restaurant/RevenueExpenseChart.vue")['default']>
export const LazyDashboardRestaurantStaffPerformanceScores: LazyComponent<typeof import("../components/Dashboard/Restaurant/StaffPerformanceScores.vue")['default']>
export const LazyDashboardRestaurantTickets: LazyComponent<typeof import("../components/Dashboard/Restaurant/Tickets.vue")['default']>
export const LazyDashboardRestaurantTopSellingItems: LazyComponent<typeof import("../components/Dashboard/Restaurant/TopSellingItems.vue")['default']>
export const LazyDashboardRestaurantTotalOrdersChart: LazyComponent<typeof import("../components/Dashboard/Restaurant/TotalOrdersChart.vue")['default']>
export const LazyDashboardSaaSActiveUserChart: LazyComponent<typeof import("../components/Dashboard/SaaS/ActiveUserChart.vue")['default']>
export const LazyDashboardSaaSActiveUsers: LazyComponent<typeof import("../components/Dashboard/SaaS/ActiveUsers.vue")['default']>
export const LazyDashboardSaaSActiveUsersChart: LazyComponent<typeof import("../components/Dashboard/SaaS/ActiveUsersChart.vue")['default']>
export const LazyDashboardSaaSConversionChart: LazyComponent<typeof import("../components/Dashboard/SaaS/ConversionChart.vue")['default']>
export const LazyDashboardSaaSGrossRevenueChart: LazyComponent<typeof import("../components/Dashboard/SaaS/GrossRevenueChart.vue")['default']>
export const LazyDashboardSaaSLatestTransaction: LazyComponent<typeof import("../components/Dashboard/SaaS/LatestTransaction.vue")['default']>
export const LazyDashboardSaaSPaymentChart: LazyComponent<typeof import("../components/Dashboard/SaaS/PaymentChart.vue")['default']>
export const LazyDashboardSaaSProductTradeConditionChart: LazyComponent<typeof import("../components/Dashboard/SaaS/ProductTradeConditionChart.vue")['default']>
export const LazyDashboardSaaSRevenueChart: LazyComponent<typeof import("../components/Dashboard/SaaS/RevenueChart.vue")['default']>
export const LazyDashboardSaaSSalesByCountry: LazyComponent<typeof import("../components/Dashboard/SaaS/SalesByCountry.vue")['default']>
export const LazyDashboardSaaSTopRefers: LazyComponent<typeof import("../components/Dashboard/SaaS/TopRefers.vue")['default']>
export const LazyDashboardSaaSUpgradePlans: LazyComponent<typeof import("../components/Dashboard/SaaS/UpgradePlans.vue")['default']>
export const LazyDashboardSalesGrossEarningsChart: LazyComponent<typeof import("../components/Dashboard/Sales/GrossEarningsChart.vue")['default']>
export const LazyDashboardSalesRealTimeSalesChart: LazyComponent<typeof import("../components/Dashboard/Sales/RealTimeSalesChart.vue")['default']>
export const LazyDashboardSalesRecentEarningsChart: LazyComponent<typeof import("../components/Dashboard/Sales/RecentEarningsChart.vue")['default']>
export const LazyDashboardSalesRecentOrders: LazyComponent<typeof import("../components/Dashboard/Sales/RecentOrders.vue")['default']>
export const LazyDashboardSalesByLocations: LazyComponent<typeof import("../components/Dashboard/Sales/SalesByLocations.vue")['default']>
export const LazyDashboardSalesOverviewChart: LazyComponent<typeof import("../components/Dashboard/Sales/SalesOverviewChart.vue")['default']>
export const LazyDashboardSalesTotalOrdersChart: LazyComponent<typeof import("../components/Dashboard/Sales/TotalOrdersChart.vue")['default']>
export const LazyDashboardSalesTotalProfitChart: LazyComponent<typeof import("../components/Dashboard/Sales/TotalProfitChart.vue")['default']>
export const LazyDashboardSalesTotalRevenueChart: LazyComponent<typeof import("../components/Dashboard/Sales/TotalRevenueChart.vue")['default']>
export const LazyDashboardSalesTotalSalesChart: LazyComponent<typeof import("../components/Dashboard/Sales/TotalSalesChart.vue")['default']>
export const LazyDashboardSalesTransactionHistory: LazyComponent<typeof import("../components/Dashboard/Sales/TransactionHistory.vue")['default']>
export const LazyDashboardSalesWelcomeBack: LazyComponent<typeof import("../components/Dashboard/Sales/WelcomeBack.vue")['default']>
export const LazyDashboardSchoolAttendanceAnalyticsChart: LazyComponent<typeof import("../components/Dashboard/School/AttendanceAnalyticsChart.vue")['default']>
export const LazyDashboardSchoolNewAdmissionsChart: LazyComponent<typeof import("../components/Dashboard/School/NewAdmissionsChart.vue")['default']>
export const LazyDashboardSchoolNoticeBoard: LazyComponent<typeof import("../components/Dashboard/School/NoticeBoard.vue")['default']>
export const LazyDashboardSchoolOverview: LazyComponent<typeof import("../components/Dashboard/School/SchoolOverview.vue")['default']>
export const LazyDashboardSchoolStatsAttendanceToday: LazyComponent<typeof import("../components/Dashboard/School/Stats/AttendanceToday.vue")['default']>
export const LazyDashboardSchoolStatsTotalStudents: LazyComponent<typeof import("../components/Dashboard/School/Stats/TotalStudents.vue")['default']>
export const LazyDashboardSchoolStatsTotalTeachers: LazyComponent<typeof import("../components/Dashboard/School/Stats/TotalTeachers.vue")['default']>
export const LazyDashboardSchoolStats: LazyComponent<typeof import("../components/Dashboard/School/Stats/index.vue")['default']>
export const LazyDashboardSchoolStudentsList: LazyComponent<typeof import("../components/Dashboard/School/StudentsList.vue")['default']>
export const LazyDashboardSchoolStudentsOverviewChart: LazyComponent<typeof import("../components/Dashboard/School/StudentsOverviewChart.vue")['default']>
export const LazyDashboardSchoolTeachers: LazyComponent<typeof import("../components/Dashboard/School/Teachers.vue")['default']>
export const LazyDashboardSchoolUpcomingEvents: LazyComponent<typeof import("../components/Dashboard/School/UpcomingEvents.vue")['default']>
export const LazyDashboardShipmentAverageDeliveryTimeChart: LazyComponent<typeof import("../components/Dashboard/Shipment/AverageDeliveryTimeChart.vue")['default']>
export const LazyDashboardShipmentChatContent: LazyComponent<typeof import("../components/Dashboard/Shipment/ChatContent.vue")['default']>
export const LazyDashboardShipmentLiveShipmentStatusChart: LazyComponent<typeof import("../components/Dashboard/Shipment/LiveShipmentStatusChart.vue")['default']>
export const LazyDashboardShipmentOnTimeDeliveryChart: LazyComponent<typeof import("../components/Dashboard/Shipment/OnTimeDeliveryChart.vue")['default']>
export const LazyDashboardShipmentDeliveredChart: LazyComponent<typeof import("../components/Dashboard/Shipment/ShipmentDeliveredChart.vue")['default']>
export const LazyDashboardShipmentList: LazyComponent<typeof import("../components/Dashboard/Shipment/ShipmentList.vue")['default']>
export const LazyDashboardShipmentToTopCountries: LazyComponent<typeof import("../components/Dashboard/Shipment/ShipmentToTopCountries.vue")['default']>
export const LazyDashboardShipmentTodaysShipmentsChart: LazyComponent<typeof import("../components/Dashboard/Shipment/TodaysShipmentsChart.vue")['default']>
export const LazyDashboardShipmentTopShippingMethodsChart: LazyComponent<typeof import("../components/Dashboard/Shipment/TopShippingMethodsChart.vue")['default']>
export const LazyDashboardShipmentTotalCustomer: LazyComponent<typeof import("../components/Dashboard/Shipment/TotalCustomer.vue")['default']>
export const LazyDashboardShipmentTotalIncome: LazyComponent<typeof import("../components/Dashboard/Shipment/TotalIncome.vue")['default']>
export const LazyDashboardShipmentTotalOrder: LazyComponent<typeof import("../components/Dashboard/Shipment/TotalOrder.vue")['default']>
export const LazyDashboardShipmentTotalShipment: LazyComponent<typeof import("../components/Dashboard/Shipment/TotalShipment.vue")['default']>
export const LazyDashboardShipmentTrackingOrder: LazyComponent<typeof import("../components/Dashboard/Shipment/TrackingOrder.vue")['default']>
export const LazyDashboardSocialMediaFacebookCampaignOverviewChart: LazyComponent<typeof import("../components/Dashboard/SocialMedia/FacebookCampaignOverviewChart.vue")['default']>
export const LazyDashboardSocialMediaFacebookFollowers: LazyComponent<typeof import("../components/Dashboard/SocialMedia/FacebookFollowers.vue")['default']>
export const LazyDashboardSocialMediaFollowersByGenderChart: LazyComponent<typeof import("../components/Dashboard/SocialMedia/FollowersByGenderChart.vue")['default']>
export const LazyDashboardSocialMediaInstagramFollowers: LazyComponent<typeof import("../components/Dashboard/SocialMedia/InstagramFollowers.vue")['default']>
export const LazyDashboardSocialMediaLinkedInFollowers: LazyComponent<typeof import("../components/Dashboard/SocialMedia/LinkedInFollowers.vue")['default']>
export const LazyDashboardSocialMediaLinkedInNetFollowersChart: LazyComponent<typeof import("../components/Dashboard/SocialMedia/LinkedInNetFollowersChart.vue")['default']>
export const LazyDashboardSocialMediaRecentInstagramFollowers: LazyComponent<typeof import("../components/Dashboard/SocialMedia/RecentInstagramFollowers.vue")['default']>
export const LazyDashboardSocialMediaSuggestions: LazyComponent<typeof import("../components/Dashboard/SocialMedia/Suggestions.vue")['default']>
export const LazyDashboardSocialMediaTikTokFollowers: LazyComponent<typeof import("../components/Dashboard/SocialMedia/TikTokFollowers.vue")['default']>
export const LazyDashboardSocialMediaUpgradePlan: LazyComponent<typeof import("../components/Dashboard/SocialMedia/UpgradePlan.vue")['default']>
export const LazyDashboardSocialMediaXFollowers: LazyComponent<typeof import("../components/Dashboard/SocialMedia/XFollowers.vue")['default']>
export const LazyDashboardSocialMediaYouTubeSubscribers: LazyComponent<typeof import("../components/Dashboard/SocialMedia/YouTubeSubscribers.vue")['default']>
export const LazyDashboardStoreAnalysisCustomerVisits: LazyComponent<typeof import("../components/Dashboard/StoreAnalysis/CustomerVisits.vue")['default']>
export const LazyDashboardStoreAnalysisGrossRevenue: LazyComponent<typeof import("../components/Dashboard/StoreAnalysis/GrossRevenue.vue")['default']>
export const LazyDashboardStoreAnalysisRecentSales: LazyComponent<typeof import("../components/Dashboard/StoreAnalysis/RecentSales.vue")['default']>
export const LazyDashboardStoreAnalysisSAWelcome: LazyComponent<typeof import("../components/Dashboard/StoreAnalysis/SAWelcome.vue")['default']>
export const LazyDashboardStoreAnalysisSalesByCategoryChart: LazyComponent<typeof import("../components/Dashboard/StoreAnalysis/SalesByCategoryChart.vue")['default']>
export const LazyDashboardStoreAnalysisSalesByGenderChart: LazyComponent<typeof import("../components/Dashboard/StoreAnalysis/SalesByGenderChart.vue")['default']>
export const LazyDashboardStoreAnalysisSalesThisMonthChart: LazyComponent<typeof import("../components/Dashboard/StoreAnalysis/SalesThisMonthChart.vue")['default']>
export const LazyDashboardStoreAnalysisStats: LazyComponent<typeof import("../components/Dashboard/StoreAnalysis/Stats.vue")['default']>
export const LazyDashboardStoreAnalysisStockAlerts: LazyComponent<typeof import("../components/Dashboard/StoreAnalysis/StockAlerts.vue")['default']>
export const LazyDashboardStoreAnalysisTopSellingProducts: LazyComponent<typeof import("../components/Dashboard/StoreAnalysis/TopSellingProducts.vue")['default']>
export const LazyDashboardECommerceOrderSummaryChart: LazyComponent<typeof import("../components/Dashboard/eCommerce/OrderSummaryChart.vue")['default']>
export const LazyDashboardECommerceRecentOrders: LazyComponent<typeof import("../components/Dashboard/eCommerce/RecentOrders.vue")['default']>
export const LazyDashboardECommerceRecentTransactions: LazyComponent<typeof import("../components/Dashboard/eCommerce/RecentTransactions.vue")['default']>
export const LazyDashboardECommerceReturningCustomerRateChart: LazyComponent<typeof import("../components/Dashboard/eCommerce/ReturningCustomerRateChart.vue")['default']>
export const LazyDashboardECommerceSalesByLocations: LazyComponent<typeof import("../components/Dashboard/eCommerce/SalesByLocations.vue")['default']>
export const LazyDashboardECommerceTopSellingProducts: LazyComponent<typeof import("../components/Dashboard/eCommerce/TopSellingProducts.vue")['default']>
export const LazyDashboardECommerceTotalCustomersChart: LazyComponent<typeof import("../components/Dashboard/eCommerce/TotalCustomersChart.vue")['default']>
export const LazyDashboardECommerceTotalOrdersChart: LazyComponent<typeof import("../components/Dashboard/eCommerce/TotalOrdersChart.vue")['default']>
export const LazyDashboardECommerceTotalRevenueChart: LazyComponent<typeof import("../components/Dashboard/eCommerce/TotalRevenueChart.vue")['default']>
export const LazyDashboardECommerceTotalSalesChart: LazyComponent<typeof import("../components/Dashboard/eCommerce/TotalSalesChart.vue")['default']>
export const LazyDashboardECommerceWelcomeDashboard: LazyComponent<typeof import("../components/Dashboard/eCommerce/WelcomeDashboard.vue")['default']>
export const LazyFrontPagesCommonBackToUp: LazyComponent<typeof import("../components/FrontPages/Common/BackToUp.vue")['default']>
export const LazyFrontPagesCommonCTA: LazyComponent<typeof import("../components/FrontPages/Common/CTA.vue")['default']>
export const LazyFrontPagesCommonContactUs: LazyComponent<typeof import("../components/FrontPages/Common/ContactUs.vue")['default']>
export const LazyFrontPagesCommonCopyRight: LazyComponent<typeof import("../components/FrontPages/Common/CopyRight.vue")['default']>
export const LazyFrontPagesCommonFAQ: LazyComponent<typeof import("../components/FrontPages/Common/FAQ.vue")['default']>
export const LazyFrontPagesCommonFooter: LazyComponent<typeof import("../components/FrontPages/Common/Footer.vue")['default']>
export const LazyFrontPagesCommonKeyFeatures: LazyComponent<typeof import("../components/FrontPages/Common/KeyFeatures.vue")['default']>
export const LazyFrontPagesCommonNavbar: LazyComponent<typeof import("../components/FrontPages/Common/Navbar.vue")['default']>
export const LazyFrontPagesCommonOurTeam: LazyComponent<typeof import("../components/FrontPages/Common/OurTeam.vue")['default']>
export const LazyFrontPagesCommonPageTitle: LazyComponent<typeof import("../components/FrontPages/Common/PageTitle.vue")['default']>
export const LazyFrontPagesHomeBanner: LazyComponent<typeof import("../components/FrontPages/Home/Banner.vue")['default']>
export const LazyFrontPagesHomeTailorYourDashboard: LazyComponent<typeof import("../components/FrontPages/Home/TailorYourDashboard.vue")['default']>
export const LazyFrontPagesHomeTestimonials: LazyComponent<typeof import("../components/FrontPages/Home/Testimonials.vue")['default']>
export const LazyLayoutAddNewCardModal: LazyComponent<typeof import("../components/Layout/AddNewCardModal.vue")['default']>
export const LazyLayoutAddNewCategorieModal: LazyComponent<typeof import("../components/Layout/AddNewCategorieModal.vue")['default']>
export const LazyLayoutAddNewContactModal: LazyComponent<typeof import("../components/Layout/AddNewContactModal.vue")['default']>
export const LazyLayoutAddNewCustomerModal: LazyComponent<typeof import("../components/Layout/AddNewCustomerModal.vue")['default']>
export const LazyLayoutAddNewDealsModal: LazyComponent<typeof import("../components/Layout/AddNewDealsModal.vue")['default']>
export const LazyLayoutAddNewFileModal: LazyComponent<typeof import("../components/Layout/AddNewFileModal.vue")['default']>
export const LazyLayoutAddNewInstructorsModal: LazyComponent<typeof import("../components/Layout/AddNewInstructorsModal.vue")['default']>
export const LazyLayoutAddNewLabelModal: LazyComponent<typeof import("../components/Layout/AddNewLabelModal.vue")['default']>
export const LazyLayoutAddNewLeadModal: LazyComponent<typeof import("../components/Layout/AddNewLeadModal.vue")['default']>
export const LazyLayoutAddNewOrderModal: LazyComponent<typeof import("../components/Layout/AddNewOrderModal.vue")['default']>
export const LazyLayoutAddNewUserModal: LazyComponent<typeof import("../components/Layout/AddNewUserModal.vue")['default']>
export const LazyLayoutCreateTaskModal: LazyComponent<typeof import("../components/Layout/CreateTaskModal.vue")['default']>
export const LazyLayoutLeftSidebar: LazyComponent<typeof import("../components/Layout/LeftSidebar/index.vue")['default']>
export const LazyLayoutMainFooter: LazyComponent<typeof import("../components/Layout/MainFooter.vue")['default']>
export const LazyLayoutPreloader: LazyComponent<typeof import("../components/Layout/Preloader.vue")['default']>
export const LazyLayoutSettingsSidebarCardStyleBG: LazyComponent<typeof import("../components/Layout/SettingsSidebar/CardStyleBG.vue")['default']>
export const LazyLayoutSettingsSidebarCardStyleRadius: LazyComponent<typeof import("../components/Layout/SettingsSidebar/CardStyleRadius.vue")['default']>
export const LazyLayoutSettingsSidebarContainerStyleBtn: LazyComponent<typeof import("../components/Layout/SettingsSidebar/ContainerStyleBtn.vue")['default']>
export const LazyLayoutSettingsSidebarHorizontalLayout: LazyComponent<typeof import("../components/Layout/SettingsSidebar/HorizontalLayout.vue")['default']>
export const LazyLayoutSettingsSidebarOnlyFooterDark: LazyComponent<typeof import("../components/Layout/SettingsSidebar/OnlyFooterDark.vue")['default']>
export const LazyLayoutSettingsSidebarOnlyHeaderDark: LazyComponent<typeof import("../components/Layout/SettingsSidebar/OnlyHeaderDark.vue")['default']>
export const LazyLayoutSettingsSidebarOnlySidebarDark: LazyComponent<typeof import("../components/Layout/SettingsSidebar/OnlySidebarDark.vue")['default']>
export const LazyLayoutSettingsSidebarRTLModeSwitch: LazyComponent<typeof import("../components/Layout/SettingsSidebar/RTLModeSwitch.vue")['default']>
export const LazyLayoutSettingsSidebar: LazyComponent<typeof import("../components/Layout/SettingsSidebar/index.vue")['default']>
export const LazyLayoutTopHeaderAdminProfile: LazyComponent<typeof import("../components/Layout/TopHeader/AdminProfile.vue")['default']>
export const LazyLayoutTopHeaderDarkSwtichBtn: LazyComponent<typeof import("../components/Layout/TopHeader/DarkSwtichBtn.vue")['default']>
export const LazyLayoutTopHeaderLanguageMenu: LazyComponent<typeof import("../components/Layout/TopHeader/LanguageMenu.vue")['default']>
export const LazyLayoutTopHeaderNavbar: LazyComponent<typeof import("../components/Layout/TopHeader/Navbar.vue")['default']>
export const LazyLayoutTopHeaderNotificationsLists: LazyComponent<typeof import("../components/Layout/TopHeader/NotificationsLists.vue")['default']>
export const LazyLayoutTopHeaderSearchFrom: LazyComponent<typeof import("../components/Layout/TopHeader/SearchFrom.vue")['default']>
export const LazyLayoutTopHeaderSettingsBtn: LazyComponent<typeof import("../components/Layout/TopHeader/SettingsBtn.vue")['default']>
export const LazyLayoutTopHeaderToggleFullscreenBtn: LazyComponent<typeof import("../components/Layout/TopHeader/ToggleFullscreenBtn.vue")['default']>
export const LazyLayoutTopHeaderWebApps: LazyComponent<typeof import("../components/Layout/TopHeader/WebApps.vue")['default']>
export const LazyLayoutTopHeader: LazyComponent<typeof import("../components/Layout/TopHeader/index.vue")['default']>
export const LazyModulesAuthenticationConfirmMail: LazyComponent<typeof import("../components/Modules/Authentication/ConfirmMail/index.vue")['default']>
export const LazyModulesAuthenticationForgetPassword: LazyComponent<typeof import("../components/Modules/Authentication/ForgetPassword/index.vue")['default']>
export const LazyModulesAuthenticationLockScreen: LazyComponent<typeof import("../components/Modules/Authentication/LockScreen/index.vue")['default']>
export const LazyModulesAuthenticationLogOut: LazyComponent<typeof import("../components/Modules/Authentication/LogOut/index.vue")['default']>
export const LazyModulesAuthenticationLogin: LazyComponent<typeof import("../components/Modules/Authentication/Login/index.vue")['default']>
export const LazyModulesAuthenticationRegister: LazyComponent<typeof import("../components/Modules/Authentication/Register/index.vue")['default']>
export const LazyModulesAuthenticationResetPassword: LazyComponent<typeof import("../components/Modules/Authentication/ResetPassword/index.vue")['default']>
export const LazyModulesExtraPagesAnimation: LazyComponent<typeof import("../components/Modules/ExtraPages/Animation/index.vue")['default']>
export const LazyModulesExtraPagesCheckRadio: LazyComponent<typeof import("../components/Modules/ExtraPages/CheckRadio/index.vue")['default']>
export const LazyModulesExtraPagesClipBoard: LazyComponent<typeof import("../components/Modules/ExtraPages/ClipBoard/index.vue")['default']>
export const LazyModulesExtraPagesDragDrop: LazyComponent<typeof import("../components/Modules/ExtraPages/DragDrop/index.vue")['default']>
export const LazyModulesExtraPagesFAQ: LazyComponent<typeof import("../components/Modules/ExtraPages/FAQ/index.vue")['default']>
export const LazyModulesExtraPagesGallery: LazyComponent<typeof import("../components/Modules/ExtraPages/Gallery/index.vue")['default']>
export const LazyModulesExtraPagesPricingStyleOne: LazyComponent<typeof import("../components/Modules/ExtraPages/Pricing/PricingStyleOne.vue")['default']>
export const LazyModulesExtraPagesPricingStyleThree: LazyComponent<typeof import("../components/Modules/ExtraPages/Pricing/PricingStyleThree.vue")['default']>
export const LazyModulesExtraPagesPricingStyleTwo: LazyComponent<typeof import("../components/Modules/ExtraPages/Pricing/PricingStyleTwo.vue")['default']>
export const LazyModulesExtraPagesPricing: LazyComponent<typeof import("../components/Modules/ExtraPages/Pricing/index.vue")['default']>
export const LazyModulesExtraPagesRangeSlider: LazyComponent<typeof import("../components/Modules/ExtraPages/RangeSlider/index.vue")['default']>
export const LazyModulesExtraPagesRatingsInteractiveRating: LazyComponent<typeof import("../components/Modules/ExtraPages/Ratings/InteractiveRating.vue")['default']>
export const LazyModulesExtraPagesRatingsRTLSupport: LazyComponent<typeof import("../components/Modules/ExtraPages/Ratings/RTLSupport.vue")['default']>
export const LazyModulesExtraPagesRatingsReadOnlyPresetValue: LazyComponent<typeof import("../components/Modules/ExtraPages/Ratings/ReadOnlyPresetValue.vue")['default']>
export const LazyModulesExtraPagesRatingsSettingGettingValues: LazyComponent<typeof import("../components/Modules/ExtraPages/Ratings/SettingGettingValues.vue")['default']>
export const LazyModulesExtraPagesRatings: LazyComponent<typeof import("../components/Modules/ExtraPages/Ratings/index.vue")['default']>
export const LazyModulesExtraPagesScrollbar: LazyComponent<typeof import("../components/Modules/ExtraPages/Scrollbar/index.vue")['default']>
export const LazyModulesExtraPagesSearch: LazyComponent<typeof import("../components/Modules/ExtraPages/Search/index.vue")['default']>
export const LazyModulesExtraPagesSelect: LazyComponent<typeof import("../components/Modules/ExtraPages/Select/index.vue")['default']>
export const LazyModulesExtraPagesTimelineAdvancedTimeline: LazyComponent<typeof import("../components/Modules/ExtraPages/Timeline/AdvancedTimeline.vue")['default']>
export const LazyModulesExtraPagesTimelineBasicTimeline: LazyComponent<typeof import("../components/Modules/ExtraPages/Timeline/BasicTimeline.vue")['default']>
export const LazyModulesExtraPagesTimeline: LazyComponent<typeof import("../components/Modules/ExtraPages/Timeline/index.vue")['default']>
export const LazyModulesExtraPagesToasts: LazyComponent<typeof import("../components/Modules/ExtraPages/Toasts/index.vue")['default']>
export const LazyModulesExtraPagesTypography: LazyComponent<typeof import("../components/Modules/ExtraPages/Typography/index.vue")['default']>
export const LazyModulesFormsAdvancedElementsQuantityCounter: LazyComponent<typeof import("../components/Modules/Forms/AdvancedElements/QuantityCounter.vue")['default']>
export const LazyModulesFormsAdvancedElementsQuantityCounterTwo: LazyComponent<typeof import("../components/Modules/Forms/AdvancedElements/QuantityCounterTwo.vue")['default']>
export const LazyModulesFormsAdvancedElements: LazyComponent<typeof import("../components/Modules/Forms/AdvancedElements/index.vue")['default']>
export const LazyModulesFormsBasicElements: LazyComponent<typeof import("../components/Modules/Forms/BasicElements/index.vue")['default']>
export const LazyModulesFormsEditors: LazyComponent<typeof import("../components/Modules/Forms/Editors/index.vue")['default']>
export const LazyModulesFormsFileUpload: LazyComponent<typeof import("../components/Modules/Forms/FileUpload/index.vue")['default']>
export const LazyModulesFormsValidation: LazyComponent<typeof import("../components/Modules/Forms/Validation/index.vue")['default']>
export const LazyModulesFormsWizard: LazyComponent<typeof import("../components/Modules/Forms/Wizard/index.vue")['default']>
export const LazyModulesGoogleMap: LazyComponent<typeof import("../components/Modules/GoogleMap/index.vue")['default']>
export const LazyModulesIconsFeatherIcon: LazyComponent<typeof import("../components/Modules/Icons/FeatherIcon/index.vue")['default']>
export const LazyModulesIconsMaterialSymbolsIcon: LazyComponent<typeof import("../components/Modules/Icons/MaterialSymbolsIcon/index.vue")['default']>
export const LazyModulesIconsRemixIcon: LazyComponent<typeof import("../components/Modules/Icons/RemixIcon/index.vue")['default']>
export const LazyModulesInternalError: LazyComponent<typeof import("../components/Modules/InternalError/index.vue")['default']>
export const LazyModulesMembers: LazyComponent<typeof import("../components/Modules/Members/index.vue")['default']>
export const LazyModulesNotification: LazyComponent<typeof import("../components/Modules/Notification/index.vue")['default']>
export const LazyModulesTablesBasicTable: LazyComponent<typeof import("../components/Modules/Tables/BasicTable/index.vue")['default']>
export const LazyModulesTablesDataTable: LazyComponent<typeof import("../components/Modules/Tables/DataTable/index.vue")['default']>
export const LazyModulesUIElementsAccordions: LazyComponent<typeof import("../components/Modules/UIElements/Accordions/index.vue")['default']>
export const LazyModulesUIElementsAlertsAdditionalContentAlerts: LazyComponent<typeof import("../components/Modules/UIElements/Alerts/AdditionalContentAlerts.vue")['default']>
export const LazyModulesUIElementsAlertsWithIcon: LazyComponent<typeof import("../components/Modules/UIElements/Alerts/AlertsWithIcon.vue")['default']>
export const LazyModulesUIElementsAlertsBGAlertsWithIcon: LazyComponent<typeof import("../components/Modules/UIElements/Alerts/BGAlertsWithIcon.vue")['default']>
export const LazyModulesUIElementsAlertsBGBasicAlerts: LazyComponent<typeof import("../components/Modules/UIElements/Alerts/BGBasicAlerts.vue")['default']>
export const LazyModulesUIElementsAlertsBGOutlineAlerts: LazyComponent<typeof import("../components/Modules/UIElements/Alerts/BGOutlineAlerts.vue")['default']>
export const LazyModulesUIElementsAlertsBasicAlerts: LazyComponent<typeof import("../components/Modules/UIElements/Alerts/BasicAlerts.vue")['default']>
export const LazyModulesUIElementsAlertsDismissingAlerts: LazyComponent<typeof import("../components/Modules/UIElements/Alerts/DismissingAlerts.vue")['default']>
export const LazyModulesUIElementsAlertsOutlineAlerts: LazyComponent<typeof import("../components/Modules/UIElements/Alerts/OutlineAlerts.vue")['default']>
export const LazyModulesUIElementsAlerts: LazyComponent<typeof import("../components/Modules/UIElements/Alerts/index.vue")['default']>
export const LazyModulesUIElementsAvatarSizeRoundedCircleExample: LazyComponent<typeof import("../components/Modules/UIElements/Avatar/AvatarSizeRoundedCircleExample.vue")['default']>
export const LazyModulesUIElementsAvatarSizeSimpleRoundedExample: LazyComponent<typeof import("../components/Modules/UIElements/Avatar/AvatarSizeSimpleRoundedExample.vue")['default']>
export const LazyModulesUIElementsAvatarGroupUserExample: LazyComponent<typeof import("../components/Modules/UIElements/Avatar/GroupUserExample.vue")['default']>
export const LazyModulesUIElementsAvatarSingleUserExample: LazyComponent<typeof import("../components/Modules/UIElements/Avatar/SingleUserExample.vue")['default']>
export const LazyModulesUIElementsAvatarSingleUserWithBadgeExample: LazyComponent<typeof import("../components/Modules/UIElements/Avatar/SingleUserWithBadgeExample.vue")['default']>
export const LazyModulesUIElementsAvatarTextAvatarSizeRoundedCircleExample: LazyComponent<typeof import("../components/Modules/UIElements/Avatar/TextAvatarSizeRoundedCircleExample.vue")['default']>
export const LazyModulesUIElementsAvatarTextAvatarSizeSimpleRoundedExample: LazyComponent<typeof import("../components/Modules/UIElements/Avatar/TextAvatarSizeSimpleRoundedExample.vue")['default']>
export const LazyModulesUIElementsAvatar: LazyComponent<typeof import("../components/Modules/UIElements/Avatar/index.vue")['default']>
export const LazyModulesUIElementsBadgesWithIcons: LazyComponent<typeof import("../components/Modules/UIElements/Badges/BadgesWithIcons.vue")['default']>
export const LazyModulesUIElementsBadgesDefaultBadges: LazyComponent<typeof import("../components/Modules/UIElements/Badges/DefaultBadges.vue")['default']>
export const LazyModulesUIElementsBadgesHeadingsBadges: LazyComponent<typeof import("../components/Modules/UIElements/Badges/HeadingsBadges.vue")['default']>
export const LazyModulesUIElementsBadgesOtherBadges: LazyComponent<typeof import("../components/Modules/UIElements/Badges/OtherBadges.vue")['default']>
export const LazyModulesUIElementsBadgesRoundedPillBadges: LazyComponent<typeof import("../components/Modules/UIElements/Badges/RoundedPillBadges.vue")['default']>
export const LazyModulesUIElementsBadgesRoundedPillBadgesTwo: LazyComponent<typeof import("../components/Modules/UIElements/Badges/RoundedPillBadgesTwo.vue")['default']>
export const LazyModulesUIElementsBadgesSoftBadges: LazyComponent<typeof import("../components/Modules/UIElements/Badges/SoftBadges.vue")['default']>
export const LazyModulesUIElementsBadges: LazyComponent<typeof import("../components/Modules/UIElements/Badges/index.vue")['default']>
export const LazyModulesUIElementsButtonsBlockButtons: LazyComponent<typeof import("../components/Modules/UIElements/Buttons/BlockButtons.vue")['default']>
export const LazyModulesUIElementsButtonsWithIcon: LazyComponent<typeof import("../components/Modules/UIElements/Buttons/ButtonsWithIcon.vue")['default']>
export const LazyModulesUIElementsButtonsDefaultButtons: LazyComponent<typeof import("../components/Modules/UIElements/Buttons/DefaultButtons.vue")['default']>
export const LazyModulesUIElementsButtonsOutlineButtons: LazyComponent<typeof import("../components/Modules/UIElements/Buttons/OutlineButtons.vue")['default']>
export const LazyModulesUIElementsButtonsOutlineRoundedButtons: LazyComponent<typeof import("../components/Modules/UIElements/Buttons/OutlineRoundedButtons.vue")['default']>
export const LazyModulesUIElementsButtonsRoundedButtons: LazyComponent<typeof import("../components/Modules/UIElements/Buttons/RoundedButtons.vue")['default']>
export const LazyModulesUIElementsButtonsSoftButtons: LazyComponent<typeof import("../components/Modules/UIElements/Buttons/SoftButtons.vue")['default']>
export const LazyModulesUIElementsButtons: LazyComponent<typeof import("../components/Modules/UIElements/Buttons/index.vue")['default']>
export const LazyModulesUIElementsCardsCardWithBgImage: LazyComponent<typeof import("../components/Modules/UIElements/Cards/CardWithBgImage.vue")['default']>
export const LazyModulesUIElementsCardsCardWithImage: LazyComponent<typeof import("../components/Modules/UIElements/Cards/CardWithImage.vue")['default']>
export const LazyModulesUIElementsCardsCardWithList: LazyComponent<typeof import("../components/Modules/UIElements/Cards/CardWithList.vue")['default']>
export const LazyModulesUIElementsCardsDefaultCard: LazyComponent<typeof import("../components/Modules/UIElements/Cards/DefaultCard.vue")['default']>
export const LazyModulesUIElementsCards: LazyComponent<typeof import("../components/Modules/UIElements/Cards/index.vue")['default']>
export const LazyModulesUIElementsCarouselsSlidesOnly: LazyComponent<typeof import("../components/Modules/UIElements/Carousels/SlidesOnly.vue")['default']>
export const LazyModulesUIElementsCarouselsSlidesWithControls: LazyComponent<typeof import("../components/Modules/UIElements/Carousels/SlidesWithControls.vue")['default']>
export const LazyModulesUIElementsCarousels: LazyComponent<typeof import("../components/Modules/UIElements/Carousels/index.vue")['default']>
export const LazyModulesUIElementsDateTimePicker: LazyComponent<typeof import("../components/Modules/UIElements/DateTimePicker/index.vue")['default']>
export const LazyModulesUIElementsDropdownsDropdownDefaultButtons: LazyComponent<typeof import("../components/Modules/UIElements/Dropdowns/DropdownDefaultButtons.vue")['default']>
export const LazyModulesUIElementsDropdowns: LazyComponent<typeof import("../components/Modules/UIElements/Dropdowns/index.vue")['default']>
export const LazyModulesUIElementsGrids: LazyComponent<typeof import("../components/Modules/UIElements/Grids/index.vue")['default']>
export const LazyModulesUIElementsImages: LazyComponent<typeof import("../components/Modules/UIElements/Images/index.vue")['default']>
export const LazyModulesUIElementsList: LazyComponent<typeof import("../components/Modules/UIElements/List/index.vue")['default']>
export const LazyModulesUIElementsModals: LazyComponent<typeof import("../components/Modules/UIElements/Modals/index.vue")['default']>
export const LazyModulesUIElementsNavs: LazyComponent<typeof import("../components/Modules/UIElements/Navs/index.vue")['default']>
export const LazyModulesUIElementsPaginations: LazyComponent<typeof import("../components/Modules/UIElements/Paginations/index.vue")['default']>
export const LazyModulesUIElementsPopoverTooltips: LazyComponent<typeof import("../components/Modules/UIElements/PopoverTooltips/index.vue")['default']>
export const LazyModulesUIElementsProgress: LazyComponent<typeof import("../components/Modules/UIElements/Progress/index.vue")['default']>
export const LazyModulesUIElementsSpinners: LazyComponent<typeof import("../components/Modules/UIElements/Spinners/index.vue")['default']>
export const LazyModulesUIElementsTabs: LazyComponent<typeof import("../components/Modules/UIElements/Tabs/index.vue")['default']>
export const LazyModulesUIElementsVideos: LazyComponent<typeof import("../components/Modules/UIElements/Videos/index.vue")['default']>
export const LazyModulesWidgetsAnnualProfitChart: LazyComponent<typeof import("../components/Modules/Widgets/AnnualProfitChart.vue")['default']>
export const LazyModulesWidgetsCoursesSalesChart: LazyComponent<typeof import("../components/Modules/Widgets/CoursesSalesChart.vue")['default']>
export const LazyModulesWidgetsInProgressChart: LazyComponent<typeof import("../components/Modules/Widgets/InProgressChart.vue")['default']>
export const LazyModulesWidgetsLeadConversionChart: LazyComponent<typeof import("../components/Modules/Widgets/LeadConversionChart.vue")['default']>
export const LazyModulesWidgetsOurTopCourses: LazyComponent<typeof import("../components/Modules/Widgets/OurTopCourses.vue")['default']>
export const LazyModulesWidgetsProjectsAnalysisChart: LazyComponent<typeof import("../components/Modules/Widgets/ProjectsAnalysisChart.vue")['default']>
export const LazyModulesWidgetsProjectsOverview: LazyComponent<typeof import("../components/Modules/Widgets/ProjectsOverview.vue")['default']>
export const LazyModulesWidgetsProjectsRoadmapChart: LazyComponent<typeof import("../components/Modules/Widgets/ProjectsRoadmapChart.vue")['default']>
export const LazyModulesWidgetsRevenueGrowthChart: LazyComponent<typeof import("../components/Modules/Widgets/RevenueGrowthChart.vue")['default']>
export const LazyModulesWidgetsTeamMembers: LazyComponent<typeof import("../components/Modules/Widgets/TeamMembers.vue")['default']>
export const LazyModulesWidgetsTicketsDueChart: LazyComponent<typeof import("../components/Modules/Widgets/TicketsDueChart.vue")['default']>
export const LazyModulesWidgetsTicketsNewOpenChart: LazyComponent<typeof import("../components/Modules/Widgets/TicketsNewOpenChart.vue")['default']>
export const LazyModulesWidgetsTicketsResolvedChart: LazyComponent<typeof import("../components/Modules/Widgets/TicketsResolvedChart.vue")['default']>
export const LazyModulesWidgetsTimeSpentChart: LazyComponent<typeof import("../components/Modules/Widgets/TimeSpentChart.vue")['default']>
export const LazyModulesWidgetsTotalCourses: LazyComponent<typeof import("../components/Modules/Widgets/TotalCourses.vue")['default']>
export const LazyModulesWidgetsTotalCustomersChart: LazyComponent<typeof import("../components/Modules/Widgets/TotalCustomersChart.vue")['default']>
export const LazyModulesWidgetsTotalEnrolled: LazyComponent<typeof import("../components/Modules/Widgets/TotalEnrolled.vue")['default']>
export const LazyModulesWidgetsTotalMentors: LazyComponent<typeof import("../components/Modules/Widgets/TotalMentors.vue")['default']>
export const LazyModulesWidgetsTotalOrdersChart: LazyComponent<typeof import("../components/Modules/Widgets/TotalOrdersChart.vue")['default']>
export const LazyModulesWidgetsTotalOrdersChartTwo: LazyComponent<typeof import("../components/Modules/Widgets/TotalOrdersChartTwo.vue")['default']>
export const LazyModulesWidgetsTotalRevenueChart: LazyComponent<typeof import("../components/Modules/Widgets/TotalRevenueChart.vue")['default']>
export const LazyModulesWidgetsWelcomeBack: LazyComponent<typeof import("../components/Modules/Widgets/WelcomeBack.vue")['default']>
export const LazyModulesWidgetsWorkingSchedule: LazyComponent<typeof import("../components/Modules/Widgets/WorkingSchedule.vue")['default']>
export const LazyModulesWidgets: LazyComponent<typeof import("../components/Modules/Widgets/index.vue")['default']>
export const LazyOthersMyProfileAdditionalInformation: LazyComponent<typeof import("../components/Others/MyProfile/AdditionalInformation.vue")['default']>
export const LazyOthersMyProfileInformation: LazyComponent<typeof import("../components/Others/MyProfile/ProfileInformation.vue")['default']>
export const LazyOthersMyProfileIntro: LazyComponent<typeof import("../components/Others/MyProfile/ProfileIntro.vue")['default']>
export const LazyOthersMyProfileProjectsAnalysisChart: LazyComponent<typeof import("../components/Others/MyProfile/ProjectsAnalysisChart.vue")['default']>
export const LazyOthersMyProfileRecentActivity: LazyComponent<typeof import("../components/Others/MyProfile/RecentActivity.vue")['default']>
export const LazyOthersMyProfileToDoList: LazyComponent<typeof import("../components/Others/MyProfile/ToDoList.vue")['default']>
export const LazyOthersMyProfileTotalOrders: LazyComponent<typeof import("../components/Others/MyProfile/TotalOrders.vue")['default']>
export const LazyOthersMyProfileTotalProjects: LazyComponent<typeof import("../components/Others/MyProfile/TotalProjects.vue")['default']>
export const LazyOthersMyProfileTotalRevenue: LazyComponent<typeof import("../components/Others/MyProfile/TotalRevenue.vue")['default']>
export const LazyOthersMyProfileWelcomeBack: LazyComponent<typeof import("../components/Others/MyProfile/WelcomeBack.vue")['default']>
export const LazyOthersMyProfile: LazyComponent<typeof import("../components/Others/MyProfile/index.vue")['default']>
export const LazyOthersSettingsAccountSettings: LazyComponent<typeof import("../components/Others/Settings/AccountSettings/index.vue")['default']>
export const LazyOthersSettingsChangePassword: LazyComponent<typeof import("../components/Others/Settings/ChangePassword/index.vue")['default']>
export const LazyOthersSettingsConnections: LazyComponent<typeof import("../components/Others/Settings/Connections/index.vue")['default']>
export const LazyOthersSettingsPrivacyPolicy: LazyComponent<typeof import("../components/Others/Settings/PrivacyPolicy/index.vue")['default']>
export const LazyOthersSettingsMenu: LazyComponent<typeof import("../components/Others/Settings/SettingsMenu.vue")['default']>
export const LazyOthersSettingsTermsConditions: LazyComponent<typeof import("../components/Others/Settings/TermsConditions/index.vue")['default']>
export const LazyPagesCRMContacts: LazyComponent<typeof import("../components/Pages/CRM/Contacts/index.vue")['default']>
export const LazyPagesCRMCustomers: LazyComponent<typeof import("../components/Pages/CRM/Customers/index.vue")['default']>
export const LazyPagesCRMDeals: LazyComponent<typeof import("../components/Pages/CRM/Deals/index.vue")['default']>
export const LazyPagesCRMLeadsAnnualProfitChart: LazyComponent<typeof import("../components/Pages/CRM/Leads/AnnualProfitChart.vue")['default']>
export const LazyPagesCRMLeadsLeadConversionChart: LazyComponent<typeof import("../components/Pages/CRM/Leads/LeadConversionChart.vue")['default']>
export const LazyPagesCRMLeadsRevenueGrowthChart: LazyComponent<typeof import("../components/Pages/CRM/Leads/RevenueGrowthChart.vue")['default']>
export const LazyPagesCRMLeadsTotalOrdersChart: LazyComponent<typeof import("../components/Pages/CRM/Leads/TotalOrdersChart.vue")['default']>
export const LazyPagesCRMLeads: LazyComponent<typeof import("../components/Pages/CRM/Leads/index.vue")['default']>
export const LazyPagesCryptoTraderCTWallet: LazyComponent<typeof import("../components/Pages/CryptoTrader/CTWallet/index.vue")['default']>
export const LazyPagesCryptoTraderGainersLosers: LazyComponent<typeof import("../components/Pages/CryptoTrader/GainersLosers/index.vue")['default']>
export const LazyPagesCryptoTraderTransactions: LazyComponent<typeof import("../components/Pages/CryptoTrader/Transactions/index.vue")['default']>
export const LazyPagesDoctorAddPatient: LazyComponent<typeof import("../components/Pages/Doctor/AddPatient/index.vue")['default']>
export const LazyPagesDoctorAppointmentsTodayAppointments: LazyComponent<typeof import("../components/Pages/Doctor/Appointments/TodayAppointments.vue")['default']>
export const LazyPagesDoctorAppointmentsTodaySchedule: LazyComponent<typeof import("../components/Pages/Doctor/Appointments/TodaySchedule.vue")['default']>
export const LazyPagesDoctorAppointments: LazyComponent<typeof import("../components/Pages/Doctor/Appointments/index.vue")['default']>
export const LazyPagesDoctorPatientDetails: LazyComponent<typeof import("../components/Pages/Doctor/PatientDetails/index.vue")['default']>
export const LazyPagesDoctorPatientsList: LazyComponent<typeof import("../components/Pages/Doctor/PatientsList/index.vue")['default']>
export const LazyPagesDoctorPrescriptions: LazyComponent<typeof import("../components/Pages/Doctor/Prescriptions/index.vue")['default']>
export const LazyPagesDoctorWritePrescription: LazyComponent<typeof import("../components/Pages/Doctor/WritePrescription/index.vue")['default']>
export const LazyPagesEcommerceCartQuantityCounter: LazyComponent<typeof import("../components/Pages/Ecommerce/Cart/QuantityCounter.vue")['default']>
export const LazyPagesEcommerceCart: LazyComponent<typeof import("../components/Pages/Ecommerce/Cart/index.vue")['default']>
export const LazyPagesEcommerceCategories: LazyComponent<typeof import("../components/Pages/Ecommerce/Categories/index.vue")['default']>
export const LazyPagesEcommerceCheckout: LazyComponent<typeof import("../components/Pages/Ecommerce/Checkout/index.vue")['default']>
export const LazyPagesEcommerceCreateOrderBillingInformation: LazyComponent<typeof import("../components/Pages/Ecommerce/CreateOrder/BillingInformation.vue")['default']>
export const LazyPagesEcommerceCreateOrderPaymentMethod: LazyComponent<typeof import("../components/Pages/Ecommerce/CreateOrder/PaymentMethod.vue")['default']>
export const LazyPagesEcommerceCreateOrderYourOrder: LazyComponent<typeof import("../components/Pages/Ecommerce/CreateOrder/YourOrder.vue")['default']>
export const LazyPagesEcommerceCreateOrder: LazyComponent<typeof import("../components/Pages/Ecommerce/CreateOrder/index.vue")['default']>
export const LazyPagesEcommerceCreateProduct: LazyComponent<typeof import("../components/Pages/Ecommerce/CreateProduct/index.vue")['default']>
export const LazyPagesEcommerceCreateSeller: LazyComponent<typeof import("../components/Pages/Ecommerce/CreateSeller/index.vue")['default']>
export const LazyPagesEcommerceCustomerDetailsTransactionsHistory: LazyComponent<typeof import("../components/Pages/Ecommerce/CustomerDetails/TransactionsHistory.vue")['default']>
export const LazyPagesEcommerceCustomerDetailsUserCard: LazyComponent<typeof import("../components/Pages/Ecommerce/CustomerDetails/UserCard.vue")['default']>
export const LazyPagesEcommerceCustomerDetails: LazyComponent<typeof import("../components/Pages/Ecommerce/CustomerDetails/index.vue")['default']>
export const LazyPagesEcommerceCustomers: LazyComponent<typeof import("../components/Pages/Ecommerce/Customers/index.vue")['default']>
export const LazyPagesEcommerceEditProduct: LazyComponent<typeof import("../components/Pages/Ecommerce/EditProduct/index.vue")['default']>
export const LazyPagesEcommerceOrderDetailsBillingDetails: LazyComponent<typeof import("../components/Pages/Ecommerce/OrderDetails/BillingDetails.vue")['default']>
export const LazyPagesEcommerceOrderDetailsDeliveryDetails: LazyComponent<typeof import("../components/Pages/Ecommerce/OrderDetails/DeliveryDetails.vue")['default']>
export const LazyPagesEcommerceOrderDetailsOrderSummary: LazyComponent<typeof import("../components/Pages/Ecommerce/OrderDetails/OrderSummary.vue")['default']>
export const LazyPagesEcommerceOrderDetailsQuantityCounter: LazyComponent<typeof import("../components/Pages/Ecommerce/OrderDetails/QuantityCounter.vue")['default']>
export const LazyPagesEcommerceOrderDetailsRecentOrders: LazyComponent<typeof import("../components/Pages/Ecommerce/OrderDetails/RecentOrders.vue")['default']>
export const LazyPagesEcommerceOrderDetailsShippingDetails: LazyComponent<typeof import("../components/Pages/Ecommerce/OrderDetails/ShippingDetails.vue")['default']>
export const LazyPagesEcommerceOrderDetailsTrackingID: LazyComponent<typeof import("../components/Pages/Ecommerce/OrderDetails/TrackingID.vue")['default']>
export const LazyPagesEcommerceOrderDetails: LazyComponent<typeof import("../components/Pages/Ecommerce/OrderDetails/index.vue")['default']>
export const LazyPagesEcommerceOrderTracking: LazyComponent<typeof import("../components/Pages/Ecommerce/OrderTracking/index.vue")['default']>
export const LazyPagesEcommerceOrders: LazyComponent<typeof import("../components/Pages/Ecommerce/Orders/index.vue")['default']>
export const LazyPagesEcommerceProductsDetailsTabs: LazyComponent<typeof import("../components/Pages/Ecommerce/ProductsDetails/ProductsDetailsTabs.vue")['default']>
export const LazyPagesEcommerceProductsDetailsProductsFilter: LazyComponent<typeof import("../components/Pages/Ecommerce/ProductsDetails/ProductsFilter.vue")['default']>
export const LazyPagesEcommerceProductsDetails: LazyComponent<typeof import("../components/Pages/Ecommerce/ProductsDetails/index.vue")['default']>
export const LazyPagesEcommerceProductsGridProductsFilter: LazyComponent<typeof import("../components/Pages/Ecommerce/ProductsGrid/ProductsFilter.vue")['default']>
export const LazyPagesEcommerceProductsGrid: LazyComponent<typeof import("../components/Pages/Ecommerce/ProductsGrid/index.vue")['default']>
export const LazyPagesEcommerceProductsList: LazyComponent<typeof import("../components/Pages/Ecommerce/ProductsList/index.vue")['default']>
export const LazyPagesEcommerceRefunds: LazyComponent<typeof import("../components/Pages/Ecommerce/Refunds/index.vue")['default']>
export const LazyPagesEcommerceReviews: LazyComponent<typeof import("../components/Pages/Ecommerce/Reviews/index.vue")['default']>
export const LazyPagesEcommerceSellerDetailsProductsList: LazyComponent<typeof import("../components/Pages/Ecommerce/SellerDetails/ProductsList.vue")['default']>
export const LazyPagesEcommerceSellerDetailsRevenueChart: LazyComponent<typeof import("../components/Pages/Ecommerce/SellerDetails/RevenueChart.vue")['default']>
export const LazyPagesEcommerceSellerDetailsSellerID: LazyComponent<typeof import("../components/Pages/Ecommerce/SellerDetails/SellerID.vue")['default']>
export const LazyPagesEcommerceSellerDetailsSellerOverview: LazyComponent<typeof import("../components/Pages/Ecommerce/SellerDetails/SellerOverview.vue")['default']>
export const LazyPagesEcommerceSellerDetails: LazyComponent<typeof import("../components/Pages/Ecommerce/SellerDetails/index.vue")['default']>
export const LazyPagesEcommerceSellers: LazyComponent<typeof import("../components/Pages/Ecommerce/Sellers/index.vue")['default']>
export const LazyPagesEventsCreateAnEvent: LazyComponent<typeof import("../components/Pages/Events/CreateAnEvent/index.vue")['default']>
export const LazyPagesEventsEditAnEvent: LazyComponent<typeof import("../components/Pages/Events/EditAnEvent/index.vue")['default']>
export const LazyPagesEventsEventDetailsAboutThisEvent: LazyComponent<typeof import("../components/Pages/Events/EventDetails/AboutThisEvent.vue")['default']>
export const LazyPagesEventsEventDetailsAnnualConference: LazyComponent<typeof import("../components/Pages/Events/EventDetails/AnnualConference.vue")['default']>
export const LazyPagesEventsEventDetailsEventInfo: LazyComponent<typeof import("../components/Pages/Events/EventDetails/EventInfo.vue")['default']>
export const LazyPagesEventsEventDetailsSpeakerTopic: LazyComponent<typeof import("../components/Pages/Events/EventDetails/SpeakerTopic.vue")['default']>
export const LazyPagesEventsEventDetails: LazyComponent<typeof import("../components/Pages/Events/EventDetails/index.vue")['default']>
export const LazyPagesEventsEventsGrid: LazyComponent<typeof import("../components/Pages/Events/EventsGrid/index.vue")['default']>
export const LazyPagesEventsEventsList: LazyComponent<typeof import("../components/Pages/Events/EventsList/index.vue")['default']>
export const LazyPagesFinanceTransactionAddNewTransactionModal: LazyComponent<typeof import("../components/Pages/Finance/Transaction/AddNewTransactionModal.vue")['default']>
export const LazyPagesFinanceTransaction: LazyComponent<typeof import("../components/Pages/Finance/Transaction/index.vue")['default']>
export const LazyPagesFinanceWalletAddCardDetailModal: LazyComponent<typeof import("../components/Pages/Finance/Wallet/AddCardDetailModal.vue")['default']>
export const LazyPagesFinanceWalletDebitCard: LazyComponent<typeof import("../components/Pages/Finance/Wallet/DebitCard.vue")['default']>
export const LazyPagesFinanceWalletStaticChart: LazyComponent<typeof import("../components/Pages/Finance/Wallet/StaticChart.vue")['default']>
export const LazyPagesFinanceWalletTotalExpenses: LazyComponent<typeof import("../components/Pages/Finance/Wallet/TotalExpenses.vue")['default']>
export const LazyPagesFinanceWalletTotalIncome: LazyComponent<typeof import("../components/Pages/Finance/Wallet/TotalIncome.vue")['default']>
export const LazyPagesFinanceWalletTransactionHistory: LazyComponent<typeof import("../components/Pages/Finance/Wallet/TransactionHistory.vue")['default']>
export const LazyPagesFinanceWallet: LazyComponent<typeof import("../components/Pages/Finance/Wallet/index.vue")['default']>
export const LazyPagesHelpDeskAgents: LazyComponent<typeof import("../components/Pages/HelpDesk/Agents/index.vue")['default']>
export const LazyPagesHelpDeskReportsCustomerSatisfactionChart: LazyComponent<typeof import("../components/Pages/HelpDesk/Reports/CustomerSatisfactionChart.vue")['default']>
export const LazyPagesHelpDeskReportsNewAndSolvedTicketsChart: LazyComponent<typeof import("../components/Pages/HelpDesk/Reports/NewAndSolvedTicketsChart.vue")['default']>
export const LazyPagesHelpDeskReportsPerformanceOfAgents: LazyComponent<typeof import("../components/Pages/HelpDesk/Reports/PerformanceOfAgents.vue")['default']>
export const LazyPagesHelpDeskReportsResponseTimeChart: LazyComponent<typeof import("../components/Pages/HelpDesk/Reports/ResponseTimeChart.vue")['default']>
export const LazyPagesHelpDeskReportsTasksOverviewChart: LazyComponent<typeof import("../components/Pages/HelpDesk/Reports/TasksOverviewChart.vue")['default']>
export const LazyPagesHelpDeskReportsTicketsStatusChart: LazyComponent<typeof import("../components/Pages/HelpDesk/Reports/TicketsStatusChart.vue")['default']>
export const LazyPagesHelpDeskReports: LazyComponent<typeof import("../components/Pages/HelpDesk/Reports/index.vue")['default']>
export const LazyPagesHelpDeskTicketDetailsAttachments: LazyComponent<typeof import("../components/Pages/HelpDesk/TicketDetails/Attachments.vue")['default']>
export const LazyPagesHelpDeskTicketDetailsComments: LazyComponent<typeof import("../components/Pages/HelpDesk/TicketDetails/Comments.vue")['default']>
export const LazyPagesHelpDeskTicketDetailsTicket: LazyComponent<typeof import("../components/Pages/HelpDesk/TicketDetails/Ticket.vue")['default']>
export const LazyPagesHelpDeskTicketDetailsTicketDescription: LazyComponent<typeof import("../components/Pages/HelpDesk/TicketDetails/TicketDescription.vue")['default']>
export const LazyPagesHelpDeskTicketDetails: LazyComponent<typeof import("../components/Pages/HelpDesk/TicketDetails/index.vue")['default']>
export const LazyPagesHelpDeskTicketsAllTickets: LazyComponent<typeof import("../components/Pages/HelpDesk/Tickets/AllTickets.vue")['default']>
export const LazyPagesHelpDeskTicketsDueChart: LazyComponent<typeof import("../components/Pages/HelpDesk/Tickets/TicketsDueChart.vue")['default']>
export const LazyPagesHelpDeskTicketsInProgressChart: LazyComponent<typeof import("../components/Pages/HelpDesk/Tickets/TicketsInProgressChart.vue")['default']>
export const LazyPagesHelpDeskTicketsNewOpenChart: LazyComponent<typeof import("../components/Pages/HelpDesk/Tickets/TicketsNewOpenChart.vue")['default']>
export const LazyPagesHelpDeskTicketsResolvedChart: LazyComponent<typeof import("../components/Pages/HelpDesk/Tickets/TicketsResolvedChart.vue")['default']>
export const LazyPagesHelpDeskTickets: LazyComponent<typeof import("../components/Pages/HelpDesk/Tickets/index.vue")['default']>
export const LazyPagesHotelGuestsList: LazyComponent<typeof import("../components/Pages/Hotel/GuestsList/index.vue")['default']>
export const LazyPagesHotelRoomDetailsReviews: LazyComponent<typeof import("../components/Pages/Hotel/RoomDetails/Reviews.vue")['default']>
export const LazyPagesHotelRoomDetails: LazyComponent<typeof import("../components/Pages/Hotel/RoomDetails/index.vue")['default']>
export const LazyPagesHotelRoomsList: LazyComponent<typeof import("../components/Pages/Hotel/RoomsList/index.vue")['default']>
export const LazyPagesInvoicesCreateInvoice: LazyComponent<typeof import("../components/Pages/Invoices/CreateInvoice/index.vue")['default']>
export const LazyPagesInvoicesEditInvoice: LazyComponent<typeof import("../components/Pages/Invoices/EditInvoice/index.vue")['default']>
export const LazyPagesInvoicesInvoiceDetails: LazyComponent<typeof import("../components/Pages/Invoices/InvoiceDetails/index.vue")['default']>
export const LazyPagesInvoicesInvoicesList: LazyComponent<typeof import("../components/Pages/Invoices/InvoicesList/index.vue")['default']>
export const LazyPagesLMSCourseDetailsCourse: LazyComponent<typeof import("../components/Pages/LMS/CourseDetails/Course.vue")['default']>
export const LazyPagesLMSCourseDetailsCourseInstructor: LazyComponent<typeof import("../components/Pages/LMS/CourseDetails/CourseInstructor.vue")['default']>
export const LazyPagesLMSCourseDetailsEnrolledStudents: LazyComponent<typeof import("../components/Pages/LMS/CourseDetails/EnrolledStudents.vue")['default']>
export const LazyPagesLMSCourseDetailsManageReviews: LazyComponent<typeof import("../components/Pages/LMS/CourseDetails/ManageReviews.vue")['default']>
export const LazyPagesLMSCourseDetailsRatings: LazyComponent<typeof import("../components/Pages/LMS/CourseDetails/Ratings.vue")['default']>
export const LazyPagesLMSCourseDetailsTablesOfContent: LazyComponent<typeof import("../components/Pages/LMS/CourseDetails/TablesOfContent.vue")['default']>
export const LazyPagesLMSCourseDetailsWriteFeedbackHere: LazyComponent<typeof import("../components/Pages/LMS/CourseDetails/WriteFeedbackHere.vue")['default']>
export const LazyPagesLMSCourseDetails: LazyComponent<typeof import("../components/Pages/LMS/CourseDetails/index.vue")['default']>
export const LazyPagesLMSCoursesList: LazyComponent<typeof import("../components/Pages/LMS/CoursesList/index.vue")['default']>
export const LazyPagesLMSCreateCourse: LazyComponent<typeof import("../components/Pages/LMS/CreateCourse/index.vue")['default']>
export const LazyPagesLMSEditCourse: LazyComponent<typeof import("../components/Pages/LMS/EditCourse/index.vue")['default']>
export const LazyPagesLMSInstructors: LazyComponent<typeof import("../components/Pages/LMS/Instructors/index.vue")['default']>
export const LazyPagesLMSLessonPreview: LazyComponent<typeof import("../components/Pages/LMS/LessonPreview/index.vue")['default']>
export const LazyPagesLMSAdminInstituteType: LazyComponent<typeof import("../components/Pages/LMS/admin/institute-type.vue")['default']>
export const LazyPagesNFTMarketplaceCreatorDetailsCarterID: LazyComponent<typeof import("../components/Pages/NFTMarketplace/CreatorDetails/CarterID.vue")['default']>
export const LazyPagesNFTMarketplaceCreatorDetailsCarterNFTs: LazyComponent<typeof import("../components/Pages/NFTMarketplace/CreatorDetails/CarterNFTs.vue")['default']>
export const LazyPagesNFTMarketplaceCreatorDetails: LazyComponent<typeof import("../components/Pages/NFTMarketplace/CreatorDetails/index.vue")['default']>
export const LazyPagesNFTMarketplaceCreatorsFilterContent: LazyComponent<typeof import("../components/Pages/NFTMarketplace/Creators/FilterContent.vue")['default']>
export const LazyPagesNFTMarketplaceCreators: LazyComponent<typeof import("../components/Pages/NFTMarketplace/Creators/index.vue")['default']>
export const LazyPagesNFTMarketplaceExploreAllPriceFilter: LazyComponent<typeof import("../components/Pages/NFTMarketplace/ExploreAll/PriceFilter.vue")['default']>
export const LazyPagesNFTMarketplaceExploreAll: LazyComponent<typeof import("../components/Pages/NFTMarketplace/ExploreAll/index.vue")['default']>
export const LazyPagesNFTMarketplaceLiveAuctionCountdownTimer: LazyComponent<typeof import("../components/Pages/NFTMarketplace/LiveAuction/CountdownTimer.vue")['default']>
export const LazyPagesNFTMarketplaceLiveAuctionHistoryOfBids: LazyComponent<typeof import("../components/Pages/NFTMarketplace/LiveAuction/HistoryOfBids.vue")['default']>
export const LazyPagesNFTMarketplaceLiveAuctionNewMobileApp: LazyComponent<typeof import("../components/Pages/NFTMarketplace/LiveAuction/NewMobileApp.vue")['default']>
export const LazyPagesNFTMarketplaceLiveAuction: LazyComponent<typeof import("../components/Pages/NFTMarketplace/LiveAuction/index.vue")['default']>
export const LazyPagesNFTMarketplaceMarketplaceCreateNFT: LazyComponent<typeof import("../components/Pages/NFTMarketplace/Marketplace/CreateNFT.vue")['default']>
export const LazyPagesNFTMarketplaceMarketplaceFeaturedNFTArtworks: LazyComponent<typeof import("../components/Pages/NFTMarketplace/Marketplace/FeaturedNFTArtworks.vue")['default']>
export const LazyPagesNFTMarketplaceMarketplaceManageYourNFT: LazyComponent<typeof import("../components/Pages/NFTMarketplace/Marketplace/ManageYourNFT.vue")['default']>
export const LazyPagesNFTMarketplaceMarketplaceTopCreators: LazyComponent<typeof import("../components/Pages/NFTMarketplace/Marketplace/TopCreators.vue")['default']>
export const LazyPagesNFTMarketplaceNFTDetailsCountdownTimer: LazyComponent<typeof import("../components/Pages/NFTMarketplace/NFTDetails/CountdownTimer.vue")['default']>
export const LazyPagesNFTMarketplaceNFTDetails: LazyComponent<typeof import("../components/Pages/NFTMarketplace/NFTDetails/index.vue")['default']>
export const LazyPagesNFTMarketplaceWalletConnect: LazyComponent<typeof import("../components/Pages/NFTMarketplace/WalletConnect/index.vue")['default']>
export const LazyPagesProfileCover: LazyComponent<typeof import("../components/Pages/Profile/ProfileCover.vue")['default']>
export const LazyPagesProfileMenu: LazyComponent<typeof import("../components/Pages/Profile/ProfileMenu.vue")['default']>
export const LazyPagesProfileProjects: LazyComponent<typeof import("../components/Pages/Profile/Projects/index.vue")['default']>
export const LazyPagesProfileTeams: LazyComponent<typeof import("../components/Pages/Profile/Teams/index.vue")['default']>
export const LazyPagesProfileUserProfileAboutMe: LazyComponent<typeof import("../components/Pages/Profile/UserProfile/AboutMe.vue")['default']>
export const LazyPagesProfileUserProfileFollowers: LazyComponent<typeof import("../components/Pages/Profile/UserProfile/Followers.vue")['default']>
export const LazyPagesProfileUserProfileMyProjects: LazyComponent<typeof import("../components/Pages/Profile/UserProfile/MyProjects.vue")['default']>
export const LazyPagesProfileUserProfile: LazyComponent<typeof import("../components/Pages/Profile/UserProfile/index.vue")['default']>
export const LazyPagesProjectManagementClients: LazyComponent<typeof import("../components/Pages/ProjectManagement/Clients/index.vue")['default']>
export const LazyPagesProjectManagementCreateProject: LazyComponent<typeof import("../components/Pages/ProjectManagement/CreateProject/index.vue")['default']>
export const LazyPagesProjectManagementKanbanBoard: LazyComponent<typeof import("../components/Pages/ProjectManagement/KanbanBoard/index.vue")['default']>
export const LazyPagesProjectManagementProjectOverviewProjectRoadmapChart: LazyComponent<typeof import("../components/Pages/ProjectManagement/ProjectOverview/ProjectRoadmapChart.vue")['default']>
export const LazyPagesProjectManagementProjectOverviewProjectsOverview: LazyComponent<typeof import("../components/Pages/ProjectManagement/ProjectOverview/ProjectsOverview.vue")['default']>
export const LazyPagesProjectManagementProjectOverviewRecentActivity: LazyComponent<typeof import("../components/Pages/ProjectManagement/ProjectOverview/RecentActivity.vue")['default']>
export const LazyPagesProjectManagementProjectOverviewTasksOverviewChart: LazyComponent<typeof import("../components/Pages/ProjectManagement/ProjectOverview/TasksOverviewChart.vue")['default']>
export const LazyPagesProjectManagementProjectOverviewTeamMembers: LazyComponent<typeof import("../components/Pages/ProjectManagement/ProjectOverview/TeamMembers.vue")['default']>
export const LazyPagesProjectManagementProjectOverviewThemeDevelopment: LazyComponent<typeof import("../components/Pages/ProjectManagement/ProjectOverview/ThemeDevelopment.vue")['default']>
export const LazyPagesProjectManagementProjectOverviewToDoList: LazyComponent<typeof import("../components/Pages/ProjectManagement/ProjectOverview/ToDoList.vue")['default']>
export const LazyPagesProjectManagementProjectOverview: LazyComponent<typeof import("../components/Pages/ProjectManagement/ProjectOverview/index.vue")['default']>
export const LazyPagesProjectManagementProjectsList: LazyComponent<typeof import("../components/Pages/ProjectManagement/ProjectsList/index.vue")['default']>
export const LazyPagesProjectManagementTeams: LazyComponent<typeof import("../components/Pages/ProjectManagement/Teams/index.vue")['default']>
export const LazyPagesProjectManagementUsers: LazyComponent<typeof import("../components/Pages/ProjectManagement/Users/index.vue")['default']>
export const LazyPagesRealEstateAddAgent: LazyComponent<typeof import("../components/Pages/RealEstate/AddAgent/index.vue")['default']>
export const LazyPagesRealEstateAddProperty: LazyComponent<typeof import("../components/Pages/RealEstate/AddProperty/index.vue")['default']>
export const LazyPagesRealEstateAgentList: LazyComponent<typeof import("../components/Pages/RealEstate/AgentList/index.vue")['default']>
export const LazyPagesRealEstateAgentOverviewClientTestimonials: LazyComponent<typeof import("../components/Pages/RealEstate/AgentOverview/ClientTestimonials.vue")['default']>
export const LazyPagesRealEstateAgentOverviewProfile: LazyComponent<typeof import("../components/Pages/RealEstate/AgentOverview/Profile.vue")['default']>
export const LazyPagesRealEstateAgentOverviewPropertyStatusPropertiesForRentChart: LazyComponent<typeof import("../components/Pages/RealEstate/AgentOverview/PropertyStatus/PropertiesForRentChart.vue")['default']>
export const LazyPagesRealEstateAgentOverviewPropertyStatusPropertiesForSaleChart: LazyComponent<typeof import("../components/Pages/RealEstate/AgentOverview/PropertyStatus/PropertiesForSaleChart.vue")['default']>
export const LazyPagesRealEstateAgentOverviewPropertyStatus: LazyComponent<typeof import("../components/Pages/RealEstate/AgentOverview/PropertyStatus/index.vue")['default']>
export const LazyPagesRealEstateAgentOverview: LazyComponent<typeof import("../components/Pages/RealEstate/AgentOverview/index.vue")['default']>
export const LazyPagesRealEstatePropertyListAddProperty: LazyComponent<typeof import("../components/Pages/RealEstate/PropertyList/AddProperty.vue")['default']>
export const LazyPagesRealEstatePropertyList: LazyComponent<typeof import("../components/Pages/RealEstate/PropertyList/index.vue")['default']>
export const LazyPagesRealEstatePropertyOverviewProfile: LazyComponent<typeof import("../components/Pages/RealEstate/PropertyOverview/Profile/index.vue")['default']>
export const LazyPagesRealEstatePropertyOverview: LazyComponent<typeof import("../components/Pages/RealEstate/PropertyOverview/index.vue")['default']>
export const LazyPagesRealEstateRealEstateCustomersAddNewCustomer: LazyComponent<typeof import("../components/Pages/RealEstate/RealEstateCustomers/AddNewCustomer.vue")['default']>
export const LazyPagesRealEstateRealEstateCustomersAddNewCustomerModal: LazyComponent<typeof import("../components/Pages/RealEstate/RealEstateCustomers/AddNewCustomerModal.vue")['default']>
export const LazyPagesRealEstateRealEstateCustomers: LazyComponent<typeof import("../components/Pages/RealEstate/RealEstateCustomers/index.vue")['default']>
export const LazyPagesRealEstateAgentProperties: LazyComponent<typeof import("../components/Pages/RealEstateAgent/Properties/index.vue")['default']>
export const LazyPagesRealEstateAgentPropertyDetailsReviews: LazyComponent<typeof import("../components/Pages/RealEstateAgent/PropertyDetails/Reviews.vue")['default']>
export const LazyPagesRealEstateAgentPropertyDetails: LazyComponent<typeof import("../components/Pages/RealEstateAgent/PropertyDetails/index.vue")['default']>
export const LazyPagesRestaurantDishDetailsReviewsComponent: LazyComponent<typeof import("../components/Pages/Restaurant/DishDetails/ReviewsComponent.vue")['default']>
export const LazyPagesRestaurantDishDetails: LazyComponent<typeof import("../components/Pages/Restaurant/DishDetails/index.vue")['default']>
export const LazyPagesRestaurantMenus: LazyComponent<typeof import("../components/Pages/Restaurant/Menus/index.vue")['default']>
export const LazyPagesSocialProfile: LazyComponent<typeof import("../components/Pages/Social/Profile/index.vue")['default']>
export const LazyPagesSocialSettings: LazyComponent<typeof import("../components/Pages/Social/Settings/index.vue")['default']>
export const LazyPagesStarter: LazyComponent<typeof import("../components/Pages/Starter/index.vue")['default']>
export const LazyPagesUsersAddUser: LazyComponent<typeof import("../components/Pages/Users/AddUser/index.vue")['default']>
export const LazyPagesUsersTeamMembers: LazyComponent<typeof import("../components/Pages/Users/TeamMembers/index.vue")['default']>
export const LazyPagesUsersUsersList: LazyComponent<typeof import("../components/Pages/Users/UsersList/index.vue")['default']>
export const LazyNuxtWelcome: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/welcome.vue")['default']>
export const LazyNuxtLayout: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-layout")['default']>
export const LazyNuxtErrorBoundary: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-error-boundary.vue")['default']>
export const LazyClientOnly: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/client-only")['default']>
export const LazyDevOnly: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/dev-only")['default']>
export const LazyServerPlaceholder: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/server-placeholder")['default']>
export const LazyNuxtLink: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-link")['default']>
export const LazyNuxtLoadingIndicator: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-loading-indicator")['default']>
export const LazyNuxtTime: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-time.vue")['default']>
export const LazyNuxtRouteAnnouncer: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-route-announcer")['default']>
export const LazyNuxtImg: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-stubs")['NuxtImg']>
export const LazyNuxtPicture: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-stubs")['NuxtPicture']>
export const LazyBAccordion: LazyComponent<typeof import("bootstrap-vue-next/components/BAccordion")['BAccordion']>
export const LazyBAccordionItem: LazyComponent<typeof import("bootstrap-vue-next/components/BAccordion")['BAccordionItem']>
export const LazyBAlert: LazyComponent<typeof import("bootstrap-vue-next/components/BAlert")['BAlert']>
export const LazyBAvatar: LazyComponent<typeof import("bootstrap-vue-next/components/BAvatar")['BAvatar']>
export const LazyBAvatarGroup: LazyComponent<typeof import("bootstrap-vue-next/components/BAvatar")['BAvatarGroup']>
export const LazyBBadge: LazyComponent<typeof import("bootstrap-vue-next/components/BBadge")['BBadge']>
export const LazyBBreadcrumb: LazyComponent<typeof import("bootstrap-vue-next/components/BBreadcrumb")['BBreadcrumb']>
export const LazyBBreadcrumbItem: LazyComponent<typeof import("bootstrap-vue-next/components/BBreadcrumb")['BBreadcrumbItem']>
export const LazyBButton: LazyComponent<typeof import("bootstrap-vue-next/components/BButton")['BButton']>
export const LazyBButtonGroup: LazyComponent<typeof import("bootstrap-vue-next/components/BButton")['BButtonGroup']>
export const LazyBButtonToolbar: LazyComponent<typeof import("bootstrap-vue-next/components/BButton")['BButtonToolbar']>
export const LazyBCloseButton: LazyComponent<typeof import("bootstrap-vue-next/components/BButton")['BCloseButton']>
export const LazyBCard: LazyComponent<typeof import("bootstrap-vue-next/components/BCard")['BCard']>
export const LazyBCardBody: LazyComponent<typeof import("bootstrap-vue-next/components/BCard")['BCardBody']>
export const LazyBCardFooter: LazyComponent<typeof import("bootstrap-vue-next/components/BCard")['BCardFooter']>
export const LazyBCardGroup: LazyComponent<typeof import("bootstrap-vue-next/components/BCard")['BCardGroup']>
export const LazyBCardHeader: LazyComponent<typeof import("bootstrap-vue-next/components/BCard")['BCardHeader']>
export const LazyBCardImg: LazyComponent<typeof import("bootstrap-vue-next/components/BCard")['BCardImg']>
export const LazyBCardSubtitle: LazyComponent<typeof import("bootstrap-vue-next/components/BCard")['BCardSubtitle']>
export const LazyBCardText: LazyComponent<typeof import("bootstrap-vue-next/components/BCard")['BCardText']>
export const LazyBCardTitle: LazyComponent<typeof import("bootstrap-vue-next/components/BCard")['BCardTitle']>
export const LazyBCarousel: LazyComponent<typeof import("bootstrap-vue-next/components/BCarousel")['BCarousel']>
export const LazyBCarouselSlide: LazyComponent<typeof import("bootstrap-vue-next/components/BCarousel")['BCarouselSlide']>
export const LazyBCol: LazyComponent<typeof import("bootstrap-vue-next/components/BContainer")['BCol']>
export const LazyBCollapse: LazyComponent<typeof import("bootstrap-vue-next/components/BCollapse")['BCollapse']>
export const LazyBContainer: LazyComponent<typeof import("bootstrap-vue-next/components/BContainer")['BContainer']>
export const LazyBDropdown: LazyComponent<typeof import("bootstrap-vue-next/components/BDropdown")['BDropdown']>
export const LazyBDropdownDivider: LazyComponent<typeof import("bootstrap-vue-next/components/BDropdown")['BDropdownDivider']>
export const LazyBDropdownForm: LazyComponent<typeof import("bootstrap-vue-next/components/BDropdown")['BDropdownForm']>
export const LazyBDropdownGroup: LazyComponent<typeof import("bootstrap-vue-next/components/BDropdown")['BDropdownGroup']>
export const LazyBDropdownHeader: LazyComponent<typeof import("bootstrap-vue-next/components/BDropdown")['BDropdownHeader']>
export const LazyBDropdownItem: LazyComponent<typeof import("bootstrap-vue-next/components/BDropdown")['BDropdownItem']>
export const LazyBDropdownItemButton: LazyComponent<typeof import("bootstrap-vue-next/components/BDropdown")['BDropdownItemButton']>
export const LazyBDropdownText: LazyComponent<typeof import("bootstrap-vue-next/components/BDropdown")['BDropdownText']>
export const LazyBForm: LazyComponent<typeof import("bootstrap-vue-next/components/BForm")['BForm']>
export const LazyBFormCheckbox: LazyComponent<typeof import("bootstrap-vue-next/components/BFormCheckbox")['BFormCheckbox']>
export const LazyBFormCheckboxGroup: LazyComponent<typeof import("bootstrap-vue-next/components/BFormCheckbox")['BFormCheckboxGroup']>
export const LazyBFormDatalist: LazyComponent<typeof import("bootstrap-vue-next/components/BForm")['BFormDatalist']>
export const LazyBFormFile: LazyComponent<typeof import("bootstrap-vue-next/components/BFormFile")['BFormFile']>
export const LazyBFormFloatingLabel: LazyComponent<typeof import("bootstrap-vue-next/components/BForm")['BFormFloatingLabel']>
export const LazyBFormGroup: LazyComponent<typeof import("bootstrap-vue-next/components/BFormGroup")['BFormGroup']>
export const LazyBFormInput: LazyComponent<typeof import("bootstrap-vue-next/components/BFormInput")['BFormInput']>
export const LazyBFormInvalidFeedback: LazyComponent<typeof import("bootstrap-vue-next/components/BForm")['BFormInvalidFeedback']>
export const LazyBFormRadio: LazyComponent<typeof import("bootstrap-vue-next/components/BFormRadio")['BFormRadio']>
export const LazyBFormRadioGroup: LazyComponent<typeof import("bootstrap-vue-next/components/BFormRadio")['BFormRadioGroup']>
export const LazyBFormRow: LazyComponent<typeof import("bootstrap-vue-next/components/BForm")['BFormRow']>
export const LazyBFormSelect: LazyComponent<typeof import("bootstrap-vue-next/components/BFormSelect")['BFormSelect']>
export const LazyBFormSelectOption: LazyComponent<typeof import("bootstrap-vue-next/components/BFormSelect")['BFormSelectOption']>
export const LazyBFormSelectOptionGroup: LazyComponent<typeof import("bootstrap-vue-next/components/BFormSelect")['BFormSelectOptionGroup']>
export const LazyBFormSpinbutton: LazyComponent<typeof import("bootstrap-vue-next/components/BFormSpinbutton")['BFormSpinbutton']>
export const LazyBFormTag: LazyComponent<typeof import("bootstrap-vue-next/components/BFormTags")['BFormTag']>
export const LazyBFormTags: LazyComponent<typeof import("bootstrap-vue-next/components/BFormTags")['BFormTags']>
export const LazyBFormText: LazyComponent<typeof import("bootstrap-vue-next/components/BForm")['BFormText']>
export const LazyBFormTextarea: LazyComponent<typeof import("bootstrap-vue-next/components/BFormTextarea")['BFormTextarea']>
export const LazyBFormValidFeedback: LazyComponent<typeof import("bootstrap-vue-next/components/BForm")['BFormValidFeedback']>
export const LazyBImg: LazyComponent<typeof import("bootstrap-vue-next/components/BImg")['BImg']>
export const LazyBInput: LazyComponent<typeof import("bootstrap-vue-next/components/BFormInput")['BInput']>
export const LazyBInputGroup: LazyComponent<typeof import("bootstrap-vue-next/components/BInputGroup")['BInputGroup']>
export const LazyBInputGroupText: LazyComponent<typeof import("bootstrap-vue-next/components/BInputGroup")['BInputGroupText']>
export const LazyBListGroup: LazyComponent<typeof import("bootstrap-vue-next/components/BListGroup")['BListGroup']>
export const LazyBListGroupItem: LazyComponent<typeof import("bootstrap-vue-next/components/BListGroup")['BListGroupItem']>
export const LazyBModal: LazyComponent<typeof import("bootstrap-vue-next/components/BModal")['BModal']>
export const LazyBModalOrchestrator: LazyComponent<typeof import("bootstrap-vue-next/components/BModal")['BModalOrchestrator']>
export const LazyBNav: LazyComponent<typeof import("bootstrap-vue-next/components/BNav")['BNav']>
export const LazyBNavForm: LazyComponent<typeof import("bootstrap-vue-next/components/BNav")['BNavForm']>
export const LazyBNavItem: LazyComponent<typeof import("bootstrap-vue-next/components/BNav")['BNavItem']>
export const LazyBNavItemDropdown: LazyComponent<typeof import("bootstrap-vue-next/components/BNav")['BNavItemDropdown']>
export const LazyBNavText: LazyComponent<typeof import("bootstrap-vue-next/components/BNav")['BNavText']>
export const LazyBNavbar: LazyComponent<typeof import("bootstrap-vue-next/components/BNavbar")['BNavbar']>
export const LazyBNavbarBrand: LazyComponent<typeof import("bootstrap-vue-next/components/BNavbar")['BNavbarBrand']>
export const LazyBNavbarNav: LazyComponent<typeof import("bootstrap-vue-next/components/BNavbar")['BNavbarNav']>
export const LazyBNavbarToggle: LazyComponent<typeof import("bootstrap-vue-next/components/BNavbar")['BNavbarToggle']>
export const LazyBOffcanvas: LazyComponent<typeof import("bootstrap-vue-next/components/BOffcanvas")['BOffcanvas']>
export const LazyBOverlay: LazyComponent<typeof import("bootstrap-vue-next/components/BOverlay")['BOverlay']>
export const LazyBPagination: LazyComponent<typeof import("bootstrap-vue-next/components/BPagination")['BPagination']>
export const LazyBPlaceholder: LazyComponent<typeof import("bootstrap-vue-next/components/BPlaceholder")['BPlaceholder']>
export const LazyBPlaceholderButton: LazyComponent<typeof import("bootstrap-vue-next/components/BPlaceholder")['BPlaceholderButton']>
export const LazyBPlaceholderCard: LazyComponent<typeof import("bootstrap-vue-next/components/BPlaceholder")['BPlaceholderCard']>
export const LazyBPlaceholderTable: LazyComponent<typeof import("bootstrap-vue-next/components/BPlaceholder")['BPlaceholderTable']>
export const LazyBPlaceholderWrapper: LazyComponent<typeof import("bootstrap-vue-next/components/BPlaceholder")['BPlaceholderWrapper']>
export const LazyBPopover: LazyComponent<typeof import("bootstrap-vue-next/components/BPopover")['BPopover']>
export const LazyBProgress: LazyComponent<typeof import("bootstrap-vue-next/components/BProgress")['BProgress']>
export const LazyBRow: LazyComponent<typeof import("bootstrap-vue-next/components/BContainer")['BRow']>
export const LazyBSpinner: LazyComponent<typeof import("bootstrap-vue-next/components/BSpinner")['BSpinner']>
export const LazyBTab: LazyComponent<typeof import("bootstrap-vue-next/components/BTabs")['BTab']>
export const LazyBTabs: LazyComponent<typeof import("bootstrap-vue-next/components/BTabs")['BTabs']>
export const LazyBToast: LazyComponent<typeof import("bootstrap-vue-next/components/BToast")['BToast']>
export const LazyBToastOrchestrator: LazyComponent<typeof import("bootstrap-vue-next/components/BToast")['BToastOrchestrator']>
export const LazyBTooltip: LazyComponent<typeof import("bootstrap-vue-next/components/BTooltip")['BTooltip']>
export const LazyBLink: LazyComponent<typeof import("bootstrap-vue-next/components/BLink")['BLink']>
export const LazyBProgressBar: LazyComponent<typeof import("bootstrap-vue-next/components/BProgress")['BProgressBar']>
export const LazyBTableSimple: LazyComponent<typeof import("bootstrap-vue-next/components/BTable")['BTableSimple']>
export const LazyBTableLite: LazyComponent<typeof import("bootstrap-vue-next/components/BTable")['BTableLite']>
export const LazyBTable: LazyComponent<typeof import("bootstrap-vue-next/components/BTable")['BTable']>
export const LazyBTbody: LazyComponent<typeof import("bootstrap-vue-next/components/BTable")['BTbody']>
export const LazyBTd: LazyComponent<typeof import("bootstrap-vue-next/components/BTable")['BTd']>
export const LazyBTh: LazyComponent<typeof import("bootstrap-vue-next/components/BTable")['BTh']>
export const LazyBThead: LazyComponent<typeof import("bootstrap-vue-next/components/BTable")['BThead']>
export const LazyBTfoot: LazyComponent<typeof import("bootstrap-vue-next/components/BTable")['BTfoot']>
export const LazyBTr: LazyComponent<typeof import("bootstrap-vue-next/components/BTable")['BTr']>
export const LazyBPopoverOrchestrator: LazyComponent<typeof import("bootstrap-vue-next/components/BPopover")['BPopoverOrchestrator']>
export const LazyBTooltipOrchestrator: LazyComponent<typeof import("bootstrap-vue-next/components/BTooltip")['BTooltipOrchestrator']>
export const LazySwiper: LazyComponent<typeof import("swiper/vue")['Swiper']>
export const LazySwiperSlide: LazyComponent<typeof import("swiper/vue")['SwiperSlide']>
export const LazyActivityIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ActivityIcon")['default']>
export const LazyAirplayIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/AirplayIcon")['default']>
export const LazyAlertCircleIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/AlertCircleIcon")['default']>
export const LazyAlertOctagonIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/AlertOctagonIcon")['default']>
export const LazyAlertTriangleIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/AlertTriangleIcon")['default']>
export const LazyAlignCenterIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/AlignCenterIcon")['default']>
export const LazyAlignJustifyIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/AlignJustifyIcon")['default']>
export const LazyAlignLeftIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/AlignLeftIcon")['default']>
export const LazyAlignRightIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/AlignRightIcon")['default']>
export const LazyAnchorIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/AnchorIcon")['default']>
export const LazyApertureIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ApertureIcon")['default']>
export const LazyArchiveIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ArchiveIcon")['default']>
export const LazyArrowDownCircleIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ArrowDownCircleIcon")['default']>
export const LazyArrowDownLeftIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ArrowDownLeftIcon")['default']>
export const LazyArrowDownRightIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ArrowDownRightIcon")['default']>
export const LazyArrowDownIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ArrowDownIcon")['default']>
export const LazyArrowLeftCircleIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ArrowLeftCircleIcon")['default']>
export const LazyArrowLeftIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ArrowLeftIcon")['default']>
export const LazyArrowRightCircleIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ArrowRightCircleIcon")['default']>
export const LazyArrowRightIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ArrowRightIcon")['default']>
export const LazyArrowUpCircleIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ArrowUpCircleIcon")['default']>
export const LazyArrowUpLeftIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ArrowUpLeftIcon")['default']>
export const LazyArrowUpRightIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ArrowUpRightIcon")['default']>
export const LazyArrowUpIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ArrowUpIcon")['default']>
export const LazyAtSignIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/AtSignIcon")['default']>
export const LazyAwardIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/AwardIcon")['default']>
export const LazyBarChart2Icon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/BarChart2Icon")['default']>
export const LazyBarChartIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/BarChartIcon")['default']>
export const LazyBatteryChargingIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/BatteryChargingIcon")['default']>
export const LazyBatteryIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/BatteryIcon")['default']>
export const LazyBellOffIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/BellOffIcon")['default']>
export const LazyBellIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/BellIcon")['default']>
export const LazyBluetoothIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/BluetoothIcon")['default']>
export const LazyBoldIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/BoldIcon")['default']>
export const LazyBookOpenIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/BookOpenIcon")['default']>
export const LazyBookIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/BookIcon")['default']>
export const LazyBookmarkIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/BookmarkIcon")['default']>
export const LazyBoxIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/BoxIcon")['default']>
export const LazyBriefcaseIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/BriefcaseIcon")['default']>
export const LazyCalendarIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CalendarIcon")['default']>
export const LazyCameraOffIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CameraOffIcon")['default']>
export const LazyCameraIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CameraIcon")['default']>
export const LazyCastIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CastIcon")['default']>
export const LazyCheckCircleIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CheckCircleIcon")['default']>
export const LazyCheckSquareIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CheckSquareIcon")['default']>
export const LazyCheckIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CheckIcon")['default']>
export const LazyChevronDownIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ChevronDownIcon")['default']>
export const LazyChevronLeftIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ChevronLeftIcon")['default']>
export const LazyChevronRightIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ChevronRightIcon")['default']>
export const LazyChevronUpIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ChevronUpIcon")['default']>
export const LazyChevronsDownIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ChevronsDownIcon")['default']>
export const LazyChevronsLeftIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ChevronsLeftIcon")['default']>
export const LazyChevronsRightIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ChevronsRightIcon")['default']>
export const LazyChevronsUpIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ChevronsUpIcon")['default']>
export const LazyChromeIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ChromeIcon")['default']>
export const LazyCircleIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CircleIcon")['default']>
export const LazyClipboardIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ClipboardIcon")['default']>
export const LazyClockIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ClockIcon")['default']>
export const LazyCloudDrizzleIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CloudDrizzleIcon")['default']>
export const LazyCloudLightningIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CloudLightningIcon")['default']>
export const LazyCloudOffIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CloudOffIcon")['default']>
export const LazyCloudRainIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CloudRainIcon")['default']>
export const LazyCloudSnowIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CloudSnowIcon")['default']>
export const LazyCloudIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CloudIcon")['default']>
export const LazyCodeIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CodeIcon")['default']>
export const LazyCodepenIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CodepenIcon")['default']>
export const LazyCodesandboxIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CodesandboxIcon")['default']>
export const LazyCoffeeIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CoffeeIcon")['default']>
export const LazyColumnsIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ColumnsIcon")['default']>
export const LazyCommandIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CommandIcon")['default']>
export const LazyCompassIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CompassIcon")['default']>
export const LazyCopyIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CopyIcon")['default']>
export const LazyCornerDownLeftIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CornerDownLeftIcon")['default']>
export const LazyCornerDownRightIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CornerDownRightIcon")['default']>
export const LazyCornerLeftDownIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CornerLeftDownIcon")['default']>
export const LazyCornerLeftUpIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CornerLeftUpIcon")['default']>
export const LazyCornerRightDownIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CornerRightDownIcon")['default']>
export const LazyCornerRightUpIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CornerRightUpIcon")['default']>
export const LazyCornerUpLeftIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CornerUpLeftIcon")['default']>
export const LazyCornerUpRightIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CornerUpRightIcon")['default']>
export const LazyCpuIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CpuIcon")['default']>
export const LazyCreditCardIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CreditCardIcon")['default']>
export const LazyCropIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CropIcon")['default']>
export const LazyCrosshairIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/CrosshairIcon")['default']>
export const LazyDatabaseIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/DatabaseIcon")['default']>
export const LazyDeleteIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/DeleteIcon")['default']>
export const LazyDiscIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/DiscIcon")['default']>
export const LazyDivideCircleIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/DivideCircleIcon")['default']>
export const LazyDivideSquareIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/DivideSquareIcon")['default']>
export const LazyDivideIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/DivideIcon")['default']>
export const LazyDollarSignIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/DollarSignIcon")['default']>
export const LazyDownloadCloudIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/DownloadCloudIcon")['default']>
export const LazyDownloadIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/DownloadIcon")['default']>
export const LazyDribbbleIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/DribbbleIcon")['default']>
export const LazyDropletIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/DropletIcon")['default']>
export const LazyEdit2Icon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/Edit2Icon")['default']>
export const LazyEdit3Icon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/Edit3Icon")['default']>
export const LazyEditIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/EditIcon")['default']>
export const LazyExternalLinkIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ExternalLinkIcon")['default']>
export const LazyEyeOffIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/EyeOffIcon")['default']>
export const LazyEyeIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/EyeIcon")['default']>
export const LazyFacebookIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/FacebookIcon")['default']>
export const LazyFastForwardIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/FastForwardIcon")['default']>
export const LazyFeatherIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/FeatherIcon")['default']>
export const LazyFigmaIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/FigmaIcon")['default']>
export const LazyFileMinusIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/FileMinusIcon")['default']>
export const LazyFilePlusIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/FilePlusIcon")['default']>
export const LazyFileTextIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/FileTextIcon")['default']>
export const LazyFileIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/FileIcon")['default']>
export const LazyFilmIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/FilmIcon")['default']>
export const LazyFilterIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/FilterIcon")['default']>
export const LazyFlagIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/FlagIcon")['default']>
export const LazyFolderMinusIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/FolderMinusIcon")['default']>
export const LazyFolderPlusIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/FolderPlusIcon")['default']>
export const LazyFolderIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/FolderIcon")['default']>
export const LazyFramerIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/FramerIcon")['default']>
export const LazyFrownIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/FrownIcon")['default']>
export const LazyGiftIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/GiftIcon")['default']>
export const LazyGitBranchIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/GitBranchIcon")['default']>
export const LazyGitCommitIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/GitCommitIcon")['default']>
export const LazyGitMergeIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/GitMergeIcon")['default']>
export const LazyGitPullRequestIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/GitPullRequestIcon")['default']>
export const LazyGithubIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/GithubIcon")['default']>
export const LazyGitlabIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/GitlabIcon")['default']>
export const LazyGlobeIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/GlobeIcon")['default']>
export const LazyGridIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/GridIcon")['default']>
export const LazyHardDriveIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/HardDriveIcon")['default']>
export const LazyHashIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/HashIcon")['default']>
export const LazyHeadphonesIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/HeadphonesIcon")['default']>
export const LazyHeartIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/HeartIcon")['default']>
export const LazyHelpCircleIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/HelpCircleIcon")['default']>
export const LazyHexagonIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/HexagonIcon")['default']>
export const LazyHomeIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/HomeIcon")['default']>
export const LazyImageIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ImageIcon")['default']>
export const LazyInboxIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/InboxIcon")['default']>
export const LazyInfoIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/InfoIcon")['default']>
export const LazyInstagramIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/InstagramIcon")['default']>
export const LazyItalicIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ItalicIcon")['default']>
export const LazyKeyIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/KeyIcon")['default']>
export const LazyLayersIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/LayersIcon")['default']>
export const LazyLayoutIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/LayoutIcon")['default']>
export const LazyLifeBuoyIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/LifeBuoyIcon")['default']>
export const LazyLink2Icon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/Link2Icon")['default']>
export const LazyLinkIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/LinkIcon")['default']>
export const LazyLinkedinIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/LinkedinIcon")['default']>
export const LazyListIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ListIcon")['default']>
export const LazyLoaderIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/LoaderIcon")['default']>
export const LazyLockIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/LockIcon")['default']>
export const LazyLogInIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/LogInIcon")['default']>
export const LazyLogOutIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/LogOutIcon")['default']>
export const LazyMailIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/MailIcon")['default']>
export const LazyMapPinIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/MapPinIcon")['default']>
export const LazyMapIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/MapIcon")['default']>
export const LazyMaximize2Icon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/Maximize2Icon")['default']>
export const LazyMaximizeIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/MaximizeIcon")['default']>
export const LazyMehIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/MehIcon")['default']>
export const LazyMenuIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/MenuIcon")['default']>
export const LazyMessageCircleIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/MessageCircleIcon")['default']>
export const LazyMessageSquareIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/MessageSquareIcon")['default']>
export const LazyMicOffIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/MicOffIcon")['default']>
export const LazyMicIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/MicIcon")['default']>
export const LazyMinimize2Icon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/Minimize2Icon")['default']>
export const LazyMinimizeIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/MinimizeIcon")['default']>
export const LazyMinusCircleIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/MinusCircleIcon")['default']>
export const LazyMinusSquareIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/MinusSquareIcon")['default']>
export const LazyMinusIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/MinusIcon")['default']>
export const LazyMonitorIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/MonitorIcon")['default']>
export const LazyMoonIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/MoonIcon")['default']>
export const LazyMoreHorizontalIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/MoreHorizontalIcon")['default']>
export const LazyMoreVerticalIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/MoreVerticalIcon")['default']>
export const LazyMousePointerIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/MousePointerIcon")['default']>
export const LazyMoveIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/MoveIcon")['default']>
export const LazyMusicIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/MusicIcon")['default']>
export const LazyNavigation2Icon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/Navigation2Icon")['default']>
export const LazyNavigationIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/NavigationIcon")['default']>
export const LazyOctagonIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/OctagonIcon")['default']>
export const LazyPackageIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/PackageIcon")['default']>
export const LazyPaperclipIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/PaperclipIcon")['default']>
export const LazyPauseCircleIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/PauseCircleIcon")['default']>
export const LazyPauseIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/PauseIcon")['default']>
export const LazyPenToolIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/PenToolIcon")['default']>
export const LazyPercentIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/PercentIcon")['default']>
export const LazyPhoneCallIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/PhoneCallIcon")['default']>
export const LazyPhoneForwardedIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/PhoneForwardedIcon")['default']>
export const LazyPhoneIncomingIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/PhoneIncomingIcon")['default']>
export const LazyPhoneMissedIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/PhoneMissedIcon")['default']>
export const LazyPhoneOffIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/PhoneOffIcon")['default']>
export const LazyPhoneOutgoingIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/PhoneOutgoingIcon")['default']>
export const LazyPhoneIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/PhoneIcon")['default']>
export const LazyPieChartIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/PieChartIcon")['default']>
export const LazyPlayCircleIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/PlayCircleIcon")['default']>
export const LazyPlayIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/PlayIcon")['default']>
export const LazyPlusCircleIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/PlusCircleIcon")['default']>
export const LazyPlusSquareIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/PlusSquareIcon")['default']>
export const LazyPlusIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/PlusIcon")['default']>
export const LazyPocketIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/PocketIcon")['default']>
export const LazyPowerIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/PowerIcon")['default']>
export const LazyPrinterIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/PrinterIcon")['default']>
export const LazyRadioIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/RadioIcon")['default']>
export const LazyRefreshCcwIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/RefreshCcwIcon")['default']>
export const LazyRefreshCwIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/RefreshCwIcon")['default']>
export const LazyRepeatIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/RepeatIcon")['default']>
export const LazyRewindIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/RewindIcon")['default']>
export const LazyRotateCcwIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/RotateCcwIcon")['default']>
export const LazyRotateCwIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/RotateCwIcon")['default']>
export const LazyRssIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/RssIcon")['default']>
export const LazySaveIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/SaveIcon")['default']>
export const LazyScissorsIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ScissorsIcon")['default']>
export const LazySearchIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/SearchIcon")['default']>
export const LazySendIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/SendIcon")['default']>
export const LazyServerIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ServerIcon")['default']>
export const LazySettingsIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/SettingsIcon")['default']>
export const LazyShare2Icon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/Share2Icon")['default']>
export const LazyShareIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ShareIcon")['default']>
export const LazyShieldOffIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ShieldOffIcon")['default']>
export const LazyShieldIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ShieldIcon")['default']>
export const LazyShoppingBagIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ShoppingBagIcon")['default']>
export const LazyShoppingCartIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ShoppingCartIcon")['default']>
export const LazyShuffleIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ShuffleIcon")['default']>
export const LazySidebarIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/SidebarIcon")['default']>
export const LazySkipBackIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/SkipBackIcon")['default']>
export const LazySkipForwardIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/SkipForwardIcon")['default']>
export const LazySlackIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/SlackIcon")['default']>
export const LazySlashIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/SlashIcon")['default']>
export const LazySlidersIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/SlidersIcon")['default']>
export const LazySmartphoneIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/SmartphoneIcon")['default']>
export const LazySmileIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/SmileIcon")['default']>
export const LazySpeakerIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/SpeakerIcon")['default']>
export const LazySquareIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/SquareIcon")['default']>
export const LazyStarIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/StarIcon")['default']>
export const LazyStopCircleIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/StopCircleIcon")['default']>
export const LazySunIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/SunIcon")['default']>
export const LazySunriseIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/SunriseIcon")['default']>
export const LazySunsetIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/SunsetIcon")['default']>
export const LazyTableIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/TableIcon")['default']>
export const LazyTabletIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/TabletIcon")['default']>
export const LazyTagIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/TagIcon")['default']>
export const LazyTargetIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/TargetIcon")['default']>
export const LazyTerminalIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/TerminalIcon")['default']>
export const LazyThermometerIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ThermometerIcon")['default']>
export const LazyThumbsDownIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ThumbsDownIcon")['default']>
export const LazyThumbsUpIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ThumbsUpIcon")['default']>
export const LazyToggleLeftIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ToggleLeftIcon")['default']>
export const LazyToggleRightIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ToggleRightIcon")['default']>
export const LazyToolIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ToolIcon")['default']>
export const LazyTrash2Icon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/Trash2Icon")['default']>
export const LazyTrashIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/TrashIcon")['default']>
export const LazyTrelloIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/TrelloIcon")['default']>
export const LazyTrendingDownIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/TrendingDownIcon")['default']>
export const LazyTrendingUpIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/TrendingUpIcon")['default']>
export const LazyTriangleIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/TriangleIcon")['default']>
export const LazyTruckIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/TruckIcon")['default']>
export const LazyTvIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/TvIcon")['default']>
export const LazyTwitchIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/TwitchIcon")['default']>
export const LazyTwitterIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/TwitterIcon")['default']>
export const LazyTypeIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/TypeIcon")['default']>
export const LazyUmbrellaIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/UmbrellaIcon")['default']>
export const LazyUnderlineIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/UnderlineIcon")['default']>
export const LazyUnlockIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/UnlockIcon")['default']>
export const LazyUploadCloudIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/UploadCloudIcon")['default']>
export const LazyUploadIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/UploadIcon")['default']>
export const LazyUserCheckIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/UserCheckIcon")['default']>
export const LazyUserMinusIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/UserMinusIcon")['default']>
export const LazyUserPlusIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/UserPlusIcon")['default']>
export const LazyUserXIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/UserXIcon")['default']>
export const LazyUserIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/UserIcon")['default']>
export const LazyUsersIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/UsersIcon")['default']>
export const LazyVideoOffIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/VideoOffIcon")['default']>
export const LazyVideoIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/VideoIcon")['default']>
export const LazyVoicemailIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/VoicemailIcon")['default']>
export const LazyVolume1Icon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/Volume1Icon")['default']>
export const LazyVolume2Icon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/Volume2Icon")['default']>
export const LazyVolumeXIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/VolumeXIcon")['default']>
export const LazyVolumeIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/VolumeIcon")['default']>
export const LazyWatchIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/WatchIcon")['default']>
export const LazyWifiOffIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/WifiOffIcon")['default']>
export const LazyWifiIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/WifiIcon")['default']>
export const LazyWindIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/WindIcon")['default']>
export const LazyXCircleIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/XCircleIcon")['default']>
export const LazyXOctagonIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/XOctagonIcon")['default']>
export const LazyXSquareIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/XSquareIcon")['default']>
export const LazyXIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/XIcon")['default']>
export const LazyYoutubeIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/YoutubeIcon")['default']>
export const LazyZapOffIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ZapOffIcon")['default']>
export const LazyZapIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ZapIcon")['default']>
export const LazyZoomInIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ZoomInIcon")['default']>
export const LazyZoomOutIcon: LazyComponent<typeof import("../node_modules/nuxt-feather-icons/dist/runtime/components/ZoomOutIcon")['default']>
export const LazyNuxtPage: LazyComponent<typeof import("../node_modules/nuxt/dist/pages/runtime/page")['default']>
export const LazyNoScript: LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['NoScript']>
export const LazyLink: LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Link']>
export const LazyBase: LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Base']>
export const LazyTitle: LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Title']>
export const LazyMeta: LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Meta']>
export const LazyStyle: LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Style']>
export const LazyHead: LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Head']>
export const LazyHtml: LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Html']>
export const LazyBody: LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Body']>
export const LazyNuxtIsland: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-island")['default']>
export const LazyNuxtRouteAnnouncer: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/server-placeholder")['default']>

export const componentNames: string[]
