declare module "@vueup/vue-quill" {
  import { DefineComponent } from "vue";

  export const QuillEditor: DefineComponent<{}, {}, any>;
}
