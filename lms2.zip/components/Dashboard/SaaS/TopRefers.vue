<template>
  <div class="card bg-white border-0 rounded-3 mb-4">
    <div class="card-body p-4">
      <div
        class="mb-3 mb-lg-30 d-flex flex-wrap gap-2 justify-content-between align-items-center"
      >
        <h3 class="mb-0">Top Refers</h3>
        <a href="#" class="text-body text-decoration-none">
          <span>Browse All</span>
          <i class="ri-arrow-right-s-line"></i>
        </a>
      </div>
      <ul class="ps-0 mb-0 list-unstyled">
        <li class="mb-3 pb-3 border-bottom">
          <div class="d-flex align-items-center justify-content-between">
            <div class="flex-shrink-0">
              <div class="d-flex">
                <img
                  src="@/assets/images/facebook.svg"
                  style="width: 31px"
                  alt="facebook"
                />
                <div class="ms-3">
                  <h4 class="mb-0 fs-14 fw-semibold lh-1">Facebook</h4>
                  <span class="fs-12">Community</span>
                </div>
              </div>
            </div>
            <div class="flex-grow-1 ms-3">
              <div class="d-flex align-items-center justify-content-end">
                <div class="progress-responsive" style="width: 120px">
                  <div
                    class="progress rounded-pill"
                    style="height: 8px; background-color: #dde4ff"
                    role="progressbar"
                    aria-label="Example with label"
                    aria-valuenow="50"
                    aria-valuemin="0"
                    aria-valuemax="100"
                  >
                    <div
                      class="progress-bar rounded-pill"
                      style="width: 50%; height: 8px; background-color: #757dff"
                    ></div>
                  </div>
                </div>
                <span class="count text-body ms-3 fs-12">50%</span>
              </div>
            </div>
          </div>
        </li>
        <li class="mb-3 pb-3 border-bottom">
          <div class="d-flex align-items-center justify-content-between">
            <div class="flex-shrink-0">
              <div class="d-flex">
                <img
                  src="@/assets/images/dribbble.svg"
                  style="width: 31px"
                  alt="dribbble"
                />
                <div class="ms-3">
                  <h4 class="mb-0 fs-14 fw-semibold lh-1">Dribbble</h4>
                  <span class="fs-12">Community</span>
                </div>
              </div>
            </div>
            <div class="flex-grow-1 ms-3">
              <div class="d-flex align-items-center justify-content-end">
                <div class="progress-responsive" style="width: 120px">
                  <div
                    class="progress rounded-pill"
                    style="height: 8px; background-color: #daebff"
                    role="progressbar"
                    aria-label="Example with label"
                    aria-valuenow="75"
                    aria-valuemin="0"
                    aria-valuemax="100"
                  >
                    <div
                      class="progress-bar rounded-pill"
                      style="width: 75%; height: 8px; background-color: #5da8ff"
                    ></div>
                  </div>
                </div>
                <span class="count text-body ms-3 fs-12">75%</span>
              </div>
            </div>
          </div>
        </li>
        <li class="mb-3 pb-3 border-bottom">
          <div class="d-flex align-items-center justify-content-between">
            <div class="flex-shrink-0">
              <div class="d-flex">
                <img
                  src="@/assets/images/instagram.svg"
                  style="width: 31px"
                  alt="instagram"
                />
                <div class="ms-3">
                  <h4 class="mb-0 fs-14 fw-semibold lh-1">Instagram</h4>
                  <span class="fs-12">Reel</span>
                </div>
              </div>
            </div>
            <div class="flex-grow-1 ms-3">
              <div class="d-flex align-items-center justify-content-end">
                <div class="progress-responsive" style="width: 120px">
                  <div
                    class="progress rounded-pill"
                    style="height: 8px; background-color: #ffe8d4"
                    role="progressbar"
                    aria-label="Example with label"
                    aria-valuenow="30"
                    aria-valuemin="0"
                    aria-valuemax="100"
                  >
                    <div
                      class="progress-bar rounded-pill"
                      style="width: 30%; height: 8px; background-color: #fe7a36"
                    ></div>
                  </div>
                </div>
                <span class="count text-body ms-3 fs-12">30%</span>
              </div>
            </div>
          </div>
        </li>
        <li class="mb-3 pb-3 border-bottom">
          <div class="d-flex align-items-center justify-content-between">
            <div class="flex-shrink-0">
              <div class="d-flex">
                <img
                  src="@/assets/images/behance.svg"
                  style="width: 31px"
                  alt="behance"
                />
                <div class="ms-3">
                  <h4 class="mb-0 fs-14 fw-semibold lh-1">Behance</h4>
                  <span class="fs-12">Community</span>
                </div>
              </div>
            </div>
            <div class="flex-grow-1 ms-3">
              <div class="d-flex align-items-center justify-content-end">
                <div class="progress-responsive" style="width: 120px">
                  <div
                    class="progress rounded-pill"
                    style="height: 8px; background-color: #f3e8ff"
                    role="progressbar"
                    aria-label="Example with label"
                    aria-valuenow="80"
                    aria-valuemin="0"
                    aria-valuemax="100"
                  >
                    <div
                      class="progress-bar rounded-pill"
                      style="width: 80%; height: 8px; background-color: #bf85fb"
                    ></div>
                  </div>
                </div>
                <span class="count text-body ms-3 fs-12">80%</span>
              </div>
            </div>
          </div>
        </li>
        <li class="mb-3 pb-3 border-bottom">
          <div class="d-flex align-items-center justify-content-between">
            <div class="flex-shrink-0">
              <div class="d-flex">
                <img
                  src="@/assets/images/figma.svg"
                  style="width: 31px"
                  alt="figma"
                />
                <div class="ms-3">
                  <h4 class="mb-0 fs-14 fw-semibold lh-1">Figma</h4>
                  <span class="fs-12">Community</span>
                </div>
              </div>
            </div>
            <div class="flex-grow-1 ms-3">
              <div class="d-flex align-items-center justify-content-end">
                <div class="progress-responsive" style="width: 120px">
                  <div
                    class="progress rounded-pill"
                    style="height: 8px; background-color: #daebff"
                    role="progressbar"
                    aria-label="Example with label"
                    aria-valuenow="50"
                    aria-valuemin="0"
                    aria-valuemax="100"
                  >
                    <div
                      class="progress-bar rounded-pill"
                      style="width: 50%; height: 8px; background-color: #5da8ff"
                    ></div>
                  </div>
                </div>
                <span class="count text-body ms-3 fs-12">50%</span>
              </div>
            </div>
          </div>
        </li>
        <li>
          <div class="d-flex align-items-center justify-content-between">
            <div class="flex-shrink-0">
              <div class="d-flex">
                <img
                  src="@/assets/images/google2.svg"
                  style="width: 31px"
                  alt="google"
                />
                <div class="ms-3">
                  <h4 class="mb-0 fs-14 fw-semibold lh-1">Google</h4>
                  <span class="fs-12">SEO & PPC</span>
                </div>
              </div>
            </div>
            <div class="flex-grow-1 ms-3">
              <div class="d-flex align-items-center justify-content-end">
                <div class="progress-responsive" style="width: 120px">
                  <div
                    class="progress rounded-pill"
                    style="height: 8px; background-color: #d8ffc8"
                    role="progressbar"
                    aria-label="Example with label"
                    aria-valuenow="20"
                    aria-valuemin="0"
                    aria-valuemax="100"
                  >
                    <div
                      class="progress-bar rounded-pill"
                      style="width: 20%; height: 8px; background-color: #58f229"
                    ></div>
                  </div>
                </div>
                <span class="count text-body ms-3 fs-12">20%</span>
              </div>
            </div>
          </div>
        </li>
      </ul>
    </div>
  </div>
</template>

<script lang="ts">
import { defineComponent } from "vue";

export default defineComponent({
  name: "TopRefers",
});
</script>
