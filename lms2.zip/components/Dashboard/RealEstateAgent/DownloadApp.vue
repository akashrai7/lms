<template>
  <div
    class="rounded-3 p-25 manage-app-for-dark"
    style="background-color: #b2ff97"
  >
    <div class="mx-auto py-sm-4 my-1" style="max-width: 210px">
      <h2 class="fs-24 text-secondary mb-20">
        Manage Your Dashboard From Your Mobile
      </h2>
      <a href="#" class="app-btn"> Download App </a>
      <div class="text-center">
        <img src="@/assets/images/saas.png" alt="saas" />
      </div>
    </div>
  </div>
</template>

<script lang="ts">
import { defineComponent } from "vue";

export default defineComponent({
  name: "DownloadApp",
});
</script>
